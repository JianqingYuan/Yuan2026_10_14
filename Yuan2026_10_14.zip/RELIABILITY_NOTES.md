# Reliability controller revision / 可靠性控制流程修订

The reliability revision changes how new fits are retried, selected and reported.
The separate 2026-10-16 saved-data revision applies the reviewed four S301 pairs
and 77 extreme ER corrections to `data/paper/`. The DE/TRF algorithms are retained;
the later, explicit ER metric boundary repair is recorded in
`vendor/ER_ENDPOINT_PATCH.md` with before/after hashes.
Default `MODE = "paper"`, `WORKERS = 1` redraws the partially corrected figures
without new fitting. A redraw is not evidence that every archived fit has
passed this new controller.

可靠性修改针对新拟合的有限补算、结果选择和状态呈现。另一次已复核的数据同步
将四对S301和77个极端ER修正纳入 `data/paper/`；DE/TRF算法保留。
ER精确端点补丁及原哈希见 `vendor/ER_ENDPOINT_PATCH.md`。
默认只重画局部修正后的论文图，不代表所有旧拟合已通过新版验收。

## What is preserved

S301 keeps two independent DE sources per attempt, its original three-level
residual checks, conditional closure and boundary
review. Only noiseless ER self-recovery uses the near-zero residual gate.
Noisy and cross-model fits use the nonzero-residual checks. The legacy pipeline
keeps its original bounded adaptive completion and integration checks.
Observations, weights, fitting bounds and scientific acceptance thresholds do
not change between attempts. Injected truth is not introduced as an optimizer
seed. A new attempt does not create a new observation or independent noise draw.

S301每轮的双DE来源、三精度残差检查、条件closure及边界检查保留；
仅无噪声ER自恢复采用近零残差门槛。legacy保留原有有限自适应补算及积分检查。
追加轮不改变观测、权重、边界或科学阈值，不把注入真值偷偷当作优化起点，
也不增加独立观测或噪声样本数。

For nonzero-residual, non-legacy S301 only, source agreement uses
`max(original scale, 1e-4)`; the original verdict is saved separately. Precision,
known-lower-point, boundary and completion checks are not relaxed. Baseline demo
retains the original one-level paired integration recovery when needed; both
models move to the same tighter objective and old optimizer success is not inherited.

仅非零残差、非legacy的S301来源一致性采用`max(原尺度, 1e-4)`，原判定另存；
精度、已知更低点、边界及完成要求不放宽。baseline demo在需要时保留原有的一层
成对积分精度恢复，两模型采用同一更严目标，不能继承旧优化成功标签。

## What is new

An outer controller allows at most `RELIABILITY_MAX_ATTEMPTS = 3` attempts by
default. `RELIABILITY_BUDGET_MULTIPLIER = 2.0` gives budget factors 1, 2 and 4.
Additional attempts use distinct reproducible seeds and retain previous
attempts, costs and statuses. The original S301 campaign did not automatically
retry failed science: its four-pair follow-up was manually authorized. This
revision adds a finite automatic policy; it is not an exact historical replay.

The base shared wall allowance is 300 seconds for demo and five days for full
recomputation. It covers an S301 model or a coupled legacy ER/RN pair. Exhausting
all three allowances gives 2,100 seconds or 35 days per work unit, not a campaign
ETA. Short demo budgets can still fail. No full campaign is claimed to have
been rerun merely by preparing or testing this revision.
Fixed-point validation is limited to 60, 120 and 240 seconds per model in
the default three rounds, always within the same total shared wall allowance.
Validation timeouts remain unaccepted; the cap does not certify long orbits.

新版外层默认最多三轮、预算倍数1/2/4，追加轮使用不同的可复现种子，原轮结果、
成本与标签均保留。历史S301失败后并无自动科学重试；四对补算是人工授权的复核。
本次有限自动化是新政策。默认demo基础300秒、正式重算基础5天，均由一个S301模型
或legacy模型对共享；三轮累计上限为2,100秒或35天，不是整套实验预计时长。
准备和短测试这个版本不等于已经重跑正式实验。
默认三轮的定点复核上限分别为每模型60、120、240秒，并计入同一累计墙钟预算。
复核超时仍标为未通过，不把短测试推广为所有长轨道均已验证。

## Reading the results

### Conditional completion within an attempt

S301 can continue its own DE lineages in six dimensions and, where indicated,
on the exact upper-charge face. Extreme ER can test that face and an adaptive
thin interior with nuisance parameters free. The existing numerical engines,
fit domain and scientific precision gates remain unchanged; these
branches share the attempt's deadline and never add independent-source votes.
The original ordinary legacy route is not replaced by the boundary helper.
An actual lowest point need not be a successful solver endpoint; that flag is
not rewritten. A separate newly computed two-source endpoint-support certificate
is required, rather than copying the native fit's old certificate.

All actual evaluated minima and failed checks remain auditable. A complete
same-lineage continuation may explicitly close an earlier iteration limit,
but cannot erase a hard failure, exhausted final validation budget, or an
unresolved lower point. Earlier statuses and cumulative costs stay recorded.
An unresolved point at a different integration precision is not silently
ranked against a new score. The controller conservatively retains the evidence
gap across retries; additional budget alone cannot manufacture its disposition.

S301可按需执行自身DE来源的六维续算及精确上界五维分支；极端ER还检查自适应
薄内层，干扰参数仍可调整。原普通legacy路线不被边界补救替换。
各分支共享本轮截止时间，不改物理范围或原精度/来源门槛，不增加独立来源票。
同来源完整续算可明确闭合早先的迭代上限，但不能抹掉硬错误、最终复核预算耗尽
或更低点未处置的问题。不同精度未核验点不混排，跨轮证据缺口仍保留。

`run_complete` describes whether the bounded controller finished. Read
`scientific_checks_passed` separately. After all allowed attempts, a numerically
validated lowest candidate remains available even if reliability did not pass;
`NEEDS_REVIEW_BEST_FOUND` is not acceptance. Lower candidates without numerical
validation remain in diagnostics and must not replace the validated plotted
value. Preserve finite zero and signed ER/RN differences.

`reliability_report.json` contains each case's status, best value, attempt
provenance and diagnostic reference. Summary plots distinguish checked results
from best-found points needing review. Complete new statistical grids retain
all numerically validated best-found points and carry an explicit notice when
any model is unaccepted. Missing numerical endpoints stay missing; the historical
archive never fills them. `plot_data/reliability.json` carries those notices for
later redraws. Keep full task and attempt directories, not just the image cache.
Collection requires matching declared retry policies across run plans, saved
inputs and controller evidence. An undeclared historical policy is not assumed
to equal the current defaults and cannot be silently mixed with a declared one.

`run_complete`只表示有限控制流程结束，须另看`scientific_checks_passed`。
数值合格的最低候选即使可靠性未通过，也保留并明确标记；未经数值检验的更低点
仅用于诊断，不替换正式图点。逐案例报告包含状态、来源和数值；新统计图不删掉
数值合格但需要复核的问题样本。缺少数值结果时保持缺失，禁止用旧图数据补齐。
应保留完整任务及轮次目录，而不只保存图片或精简缓存。
汇总时还核对运行计划、任务输入和控制器记录中的重试政策是否一致；
未声明旧政策的运行不能假定等同于新版默认值，也不能与明确声明的新运行混合。

Multiple searches agreeing, stable residuals across precision levels, and an
optimizer reporting success provide different forms of finite evidence. None
proves a global minimum. Three rounds cannot guarantee it either. A feasible
candidate supplies an upper bound on the unknown minimum objective, not a lower
bound. Changing only RN while holding an archived ER value fixed does not give
the difference of two newly minimized objectives or its bound. Model-selection
significance requires its own statistical justification.

多来源一致、跨精度稳定及优化器成功停止是不同证据，均不能证明全局最小值，
三轮也不保证全局最优。合法候选给未知最小目标值提供上界，而非下界。
只降低RN、固定旧ER所得差值并非两模型重新最小化后的差值或其界。
显著性结论仍需要独立的统计依据。

## Scientific audit scope

Olivier's exact ER endpoint/horizon floating-point defect has now been repaired
and independently tested; this is an explicit numerical-source patch, not a
claim that all historical fits are scientifically accepted. The saved figure
caches include only the declared four-pair/77-case correction. Their compact S301/extreme formats
do not contain the old best-fit parameter vectors or full residual evidence;
this does not assert that those records are absent from all original archives.
The later targeted campaign supplied finite dispositions for four S301 pairs
and the 77 identified extreme ER cases. Its endpoint evidence is separate from
tests of this integrated implementation. See `AUDIT_STATUS.md`; neither result
certifies every old manuscript value or all numerical/statistical conclusions.

Olivier指出的ER精确端点/视界浮点问题现已修复并独立检验。这是明确记录的数值源补丁，
不是所有历史拟合不受影响或已通过科学验收的声明。
论文缓存仅纳入已声明的四对及77例修正；其中S301/extreme的精简格式不包含旧最优参数及完整
残差证据，但不能据此断言原始档案中都没有这些记录。补上有限重试机制不代表
全部历史拟合已经验收。之后的针对性实验已处理四对S301和77个已知极端ER反例，
详见`AUDIT_STATUS.md`；该实验与本版程序测试分列，不泛化为所有论文统计已重验。
