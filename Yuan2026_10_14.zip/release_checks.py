"""Read-only integrity check for the files supplied in a paper release."""
import hashlib
import json
from pathlib import Path


def verify_release(root):
    root = Path(root).resolve()
    manifest = root / "RELEASE_MANIFEST.json"
    if not manifest.is_file():
        raise FileNotFoundError("RELEASE_MANIFEST.json is missing; this is an unsealed development tree.")
    record = json.loads(manifest.read_text(encoding="utf-8"))
    errors = []
    for name, expected in record["files"].items():
        target = (root / name).resolve()
        if root not in target.parents:
            raise ValueError("Release manifest contains an unsafe relative path.")
        actual = hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
        if actual != expected:
            errors.append(name)
    if errors:
        raise ValueError("Release content changed or missing: " + ", ".join(errors[:12]))
    return record
