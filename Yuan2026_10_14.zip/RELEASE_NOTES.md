# Paper-synchronized release — 2026.10.16

Synchronizes the two saved-data files for revised manuscript Figures 12/13:
four S301 pairs and 77 extreme ER cells only. All other paper values, observations,
fitting code and numerical thresholds are retained. The original audit attachment
is unchanged. The default redraw notice and citation now describe the current
paper; no new fit or full-campaign recertification is implied. See VALIDATION.json.

## Scoped code/evidence release — 2026.10.16 (earlier stage)

This revision retains the existing physical models and adds only the reviewed
calling-layer reliability and evidence handling described below. Baseline demo
precision recovery now shares its finite budget between ER and RN, reserving
verification time before optional additional local work. No new user setting
or continued-computation interface is introduced.

Validation distinguishes code behavior from scientific convergence. The actual
paired baseline recovery completed and passed the original precision checks;
its RN result remains source-unresolved. Numerically checked S301 examples may
be displayed with explicit review labels, including legal injected-point vetoes
and lower incomplete diagnostics. Such differences are not model-discrimination
evidence. The multi-run plotting check does not constitute a fresh 42-fit campaign.
See `VALIDATION.json` for exact tested identities, evidence and remaining limits.

At that earlier stage, `paper` still redrew unchanged historical caches. The
four-pair/77-case evidence was supplied separately. The data sync above now
applies those corrections, but does not recertify all manuscript data, prove global minima, or promise
that every finite-budget demo panel will contain a successful fit.

## Previous development candidate — 2026.10.16 (historical status)

Connects bounded S301 fixed-evidence completion to the public calling path.
The T071_ER/T091_RN physical evidence and 55-call ordered raw replay passed;
this is not a fresh full-campaign or full-demo certificate. The source-only
agreement policy is documented in RELIABILITY_NOTES.md. Baseline demo restores
the original optional paired precision recovery; the extreme route is unchanged.
An identical S301 endpoint/raw/objective alias is synchronized after successful
outer reproduction, preventing a one-ULP duplicate-score false veto; distinct
lower candidates are not given a new tolerance. Saved-data controller replay
passes, while full original-data demo validation remains pending. No final VALIDATION.json
or release manifest has yet been issued for this candidate. Historical paper
data remain unchanged and are not recertified by these changes.

## Previous development integration — 2026.10.15-targeted1

Adds finite, conditional local completion to the existing two workflows. S301
keeps its original DE lineages and full-dimensional/conditional-boundary checks.
The extreme ER adapter checks the exact charge face and an adaptive thin
interior; it does not fix all high-charge fits to one face or one offset.
Budgets remain shared and finite. Failed and unverified actual candidates stay
visible, including across retry attempts; a higher consensus cannot hide them.
Earlier iteration limits may be closed only by explicit, complete own-lineage
continuation and the final checks, without rewriting the earlier status.

No numerical-engine, observation, configuration or default historical cache
change is made in this integration. The earlier recorded ER endpoint patch is
retained. Tests of this implementation and the separate targeted scientific
campaign are distinguished in VALIDATION.json and AUDIT_STATUS.md. This is not
a universal successor or a promise that the demo will certify every minimum.

## Previous revision: 2026.10.14-audit2

Replicated the external fit counterexamples without replacing historical data.
Fixed the exact ER horizon endpoint and rejected zero-area normalization, with
explicit source patches and hashes. Added self-contained S301 endpoint metadata,
fixed two conservative acceptance/diagnostic gaps, and added independent tests.
Paper redraws now warn about outstanding historical fit findings.
See AUDIT_STATUS.md for issues resolved versus scientific work still pending.

## Previous revision: 2026.10.14-reliability1

New demo/recompute runs use bounded independent attempts (default budget
factors 1, 2, 4), unchanged native scientific gates, fixed-point residual
verification and an applicable injected-parameter baseline. Validated minima
are retained with explicit unresolved labels when acceptance fails. All
attempts remain auditable; cancellation and infrastructure failures are not
silently retried. Default settings now match the documented paper redraw.

This is a separate package, not a replacement of historical fitted data.
The frozen numerical engines, observations and paper caches are unchanged.
At that earlier revision the exact ER horizon endpoint issue was still open;
it was repaired in audit2 above. See RELIABILITY_NOTES.md
for scientific limits and VALIDATION.json for the tests actually performed.

## Previous release: 2026.10.14-dual6

One entry point provides saved-result redraws (`paper`), a small live fit
(`demo`), and new full-budget experiments (`recompute`). See the README for
configuration and expected outputs. No mode submits jobs to a remote service.

## Panel-covering demonstration (dual6)

Only the demo catalogue and its plots change: 21 data sets / 42 model fits
cover all statistical figure panels, with the existing per-fit demo budgets.
The 13 numbered demo figures redraw bundled geometry for 1-5 and use only
new finite-budget endpoints for 6-13. Small grids and individual noisy points
are not Monte Carlo confidence intervals or convergence claims. Missing
endpoints stay missing, and no historical fit result fills a demo panel.
The existing summary and time-series plots are retained. English and Chinese
usage instructions describe the selection, costs and figure sources.

The numerical engines, data, configurations, user settings, paper redraws
and full recompute selection are unchanged. This plotting/source revision
changes run fingerprints: resume or collect old runs with their originating
release. No new long-fitting campaign is required to test this plotting change.

The sections below record earlier revisions.

## Documentation and independent re-audit

The English README follows the author's revised Chinese structure and usage
steps. Model-fit counts are explicitly distinguished from work-unit counts.
The Chinese source and current user settings are preserved.

Figure 13 now rejects inconsistent external caches before plotting: it requires
the complete 48-pair grid, the declared 30-microarcsecond noise, finite valid
chi-squared values, and a matching signed difference. Original data, signed/zero
results and figure appearance are unchanged. Final full-run figure reporting
also includes geometry figures 1–5 saved earlier in the run.

The portable local-refinement adapter explicitly cleans up its owned workers
even when a final checkpoint write fails. This is exception cleanup, not a
change to numerical methods, seeds, budgets or stopping criteria. All vendored
numerical sources, observations and experiment configurations remain unchanged.
Use the originating release to resume or collect an existing run.

## Manual work-unit ranges

`TASK_RANGE` / `--task-range FIRST LAST` selects inclusive, one-based work units
only in `recompute`. With the default per-suite workflow, all experiments contain
7,884 units (15,660 model fits): an indivisible ER/RN pair in legacy, and one model
fit in S301. Users assign non-overlapping ranges to their allocated nodes; this
package has no scheduler or cross-node coordination. Inputs, seeds, bounds,
budgets and numerical engines are unchanged by slicing.

Each run records its exact task identities. Collection checks these identities,
retains legacy pairs, rejects conflicting duplicates, and never fills missing
results from the historical paper snapshot. Ranged runs skip geometric figures
1–5; a complete plot-eligible full-design collection computes them once. The
science fingerprint now also covers plotting code. Existing runs must be resumed
or collected using their originating release.

## Repairs retained from dual3

This revision fixes an ER-only `base_frame` option being passed to RN for the
S301 datasets. Model constructors are checked before child processes start;
each child must then report readiness. Initialization failure, timeout or
cancellation cleans up the owned pool instead of repeatedly respawning it.
Hard numerical-stage failures are no longer reported as ordinary demo
iteration limits, including when a later source exhausts its budget.

The six bundled S301 noiseless ER cases now use the original, fixed
`threshold_D` as their reference-reproduction ceiling on another machine,
rather than requiring that machine's reference norm to match the historical
platform norm. Historical and measured norms, their differences and the old
match-test results are retained in `reference_compatibility.json`. This is an
explicit portability-check policy change; it does not change the original
fit-acceptance gate, precision checks, optimization seeds or candidate starts.
A reference exceeding the original fixed ceiling is still rejected.

The README clarifies actual settings and demo outcomes. Regression tests now
cover real ER/RN catalogue inputs, spawn failures and cleanup, reference
compatibility, and hard-failure reporting. The frozen numerical sources,
observations, truth parameters, fitting bounds and seeds remain unchanged.

## Scientific scope

One launcher now selects two genuinely different workflows. The default
FIT_PIPELINE='paper' uses the archived paired 0.6.3 legacy workflow for the
baseline/extreme experiments, and the existing portable S301 workflow for
Section 6. The old numerical sources are added byte-for-byte; the previously
vendored S301 numerical sources, observations, fitting bounds and saved paper
results are unchanged. The adapter restores the old five-source and paired
cross-model stages rather than renaming the two-source S301 implementation.

Saved paper results remain a historical snapshot. New fits record requested
workflow, resolved workflow and version. No universal speed or accuracy ranking
between workflows is claimed. A forced cross-suite workflow is a new experiment;
fixed seeds do not guarantee identical trajectories across environments and
stopping criteria. Use the originating release to resume an existing run.
Legacy jobs must contain complete ER/RN pairs and use one CPU per pair;
different datasets can run in parallel. Interrupted pairs are not silently
restarted or split into independent arms.

The full numerical campaign has not been completed as part of this release.
Packaging tests do not establish global optimality or speed for every orbit.
No visualization viewer, platform credentials, job submission or automatic
cleanup is included. This release does not alter remote or self-use experiments.
