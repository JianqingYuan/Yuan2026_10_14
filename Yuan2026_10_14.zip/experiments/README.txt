EXPERIMENT INPUTS

One public case API feeds two distinct fitting workflows. fit_pipeline='paper'
automatically uses legacy for baseline/extreme and s301 for S301. The legacy
entry fits ER/RN together, retaining cross-model stages; the S301 entry fits
one model at a time. Forcing either pipeline across suites is a NEW comparison,
not historical reproduction. No full campaign was run during this packaging.

Suite       True orbits   Noiseless pairs   Noisy pairs   Individual fits
baseline           80                80          6400             12960
extreme            16                16          1280              2592
s301                6                 6            48               108
total             102               102          7728             15660

Each pair uses the identical observed positions and uncertainties for ER/RN.
Baseline/extreme retain ten common noise levels and eight realizations per
orbit per level. The eight seeded normal vectors are shared across cases and
noise levels; these are not 7680 independently drawn noise vectors.
S301 retains only the six noiseless data sets and the eight 30-microarcsecond
realizations for each of six configurations. The former 207-microarcsecond
experiments, debugging cases and targeted repeat attempts are not extra data
sets in this catalogue.

Data and optimization are separate
----------------------------------
The frozen inputs retain truth parameters, fitting bounds, observation times,
uncertainties and noise seeds. Baseline/extreme saved truth arrays plus the
documented PCG64 noise generator reproduce the chosen historical checkpoint
observations exactly. S301 observed arrays are copied directly from its final
frozen experiment input files. No historical fitted parameters or optimizer
population appears in these input files.

Only erlim_eq27_p07 lacked a complete local historical observation array. Its
truth orbit was regenerated from the frozen truth parameters, epoch grid and
truth integration settings. This provenance is explicit in extreme.json;
historical byte equality is not claimed for that one orbit. A companion
forward integration with available historical arrays differed by at most
1.04e-12 in position, about 1.53e-7 of the smallest adopted noise sigma.

Numerical policies
------------------
The old baseline/extreme accuracy condition is an absolute change in chi2:
abs(chi2_tight - chi2_nominal) <= 0.01 at the same parameter vector. It is NOT a
pointwise residual limit or a norm threshold. The legacy workflow retains this
condition. Forced calls to the S301 workflow use a nonzero-residual diagnostic
policy, including noiseless cases; no invented zero-residual stop is added.
S301 preserves its separately frozen numerical vector ceilings. True
parameters, when supplied for numerical-reference checks, are never optimizer
starting points or candidates. No historical best-fit vectors are injected.
The legacy code may also derive seeds from the observed trajectory, as in its
archived implementation.

For the six bundled noiseless S301 ER cases, the portable adapter checks the
local truth-reference residual against the ORIGINAL fixed threshold_D. It
does not require equality to the platform's archived nominal/tight norms.
The old norms, local norms and historical match flags are retained in
reference_compatibility.json. This reference-only portability policy does not
relax the fitted-endpoint gate or precision ceilings, and never uses truth
parameters as optimizer seeds. Values above the original ceiling still fail.

The legacy workflow retains the original five initial DE sources and adaptive
stages, using each dataset's original root (RN offset +1000). Its original
physics and workflow source is retained under vendor/legacy; its manifest
records the final 0.6.3 baseline and extreme provenance and template hashes.
The S301 workflow uses two sources. When forced onto baseline/extreme, it uses
the first two child seeds of the original model root; S301 keeps its original
two seeds. When legacy is forced onto S301, the first saved ER source becomes
an explicitly new dataset root, and legacy's precision criterion is used.
Both workflows use the selected dataset's nominal/tight integration settings;
native baseline/extreme settings equal their archived templates. In particular,
forced legacy-on-S301 does not apply the old short-orbit max_step=4 to its much
longer time span. This is not an original S301 seed schedule. Result metadata identifies
the requested and resolved workflow and its version.

The catalogue retains full_unified_refit_has_not_been_run=true: completion of
a full cross-suite S301-workflow recomputation is not claimed by this release.
The case API records the actual selected seed/pipeline policy.
Fixed seeds do not ensure bitwise equality across environments. The reduced
demo profile tests execution only and does not reproduce full-budget fits.

API
---
from experiments.api import describe, iter_cases, count_cases, list_case_ids
describe(suite='all', mode='paper')       # cheap plan; no orbit computation
iter_cases(suite='s301', mode='paper')    # one dictionary per model fit
iter_cases(suite='baseline', indices=['q01_p00_noiseless_main'])

from experiments.generate import generate_observations, regenerate_truth
generate_observations('baseline','q01_p00_s00_r00') # no orbit integration
regenerate_truth('baseline',0) # explicitly integrate one configured ER truth

regenerate_truth calls the same public forward engine and returns the maximum
and L2 differences from the archived coordinates. It never overwrites inputs
and is never called implicitly by dry-run or by a fitting case selection.

Supported suites: all, baseline, extreme, s301. Supported modes: paper, demo.
Here API mode='paper' selects full-budget inputs for main.py --mode recompute;
main.py --mode paper instead redraws saved figures without fitting.
Indices are local catalogue DATA-SET indices, or original dataset_id strings;
ER/RN model selection is a separate models argument. include_noiseless and
include_noisy can restrict the selected data type.
The launcher requires both models of every selected legacy dataset and uses
one CPU for each pair, parallelising across datasets. Selecting only ER/RN or
cutting a pair with --max-tasks is rejected before launch. S301 supports single
model tasks. The API may still expose individual legacy cases for inspection;
execution requires engine.legacy.fit_pair(er_case, rn_case, output_dir).

Demo chooses only the first true orbit, its noiseless data, and its first noise
level/realization in each suite: six data sets and twelve model fits in total.
It does not change the selected physical parameters, bounds or 101 epochs.
The engine additionally reduces computational budgets in demo mode. Demo
images/results must be labelled as demonstrations, not published Monte Carlo
statistics. The smoke_case() helper has only two archived epochs and is solely
for inexpensive forward-engine testing; it is not part of either catalogue.
