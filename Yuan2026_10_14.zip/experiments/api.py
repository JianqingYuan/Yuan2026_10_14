"""One experiment catalogue for the two explicitly identified fitting workflows.

Reading the catalogue never integrates an orbit or launches an optimizer.
Published data arrays are independent of the number of fitting workers.
``xy_true`` is a legacy interface name for the OBSERVED fit target (noisy when
specified), not a vector of true parameters and never an optimizer start.
"""
from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SUITES = ('baseline', 'extreme', 's301')
PARAMETERS = ('M', 'q', 'rho0', 'drho_dt0', 'phi0', 'dphi_dt0')
PIPELINE_VERSIONS = {'legacy': 'legacy-paired-v1', 's301': 's301-portable-v1'}


def resolve_fit_pipeline(suite, requested='paper'):
    """Resolve a workflow without importing an optimizer or reading observations."""
    if suite not in SUITES:
        raise ValueError(f'Unknown suite: {suite!r}')
    if requested not in ('paper', 'legacy', 's301'):
        raise ValueError('fit_pipeline must be paper, legacy, or s301')
    return ('s301' if suite == 's301' else 'legacy') if requested == 'paper' else requested


@lru_cache(maxsize=3)
def _config(suite):
    if suite not in SUITES:
        raise ValueError(f'Unknown suite: {suite!r}')
    return json.loads((ROOT/'configs'/f'{suite}.json').read_text(encoding='utf-8'))


@lru_cache(maxsize=3)
def _arrays(suite):
    with np.load(ROOT/'data'/'observations'/f'{suite}.npz', allow_pickle=False) as archive:
        return {name: archive[name] for name in archive.files}


def _selection(suite='all', mode='paper', models=('ER','RN'), indices=None,
               include_noiseless=True, include_noisy=True):
    if mode not in ('paper','demo'):
        raise ValueError('mode must be paper or demo')
    suites = SUITES if suite == 'all' else (suite,)
    models = (models,) if isinstance(models,str) else tuple(models)
    if not models or len(set(models)) != len(models) or any(m not in ('ER','RN') for m in models):
        raise ValueError('models must be a nonempty unique subset of ER, RN')
    if indices is not None:
        indices = {indices} if isinstance(indices,(str,int)) else set(indices)
    for name in suites:
        config = _config(name)
        for index,dataset in enumerate(config['datasets']):
            if dataset['add_noise'] and not include_noisy:
                continue
            if not dataset['add_noise'] and not include_noiseless:
                continue
            if indices is not None and index not in indices and dataset['dataset_id'] not in indices:
                continue
            # Same physical inputs and full observation times; only the number
            # of designs/noise draws and the engine's budget are reduced.
            if mode == 'demo' and (dataset['truth_index'] != 0 or
                (dataset['add_noise'] and (dataset['noise_index'] != 0 or dataset['realization'] != 0))):
                continue
            for model in models:
                yield name,config,index,dataset,model


def _case_id(suite,dataset,model):
    return f"{suite}__{dataset['dataset_id']}__{model}"


def list_case_ids(suite='all',mode='paper',**kwargs):
    """List model-task IDs using only small JSON metadata, never observation I/O."""
    return [_case_id(s,d,m) for s,c,i,d,m in _selection(suite,mode,**kwargs)]


def count_cases(suite='all',mode='paper',**kwargs):
    """Return the number of individual model fits (two per paired data set)."""
    return sum(1 for _ in _selection(suite,mode,**kwargs))


def describe(suite='all',mode='paper',fit_pipeline='paper',**kwargs):
    """A cheap execution plan. This function performs no numerical experiment."""
    counts={}
    ids=set()
    for s,c,i,d,m in _selection(suite,mode,**kwargs):
        pipeline=resolve_fit_pipeline(s,fit_pipeline)
        entry=counts.setdefault(s,{'datasets':0,'noiseless_datasets':0,'noisy_datasets':0,'model_fits':0,
                                  'fit_pipeline':pipeline,'fit_pipeline_version':PIPELINE_VERSIONS[pipeline]})
        entry['model_fits']+=1
        key=(s,d['dataset_id'])
        if key not in ids:
            ids.add(key)
            entry['datasets']+=1
            entry['noisy_datasets' if d['add_noise'] else 'noiseless_datasets']+=1
    return {'mode':mode,'fit_pipeline_requested':fit_pipeline,'suites':counts,'datasets':len(ids),
        'model_fits':sum(v['model_fits'] for v in counts.values()),
        'computations_started':False,
        'note':'Demo is not a reproduction of the full Monte Carlo study.' if mode=='demo' else
               'Full design with explicit workflow provenance; no new fit has been started.'}


def _observations(suite,truth,dataset):
    arrays=_arrays(suite)
    array_index=dataset.get('array_index',dataset['truth_index'])
    times=arrays[f'times_{array_index:03d}'].copy()
    xy=arrays[f'xy_{array_index:03d}'].copy()
    if suite!='s301' and dataset['add_noise']:
        rng=np.random.default_rng(dataset['noise_seed'])
        sigma=np.full(len(times),dataset['sigma'])
        xy += np.column_stack((rng.normal(0.,sigma,len(times)),rng.normal(0.,sigma,len(times))))
    if xy.shape!=(len(times),2) or not np.all(np.isfinite(xy)):
        raise ValueError('Invalid saved observations')
    return times,xy


def _legacy_root_seed(dataset):
    # S301 has two explicit source seeds, not a historical five-DE root.
    # A forced legacy-on-S301 comparison uses its first ER source as a declared
    # new root; this is never presented as a historical S301 seed schedule.
    return int(dataset['optimizer_seed']) if 'optimizer_seed' in dataset else int(dataset['run_seeds']['ER'][0])


def _model_seeds(dataset,model,fit_pipeline='s301'):
    if fit_pipeline == 'legacy':
        root=_legacy_root_seed(dataset)+(1000 if model=='RN' else 0)
        return [int(child.generate_state(1,dtype=np.uint32)[0]) for child in np.random.SeedSequence(root).spawn(5)]
    if 'run_seeds' in dataset:
        return list(dataset['run_seeds'][model])
    root=int(dataset['optimizer_seed'])+(1000 if model=='RN' else 0)
    return [int(child.generate_state(1,dtype=np.uint32)[0]) for child in np.random.SeedSequence(root).spawn(2)]


def iter_cases(suite='all',mode='paper',models=('ER','RN'),indices=None,
               include_noiseless=True,include_noisy=True,fit_pipeline='paper'):
    """Yield one engine-ready dictionary per model and data set.

    ``indices`` accepts catalogue data-set indices or original data-set IDs;
    indices are local to each suite. Diagnostic truth is stored in metadata,
    separately from the fitting bounds/observations. No true or saved best-fit
    parameter vector is ever offered as a DE/TRF starting point.
    """
    for s,c,index,d,m in _selection(suite,mode,models,indices,include_noiseless,include_noisy):
        pipeline=resolve_fit_pipeline(s,fit_pipeline)
        truth=c['truths'][d['truth_index']]
        times,xy=_observations(s,truth,d)
        # Catalogue options describe the generating ER model. Its frame
        # selector is not an RN constructor argument; observations stay fixed.
        fit_options=deepcopy(c['theory_options'])
        if m=='RN' and c.get('nature')=='ER':
            fit_options.pop('base_frame',None)
        bounds=deepcopy(truth['bounds_by_theory'][m])
        metadata={'suite':s,'mode':mode,'dataset_id':d['dataset_id'],
            'dataset_index':index,'truth_id':truth['truth_id'],'truth_index':d['truth_index'],
            'group':d['truth_index']+1,'q':truth['q'],'rho_peri':truth['rho_peri'],
            'peri':truth['rho_peri'],'noise_index':d['noise_index'],'realization':d['realization'],
            'sigma':d['sigma'],'noise_seed':d['noise_seed'],'add_noise':d['add_noise'],
            'theta_true':list(truth['theta_true']),'truth':list(truth['theta_true']),
            'bounds':deepcopy(bounds),'parameter_order':list(PARAMETERS),
            'charge_tag':truth.get('charge_tag'),'charge_index':truth.get('charge_index'),
            'orbit':truth.get('orbit'),'noise_uas':d.get('noise_uas'),
            'observation_sha256':hashlib.sha256(np.ascontiguousarray(xy,dtype='<f8').tobytes()).hexdigest(),
            'truth_provenance':deepcopy(truth['provenance']),
            'fit_pipeline':pipeline,'fit_pipeline_requested':fit_pipeline,
            'fit_pipeline_version':PIPELINE_VERSIONS[pipeline]}
        case={'case_id':_case_id(s,d,m),'dataset_id':f"{s}__{d['dataset_id']}",
            'times':times.tolist(),'xy_true':xy.tolist(),'xy_observed':xy.tolist(),
            'data_semantics':'xy_true is the fixed observed fit target, not injected parameters.',
            'bounds':bounds,'nominal_integration':deepcopy(c['nominal_integration']),
            'tight_integration':deepcopy(c['tight_integration']),
            'fit_theory':m,'generating_theory':'ER','residual_sigma':d['sigma'],
            'fit_theory_options':deepcopy(fit_options),
            'theory_options':deepcopy(fit_options),
            'parameter_order':list(PARAMETERS),'run_seeds':_model_seeds(d,m,pipeline),
            'fit_pipeline':pipeline,'fit_pipeline_requested':fit_pipeline,
            'fit_pipeline_version':PIPELINE_VERSIONS[pipeline],
            'precision_criterion':deepcopy(c['precision_criterion']),
            'metadata':metadata,'execution_mode':mode}
        if pipeline=='legacy':
            case.update(legacy_optimizer_seed=_legacy_root_seed(d),
                        legacy_variant='baseline' if s=='baseline' else 'extreme')
            case['metadata']['legacy_seed_policy']=(
                'Historical dataset root; RN offset +1000; five initial child DE seeds plus frozen adaptive workflow.'
                if s!='s301' else
                'Forced cross-workflow comparison: first saved S301 ER source used as a new root, RN offset +1000; not historical S301 execution.')
            if s=='s301':
                case['metadata']['original_precision_criterion']=deepcopy(case['precision_criterion'])
                case['metadata']['cross_workflow_policy']=(
                    'New comparison: legacy optimizer with the selected dataset integration settings, '
                    'legacy absolute-delta-chi2 precision check and explicitly derived new seed root.')
                case['precision_criterion']={'kind':'absolute_delta_chi2','tolerance':.01,
                    'definition':'Legacy workflow nominal/tight fixed-point chi2 check; forced cross-workflow comparison.'}
        if s=='s301':
            case.update(threshold_D=truth['threshold_D'],
                precision_vector_ceiling=truth['precision_vector_ceiling'],
                reference_D=deepcopy(truth['reference_D']))
            if not d['add_noise'] and m=='ER':
                case['reference_theta']=list(truth['theta_true'])
            else:
                case['fit_mode']='nonzero_residual_diagnostic'
        else:
            # Historical accuracy checking compares chi-square values, not an
            # invented L2 zero-residual gate. This also applies when S301's
            # portable workflow is deliberately used for a new comparison.
            case['fit_mode']='nonzero_residual_diagnostic'
        yield case


def smoke_case():
    """Two real archived epochs for a cheap forward-engine smoke test only."""
    case=next(iter_cases('baseline','demo',models=('ER',),include_noisy=False))
    for key in ('times','xy_true','xy_observed'):
        case[key]=case[key][:2]
    case['case_id']='smoke__baseline_two_epochs__ER'
    case['metadata']['purpose']='forward smoke test, not a paper data set'
    return case
