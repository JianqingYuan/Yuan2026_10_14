"""Explicit data-generation helpers, separate from fitting and plotting.

Normal experiments use saved inputs through api.iter_cases. Calling
regenerate_truth deliberately integrates one orbit and never overwrites the
archived inputs. Floating-point identity across environments is not promised.
"""
from __future__ import annotations

from copy import deepcopy
import numpy as np
from .api import _config, _observations


def generate_observations(suite, dataset_id):
    """Return a fresh copy of one archived/mock data set; no orbit integration."""
    config=_config(suite)
    matches=[d for d in config['datasets'] if d['dataset_id']==dataset_id]
    if len(matches)!=1:
        raise ValueError(f'Unknown data set: {suite}/{dataset_id}')
    dataset=matches[0]
    truth=config['truths'][dataset['truth_index']]
    times,xy=_observations(suite,truth,dataset)
    return {'dataset_id':dataset_id,'times':times,'xy_observed':xy,
            'sigma':dataset['sigma'],'noise_seed':dataset['noise_seed'],
            'metadata':deepcopy(dataset)}


def regenerate_truth(suite, truth_index):
    """Integrate one exact configured truth with the shared forward engine.

    This explicit operation is not performed by count/describe/list_case_ids,
    iter_cases or generate_observations. It returns data rather than modifying
    the public archived arrays.
    """
    from engine import predict
    config=_config(suite)
    if isinstance(truth_index,bool) or not isinstance(truth_index,int) or not 0<=truth_index<len(config['truths']):
        raise ValueError('truth_index is outside the selected suite')
    truth=config['truths'][truth_index]
    noiseless=next(d for d in config['datasets'] if d['truth_index']==truth_index and not d['add_noise'])
    times,archived=_observations(suite,truth,noiseless)
    xy=predict(truth['theta_true'],times,theory='ER',
        integration=deepcopy(config['truth_integration']),
        theory_options=deepcopy(config['theory_options']))
    xy=np.asarray(xy,dtype=float)
    if xy.shape!=archived.shape or not np.all(np.isfinite(xy)):
        raise ValueError('The forward model returned an invalid truth orbit')
    return {'truth_id':truth['truth_id'],'times':times,'xy_truth':xy,
        'truth_integration':deepcopy(config['truth_integration']),
        'maximum_difference_from_archive':float(np.max(np.abs(xy-archived))),
        'l2_difference_from_archive':float(np.linalg.norm(xy-archived)),
        'archived_data_modified':False}
