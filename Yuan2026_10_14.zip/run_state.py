"""Small shared helpers for atomic records and read-only task validation."""
import hashlib
import json
from pathlib import Path


def json_default(value):
    if isinstance(value, Path):
        return value.as_posix()
    if hasattr(value, "tolist"):
        return value.tolist()
    raise TypeError(f"Cannot serialize {type(value).__name__}")


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, indent=2, ensure_ascii=False,
                                    allow_nan=False, default=json_default) + "\n",
                         encoding="utf-8")
    temporary.replace(path)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False,
                                     default=json_default).encode()).hexdigest()


PIPELINE_FIELDS = ("fit_pipeline", "fit_pipeline_requested", "fit_pipeline_version")


def pipeline_provenance(case):
    """The selected numerical flow is part of task identity, never a default on load."""
    values = {name: case.get(name) for name in PIPELINE_FIELDS}
    if values['fit_pipeline'] not in ('legacy', 's301'):
        raise ValueError('Task lacks a valid resolved fit pipeline.')
    if values['fit_pipeline_requested'] not in ('paper', 'legacy', 's301'):
        raise ValueError('Task lacks a valid requested fit pipeline.')
    if not isinstance(values['fit_pipeline_version'], str) or not values['fit_pipeline_version']:
        raise ValueError('Task lacks an explicit fit pipeline version.')
    return values


def pair_input_fingerprint(er_case, rn_case):
    """Identify the two coupled inputs, not a unique physical execution or rerun."""
    return digest({'ER': er_case, 'RN': rn_case})


def load_task(task_dir, expected_case=None, profile=None, require_complete=False):
    """Read a mutually consistent task triple; never repair or rewrite files.

    Execution completion is separate from numerical/scientific acceptance.
    An INCOMPLETE result is readable, but cannot be reused as a completed fit.
    """
    task_dir = Path(task_dir)
    if profile not in (None, "paper", "demo"):
        raise ValueError("Expected task profile must be paper or demo.")
    records = []
    for name in ("case.json", "result.json", "task_receipt.json"):
        record = json.loads((task_dir / name).read_text(encoding="utf-8"))
        if not isinstance(record, dict):
            raise ValueError(f"Task record is not an object: {task_dir / name}.")
        records.append(record)
    case, result, receipt = records
    provenance = pipeline_provenance(case)
    for record in (result, receipt):
        if any(record.get(name) != value for name, value in provenance.items()):
            raise ValueError('Task pipeline identities or versions disagree.')
    if provenance['fit_pipeline'] == 'legacy':
        pair_hash = result.get('pair_input_sha256')
        if (not isinstance(pair_hash, str) or len(pair_hash) != 64
                or any(c not in '0123456789abcdef' for c in pair_hash)
                or receipt.get('pair_input_sha256') != pair_hash):
            raise ValueError('Legacy pair input fingerprints are missing or disagree.')
    identity = case.get("case_id")
    allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-"
    if (not isinstance(identity, str) or not identity or identity in (".", "..")
            or task_dir.name != identity or any(c not in allowed for c in identity)):
        raise ValueError("Unsafe or inconsistent task identity.")
    if case.get("fit_theory") not in ("ER", "RN"):
        raise ValueError(f"Invalid fitted theory: {identity}.")
    if (receipt.get("case_id") != identity or result.get("case_id") != identity
            or result.get("fit_theory") != case["fit_theory"]):
        raise ValueError(f"Task record identities disagree: {identity}.")
    case_hash = digest(case)
    if receipt.get("case_sha256") != case_hash:
        raise ValueError(f"Saved input fingerprint mismatch: {identity}.")
    if expected_case is not None and digest(expected_case) != case_hash:
        raise ValueError(f"Task differs from the selected input: {identity}.")
    saved_profile = result.get("profile")
    if (saved_profile not in ("paper", "demo")
            or receipt.get("profile") != saved_profile
            or result.get("result_is_demo") is not (saved_profile == "demo")
            or (profile is not None and saved_profile != profile)):
        raise ValueError(f"Task profiles or demo flags disagree: {identity}.")
    if case.get("execution_mode", saved_profile) != saved_profile:
        raise ValueError(f"Input and result execution modes disagree: {identity}.")
    complete = result.get("run_complete")
    if type(complete) is not bool:
        raise ValueError(f"Task lacks an explicit completion flag: {identity}.")
    expected_state = "FINISHED" if complete else "INCOMPLETE"
    if receipt.get("state") != expected_state:
        raise ValueError(f"Task receipt disagrees with result completion: {identity}.")
    if "engine_status" in receipt and receipt["engine_status"] != result.get("status"):
        raise ValueError(f"Task receipt and engine status disagree: {identity}.")
    if require_complete and not complete:
        raise ValueError(f"Unfinished task is preserved, not restarted: {identity}.")
    return case, result, receipt
