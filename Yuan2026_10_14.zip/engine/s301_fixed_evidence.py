"""Private bounded completion of current-call S301 evidence, never optimization."""
from copy import deepcopy
import hashlib
import math
import time

import numpy as np

from . import s301_finalization


def _normalize_report(report):
    """Only bridge the native float64-array representation, after raw saving."""
    if not isinstance(report, dict) or not isinstance(report.get('samples'), list):
        raise ValueError('Malformed original boundary report')
    result = deepcopy(report)
    for sample in result['samples']:
        theta = sample.get('theta')
        if (type(theta) is not np.ndarray or theta.dtype != np.dtype('float64') or
                theta.shape != (6,) or not np.all(np.isfinite(theta))):
            raise ValueError('Original boundary theta must be finite float64[6]')
        sample['theta'] = theta.tolist()
    return result


def complete(api, root, config, case, bounds, directory, deadline, cancel_event,
             interrupt_requested, points, actual, invalid, ranking, boundaries,
             seeds, report):
    """Use remaining native time, with no new fit calls, source votes or knobs.

    The caller retains ALL optimizer stage dispositions and owns final acceptance.
    `report` is shared with its result, including on interruption or failure.
    Only raw observations made in this call can nominate new fixed audit points.
    """
    sources = tuple(str(s) for s in seeds)
    report.update(schema='public-s301-fixed-evidence-v1', status='SKIPPED',
        complete=False, optimizer_calls=0, new_independent_DE_sources=0,
        max_points=27, max_forward_calls=81, max_rounds=2,
        existing_deadline_unchanged=True, historical_answers_loaded=False,
        scientific_acceptance=False, raw_events=[], cache_reuse=[], coordinator={})
    if api._historical_criterion(case) or not api.nonzero_residual_mode(case):
        report['reason'] = 'Original legacy/noiseless route unchanged'
        return ranking, boundaries
    guard = api.targeted.lower_guard(points, actual)
    if (set(api._source_best(points)) != set(sources) or invalid):
        report['reason'] = 'Two valid original sources are required; invalid evidence is not repaired here'
        return ranking, boundaries
    if (guard['passed'] and ranking.get('passed') and set(boundaries) == set(sources)
            and all(not b['issues'] and not b['significant_fixed_nuisance_descent']
                    for b in boundaries.values())):
        report['reason'] = 'Current-call evidence already closed'
        return ranking, boundaries
    requests = deepcopy(guard['unresolved_lower_actual_candidates'])
    if not requests:
        report['reason'] = 'No missing current-call fixed-point evidence; not an optimizer retry'
        return ranking, boundaries
    for row in requests:
        if str(row.get('lineage_id')) not in sources:
            raise ValueError('Cannot transfer a lower actual observation across sources')
        s301_finalization._theta(row.get('theta'))
    output = directory/'fixed_evidence'
    output.mkdir()
    (output/'raw').mkdir()
    (output/'candidates').mkdir()
    report.update(status='RUNNING', fixed_requests=requests,
        original_seeds=list(seeds), shared_monotonic_deadline=config['portable_monotonic_deadline'],
        shared_epoch_deadline=deadline, reserved_forward_calls=0, observed_point_count=0,
        audited_candidate_count=0)
    save = lambda: api.write(output/'finalization.json', report)
    save()
    run = None
    cache, observed = {}, set()
    current_source = [str(requests[0]['lineage_id'])]
    context = dict(bounds=dict(lower=bounds.lower, upper=bounds.upper),
        expected_size=np.asarray(case['xy_true']).size, sigma=case['residual_sigma'],
        ceiling=case.get('precision_vector_ceiling', case['threshold_D']))
    try:
        seed = dict(theta=requests[0]['theta'], purpose='Fixed evaluation only; never optimization')
        seed_path = output/'request.json'
        api.write(seed_path, seed)
        run = api._NonzeroRun(root, config, dict(id='fixed_evidence', hybrid_phi=True, x_scale='jac'),
            seed, case, directory/'case.json', 'fixed_evidence', reference_theta=None,
            seed_source=seed_path, output_override=output/'physical', shared_deadline=deadline)
        run.cancel_event, run.interrupt_requested = cancel_event, interrupt_requested
        run.state.update(optimizer_invoked=False, new_independent_DE_sources=0,
            physical_engine_shared_across_original_lineages=True)
        physical_original = run.physical

        def physical(theta, accuracy, category='validation', role='fixed_theta'):
            run.guard()
            # Native audit/boundary inputs are numeric arrays or exact lists.
            array = np.asarray(theta)
            if (array.shape != (6,) or array.dtype != np.dtype('float64') or
                    not np.all(np.isfinite(array)) or np.any(array < bounds.lower) or
                    np.any(array > bounds.upper) or accuracy not in ('nominal', 'tight', 'third')
                    or category != 'validation' or current_source[0] not in sources):
                raise ValueError('Invalid fixed physical request or provenance')
            coordinates = array.tolist()
            source = current_source[0]
            point_key = (source, tuple(coordinates))
            key = (*point_key, accuracy)
            if key in cache:
                report['cache_reuse'].append(dict(lineage_id=source, theta=coordinates,
                    accuracy=accuracy, original_raw_file=cache[key]['file'], new_forward=False))
                save()
                run.guard()
                return np.asarray(cache[key]['raw'], dtype=float)
            if (point_key not in observed and len(observed) >= 27) or len(report['raw_events']) >= 81:
                raise api.Interrupted('fixed_evidence_shared_point_or_forward_cap_exhausted')
            observed.add(point_key)
            number = len(report['raw_events']) + 1
            raw_path = output/'raw'/f'{number:03d}.json'
            event = dict(sequence=number, lineage_id=source, theta=coordinates, accuracy=accuracy,
                role=role, category=category, status='RESERVED', raw_residuals=None,
                physical_invocation_attempted=False, native_dispatch='UNKNOWN',
                started_monotonic=time.monotonic(), case_sha256=run.state['case_sha256'],
                config_sha256=run.state['config_sha256'], manifest_sha256=run.state['manifest_sha256'],
                integration=run.state['integration'][accuracy], residual_sigma=case['residual_sigma'],
                effective_bounds=run.state['effective_bounds'], new_independent_DE_sources=0)
            report['raw_events'].append(event)
            report.update(reserved_forward_calls=number, observed_point_count=len(observed))
            api.write(raw_path, event)
            before = run.state.get('submitted_forward_calls', 0)
            try:
                run.guard()  # Writing evidence must not extend the dispatch allowance.
                event['physical_invocation_attempted'] = True
                vector = physical_original(coordinates, accuracy, category=category, role=role)
                raw = np.asarray(vector)
                event.update(raw_residuals=raw.tolist(), returned_monotonic=time.monotonic())
                api.write(raw_path, event)  # Keep even malformed returned vectors before checking.
                if raw.shape != (context['expected_size'],) or not np.all(np.isfinite(raw)):
                    invalid.append(dict(lineage_id=source, stage_id='fixed_evidence',
                        evaluation=number, reason='Malformed fixed physical residual'))
                    raise ValueError('Malformed fixed physical residual')
                score = float((raw / case['residual_sigma']) @ (raw / case['residual_sigma']))
                if not math.isfinite(score):
                    invalid.append(dict(lineage_id=source, stage_id='fixed_evidence',
                        evaluation=number, reason='Nonfinite fixed objective'))
                    raise ValueError('Nonfinite fixed objective')
                event.update(status='COMPLETE', chi2=score, native_dispatch='RETURNED')
                api.write(raw_path, event)
                relative = raw_path.relative_to(directory).as_posix()
                actual.append(dict(theta=coordinates, accuracy=accuracy, chi2=score,
                    lineage_id=source, raw_residuals=raw.tolist(), stage_id='fixed_evidence',
                    evaluation=number, raw_file=relative,
                    source_document_sha256=hashlib.sha256(raw_path.read_bytes()).hexdigest()))
                cache[key] = dict(raw=raw.tolist(), file=relative)
                run.guard()  # Late work stays saved, but cannot supply an acceptance.
                return vector
            except BaseException as exc:
                if event['status'] != 'COMPLETE':
                    submitted = run.state.get('submitted_forward_calls', before) - before
                    event.update(status='RAISED', exception_type=type(exc).__name__, error=str(exc),
                        native_dispatch='SUBMITTED_OUTCOME_UNKNOWN' if submitted else 'NEVER_DISPATCHED')
                    api.write(raw_path, event)
                raise
            finally:
                save()

        run.physical = physical

        def evaluate_point(source, theta, parent, reason):
            current_source[0] = source
            run.guard()
            raw, audit = run.audit_crossfit_point(theta, 'fixed_evidence_only')
            report['audited_candidate_count'] += 1
            identifier = f'fixed_evidence/{source}/{report["audited_candidate_count"]:03d}'
            point = dict(id=identifier, source=int(source), lineage_id=source, theta=list(theta),
                raw_residuals=raw, D=audit['D'], chi2=audit['chi2'], numerical_evidence_valid=False,
                comparison_key=case.get('case_id', 'case'), counts_as_independent_source=True,
                truth_seed_used=False, new_independent_DE_source=False,
                source_class='fixed_descendant_not_an_additional_DE_vote', optimizer_invoked=False,
                parent_candidate_id=parent, fixed_request_reason=reason)
            try:
                point.update(api.verify_vectors(raw, audit, **context))
            except ValueError as exc:
                point['check_reason'] = str(exc)
            api.write(output/'candidates'/(identifier.replace('/', '_')+'.json'), point)
            return point

        def boundary_check(source, point, round_index):
            current_source[0] = source
            run.guard()
            raw_path = output/f'boundary_{source}_{round_index+1}_raw.json'
            entry = dict(lineage_id=source, point_id=point['id'], point_theta=point['theta'],
                round=round_index+1, status='STARTED', report_generation_completed=False,
                case_sha256=run.state['case_sha256'], config_sha256=run.state['config_sha256'],
                manifest_sha256=run.state['manifest_sha256'], integration=run.state['integration'],
                residual_sigma=case['residual_sigma'], effective_bounds=run.state['effective_bounds'],
                boundary_policy=config['crossfit_review'])
            api.write(raw_path, entry)
            try:
                native = api.ClosureRun.all_boundary_diagnostics(run, api.feasible_z(point['theta'], bounds))
                entry.update(status='REPORT_RETURNED', report_generation_completed=True, report=native)
                api.write(raw_path, entry)
                normalized = _normalize_report(native)
                checked = api.boundary_review(normalized, point, context, config['crossfit_review'])
                return dict(lineage_id=source, point_theta=point['theta'], point_id=point['id'],
                    checked=checked, samples=normalized['samples'], round=round_index+1,
                    raw_report_file=raw_path.relative_to(directory).as_posix(),
                    raw_report_sha256=hashlib.sha256(raw_path.read_bytes()).hexdigest())
            except BaseException as exc:
                entry.update(status='RAISED', exception_type=type(exc).__name__, error=str(exc))
                api.write(raw_path, entry)
                raise

        run.start_pool()
        finished = s301_finalization.finalize(points, actual, seeds, fixed_requests=requests,
            evaluate_point=evaluate_point, boundary_check=boundary_check,
            rank=lambda rows: api._rank_candidates_for_case(case, rows), source_best=api._source_best,
            lower_guard=api.targeted.lower_guard, max_rounds=2, max_points=27)
        run.guard()
        report.update(status='EVIDENCE_RETURNED', complete=finished['complete'], coordinator=finished)
        # Missing exact-current-theta boundary evidence remains a veto, not all([]).
        final_boundaries = dict(finished['boundary_checks'])
        for source in sources:
            final_boundaries.setdefault(source, dict(issues=['Missing exact selected-theta boundary report'],
                significant_fixed_nuisance_descent=False))
        return finished['ranking'], final_boundaries
    except BaseException as exc:
        report.update(status='INCOMPLETE', complete=False, exception_type=type(exc).__name__, error=str(exc))
        raise
    finally:
        try:
            if run is not None and run.pool is not None:
                try:
                    run.pool.terminate()
                finally:
                    run.pool.join()
                run.pool = None
        finally:
            if run is not None:
                run.state.update(status='FIXED_EVIDENCE_ONLY', optimizer_invoked=False,
                    phase='finished', fixed_evidence_complete=report['complete'])
                run.save()
            save()
