"""Isolated fixed-point checks. No optimizer is imported or invoked here.

Legacy checks use the same archived runtime as their fit, not the S301 runtime.
The parent owns this process and bounds its wall time, including startup.
"""
import json
from pathlib import Path
import sys
import traceback


def evaluate(payload):
    root = Path(__file__).resolve().parents[1]
    if payload['pipeline'] == 'legacy':
        # This module is a standalone script: engine.__init__ has not imported
        # the S301 numerical modules into this interpreter.
        from _legacy_worker import bootstrap
        bootstrap(payload['legacy_variant'])
    else:
        sys.path.insert(0, str(root / 'vendor' / 'core'))
    import numpy as np
    from metric_library import build_theory
    from spherical_geodesics import CoordinateTimeSettings
    from spherical_geodesics.astrometry import TheoryForwardModel

    observed = np.asarray(payload['observed'], dtype=float)
    times = np.asarray(payload['times'], dtype=float)
    sigma = payload['sigma']
    evidence = {}
    for label, theta in payload['vectors'].items():
        levels = {}
        for name, settings in payload['integrations'].items():
            model = TheoryForwardModel(payload['theory'], build_theory,
                settings=CoordinateTimeSettings(**settings),
                theory_options=payload['theory_options'])
            prediction = model.predict(np.asarray(theta, dtype=float), times)
            raw = (np.column_stack((prediction.x, prediction.y)) - observed).ravel()
            weighted = raw / sigma
            if raw.size != observed.size or not np.all(np.isfinite(raw)):
                raise ValueError('Nonfinite or incomplete fixed-point prediction')
            score = float(weighted @ weighted)
            if not np.isfinite(score):
                raise ValueError('Nonfinite fixed-point chi2')
            levels[name] = dict(chi2=score, residuals=raw.tolist(), settings=settings)
        evidence[label] = dict(theta=theta, levels=levels)
    return evidence


if __name__ == '__main__':
    payload_path, output_path = map(Path, sys.argv[1:3])
    try:
        result = dict(ok=True, evidence=evaluate(json.loads(payload_path.read_text(encoding='utf-8'))))
    except Exception as exc:
        result = dict(ok=False, error=type(exc).__name__ + ': ' + str(exc), traceback=traceback.format_exc())
    output_path.write_text(json.dumps(result, allow_nan=False), encoding='utf-8')
    raise SystemExit(0 if result['ok'] else 1)
