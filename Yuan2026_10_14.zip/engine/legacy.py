"""Isolated adapter for the archived, paired 0.6.3 DE/TRF workflow."""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / 'vendor' / 'legacy'
VERSION = 'legacy-paired-v1'


def _write(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    os.replace(temporary, path)


def verify_legacy_vendor():
    manifest = json.loads((VENDOR / 'MANIFEST.json').read_text(encoding='utf-8'))
    for name, expected in manifest['files'].items():
        path = (VENDOR / name).resolve()
        if VENDOR.resolve() not in path.parents or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError('Archived legacy source checksum mismatch: ' + name)
    return manifest


def _payload(er_case, rn_case, profile):
    if profile not in ('paper', 'demo'):
        raise ValueError('profile must be paper or demo')
    if er_case.get('fit_theory') != 'ER' or rn_case.get('fit_theory') != 'RN':
        raise ValueError('Legacy fitting requires the ordered ER/RN pair')
    for case in (er_case, rn_case):
        if case.get('fit_pipeline', 'legacy') != 'legacy' or case.get('fit_pipeline_version', VERSION) != VERSION:
            raise ValueError('Legacy case pipeline/version does not match this adapter')
        if 'xy_true' in case and 'xy_observed' in case and not np.array_equal(
                np.asarray(case['xy_true'], dtype=float), np.asarray(case['xy_observed'], dtype=float)):
            raise ValueError('Legacy xy_true and xy_observed must describe exactly the same observations')
    if er_case.get('fit_pipeline_requested', 'legacy') != rn_case.get('fit_pipeline_requested', 'legacy'):
        raise ValueError('Legacy pair differs in requested pipeline')
    for key in ('dataset_id', 'times', 'residual_sigma', 'legacy_optimizer_seed'):
        if key not in er_case or er_case[key] != rn_case.get(key):
            raise ValueError('Legacy pair differs in ' + key)
    for key in ('nominal_integration', 'tight_integration'):
        if er_case.get(key) != rn_case.get(key):
            raise ValueError('Legacy pair differs in ' + key)
    observed = er_case.get('xy_observed', er_case.get('xy_true'))
    if observed != rn_case.get('xy_observed', rn_case.get('xy_true')):
        raise ValueError('Legacy pair must share exactly the same observations')
    seed = er_case['legacy_optimizer_seed']
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError('legacy_optimizer_seed must be an explicit uint32 dataset root')
    variant = er_case.get('legacy_variant', er_case.get('metadata', {}).get('suite'))
    if variant not in ('baseline', 'extreme') or variant != rn_case.get('legacy_variant', rn_case.get('metadata', {}).get('suite')):
        raise ValueError('legacy_variant must match: baseline or extreme')
    noisy = bool(er_case.get('metadata', {}).get('add_noise', False))
    if noisy != bool(rn_case.get('metadata', {}).get('add_noise', False)):
        raise ValueError('Legacy pair differs in noise classification')
    return dict(version=VERSION, variant=variant, profile=profile,
        template=variant + ('_noisy' if noisy else '_noiseless'),
        cases={'ER': deepcopy(er_case), 'RN': deepcopy(rn_case)},
        optimizer_seed=seed, xy_observed=deepcopy(observed))


def _base_result(case, profile, workers):
    return dict(schema=VERSION, fit_pipeline='legacy', fit_pipeline_version=VERSION,
        fit_pipeline_requested=case.get('fit_pipeline_requested', case.get('fit_pipeline', 'legacy')),
        case_id=case['case_id'], dataset_id=case['dataset_id'], fit_theory=case['fit_theory'],
        profile=profile, result_is_demo=profile == 'demo', workers=workers,
        run_complete=False, scientific_checks_passed=False, best_candidate_checks_passed=False, status='RUNNING',
        input_metadata=deepcopy(case.get('metadata', {})), sigma=case['residual_sigma'],
        optimizer_truth_seed_used=False, historical_run_reproduced=False,
        legacy_optimizer_seed=case['legacy_optimizer_seed'], no_global_optimum_certificate=True)


def _stop_owned_process(process):
    """The immutable workflow is single-process; no pool or descendants exist."""
    if process.poll() is not None:
        return
    if os.name == 'nt':
        process.kill()  # Popen's retained handle identifies exactly our child.
    else:
        try:
            os.killpg(process.pid, signal.SIGKILL)  # start_new_session below owns this group.
        except ProcessLookupError:
            pass
    process.wait(timeout=10)


def fit_pair(er_case, rn_case, output_dir, workers=1, profile='paper', cancel_event=None,
             budget_factor=1.0, absolute_deadline=None):
    """Fit both models once, preserving original cross-theory rescue stages.

    Only datasets are parallelized. Each original DE archive requires one CPU.
    Cancellation terminates this owned isolated process and retains its last
    atomic checkpoint; an unfinished primary solver call has no checkpoint.
    The optional internal deadline is absolute time.monotonic(), shared by both
    models and never extended by preparation or by the relative case budget.
    """
    started = time.monotonic()
    if type(workers) is not int or workers != 1:
        raise ValueError('Legacy pairs require workers=1; parallelize datasets instead')
    try:
        valid_factor = not isinstance(budget_factor, bool) and isinstance(budget_factor, (int, float)) and math.isfinite(budget_factor) and budget_factor >= 1
    except (OverflowError, ValueError):
        valid_factor = False
    if not valid_factor:
        raise ValueError('budget_factor must be finite and at least 1')
    if absolute_deadline is not None and (isinstance(absolute_deadline, bool)
            or not isinstance(absolute_deadline, (int, float)) or not math.isfinite(absolute_deadline)):
        raise ValueError('absolute_deadline must be a finite time.monotonic value')
    seconds = er_case.get('wall_seconds_per_pair', 300 if profile == 'demo' else 5 * 24 * 3600)
    if isinstance(seconds, bool) or not isinstance(seconds, (int, float)) or not math.isfinite(seconds) or seconds <= 0:
        raise ValueError('wall_seconds_per_pair must be finite and positive')
    if rn_case.get('wall_seconds_per_pair', seconds) != seconds:
        raise ValueError('Legacy pair must share the same wall limit')
    seconds *= budget_factor
    if not math.isfinite(seconds):
        raise ValueError('scaled wall_seconds_per_pair must be finite')
    deadline = min(started + seconds, absolute_deadline) if absolute_deadline is not None else started + seconds
    payload = _payload(er_case, rn_case, profile)
    payload['budget_factor'] = float(budget_factor)
    verify_legacy_vendor()
    if cancel_event is not None and cancel_event.is_set():
        raise KeyboardInterrupt('Calculation cancelled before starting legacy pair')
    directory = Path(output_dir).resolve()
    directory.mkdir(parents=True, exist_ok=False)
    # The extra candidate branch shares this exact owned-child wall ceiling.
    # It cannot request a retry or extend the complete paired attempt.
    payload['pair_deadline_monotonic'] = deadline
    payload_path = directory / 'input.json'
    _write(payload_path, payload)
    results = {name: _base_result(case, profile, workers) for name, case in payload['cases'].items()}
    for name, result in results.items():
        (directory / name).mkdir()
        _write(directory / name / 'result.json', result)
    process = None
    interrupted = False
    status, reason = 'FAILED', None
    try:
        environment = os.environ.copy()
        for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'BLIS_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
            environment[key] = '1'
        environment.update(MPLBACKEND='Agg', PYTHONDONTWRITEBYTECODE='1')
        with (directory / 'worker.log').open('w', encoding='utf-8') as log:
            if time.monotonic() >= deadline:
                status, reason = 'BUDGET_OR_INTERRUPTION', 'Shared legacy pair wall budget exhausted during preparation; worker not started'
            else:
                process = subprocess.Popen([sys.executable, '-E', '-B', str(ROOT / 'engine' / '_legacy_worker.py'),
                    str(payload_path), str(directory)], stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                    env=environment, cwd=directory, start_new_session=os.name != 'nt',
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
                while process.poll() is None:
                    if cancel_event is not None and cancel_event.is_set():
                        raise KeyboardInterrupt('Legacy pair cancelled')
                    if time.monotonic() >= deadline:
                        status, reason = 'BUDGET_OR_INTERRUPTION', 'Shared legacy pair wall budget exhausted'
                        _stop_owned_process(process)
                        break
                    time.sleep(min(.05, max(0.0, deadline - time.monotonic())))
                else:
                    status = 'COMPLETED' if process.returncode == 0 else 'FAILED'
                    reason = None if process.returncode == 0 else 'Legacy worker exited with code ' + str(process.returncode)
    except KeyboardInterrupt:
        interrupted = True
        status, reason = 'INTERRUPTED', 'User interruption; last completed stage checkpoint preserved'
        if cancel_event is not None:
            cancel_event.set()
    except Exception as exc:
        reason = type(exc).__name__ + ': ' + str(exc)
    finally:
        if process is not None:
            _stop_owned_process(process)
        pair_file = directory / 'pair_result.json'
        if status == 'COMPLETED' and not pair_file.exists():
            status, reason = 'FAILED', 'Legacy worker exited without a completed pair result'
        if pair_file.exists():
            saved = json.loads(pair_file.read_text(encoding='utf-8'))
            for name, value in saved.get('results', {}).items():
                results[name].update(value)
        checkpoint = directory / 'checkpoint.json'
        if checkpoint.exists():
            saved = json.loads(checkpoint.read_text(encoding='utf-8'))
            for name, record in saved.get('models', {}).items():
                if 'theta' not in results[name]:
                    results[name].update(theta=record['best_theta'], chi2=record['chi2_min'],
                        legacy_record=record, partial_checkpoint_only=True)
        if cancel_event is not None and cancel_event.is_set():
            interrupted, status = True, 'INTERRUPTED'
            reason = 'User interruption; partial results preserved'
        if status == 'COMPLETED' and time.monotonic() >= deadline:
            status, reason = 'BUDGET_OR_INTERRUPTION', 'Shared legacy pair wall budget exhausted before completed result was checked'
        for name, result in results.items():
            if status != 'COMPLETED' or not pair_file.exists():
                result.update(status=status, run_complete=False, scientific_checks_passed=False,
                    best_candidate_checks_passed=False, stop_reason=reason)
            result.update(elapsed_seconds=time.monotonic() - started,
                finished_utc=datetime.now(timezone.utc).isoformat(),
                pair_checkpoint='checkpoint.json', wall_seconds_per_pair=seconds,
                pair_started_monotonic=started, pair_deadline_monotonic=deadline,
                deadline_includes_preparation=True,
                portable_budget_factor=budget_factor)
            _write(directory / name / 'result.json', result)
    if interrupted:
        raise KeyboardInterrupt('Calculation cancelled; legacy checkpoint preserved')
    return results
