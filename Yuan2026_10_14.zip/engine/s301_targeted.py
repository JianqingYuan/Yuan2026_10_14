"""Finite own-lineage S301 completion and fail-closed actual-point accounting.

No catalogue IDs, archived answers, truth seeds, new DE runs or altered physical
bounds. Vector-precision and lower-point gates are unchanged; the separately
recorded source-agreement floor is a caller policy, not a numerical error bound.
The caller owns the one shared deadline.
"""
import copy
import math
import time
import traceback

import numpy as np
from scipy.optimize import least_squares

from hybrid_support import (Interrupted, feasible_z, solver_options, utc, write,
                            parallel_difference_jacobian)
from jacobian import phase_column
from candidate_policy import rank_candidates as _original_rank_candidates

LEVELS = ('nominal', 'tight', 'third')
COMPLETE = 'S301_TARGETED_COMPLETE_REQUIRES_REVIEW'
BUDGET = 'S301_TARGETED_BUDGET_REQUIRES_REVIEW'
ITERATION_STATES = {'LOCAL_NFEV_BUDGET_EXHAUSTED',
    'CROSS_FIT_LOCAL_BUDGET_EXHAUSTED_DIAGNOSTICS_RETAINED',
    'CLOSURE_NFEV_BUDGET_EXHAUSTED_REQUIRES_REVIEW'}
COMPLETE_STATES = {'RECOVERY_VALIDATED', 'DUAL_GATE_PASSED_THIRD_REVIEW',
    'CROSS_FIT_DIAGNOSTIC_COMPLETE_REQUIRES_REVIEW',
    'CLOSURE_DIAGNOSTIC_COMPLETE_REQUIRES_REVIEW', COMPLETE}
SOURCE_AGREEMENT_CHI2_FLOOR = 1e-4


def rank_source_candidates(candidates, *, minimum_independent_sources=2):
    """Apply one fixed source-agreement floor after the original rank checks.

    All original lineages are compared with the global retained best, including
    an auxiliary best. Original discrepancy comparisons remain untouched. The
    new report's passed/status describe the caller policy; original_passed and
    original_status retain the unchanged ranker's verdict, not a rewritten audit.
    This changes neither raw-vector validation nor any lower-point, boundary, stage
    completion or production-acceptance gate; callers still own those checks.
    """
    ranking = _original_rank_candidates(candidates,
        minimum_independent_sources=minimum_independent_sources)
    ranking['original_passed'] = ranking['passed']
    ranking['original_status'] = ranking['status']
    ranking['source_agreement_policy'] = dict(
        id='s301-source-agreement-absolute-floor-v1',
        absolute_chi2_floor=SOURCE_AGREEMENT_CHI2_FLOOR,
        allowance='max(original_two_point_discrepancy_scale, absolute_chi2_floor)',
        scope='source_agreement_only',
        all_original_source_bests_required=True,
        is_optimizer_error_bound=False, is_global_optimum_certificate=False)
    agreements = {}
    for lineage, original in ranking.get('comparisons', {}).items():
        effective = max(original['two_point_discrepancy_scale'], SOURCE_AGREEMENT_CHI2_FLOOR)
        agreements[lineage] = dict(
            delta_chi2=original['delta_chi2'],
            original_two_point_discrepancy_scale=original['two_point_discrepancy_scale'],
            effective_source_agreement_allowance=effective,
            original_consistent_with_discrepancy_scale=original['consistent_with_discrepancy_scale'],
            source_agreement_passed=abs(original['delta_chi2']) <= effective)
    ranking['source_agreement_comparisons'] = agreements
    if candidates:
        passed = (ranking['independent_sources'] >= minimum_independent_sources
            and all(row['source_agreement_passed'] for row in agreements.values()))
        ranking['passed'] = passed
        ranking['status'] = ('REPEATABILITY_SUPPORTED_NOT_FROZEN' if passed
            else 'NEEDS_TARGETED_REVIEW')
    return ranking


def iteration_limited(stage):
    return (stage['status'] in ITERATION_STATES or
        (stage['status'] == BUDGET and (stage.get('solver') or {}).get('status') == 0))


def completion_disposition(stages, final_checks_passed):
    """A later complete own-lineage continuation can close an iteration limit.

    Old states are never mutated. This cannot forgive hard failures, missing
    evidence, wall/forward guards, a later incomplete solve, or failed final
    numerical/source/boundary/lower-candidate checks.
    """
    disposition = dict(targeted_completion_closed=False, superseded_iteration_stages=[])
    if not final_checks_passed or not stages:
        return disposition
    pending = [(i, stage) for i, stage in enumerate(stages) if stage['status'] not in COMPLETE_STATES]
    if not pending:
        return disposition
    for index, stage in pending:
        if not iteration_limited(stage) or not stage.get('lineage_id'):
            return disposition
        replacements = [later for later in stages[index+1:] if later['status'] == COMPLETE
            and later.get('lineage_id') == stage['lineage_id']]
        if not replacements:
            return disposition
        disposition['superseded_iteration_stages'].append(dict(id=stage['id'],
            original_status=stage['status'], lineage_id=stage['lineage_id'],
            replacement_id=replacements[-1]['id'], original_stage_relabelled=False,
            basis='Later own-lineage continuation plus complete final candidate/source/precision/boundary checks'))
    disposition['targeted_completion_closed'] = True
    return disposition


def finite_policy(config, profile):
    """Scheduling limits, never scientific tolerances or extra case time."""
    return dict(max_stages_per_lineage=2, modes=['full6d', 'qmax5d'],
        max_nfev=min(config['max_nfev_per_solve'], 8 if profile == 'demo' else 1000),
        max_stage_seconds=min(config['wall_seconds_per_arm'], 15 if profile == 'demo' else 1800),
        optimization_fraction=.75, max_audited_actual_points=6,
        new_independent_DE_sources=0, automatic_retries=0)


def retain_actual(state, event, sigma, expected_size):
    """Retain a raw minimum per precision; every compact event is also logged.

    Short preflight trajectories are a different objective and are excluded.
    Failed forwards cannot supply a finite candidate; their event remains in
    the log. No successful actual point is rejected by solver success/status.
    """
    if event.get('category') == 'preflight' or event.get('status') != 'COMPLETE':
        return
    level = event.get('accuracy')
    if level not in LEVELS or event.get('residual') is None:
        return
    raw = np.asarray(event['residual'], dtype=float)
    theta = np.asarray(event['theta'], dtype=float)
    if raw.shape != (expected_size,) or theta.shape != (6,) or not np.all(np.isfinite(raw)) or not np.all(np.isfinite(theta)):
        state.setdefault('invalid_actual_evidence', []).append(dict(
            evaluation=event.get('id'), accuracy=level, reason='Malformed actual forward evidence'))
        return
    score = float((raw / sigma) @ (raw / sigma))
    if not math.isfinite(score):
        state.setdefault('invalid_actual_evidence', []).append(dict(
            evaluation=event.get('id'), accuracy=level, reason='Nonfinite actual objective'))
        return
    minima = state.setdefault('actual_minima', {})
    if level not in minima or score < minima[level]['chi2']:
        minima[level] = dict(theta=theta.tolist(), accuracy=level, chi2=score,
            raw_residuals=raw.tolist(), evaluation=event.get('id'), role=event.get('role'),
            category=event.get('category'), status='COMPLETE')


def lower_guard(points, actual):
    """A higher validated consensus cannot hide a lower failed/unverified point."""
    valid = [p for p in points if p.get('numerical_evidence_valid') is True]
    if not valid:
        return dict(passed=False, lower_failed_candidate_veto=False,
            unresolved_lower_actual_candidates=[], reason='No validated endpoint')
    selected = min(valid, key=lambda p: (p['chi2']['third'], p['id']))
    failed = [p['id'] for p in points if p.get('numerical_evidence_valid') is not True
        and p['chi2']['third'] < selected['chi2']['third']]
    unresolved = []
    for row in actual:
        level = row['accuracy']
        if level not in LEVELS or not math.isfinite(row['chi2']):
            unresolved.append(dict(row, reason='Invalid precision or objective'))
            continue
        same = [p for p in points if p['theta'] == row['theta']]
        if same:
            # A full same-point disposition may legitimately change the order
            # between precision levels. Never silently accept inconsistent raw.
            if not any(np.isclose(p['chi2'][level], row['chi2'], rtol=1e-12, atol=1e-15) for p in same):
                unresolved.append(dict(row, reason='Same-point saved score mismatch'))
        elif row['chi2'] < selected['chi2'][level]:
            unresolved.append(dict(row, reason='Lower actual point lacks three-precision disposition'))
    return dict(passed=not failed and not unresolved, lower_failed_candidate_veto=bool(failed),
        lower_failed_candidate_ids=failed, unresolved_lower_actual_candidates=unresolved)


def needs_completion(ranking, boundaries, guard):
    return (not ranking.get('passed', False) or not guard['passed'] or
        any(b.get('issues') or b.get('significant_fixed_nuisance_descent') for b in boundaries.values()))


def source_start(lineage, points, actual):
    """Own-lineage only. Prefer the lowest complete third-level disposition."""
    own = [p for p in points if p['lineage_id'] == lineage]
    if own:
        return copy.deepcopy(min(own, key=lambda p: (p['chi2']['third'], p['id'])))
    own = [p for p in actual if p['lineage_id'] == lineage and p['accuracy'] == 'tight']
    return copy.deepcopy(min(own, key=lambda p: p['chi2'])) if own else None


def upper_face_eligible(theta, bounds, tolerance):
    z = feasible_z(theta, bounds)
    return bool(z[1] >= 1. - tolerance)


class TargetedRunMixin:
    """One bounded TRF continuation using the existing residual/J machinery."""
    def guard(self):
        super().guard()
        if time.time() >= self.targeted_deadline:
            raise Interrupted('targeted_stage_wall_budget_exhausted')
        if self.state.get('phase') == 'targeted_optimization' and time.time() >= self.optimization_deadline:
            raise Interrupted('targeted_optimization_wall_budget_exhausted')

    def _face_jacobian(self, reduced, full, active):
        """Original hybrid stencil, only on the five conditional coordinates."""
        z = full(reduced)
        base = self.residual(z)
        columns = [i for i in active if i != self.phi_index]
        def batch(points):
            return [self.residual(p) for p in points]
        matrix = parallel_difference_jacobian(batch, z,
            self.config['selected_absolute_step'], base, active_columns=columns)
        # Re-establish the exact same-z prediction after the finite differences.
        self.base_cache = None
        self.residual(z)
        matrix[:, self.phi_index] = phase_column(self.base_cache[2], self.bounds.scale[self.phi_index]) / self.sigma
        self.state['actual_jacobian_batches'] += 1
        return matrix[:, active]

    def run(self):
        policy = self.config['targeted_completion']
        now = time.time()
        self.targeted_deadline = min(self.shared_deadline, now + policy['max_stage_seconds'])
        self.optimization_deadline = now + (self.targeted_deadline-now)*policy['optimization_fraction']
        self.state.update(new_independent_DE_sources=0, truth_parameter_reference_used_for_fit=False,
            optimization_seed_from_own_DE_only=True, mode=self.arm['mode'],
            targeted_policy=copy.deepcopy(policy), original_shared_deadline=self.shared_deadline,
            targeted_deadline=self.targeted_deadline, optimizer_invoked=False,
            scientific_checks_passed=False, actual_minima={}, crossfit_audits={})
        saved = {}
        budget_hit = False
        try:
            self.start_pool()
            self.preflight()
            self.state['phase'] = 'source_reproduction'
            original = np.asarray(self.seed_spec['source_theta'], dtype=float)
            source_raw, source_audit = self.audit_crossfit_point(original, 'inherited_source')
            expected = self.seed_spec.get('source_raw_residuals')
            if expected is not None:
                ceiling = self.case.get('precision_vector_ceiling', self.case['threshold_D'])
                if np.linalg.norm(np.asarray(source_raw['tight'])-expected['tight']) > ceiling:
                    raise ValueError('Own source tight residual vector was not reproduced')
            saved['inherited_source'] = source_raw
            self.state['crossfit_audits']['inherited_source'] = source_audit
            fixed = feasible_z(original, self.bounds)
            active = list(range(6))
            if self.arm['mode'] == 'qmax5d':
                fixed[1] = 1.
                active = [0, 2, 3, 4, 5]
            elif self.arm['mode'] != 'full6d':
                raise ValueError('Unknown targeted completion mode')
            def full(value):
                result = fixed.copy()
                result[active] = value
                return result
            options = solver_options(self.config, self.arm)
            options['max_nfev'] = policy['max_nfev']
            self.state.update(phase='targeted_optimization', optimizer_invoked=True,
                targeted_optimizer=options, fixed_q=float(self.bounds.upper[1]) if len(active) == 5 else None)
            try:
                result = least_squares(lambda x: self.residual(full(x)), fixed[active],
                    jac=(lambda x: self._face_jacobian(x, full, active)) if len(active) == 5 else self.jacobian,
                    bounds=(np.zeros(len(active)), np.ones(len(active))), **options)
                theta = self.bounds.denormalize(full(result.x)).tolist()
                self.state['solver_accepted'] = dict(status=int(result.status), success=bool(result.success),
                    message=str(result.message), nfev=int(result.nfev), njev=int(result.njev),
                    optimality=float(result.optimality), theta=theta, active_mask=result.active_mask,
                    kind='solver_returned_not_optimum_certificate')
                budget_hit = result.status == 0
            except Interrupted as exc:
                budget_hit = True
                self.state['reason'] = str(exc)
                # Complete pending work must not compete with reserved checks.
                if self.pool is not None:
                    self.pool.terminate(); self.pool.join(); self.pool = None
                self.state['phase'] = 'targeted_validation'
                self.start_pool()
            self.state['phase'] = 'targeted_validation'
            # Include each precision's actual minimum, the source, and solver
            # return. A finite cap is explicit; any remaining lower point vetoes.
            pending = [row['theta'] for row in self.state.get('actual_minima', {}).values()]
            if self.state['solver_accepted'] is not None:
                pending.append(self.state['solver_accepted']['theta'])
            pending += [row['theta'] for row in self.seed_spec.get('pending_actual', [])]
            seen = {tuple(source_raw['theta'])}
            for theta in pending:
                key = tuple(theta)
                if key in seen:
                    continue
                if len(saved) >= policy['max_audited_actual_points']:
                    break
                seen.add(key)
                label = 'actual_' + str(len(saved))
                raw, audit = self.audit_crossfit_point(theta, label)
                saved[label] = raw
                self.state['crossfit_audits'][label] = audit
                write(self.out/'diagnostic_residuals.json', dict(candidates=saved))
            self.state['status'] = BUDGET if budget_hit else COMPLETE
        except Interrupted as exc:
            self.state.update(status=BUDGET, reason=str(exc))
        except KeyboardInterrupt:
            self.state.update(status='INTERRUPTED_CHECKPOINT_RETAINED', reason='User interruption')
            raise
        except Exception as exc:
            self.state.update(status='FAILED', error=str(exc), traceback=traceback.format_exc())
        finally:
            if self.pool is not None:
                self.pool.terminate(); self.pool.join(); self.pool = None
            if saved:
                write(self.out/'diagnostic_residuals.json', dict(candidates=saved))
            self.state.update(phase='finished', finished_utc=utc())
            self.save()
            write(self.out/'result.json', self.state)
