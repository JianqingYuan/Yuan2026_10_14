"""Bounded ER face/thin-layer candidates after the unchanged paired workflow.

This adapter changes neither the domain nor the numerical core.  All local
branches inherit existing DE ancestry; a projection is only a proposal.  The
caller supplies the original residual and certification functions in its
isolated legacy interpreter.  No truth or historical vector is a local seed.
"""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
import hashlib
import math
import signal
import time

import numpy as np

NAMES = ('M', 'q', 'rho0', 'drho_dt0', 'phi0', 'dphi_dt0')
FREE = (0, 2, 3, 4, 5)
GAPS = (1.e-12, 1.e-10, 1.e-8)
PASS = ('REPEATABLE_SOLUTION', 'MULTIPLE_NEAR_EQUAL_SOLUTIONS')


class BudgetExpired(RuntimeError):
    pass


def limits_for(profile, pair_deadline):
    """Finite ceilings inside, never extensions of, the parent's shared cap."""
    if not isinstance(pair_deadline, (int, float)) or not math.isfinite(pair_deadline):
        raise ValueError('A finite parent monotonic deadline is required')
    if profile not in ('paper', 'demo'):
        raise ValueError('Unknown profile')
    demo = profile == 'demo'
    return dict(pair_deadline=float(pair_deadline), local_seconds=10. if demo else 3600.,
        validation_seconds=10. if demo else 600., forward_seconds=5. if demo else 180.,
        max_nfev=2 if demo else 250, max_evaluations=120 if demo else 12000)


def bounds_and_levels(case):
    if (case.get('fit_theory') != 'ER'
            or case.get('legacy_variant', case.get('metadata', {}).get('suite')) != 'extreme'
            or tuple(case.get('parameter_order', NAMES)) != NAMES):
        raise ValueError('Only original six-parameter extreme ER is eligible')
    lower = np.array([case['bounds'][key][0] for key in NAMES], dtype=float)
    upper = np.array([case['bounds'][key][1] for key in NAMES], dtype=float)
    if not np.all(np.isfinite([lower, upper])) or np.any(lower >= upper):
        raise ValueError('Six finite nondegenerate original intervals are required')
    if lower[1] != 0. or upper[1] != math.sqrt(12. / 11.):
        raise ValueError('The original ER charge upper bound must remain sqrt(12/11)')
    criterion = case.get('precision_criterion', {})
    if criterion.get('kind') != 'absolute_delta_chi2' or criterion.get('tolerance') != .01:
        raise ValueError('Original absolute delta chi2 tolerance must remain 0.01')
    levels = {key: deepcopy(case[key + '_integration']) for key in ('nominal', 'tight')}
    levels['third'] = deepcopy(levels['tight'])
    for key in ('max_step', 'relative_tolerance', 'absolute_tolerance'):
        levels['third'][key] *= .5 if key == 'max_step' else .1
    observed = np.asarray(case.get('xy_observed', case.get('xy_true')), dtype='<f8')
    if (observed.shape != (len(case['times']), 2) or not np.all(np.isfinite(observed))
            or not math.isfinite(case['residual_sigma']) or case['residual_sigma'] <= 0):
        raise ValueError('Malformed unchanged observations or weights')
    expected = case.get('metadata', {}).get('observation_sha256')
    if expected and hashlib.sha256(np.ascontiguousarray(observed).tobytes()).hexdigest() != expected:
        raise ValueError('Observation hash mismatch')
    return lower, upper, levels


def feasible(theta, lower, upper):
    theta = np.asarray(theta, dtype=float)
    return bool(theta.shape == (6,) and np.all(np.isfinite(theta))
                and np.all(theta >= lower) and np.all(theta <= upper))


def physical(x, q, lower, upper):
    x = np.asarray(x, dtype=float)
    if x.shape != (5,) or not np.all(np.isfinite(x)) or np.any(x < 0) or np.any(x > 1):
        raise ValueError('Invalid five-dimensional nuisance coordinates')
    if not lower[1] <= q <= upper[1]:
        raise ValueError('Fixed charge outside original domain')
    theta = np.empty(6)
    for j, column in enumerate(FREE):
        theta[column] = lower[column] if x[j] == 0 else upper[column] if x[j] == 1 else lower[column] + x[j] * (upper[column] - lower[column])
    theta[1] = q
    return theta


def inherited_sources(record, lower, upper):
    """Use real global candidates only; borrowed/local labels cannot add votes."""
    runs = {}
    for run in record.get('global_runs', []):
        index, seed = run.get('index'), run.get('random_seed')
        if type(index) is not int or type(seed) is not int or not 0 <= seed < 2**32:
            raise ValueError('Malformed original DE run identity')
        if index in runs:
            raise ValueError('Duplicate original DE run index')
        runs[index] = seed
    candidates = {}
    for row in record.get('global_candidates', []):
        index = row.get('run_index')
        if (type(index) is not int or index not in runs or not str(row.get('source', '')).startswith('global-')
                or not feasible(row.get('theta'), lower, upper)):
            continue
        score = row.get('chi2')
        if isinstance(score, bool) or not isinstance(score, (float, int)) or not math.isfinite(score) or not 0 <= score < 1.e99:
            continue
        z = np.asarray(row.get('z'), dtype=float)
        if z.shape != (6,) or not np.allclose(z, (np.asarray(row['theta']) - lower) / (upper - lower), rtol=0., atol=2.e-14):
            raise ValueError('Original DE normalized/physical coordinates disagree')
        if index not in candidates or score < candidates[index]['chi2']:
            candidates[index] = row
    selected, seeds = [], set()
    for index in sorted(candidates, key=lambda key: (candidates[key]['chi2'], key)):
        if runs[index] in seeds:
            continue
        selected.append(dict(run_index=index, random_seed=runs[index],
            lineage='original_de_seed_' + str(runs[index]), original_candidate=deepcopy(candidates[index])))
        seeds.add(runs[index])
        if len(selected) == 2:
            break
    return selected


def projection(matrix):
    matrix = np.asarray(matrix, dtype=float)
    if matrix.ndim != 2 or matrix.shape[1] != 5 or not np.all(np.isfinite(matrix)):
        raise ValueError('Five finite nuisance columns required')
    norms = np.linalg.norm(matrix, axis=0)
    if np.any(norms <= 0):
        raise ValueError('Zero nuisance sensitivity')
    u, singular, _ = np.linalg.svd(matrix / norms, full_matrices=False)
    cutoff = singular[0] * max(matrix.shape) * np.finfo(float).eps
    if np.sum(singular > cutoff) != 5:
        raise ValueError('Rank-deficient nuisance projection needs review')
    return lambda value: np.asarray(value) - u @ (u.T @ np.asarray(value))


def choose_proposal(samples, r0, project):
    comparisons = []
    for index in range(len(samples) - 1):
        changes = []
        for level in ('tight', 'third'):
            a, b = (np.asarray(samples[j]['sensitivity'][level]) for j in (index, index + 1))
            changes.append(float(np.linalg.norm(a - b) / max(np.linalg.norm(a), np.linalg.norm(b))))
        for row in samples[index:index + 2]:
            a, b = (np.asarray(row['sensitivity'][level]) for level in ('tight', 'third'))
            changes.append(float(np.linalg.norm(a - b) / max(np.linalg.norm(a), np.linalg.norm(b))))
        comparisons.append(dict(indices=[index, index + 1], maximum_relative_change=max(changes)))
    selected = min(comparisons, key=lambda row: (row['maximum_relative_change'], row['indices']))
    result = dict(comparisons=comparisons, proposal_heuristic_limit=.05,
                  scientific_acceptance_threshold_changed=False)
    if not np.isfinite(selected['maximum_relative_change']) or selected['maximum_relative_change'] > .05:
        return dict(result, status='UNSTABLE_SENSITIVITY_NO_PROPOSAL')
    b = np.mean([samples[j]['sensitivity']['third'] for j in selected['indices']], axis=0)
    square = float(b @ b)
    if not np.isfinite(square) or square <= 0:
        return dict(result, status='NO_FINITE_SENSITIVITY')
    optimum = -float(project(r0) @ b) / square
    if not np.isfinite(optimum) or not 0 < optimum < 1:
        return dict(result, status='NO_POSITIVE_IN_DOMAIN_PROPOSAL')
    return dict(result, status='FINITE_POSITIVE_PROPOSAL', u=optimum, normalized_gap=optimum**2)


@contextmanager
def forward_guard(deadline, maximum):
    guard_started = time.monotonic()
    remaining = deadline - guard_started
    if remaining <= 0:
        raise BudgetExpired('Shared targeted deadline exhausted')
    if not hasattr(signal, 'setitimer'):
        yield  # The parent's owned-process supervisor is the hard Windows cap.
        return
    previous = signal.getsignal(signal.SIGALRM)
    old_timer = signal.getitimer(signal.ITIMER_REAL)
    def alarm(_signum, _frame):
        raise BudgetExpired('Forward or targeted stage deadline exhausted')
    signal.signal(signal.SIGALRM, alarm)
    ceiling = min(remaining, maximum, old_timer[0] if old_timer[0] else remaining)
    signal.setitimer(signal.ITIMER_REAL, ceiling)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0.)
        signal.signal(signal.SIGALRM, previous)
        if old_timer[0]:
            # Nested guards must not extend a previously owned timer.
            signal.setitimer(signal.ITIMER_REAL, max(1.e-9, old_timer[0]-(time.monotonic()-guard_started)), old_timer[1])


def run(case, original_record, *, limits, evaluate, certify, certification_config,
        save=lambda document: None, record_evaluation=lambda row: None, solver=None):
    """Return auditable candidates/certificate; never mutate the native record.

    evaluate(theta, settings) returns original weighted residuals. certify(rows)
    must use the original profile's FitCertificationConfig and native function.
    A caller must only promote selected when scientific_checks_passed is true.
    """
    from scipy.optimize import least_squares
    solver = least_squares if solver is None else solver
    lower, upper, levels = bounds_and_levels(case)
    if any(certification_config.get(key) != expected for key, expected in (
            ('chi2_agreement', .1), ('normalized_parameter_agreement', .02), ('minimum_independent_routes', 2))):
        raise ValueError('Original extreme source certification thresholds must remain unchanged')
    for key in ('pair_deadline', 'local_seconds', 'validation_seconds', 'forward_seconds', 'max_nfev', 'max_evaluations'):
        value = limits[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            raise ValueError('Finite positive targeted limits required')
    for key in ('max_nfev', 'max_evaluations'):
        if type(limits[key]) is not int:
            raise ValueError('Integer evaluation ceilings required')
    started = time.monotonic()
    total_end = min(limits['pair_deadline'], started + limits['local_seconds'] + limits['validation_seconds'])
    local_end = min(started + limits['local_seconds'], total_end - limits['validation_seconds'])
    document = dict(schema='extreme-targeted-v1', status='NOT_TRIGGERED', triggered=False,
        scientific_checks_passed=False, new_independent_DE_sources=0, truth_used_as_optimizer_seed=False,
        original_record=deepcopy(original_record), limits=deepcopy(limits), multi_precision_settings=levels,
        original_bounds=deepcopy(case['bounds']), evaluations=[], branches=[], validations=[], errors=[],
        source_selection=[], known_lower_unresolved=True, selected=None)
    def persist():
        document['elapsed_seconds'] = time.monotonic() - started
        save(document)
    def point(theta, level, purpose, lineage=None, deadline=None):
        if len(document['evaluations']) >= limits['max_evaluations']:
            raise BudgetExpired('Finite targeted evaluation ceiling exhausted')
        if not feasible(theta, lower, upper):
            raise ValueError('Evaluation outside original domain')
        row = dict(theta=np.asarray(theta).tolist(), level=level, purpose=purpose, lineage=lineage,
                   valid=False, integration=levels[level])
        document['evaluations'].append(row)
        try:
            with forward_guard(total_end if deadline is None else deadline, limits['forward_seconds']):
                residual = np.asarray(evaluate(np.asarray(theta), levels[level]), dtype=float)
            if residual.shape != (2 * len(case['times']),) or not np.all(np.isfinite(residual)):
                raise ValueError('Malformed weighted residual')
            score = float(residual @ residual)
            if not math.isfinite(score) or score >= 1.e99:
                raise ValueError('Invalid residual score')
            row.update(valid=True, chi2=score, weighted_residuals=residual.tolist(),
                       raw_residuals=(residual * case['residual_sigma']).tolist())
            if level == 'tight' and purpose != 'injected_reference_not_optimizer_seed':
                previous = document.get('lowest_actual_tight')
                if previous is None or score < previous['chi2']:
                    document['lowest_actual_tight'] = deepcopy(row)
        except Exception as exc:
            row['error'] = repr(exc)
            persist()
            raise
        finally:
            # The worker appends and flushes one journal row before an actual
            # call returns. This retains nonminimum/failed/Jacobian probes on
            # an owned-child hard stop without rewriting the growing document.
            try:
                record_evaluation(deepcopy(row))
            except Exception as exc:
                document['errors'].append('Evaluation journal write failed: ' + repr(exc))
                raise
        return row
    def validate(theta, purpose, lineage=None):
        row = dict(theta=np.asarray(theta).tolist(), purpose=purpose, lineage=lineage, levels={}, passed=False)
        document['validations'].append(row)
        try:
            for level in levels:
                row['levels'][level] = point(theta, level, purpose, lineage)
            n, t, h = (row['levels'][key]['chi2'] for key in levels)
            delta = np.asarray(row['levels']['tight']['weighted_residuals']) - row['levels']['third']['weighted_residuals']
            norm = float(np.linalg.norm(delta))
            row.update(nominal_tight_difference=abs(n-t), tight_third_difference=abs(t-h),
                measured_discrepancy_scale=2*np.sqrt(h)*norm+norm*norm,
                passed=bool(abs(n-t) <= .01 and abs(t-h) <= .01))
            if row['passed'] and purpose != 'injected_reference_not_optimizer_seed':
                previous = document.get('best_numerically_validated')
                if previous is None or t < previous['levels']['tight']['chi2']:
                    document['best_numerically_validated'] = deepcopy(row)
        except Exception as exc:
            row['error'] = repr(exc)
        persist()
        return row
    def local(source, q, start_theta, identity, deadline, jac=None):
        branch = dict(identity=identity, lineage=source['lineage'], run_index=source['run_index'],
            random_seed=source['random_seed'], fixed_q=float(q), status='RUNNING', optimizer_success=False,
            best=None, solver=dict(method='trf', jac='3-point', x_scale='jac', max_nfev=limits['max_nfev'],
                                  ftol=1.e-8, xtol=1.e-8, gtol=1.e-8))
        document['branches'].append(branch)
        def objective(x):
            theta = physical(x, q, lower, upper)
            try:
                row = point(theta, 'tight', identity, source['lineage'], deadline)
            except BudgetExpired:
                raise
            except (ValueError, RuntimeError, FloatingPointError, OverflowError):
                return np.full(2*len(case['times']), 1.e50)
            if branch['best'] is None or row['chi2'] < branch['best']['chi2']:
                branch['best'] = deepcopy(row)
                persist()
            return np.asarray(row['weighted_residuals'])
        try:
            x = ((np.asarray(start_theta)-lower)/(upper-lower))[list(FREE)]
            residual = objective(x)
            if branch['best'] is None:
                raise ValueError('Invalid exact starting candidate')
            if jac is not None:
                proposed = x + np.linalg.lstsq(jac, -residual, rcond=None)[0]
                if np.all(np.isfinite(proposed)) and np.all(proposed >= 0) and np.all(proposed <= 1):
                    actual = objective(proposed)
                    if float(actual @ actual) < float(residual @ residual):
                        x = proposed
            result = solver(objective, x, bounds=(0., 1.), **branch['solver'])
            theta = physical(result.x, q, lower, upper)
            final = point(theta, 'tight', identity + ':solver_return', source['lineage'], deadline)
            branch.update(status='FINISHED', optimizer_success=bool(result.success), message=str(result.message),
                nfev=int(result.nfev), termination_status=int(result.status), solver_endpoint=final,
                optimality=float(result.optimality) if hasattr(result, 'optimality') and np.isfinite(result.optimality) else None)
        except BudgetExpired as exc:
            branch.update(status='BUDGET_EXHAUSTED', error=str(exc))
        except Exception as exc:
            branch.update(status='FAILED', error=repr(exc))
        persist()
        return branch
    try:
        best = np.asarray(original_record['best_theta'], dtype=float)
        if not feasible(best, lower, upper):
            raise ValueError('Native selected endpoint outside original domain')
        gap = float((upper[1]-best[1])/(upper[1]-lower[1]))
        document['trigger_boundary_gap'] = gap
        if gap > .01:
            persist()
            return document
        # Once boundary checks begin, an incomplete check must not silently
        # return the old certificate as if no remediation had been needed.
        document['triggered'] = True
        native = validate(best, 'native_endpoint')
        truth = case.get('metadata', {}).get('theta_true') if case.get('generating_theory', 'ER') == 'ER' else None
        if truth is not None and not feasible(truth, lower, upper):
            raise ValueError('Malformed or infeasible injected reference; never clipped or used as seed')
        truth_check = validate(truth, 'injected_reference_not_optimizer_seed') if truth is not None and feasible(truth, lower, upper) else None
        document['truth_validation'] = truth_check
        failed = (original_record.get('diagnostics', {}).get('certification_status') not in PASS
                  or original_record.get('integration_check', {}).get('within_tolerance') is not True
                  or not native['passed'] or (truth_check is not None and not truth_check['passed']))
        # This is the campaign's measured known-lower veto, NOT a replacement
        # for the unchanged .01 nominal/tight or tight/third precision gates.
        truth_scale = (native.get('measured_discrepancy_scale', 0.) +
                       (truth_check or {}).get('measured_discrepancy_scale', 0.) + 1.e-8)
        truth_lower = bool(truth_check and truth_check['passed'] and native['levels'].get('tight') and
            native['levels']['tight']['chi2'] > truth_check['levels']['tight']['chi2'] + truth_scale)
        # Check the unfiltered native union BEFORE any successful early return.
        # Native nominal scores are not used to prefilter common-tight scores.
        native_seen = set()
        for field in ('global_candidates', 'screening_candidates', 'local_candidates'):
            for candidate in original_record.get(field, []):
                theta = candidate.get('theta')
                if not feasible(theta, lower, upper):
                    document['errors'].append('Invalid native candidate in ' + field)
                    continue
                key = tuple(theta)
                if key in native_seen:
                    continue
                native_seen.add(key)
                point(theta, 'tight', 'native_candidate:' + field)
        document['native_union_complete'] = True
        native_lower = False
        lowest = document.get('lowest_actual_tight')
        if lowest and native['levels'].get('tight') and lowest['chi2'] < native['levels']['tight']['chi2']:
            challenger = validate(lowest['theta'], 'native_known_lower_validation')
            document['native_known_lower_validation'] = challenger
            native_scale = native.get('measured_discrepancy_scale', 0.) + challenger.get('measured_discrepancy_scale', 0.) + 1.e-8
            native_lower = bool(not challenger['passed'] or not native['passed'] or
                native['levels']['tight']['chi2'] - lowest['chi2'] > native_scale)
        failed = bool(failed or document['errors'])
        document['trigger_reasons'] = dict(original_quality_failed=failed,
            injected_reference_lower=truth_lower, native_saved_candidate_lower=native_lower)
        if not failed and not truth_lower and not native_lower:
            document.update(triggered=False, known_lower_unresolved=False)
            persist()
            return document
        document.update(triggered=True, status='RUNNING')
        sources = inherited_sources(original_record, lower, upper)
        document['source_selection'] = sources
        if len(sources) != 2:
            raise ValueError('Two distinct traceable original DE seeds are required')
        for source_index, source in enumerate(sources):
            remaining = local_end-time.monotonic()
            if remaining <= 0:
                raise BudgetExpired('No local time remains inside parent budget')
            source_end = min(local_end, time.monotonic()+remaining/(2-source_index))
            face = local(source, upper[1], source['original_candidate']['theta'], 'exact_face',
                         time.monotonic()+max(0., source_end-time.monotonic())/2)
            if face['best'] is None:
                continue
            theta = np.asarray(face['best']['theta'])
            z = (theta-lower)/(upper-lower)
            try:
                if np.any(z[list(FREE)] <= .001) or np.any(z[list(FREE)] >= .999):
                    raise ValueError('Active nuisance boundary invalidates unrestricted projection')
                r0 = {key: point(theta, key, 'face_sensitivity_base', source['lineage'], source_end) for key in ('tight', 'third')}
                columns = []
                for column in FREE:
                    shifted = []
                    for sign in (-1., 1.):
                        x = z[list(FREE)].copy()
                        x[list(FREE).index(column)] += sign*1.e-4
                        shifted.append(np.asarray(point(physical(x, upper[1], lower, upper), 'third',
                            'nuisance_jacobian', source['lineage'], source_end)['weighted_residuals']))
                    columns.append((shifted[1]-shifted[0])/2.e-4)
                jac = np.column_stack(columns)
                project = projection(jac)
                samples = []
                for gap_value in GAPS:
                    shifted = theta.copy()
                    shifted[1] = upper[1]-gap_value*(upper[1]-lower[1])
                    actual_gap = (upper[1]-shifted[1])/(upper[1]-lower[1])
                    if not 0 < actual_gap < 1:
                        raise ValueError('Unrepresentable inward gap')
                    sample = dict(requested_gap=gap_value, actual_gap=float(actual_gap), sensitivity={})
                    for level in ('tight', 'third'):
                        residual = point(shifted, level, 'gap_sensitivity', source['lineage'], source_end)
                        sensitivity = project((np.asarray(residual['weighted_residuals'])-r0[level]['weighted_residuals'])/np.sqrt(actual_gap))
                        if not np.isfinite(sensitivity @ sensitivity) or float(sensitivity @ sensitivity) <= 0:
                            raise ValueError('Invalid sqrt-gap sensitivity')
                        sample['sensitivity'][level] = sensitivity.tolist()
                    samples.append(sample)
                proposal = choose_proposal(samples, np.asarray(r0['third']['weighted_residuals']), project)
                face.update(proposal=proposal, sensitivity_samples=samples, nuisance_jacobian=jac.tolist())
                if proposal['status'] == 'FINITE_POSITIVE_PROPOSAL':
                    for index, factor in enumerate((.5, 1., 2.)):
                        gap_value = (factor*proposal['u'])**2
                        if not 0 < gap_value < 1:
                            continue  # Never clip a proposal into the original domain.
                        q = float(upper[1]-gap_value*(upper[1]-lower[1]))
                        if not lower[1] < q < upper[1]:
                            continue
                        deadline = min(source_end, time.monotonic()+max(0., source_end-time.monotonic())/(3-index))
                        local(source, q, theta, 'adaptive_u_factor_' + str(factor), deadline, jac)
            except Exception as exc:
                face['adaptive_error'] = repr(exc)
            persist()
        # All actual points are saved; minima from EVERY precision are tested,
        # including Jacobian probes and unsuccessful local solves.
        pending = []
        for level in levels:
            values = [row for row in document['evaluations'] if row['valid'] and row['level'] == level
                      and row['purpose'] != 'injected_reference_not_optimizer_seed']
            if values:
                pending.append(min(values, key=lambda row: row['chi2']))
        for branch in document['branches']:
            pending.extend(row for row in (branch.get('best'), branch.get('solver_endpoint')) if row is not None)
        validated, support = {}, []
        for candidate in pending:
            key = tuple(candidate['theta'])
            if key not in validated:
                validated[key] = validate(candidate['theta'], 'candidate_validation', candidate.get('lineage'))
        for branch in document['branches']:
            endpoint = branch.get('solver_endpoint')
            if branch['optimizer_success'] and endpoint and validated[tuple(endpoint['theta'])]['passed']:
                checked = validated[tuple(endpoint['theta'])]
                support.append(dict(theta=endpoint['theta'], z=((np.asarray(endpoint['theta'])-lower)/(upper-lower)).tolist(),
                    chi2=checked['levels']['tight']['chi2'], success=True, run_index=branch['run_index'],
                    source='targeted:' + branch['lineage'] + ':' + branch['identity'], message=branch.get('message', ''),
                    optimality=branch.get('optimality')))
        valid = [row for row in validated.values() if row['levels'].get('tight')]
        if not valid:
            raise ValueError('No validated candidate available')
        selected = min(valid, key=lambda row: row['levels']['tight']['chi2'])
        # Validate every actually lower same-level point, not just the first
        # minimum. Newly measured tight values may themselves lower selection.
        # Each physical point is visited once and all calls share the same cap.
        while True:
            unchecked = {}
            for row in document['evaluations']:
                key = tuple(row['theta'])
                if (row['valid'] and row['purpose'] != 'injected_reference_not_optimizer_seed'
                        and key not in validated and row['level'] in selected['levels']
                        and row['chi2'] < selected['levels'][row['level']]['chi2'] -
                            64*np.finfo(float).eps*max(1., row['chi2'])):
                    unchecked[key] = row
            if not unchecked:
                break
            for key, candidate in unchecked.items():
                validated[key] = validate(candidate['theta'], 'lower_candidate_validation', candidate.get('lineage'))
            valid = [row for row in validated.values() if row['levels'].get('tight')]
            selected = min(valid, key=lambda row: row['levels']['tight']['chi2'])
        document['selected'] = selected
        # Do not silently label a lower derivative/failed point a successful solve.
        selected_key = tuple(selected['theta'])
        if not any(tuple(row['theta']) == selected_key for row in support):
            support.append(dict(theta=selected['theta'], z=((np.asarray(selected['theta'])-lower)/(upper-lower)).tolist(),
                chi2=selected['levels']['tight']['chi2'], success=False, run_index=None,
                source='lowest_actual_candidate_not_a_converged_endpoint', message='Retained without borrowed certification'))
        native_certificate = certify(support)
        endpoint_certificate = certify([row for row in support if row['success'] is True])
        selected_z = (np.asarray(selected['theta'])-lower)/(upper-lower)
        matches = []
        for row in support:
            delta = abs(row['chi2']-selected['levels']['tight']['chi2'])
            distance = float(np.linalg.norm(np.asarray(row['z'])-selected_z))
            if row['success'] is True and delta <= certification_config['chi2_agreement'] and distance <= certification_config['normalized_parameter_agreement']:
                source = next(item for item in sources if item['run_index'] == row['run_index'])
                matches.append(dict(run_index=row['run_index'], random_seed=source['random_seed'],
                    source=row['source'], chi2_difference=delta, normalized_parameter_distance=distance))
        distinct = len({row['random_seed'] for row in matches})
        supported = distinct >= certification_config['minimum_independent_routes'] and endpoint_certificate.get('status') in PASS
        certificate = dict(status='REPEATABLE_SOLUTION' if supported else 'COMPUTATIONALLY_UNRESOLVED',
            kind='lowest_actual_point_supported_by_two_original_DE_endpoints',
            selected_solver_success=any(tuple(row['theta']) == selected_key and row['success'] is True for row in support),
            selected_success_was_not_fabricated=True, original_config=deepcopy(certification_config),
            independent_route_count=distinct, matched_successful_endpoints=matches,
            original_certifier_with_lowest_actual_point=native_certificate,
            original_certifier_successful_endpoints=endpoint_certificate, global_optimum_proven=False)
        document['certification'] = certificate
        document['certification_candidates'] = support
        # Compare like precision with like precision. A third-level low probe
        # with a failed tight replay is unresolved evidence, not a disposable
        # high-tight candidate. Never compare a third score directly to tight.
        lower_unverified = [row for row in document['evaluations'] if row['valid']
            and row['purpose'] != 'injected_reference_not_optimizer_seed'
            and row['level'] in selected['levels']
            and row['chi2'] < selected['levels'][row['level']]['chi2'] - 64*np.finfo(float).eps*max(1., row['chi2'])
            and (tuple(row['theta']) not in validated or not validated[tuple(row['theta'])]['passed'])]
        truth_scale = selected.get('measured_discrepancy_scale', 0.) + (truth_check or {}).get('measured_discrepancy_scale', 0.) + 1.e-8
        truth_ok = bool(truth_check is None or (truth_check['passed'] and
            selected['levels']['tight']['chi2'] <= truth_check['levels']['tight']['chi2'] + truth_scale))
        document.update(known_lower_unresolved=bool(lower_unverified), lower_unverified=lower_unverified,
            injected_reference_guard_passed=truth_ok,
            injected_reference_measured_scale=truth_scale, measured_scale_is_not_rigorous_error_bound=True,
            scientific_checks_passed=bool(selected['passed'] and not lower_unverified and truth_ok and
                not document['errors'] and certificate.get('status') in PASS),
            status='COMPLETE_REQUIRES_REVIEW')
        if document['scientific_checks_passed']:
            document['status'] = 'TARGETED_CERTIFIED'
    except Exception as exc:
        document.update(status='NEEDS_REVIEW', triggered=True, scientific_checks_passed=False)
        document['errors'].append(repr(exc))
        if document['selected'] is None:
            document['selected'] = deepcopy(document.get('best_numerically_validated'))
    persist()
    return document
