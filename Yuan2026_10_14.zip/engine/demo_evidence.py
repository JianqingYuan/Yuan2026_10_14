"""Finite-budget bookkeeping and immediate audit retention; no fit policy.

Complete evidence is not a numerical pass, a new candidate nomination, a solver
success or an independent-source vote. All scientific checks remain elsewhere.
"""
from copy import deepcopy
import json
import math
import os


def split_attempt_budget(seconds, factor, models):
    """Reserve validation inside this attempt, including very short budgets.

    Normal allowance is the existing 60 * factor per model. At most half of a
    short attempt is reserved, leaving positive native and validation shares.
    A pair receives one native share for its intact paired workflow, not two
    independent fits. Unused validation time never enlarges another model's cap.
    """
    if (isinstance(seconds, bool) or not isinstance(seconds, (int, float))
            or not math.isfinite(seconds) or seconds <= 0
            or isinstance(factor, bool) or not isinstance(factor, (int, float))
            or not math.isfinite(factor) or factor < 1 or type(models) is not int or models < 1):
        raise ValueError('Positive finite attempt budget and model count required')
    per_model = min(60.0 * factor, seconds / (2.0 * models))
    native = seconds - models * per_model
    if not (0 < per_model < seconds and 0 < native < seconds):
        raise ValueError('Budget too small to represent positive native and validation shares')
    return dict(total_seconds=float(seconds), native_seconds=native,
                validation_seconds_per_model=per_model, reserved_seconds=models * per_model)


def _plain(value):
    if hasattr(value, 'tolist'):
        return value.tolist()
    if hasattr(value, 'item'):
        return value.item()
    raise TypeError(type(value).__name__)


def retain_completed_audit(run, theta, label, raw, audit, write, *, endpoint):
    """Persist exactly a returned original same-theta audit before next work.

    The append-only receipt binds raw vectors and original audit together and is
    flushed before updating the existing diagnostic/checkpoint representation.
    No forward is called and neither acceptance nor stopping flags are changed.
    """
    theta = list(theta)
    if (not isinstance(label, str) or not label or len(theta) != 6
            or raw.get('theta') != theta or audit.get('theta') != theta
            or not all(math.isfinite(float(x)) for x in theta)):
        raise ValueError('Completed audit must bind one exact six-parameter point')
    size = run.truth.size
    if any(not isinstance(raw.get(level), list) or len(raw[level]) != size
           or not all(math.isfinite(float(x)) for x in raw[level])
           for level in ('nominal', 'tight', 'third')):
        raise ValueError('Completed audit requires all finite same-theta raw vectors')
    record = dict(schema='portable-completed-audit-receipt-v1', label=label,
        raw_residuals=deepcopy(raw), original_audit=deepcopy(audit),
        original_shared_deadline=run.shared_deadline,
        identity={key:deepcopy(run.state.get(key)) for key in (
            'case_sha256', 'config_sha256', 'manifest_sha256', 'seeds_sha256',
            'seed_provenance', 'effective_bounds', 'integration', 'fit_theory',
            'fit_theory_options', 'residual_sigma')},
        stage_status_at_return=run.state.get('status'), phase_at_return=run.state.get('phase'),
        evidence_complete_not_scientific_acceptance=True, new_independent_DE_sources=0,
        existing_endpoint_label=endpoint)
    line = json.dumps(record, default=_plain, allow_nan=False, separators=(',', ':'))
    with (run.out/'completed_audits.jsonl').open('a', encoding='utf-8') as stream:
        stream.write(line+'\n')
        stream.flush()
        os.fsync(stream.fileno())
    if not endpoint:
        # Some original source/start audits are checks, not endpoint candidates.
        # Preserve their raw receipt without silently nominating a new endpoint.
        run.last_save = 0
        run.save()
        return
    candidates = getattr(run, '_completed_audit_candidates', None)
    if candidates is None:
        path = run.out/'diagnostic_residuals.json'
        candidates = json.loads(path.read_text(encoding='utf-8'))['candidates'] if path.exists() else {}
        run._completed_audit_candidates = candidates
    if label in candidates and candidates[label] != raw:
        raise ValueError('Audit label reused for different raw evidence; receipts retained')
    candidates[label] = deepcopy(raw)
    run.state.setdefault('crossfit_audits', {})[label] = deepcopy(audit)
    write(run.out/'diagnostic_residuals.json', dict(fit_theory=run.fit_theory,
        fit_mode='nonzero_residual_diagnostic', residual_sigma=run.sigma, candidates=candidates))
    # _PortableIO.save normally throttles running checkpoints. A complete raw /
    # audit pair is a persistence boundary, not an optional periodic checkpoint.
    run.last_save = 0
    run.save()
