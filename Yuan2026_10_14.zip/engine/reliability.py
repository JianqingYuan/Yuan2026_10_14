"""New portable bounded retry automation, not a replay of historical retries.

Each attempt uses the original independent-source scientific acceptance. A
certificate belongs only to that attempt's endpoint; it is never transferred
to a lower unresolved endpoint found by another attempt. Legacy pairs remain
atomic throughout their original cross-theory rescue workflow.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import threading
import time

import numpy as np

from .api import fit_case
from .legacy import fit_pair
from .fit_validation import validate_endpoint
from .demo_evidence import split_attempt_budget

VERSION = 'portable-bounded-reliability-v2-targeted'
DEFAULT_POLICY = {'max_attempts': 3, 'budget_multiplier': 2.0}
_ENDPOINT_KEYS = ('theta', 'chi2', 'residuals', 'best_candidate_id', 'residual_check_chi2')


def validate_policy(policy=None):
    """Return a normalized finite policy; no implicit unlimited restart mode."""
    if policy is None:
        policy = {}
    if not isinstance(policy, dict) or set(policy) - set(DEFAULT_POLICY):
        raise ValueError('reliability policy accepts only max_attempts and budget_multiplier')
    result = dict(DEFAULT_POLICY, **policy)
    count, multiplier = result['max_attempts'], result['budget_multiplier']
    if type(count) is not int or not 1 <= count <= 32:
        raise ValueError('max_attempts must be an integer between 1 and 32')
    if isinstance(multiplier, bool) or not isinstance(multiplier, (int, float)):
        raise ValueError('budget_multiplier must be finite and at least 1')
    try:
        multiplier = float(multiplier)
        factors = [multiplier ** index for index in range(count)]
        valid = multiplier >= 1 and all(math.isfinite(x) for x in factors) and math.isfinite(sum(factors))
    except (OverflowError, ValueError):
        valid = False
    if not valid:
        raise ValueError('budget_multiplier and the complete budget schedule must be finite and at least 1')
    result['budget_multiplier'] = multiplier
    return result


def _write(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    os.replace(temporary, path)


def _finite(value):
    try:
        return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value)
    except (OverflowError, ValueError):
        return False


def _usable(result):
    if result.get('best_candidate_checks_passed') is not True or not _finite(result.get('chi2')) or result['chi2'] < 0:
        return False
    try:
        theta, residuals = np.asarray(result['theta'], dtype=float), np.asarray(result['residuals'], dtype=float)
        return bool(theta.shape == (6,) and np.all(np.isfinite(theta)) and residuals.ndim == 1
                    and residuals.size > 0 and residuals.size % 2 == 0 and np.all(np.isfinite(residuals)))
    except (KeyError, TypeError, ValueError):
        return False


def _diagnostic(result, attempt, path, comparable=True):
    available = []
    for candidate in (result, result.get('diagnostic_best', {})):
        if isinstance(candidate, dict) and _finite(candidate.get('chi2')) and candidate['chi2'] >= 0:
            theta = candidate.get('theta')
            try:
                if np.asarray(theta, dtype=float).shape != (6,) or not np.all(np.isfinite(np.asarray(theta, dtype=float))):
                    theta = None
            except (ValueError, TypeError):
                theta = None
            available.append(dict(chi2=candidate['chi2'], theta=theta,
                id=candidate.get('id', candidate.get('best_candidate_id')),
                checks_passed=bool(candidate.get('checks_passed', candidate.get('best_candidate_checks_passed', False))),
                attempt_index=attempt, result_path=str(path), comparable_across_attempts=comparable))
    return min(available, key=lambda item:item['chi2']) if available else None


def _comparison_result(result, validation, pair):
    candidate = deepcopy(result)
    common = validation.get('comparison_endpoint')
    comparable = not pair
    if isinstance(common, dict) and _finite(common.get('chi2')) and common['chi2'] >= 0:
        candidate.update(native_chi2=result.get('chi2'),
            native_residual_accuracy=result.get('residual_accuracy'),
            native_residual_integration=deepcopy(result.get('residual_integration')),
            native_residual_check_chi2=result.get('residual_check_chi2'))
        for key in ('chi2', 'residuals', 'residual_accuracy', 'residual_integration'):
            if key in common:
                candidate[key] = deepcopy(common[key])
        candidate['residual_check_chi2'] = common['chi2']
        candidate['candidate_comparison_policy'] = 'Same fixed case tight objective across legacy attempts' if pair else 'Same third-precision objective across S301 attempts'
        # S301 already uses the same third-precision objective in every
        # attempt. Failed numeric checks exclude a point from usable minima,
        # but must not erase its lower same-objective diagnostic. Legacy's
        # native integration objective may differ and needs a validated common
        # score before claiming cross-attempt comparability.
        comparable = not pair or validation.get('numerical_checks_passed') is True
        if not pair and _same_reproduced_endpoint_alias(result, validation, common):
            # Identical saved raw data can be reduced one ULP differently by
            # the outer validator. This is the SAME endpoint, not a lower
            # candidate. Normalize only this proven alias in the comparison
            # copy; keep the original report and all distinct points intact.
            candidate['diagnostic_alias_reproduction'] = dict(
                policy='Exact same S301 endpoint/raw/objective; no tolerance relaxation',
                original_diagnostic=deepcopy(result['diagnostic_best']),
                comparison_chi2=common['chi2'])
            candidate['diagnostic_best']['chi2'] = common['chi2']
    elif pair:
        candidate['candidate_comparison_policy'] = 'Native endpoint retained without common-objective score; not ranked against a different objective'
    else:
        candidate['candidate_comparison_policy'] = 'Same third-precision objective across S301 attempts'
    return candidate, comparable


def _same_reproduced_endpoint_alias(result, validation, common):
    """Identity-only de-duplication, never a numerical closeness allowance."""
    diagnostic = result.get('diagnostic_best')
    checks = validation.get('checks', {})
    evidence = validation.get('fixed_point_evidence', {})
    if not isinstance(checks, dict) or not isinstance(evidence, dict):
        return False
    reproduced = checks.get('saved_endpoint_reproduced', {})
    fitted = evidence.get('fitted', {})
    if not isinstance(reproduced, dict) or not isinstance(fitted, dict):
        return False
    levels = fitted.get('levels', {})
    selected = levels.get('selected', {}) if isinstance(levels, dict) else None
    if not isinstance(selected, dict):
        return False
    return bool(result.get('fit_pipeline') == 's301' and _usable(result)
        and _native_acceptance(result) and isinstance(diagnostic, dict)
        and diagnostic.get('checks_passed') is True
        and isinstance(result.get('best_candidate_id'), str) and result['best_candidate_id']
        and diagnostic.get('id') == result['best_candidate_id']
        and diagnostic.get('theta') == result['theta'] == fitted.get('theta')
        and diagnostic.get('chi2') == result['chi2']
        and result.get('residual_accuracy') == common.get('residual_accuracy') == 'third'
        and isinstance(result.get('residual_integration'), dict) and result['residual_integration']
        and result['residual_integration'] == result.get('third_integration')
            == common.get('residual_integration') == selected.get('settings')
        and result['residuals'] == common.get('residuals') == selected.get('residuals')
        and selected.get('chi2') == common['chi2']
        and validation.get('passed') is True and validation.get('numerical_checks_passed') is True
        and reproduced.get('passed') is True and reproduced.get('residual_difference') == 0.
        and reproduced.get('saved_chi2') == result['chi2']
        and reproduced.get('recomputed_chi2') == common['chi2'])


def _attempt_diagnostic(case, result, comparable_result, comparable, pair, index, path):
    """Keep actual common-objective points without inheriting a certificate.

    Legacy's old nominal diagnostics cannot be ranked as tight scores. The
    targeted adapter may explicitly supply a common-tight diagnostic, but its
    settings and raw residual/score binding must check independently first.
    An unranked/malformed new claim is retained as an unresolved evidence gap.
    """
    source = comparable_result if comparable else result
    gap = False
    if pair:
        source = {key: value for key, value in source.items() if key != 'diagnostic_best'}
    diagnostic = _diagnostic(source, index, path, comparable)
    extra = result.get('diagnostic_best')
    common_extra_valid = False
    if pair and isinstance(extra, dict) and extra.get('objective') == 'legacy_common_tight':
        try:
            from spherical_geodesics.astrometry.parameters import resolve_theory_bounds
            raw = np.asarray(extra['residuals'], dtype=float)
            theta = np.asarray(extra['theta'], dtype=float)
            bounds = resolve_theory_bounds(case['fit_theory'], case['bounds'])
            observed = np.asarray(case.get('xy_observed', case.get('xy_true')), dtype=float)
            sigma = case['residual_sigma']
            score = float((raw / sigma) @ (raw / sigma))
            valid = bool(extra.get('residual_accuracy') == 'tight'
                and isinstance(case.get('tight_integration'), dict)
                and extra.get('residual_integration') == case['tight_integration']
                and _finite(sigma) and sigma > 0 and theta.shape == (6,)
                and np.all(np.isfinite(theta)) and np.all(theta >= bounds.lower)
                and np.all(theta <= bounds.upper) and raw.ndim == 1
                and observed.ndim == 2 and observed.shape[1] == 2
                and raw.size == observed.size and np.all(np.isfinite(raw))
                and _finite(extra.get('chi2')) and extra['chi2'] >= 0
                and math.isfinite(score)
                and abs(score-extra['chi2']) <= 64*np.finfo(float).eps*max(1., score, extra['chi2']))
        except (KeyError, TypeError, ValueError, FloatingPointError, ZeroDivisionError):
            valid = False
        if valid:
            common_extra_valid = True
            common = _diagnostic(extra, index, path, True)
            common.update(objective='legacy_common_tight',
                residual_accuracy='tight', residual_integration=deepcopy(case['tight_integration']),
                source_file=extra.get('source_file'), checks_passed=False)
            if diagnostic is None or not diagnostic['comparable_across_attempts'] or common['chi2'] < diagnostic['chi2']:
                diagnostic = common
        else:
            gap = True
    # A lower point at another precision is not disposed merely because a
    # subsequent independent run returned a successful third/tight endpoint.
    unresolved = result.get('unresolved_lower_actual_candidates', [])
    invalid = result.get('invalid_actual_evidence', [])
    veto = result.get('lower_failed_candidate_veto', False)
    explained_lower = bool(isinstance(extra, dict) and _finite(extra.get('chi2'))
        and _finite(comparable_result.get('chi2')) and extra['chi2'] < comparable_result['chi2']
        and diagnostic is not None and diagnostic['comparable_across_attempts']
        and diagnostic['chi2'] <= extra['chi2']
        and (common_extra_valid if pair else result.get('residual_accuracy') == 'third'))
    gap = bool(gap or not isinstance(unresolved, list) or unresolved
        or not isinstance(invalid, list) or invalid or type(veto) is not bool
        or (veto and not explained_lower))
    return diagnostic, gap


def _legacy_seed_inventory(root, profile):
    """Reserve all five original streams, plus archived fresh-DE streams.

    Demo executes two streams but reserving all five prevents later collisions
    across profiles. Fresh DE has a plan seed and then its own one-run child.
    """
    inventory = [root, root + 1000]
    for model_root in (root, root + 1000):
        inventory.extend(int(child.generate_state(1, dtype=np.uint32)[0])
                         for child in np.random.SeedSequence(model_root).spawn(5))
        for child in np.random.SeedSequence([model_root, 0xAC0F2026]).spawn(2):
            fresh = int(child.generate_state(1, dtype=np.uint32)[0])
            inventory.extend((fresh, int(np.random.SeedSequence(fresh).spawn(1)[0].generate_state(1, dtype=np.uint32)[0])))
    return inventory


def _seed_plan(cases, pair, profile, count):
    if pair:
        initial = cases['ER'].get('legacy_optimizer_seed')
        if type(initial) is not int or not 0 <= initial < 2**32 or initial != cases['RN'].get('legacy_optimizer_seed'):
            raise ValueError('Legacy pair requires the same explicit uint32 optimizer root')
        first = dict(legacy_optimizer_seed=initial, reserved_seeds=_legacy_seed_inventory(initial, profile))
    else:
        initial = list(next(iter(cases.values())).get('run_seeds', [104729, 130363]))
        if len(initial) != 2 or len(set(initial)) != 2 or any(type(x) is not int or not 0 <= x < 2**32 for x in initial):
            raise ValueError('Exactly two distinct explicit uint32 DE seeds are required')
        first = dict(run_seeds=initial, reserved_seeds=initial)
    used = set(first['reserved_seeds'])
    if len(used) != len(first['reserved_seeds']):
        raise ValueError('Original optimizer seed streams collide')
    plans = [first]
    for attempt in range(1, count):
        salt = 0
        while True:
            digest = hashlib.sha256(json.dumps([VERSION, initial, attempt, salt]).encode('ascii')).digest()
            if pair:
                root = int.from_bytes(digest[:4], 'big') % (2**32 - 1000)
                proposed = dict(legacy_optimizer_seed=root, reserved_seeds=_legacy_seed_inventory(root, profile))
            else:
                seeds = [int.from_bytes(digest[start:start+4], 'big') for start in (0, 4)]
                proposed = dict(run_seeds=seeds, reserved_seeds=seeds)
            reserved = proposed['reserved_seeds']
            if len(reserved) == len(set(reserved)) and not used.intersection(reserved):
                plans.append(proposed)
                used.update(reserved)
                break
            salt += 1
    return plans


def _hard_status(result):
    status = str(result.get('status', ''))
    if status == 'INTERRUPTED':
        return 'INTERRUPTED'
    if status == 'FAILED' or status.endswith('_FAILED'):
        return 'FAILED'
    return None


def _native_acceptance(result):
    """A success flag cannot override an explicit unresolved-candidate veto.

    Adapters own same-objective numerical comparisons; the outer controller
    must not compare a nominal score with a third-precision score or invent
    independent sources. Absent fields preserve the archived adapter contract.
    """
    unresolved = result.get('unresolved_lower_actual_candidates', [])
    veto = result.get('lower_failed_candidate_veto', False)
    return bool(result.get('scientific_checks_passed') is True and result.get('run_complete') is True
                and type(veto) is bool and not veto
                and isinstance(unresolved, list) and not unresolved)


def _blank(case, profile):
    return dict(case_id=case.get('case_id'), dataset_id=case.get('dataset_id'),
        fit_theory=case.get('fit_theory'), fit_pipeline=case.get('fit_pipeline', 's301'),
        fit_pipeline_requested=case.get('fit_pipeline_requested', case.get('fit_pipeline', 's301')),
        fit_pipeline_version=case.get('fit_pipeline_version'), sigma=case.get('residual_sigma'),
        profile=profile, input_metadata=deepcopy(case.get('metadata', {})),
        scientific_checks_passed=False, best_candidate_checks_passed=False, run_complete=False)


def _run(cases, output_dir, workers, profile, cancel_event, policy, pair, absolute_deadline=None):
    # One monotonic clock includes controller preparation and all attempts.
    started = time.monotonic()
    policy = validate_policy(policy)
    if profile not in ('paper', 'demo'):
        raise ValueError('profile must be paper or demo')
    if type(workers) is not int or workers < 1 or (pair and workers != 1):
        raise ValueError('workers must be positive; legacy pairs require workers=1')
    cancel_event = threading.Event() if cancel_event is None else cancel_event
    if cancel_event.is_set():
        raise KeyboardInterrupt('Calculation cancelled before reliability controller started')
    if absolute_deadline is not None and not _finite(absolute_deadline):
        raise ValueError('absolute_deadline must be a finite time.monotonic value')
    cases = deepcopy(cases)
    plans = _seed_plan(cases, pair, profile, policy['max_attempts'])
    wall_key = 'wall_seconds_per_pair' if pair else 'wall_seconds'
    base = next(iter(cases.values())).get(wall_key, 300 if profile == 'demo' else 432000)
    if not _finite(base) or base <= 0:
        raise ValueError(wall_key + ' must be finite and positive')
    if pair and any(case.get(wall_key, base) != base for case in cases.values()):
        raise ValueError('Legacy pair must share the same wall limit')
    factors = [policy['budget_multiplier'] ** index for index in range(policy['max_attempts'])]
    maximum = base * sum(factors)
    if not math.isfinite(maximum):
        raise ValueError('Complete reliability wall budget must be finite')
    directory = Path(output_dir).resolve()
    directory.mkdir(parents=True, exist_ok=False)
    overall_deadline = started + maximum
    if absolute_deadline is not None:
        overall_deadline = min(overall_deadline, absolute_deadline)
    attempts, best, diagnostics = [], {}, {}
    terminal, reason = None, None
    evidence = dict(schema=VERSION, implementation='new_portable_automation_not_historical_retry_replay',
        policy=policy, budget_factors=factors, base_wall_seconds=base,
        maximum_total_wall_seconds=maximum, validation_base_wall_seconds_per_model=60.0,
        validation_wall_seconds_per_model_by_attempt=[60.0 * factor for factor in factors],
        validation_budget_policy='Reserved inside each fixed attempt: at most 60 seconds times factor per model, and at most half of short attempts in total; no transfer between models',
        finalization_scope='Outer endpoint validation only; native candidate and internal audit completion are not guaranteed by this reserve',
        deadline_clock='time.monotonic', absolute_deadline_monotonic=overall_deadline,
        available_total_wall_seconds=max(0.0, overall_deadline-started),
        includes_validation_in_total_budget=True, started_utc=datetime.now(timezone.utc).isoformat(),
        attempts=attempts, seed_plan=plans, historical_run_reproduced=False,
        no_global_optimum_certificate=True, pair_atomic=pair)

    def remaining():
        return max(0.0, overall_deadline - time.monotonic())

    def selected_passes():
        passed = {}
        for name in cases:
            chosen = best.get(name)
            diagnostic = diagnostics.get(name)
            passed[name] = bool(chosen and chosen['passed'] and
                (diagnostic is None or not diagnostic['comparable_across_attempts'] or
                 diagnostic['chi2'] >= chosen['result']['chi2']))
            if pair and any(receipt['models'].get(name, {}).get('native_endpoint_unranked', False) for receipt in attempts):
                passed[name] = False
            if any(receipt['models'].get(name, {}).get('unresolved_evidence_gap', False) for receipt in attempts):
                passed[name] = False
        if pair and (len(best) != len(cases) or len({record['attempt_index'] for record in best.values()}) != 1):
            return {name:False for name in cases}
        return passed

    def save():
        if terminal is not None and terminal != 'INTERRUPTED' and cancel_event.is_set():
            raise KeyboardInterrupt('Reliability controller cancelled before terminal save')
        passed = selected_passes()
        evidence.update(spent_wall_seconds=time.monotonic() - started,
            remaining_wall_seconds=remaining(), attempts_started=len(attempts),
            attempts_completed=sum(receipt['status'] != 'RUNNING' for receipt in attempts), stop_reason=reason,
            controller_finished=terminal is not None, terminal_status=terminal,
            selected_attempts={name:record['attempt_index'] for name, record in best.items()},
            selected_pair_same_attempt=bool(pair and len(best) == len(cases) and
                len({record['attempt_index'] for record in best.values()}) == 1))
        outputs = {}
        for name, case in cases.items():
            chosen = best.get(name)
            result = deepcopy(chosen['result']) if chosen else _blank(case, profile)
            if pair and 'comparison' in result:
                result['native_pair_comparison'] = result.pop('comparison')
            if not chosen:
                for key in _ENDPOINT_KEYS:
                    result.pop(key, None)
            scientific = bool(passed[name] and terminal is not None and terminal not in ('FAILED', 'INTERRUPTED'))
            status = terminal if terminal in ('FAILED', 'INTERRUPTED') else (
                'COMPLETED' if scientific else ('NEEDS_REVIEW_BEST_FOUND' if chosen else 'NEEDS_REVIEW_NO_VALID_CANDIDATE'))
            result.update(status=status, run_complete=terminal is not None and terminal not in ('FAILED', 'INTERRUPTED'),
                scientific_checks_passed=scientific, best_candidate_checks_passed=bool(chosen),
                result_is_demo=profile == 'demo', no_global_optimum_certificate=True,
                historical_run_reproduced=False, reliability=deepcopy(evidence),
                selected_attempt_index=chosen['attempt_index'] if chosen else None,
                selected_result_path=chosen['path'] if chosen else None,
                selected_native_run_complete=chosen['result'].get('run_complete') if chosen else None,
                selected_native_status=chosen['result'].get('status') if chosen else None,
                selected_endpoint_validation=deepcopy(chosen['validation']) if chosen else None,
                reliability_attempts=deepcopy(attempts), best_attempt=chosen['attempt_index'] if chosen else None,
                elapsed_seconds=time.monotonic() - started, stop_reason=reason,
                diagnostic_best=deepcopy(diagnostics.get(name)),
                candidate_selection='Lowest numerically validated retained endpoint across bounded attempts; scientific certificate applies only to its own attempt')
            result['reliability']['selected_attempt_index'] = result['selected_attempt_index']
            result['reliability']['selected_result_path'] = result['selected_result_path']
            result['reliability']['selected_native_run_complete'] = result['selected_native_run_complete']
            if pair:
                (directory / name).mkdir(exist_ok=True)
            if terminal is not None and terminal != 'INTERRUPTED' and cancel_event.is_set():
                raise KeyboardInterrupt('Reliability controller cancelled while saving terminal results')
            _write((directory / name if pair else directory) / 'result.json', result)
            outputs[name] = result
        _write(directory / 'reliability.json', evidence)
        if pair:
            _write(directory / 'pair_result.json', dict(results=outputs,
                scientific_checks_passed=all(passed.values()) and terminal is not None and terminal not in ('FAILED', 'INTERRUPTED'),
                reliability=deepcopy(evidence)))
        if terminal is not None and terminal != 'INTERRUPTED' and cancel_event.is_set():
            raise KeyboardInterrupt('Reliability controller cancelled before returning terminal results')
        return outputs

    save()
    try:
        for index, factor in enumerate(factors):
            if cancel_event.is_set():
                raise KeyboardInterrupt('Reliability controller cancelled')
            if remaining() <= 0:
                reason = 'Cumulative wall budget exhausted; best retained without acceptance'
                break
            attempt_dir = directory / ('attempt_' + str(index + 1).zfill(2))
            tick = time.monotonic()
            attempt_deadline = min(overall_deadline, tick + base * factor)
            allocated = attempt_deadline - tick
            if allocated <= 0:
                reason = 'Cumulative wall budget exhausted; best retained without acceptance'
                break
            split = split_attempt_budget(allocated, factor, len(cases))
            native_deadline = tick + split['native_seconds']
            attempt_cases = deepcopy(cases)
            for name, case in attempt_cases.items():
                case[wall_key] = split['native_seconds'] / factor
                for key in ('run_seeds', 'legacy_optimizer_seed'):
                    if key in plans[index]:
                        case[key] = deepcopy(plans[index][key])
                if pair:
                    model_root = plans[index]['legacy_optimizer_seed'] + (1000 if name == 'RN' else 0)
                    case['run_seeds'] = [int(child.generate_state(1, dtype=np.uint32)[0])
                        for child in np.random.SeedSequence(model_root).spawn(5)]
            receipt = dict(attempt_index=index, directory=str(attempt_dir), budget_factor=factor,
                allocated_wall_seconds=allocated, maximum_validation_wall_seconds_per_model=60.0 * factor,
                allocated_native_wall_seconds=split['native_seconds'],
                reserved_validation_wall_seconds_per_model=split['validation_seconds_per_model'],
                reserved_validation_wall_seconds_total=split['reserved_seconds'],
                started_monotonic=tick, absolute_deadline_monotonic=attempt_deadline,
                native_absolute_deadline_monotonic=native_deadline,
                seed_plan=plans[index], models={}, status='RUNNING')
            attempts.append(receipt)
            save()
            try:
                kwargs = dict(workers=workers, profile=profile, cancel_event=cancel_event,
                    budget_factor=factor, absolute_deadline=native_deadline)
                native = fit_pair(attempt_cases['ER'], attempt_cases['RN'], attempt_dir, **kwargs) if pair else {
                    next(iter(cases)):fit_case(next(iter(attempt_cases.values())), attempt_dir, **kwargs)}
                if not isinstance(native, dict) or set(native) != set(cases) or any(
                        not isinstance(native[name], dict) or 'status' not in native[name] for name in cases):
                    raise RuntimeError('Fitting attempt returned missing or malformed model results')
                for name, result in native.items():
                    for key in ('case_id', 'fit_theory', 'fit_pipeline', 'fit_pipeline_version', 'fit_pipeline_requested'):
                        expected = attempt_cases[name].get(key)
                        if expected is not None and result.get(key) != expected:
                            raise RuntimeError('Fitting result provenance mismatch for ' + name + '.' + key)
                    saved_path = (attempt_dir / name if pair else attempt_dir) / 'result.json'
                    if not saved_path.is_file():
                        raise RuntimeError('Fitting attempt did not save its model result: ' + str(saved_path))
                    saved = json.loads(saved_path.read_text(encoding='utf-8'))
                    if saved != result:
                        raise RuntimeError('Saved fitting result differs from the returned result: ' + str(saved_path))
                hard = next((_hard_status(result) for result in native.values() if _hard_status(result)), None)
                hard_reason = None
                if cancel_event.is_set() or hard == 'INTERRUPTED':
                    raise KeyboardInterrupt('Underlying fitting attempt was interrupted')
                for model_index, name in enumerate(cases):
                    result = native[name]
                    result_path = (attempt_dir / name if pair else attempt_dir) / 'result.json'
                    now = time.monotonic()
                    share = split['validation_seconds_per_model']
                    later_reserved = share * (len(cases) - model_index - 1)
                    validation_deadline = min(now + share, attempt_deadline - later_reserved,
                        overall_deadline)
                    validation_allowance = max(0.0, validation_deadline - now) if not hard else 0.0
                    validation = (dict(passed=False, status='SKIPPED_HARD_FAILURE') if hard else
                        validate_endpoint(attempt_cases[name], result,
                            time.time() + validation_allowance, cancel_event=cancel_event,
                            absolute_deadline=validation_deadline))
                    if cancel_event.is_set():
                        raise KeyboardInterrupt('Reliability controller cancelled after endpoint validation')
                    if not isinstance(validation, dict) or type(validation.get('passed')) is not bool:
                        raise RuntimeError('Endpoint validation returned a malformed report')
                    if validation.get('status') == 'VALIDATION_FAILED':
                        hard = 'FAILED'
                        hard_reason = 'Endpoint validation failed: ' + str(validation.get('error', 'missing or invalid worker result'))
                    comparable_result, comparable = _comparison_result(result, validation, pair)
                    diagnostic, evidence_gap = _attempt_diagnostic(attempt_cases[name], result,
                        comparable_result, comparable, pair, index, result_path)
                    if diagnostic and (name not in diagnostics or
                            (diagnostic['comparable_across_attempts'] and not diagnostics[name]['comparable_across_attempts']) or
                            (diagnostic['comparable_across_attempts'] == diagnostics[name]['comparable_across_attempts'] and diagnostic['chi2'] < diagnostics[name]['chi2'])):
                        diagnostics[name] = diagnostic
                    native_usable = _usable(result)
                    usable = native_usable and _usable(comparable_result) and validation.get('numerical_checks_passed', True) is not False
                    receipt['models'][name] = dict(result_path=str(result_path), status=result['status'],
                        native_run_complete=result.get('run_complete'),
                        native_scientific_checks_passed=result.get('scientific_checks_passed'),
                        native_acceptance_without_candidate_veto=_native_acceptance(result),
                        lower_failed_candidate_veto=result.get('lower_failed_candidate_veto', False),
                        unresolved_lower_actual_candidates=deepcopy(result.get('unresolved_lower_actual_candidates', [])),
                        unresolved_evidence_gap=evidence_gap,
                        best_candidate_checks_passed=result.get('best_candidate_checks_passed'),
                        chi2=result.get('chi2') if _finite(result.get('chi2')) else None,
                        usable_endpoint=usable, validation=validation,
                        allocated_validation_wall_seconds=validation_allowance,
                        validation_absolute_deadline_monotonic=validation_deadline,
                        comparison_chi2=comparable_result.get('chi2') if comparable else None,
                        native_endpoint_unranked=bool(pair and native_usable and not comparable),
                        run_seeds=result.get('run_seeds'), sources=result.get('sources'),
                        diagnostic_best=diagnostic, native_stop_reason=result.get('stop_reason'))
                    candidate = dict(result=comparable_result, comparable=comparable, attempt_index=index, path=str(result_path),
                        validation=validation, passed=bool(_native_acceptance(result) and validation['passed']))
                    previous = best.get(name)
                    same_objective = bool(previous and (comparable == previous['comparable']) and
                        (comparable or (comparable_result.get('residual_integration') == previous['result'].get('residual_integration') and
                                        comparable_result.get('residual_accuracy') == previous['result'].get('residual_accuracy'))))
                    if usable and (previous is None or (comparable and not previous['comparable']) or
                            (same_objective and (comparable_result['chi2'] < previous['result']['chi2'] or
                             (comparable_result['chi2'] == previous['result']['chi2'] and candidate['passed'] and not previous['passed'])))):
                        best[name] = candidate
                receipt.update(status=hard or 'COMPLETED', spent_wall_seconds=time.monotonic() - tick)
                _write(attempt_dir / 'reliability_receipt.json', receipt)
                if hard:
                    terminal, reason = 'FAILED', (hard_reason or 'Hard fitting failure') + '; no automatic retry'
                    break
                if all(selected_passes().values()):
                    terminal, reason = 'COMPLETED', 'Selected minimum passed its own original scientific checks and endpoint validation'
                    break
            except KeyboardInterrupt:
                receipt.update(status='INTERRUPTED', spent_wall_seconds=time.monotonic() - tick)
                if attempt_dir.exists():
                    _write(attempt_dir / 'reliability_receipt.json', receipt)
                raise
            except Exception as exc:
                receipt.update(status='FAILED', error=type(exc).__name__ + ': ' + str(exc),
                    spent_wall_seconds=time.monotonic() - tick)
                if attempt_dir.exists():
                    _write(attempt_dir / 'reliability_receipt.json', receipt)
                terminal, reason = 'FAILED', receipt['error'] + '; no automatic retry'
                break
            save()
        if terminal is None:
            terminal = 'NEEDS_REVIEW_BEST_FOUND'
            reason = reason or 'Maximum attempt count exhausted; selected minima remain explicitly unpassed'
        return save()
    except KeyboardInterrupt:
        terminal, reason = 'INTERRUPTED', 'User interruption; no automatic retry; completed attempts preserved'
        save()
        raise


def fit_case_reliable(case, output_dir, workers=1, profile='paper', cancel_event=None, policy=None,
                      absolute_deadline=None):
    """Fit one case with finite escalating budgets and auditable best retention."""
    name = case.get('fit_theory', 'ER')
    return _run({name:case}, output_dir, workers, profile, cancel_event, policy, False, absolute_deadline)[name]


def fit_pair_reliable(er_case, rn_case, output_dir, workers=1, profile='paper', cancel_event=None, policy=None,
                      absolute_deadline=None):
    """Retry the intact archived paired workflow; never graft pair certificates."""
    return _run({'ER':er_case, 'RN':rn_case}, output_dir, workers, profile, cancel_event, policy, True, absolute_deadline)
