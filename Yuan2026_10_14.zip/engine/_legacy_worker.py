"""Standalone child entry: only archived legacy modules enter this interpreter."""
from __future__ import annotations

from copy import deepcopy
from contextlib import contextmanager
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / 'vendor' / 'legacy'


def _write(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    os.replace(temporary, path)


def bootstrap(variant):
    if variant not in ('baseline', 'extreme'):
        raise ValueError('Unknown legacy variant')
    source = VENDOR / variant
    sys.path.insert(0, str(source))
    import numpy as np
    import scipy
    if (np.__version__, scipy.__version__) != ('1.26.4', '1.13.0'):
        raise RuntimeError('Legacy reproduction requires numpy==1.26.4 and scipy==1.13.0')
    from workflow import study
    if Path(study.__file__).resolve().parent.parent != source.resolve():
        raise RuntimeError('Foreign workflow import in isolated legacy worker')
    return study


def build_profile(payload):
    """Deserialize frozen original budgets and apply the actual paired dataset."""
    import numpy as np
    from spherical_geodesics import CoordinateTimeSettings
    from spherical_geodesics.astrometry import (AdaptivePortfolioConfig, DifferentialEvolutionConfig,
        FitCertificationConfig, LeastSquaresConfig, LocalScreeningConfig)
    from workflow.config import ExperimentProfile
    from workflow.completion_config import AdaptiveCompletionConfig
    from workflow.integration_recovery import IntegrationRecoveryConfig
    document = json.loads((VENDOR / 'configs' / (payload['template'] + '.json')).read_text(encoding='utf-8'))
    specification = deepcopy(document['profile'])
    cases = payload['cases']
    er = cases['ER']
    specification.update(times=np.asarray(er['times'], dtype=float),
        noise_levels=(float(er['residual_sigma']),), realizations=1,
        parameter_bounds=deepcopy(er['bounds']),
        theory_parameter_bounds={name: deepcopy(case['bounds']) for name, case in cases.items()},
        nature='ER', theory_names=('ER', 'RN'))
    # Theory options describe the physical model; never use true parameters as seeds.
    specification['theory_options'] = {name: deepcopy(case.get('fit_theory_options', {})) for name, case in cases.items()}
    for source, destination in (('nominal_integration', 'nominal_settings'), ('tight_integration', 'tight_settings')):
        if source in er:
            specification[destination] = deepcopy(er[source])
    if payload['profile'] == 'demo':
        specification['global_config'].update(runs=2, maxiter=0, popsize=2,
            candidates_per_run=2, archive_candidates_per_run=4, max_local_seeds=2)
        specification['local_config']['max_nfev'] = 3
        specification['portfolio_config'].update(baseline_seeds=2, screening_seeds=2,
            max_promoted_seeds=1, alarm_promoted_seeds=1)
        specification['portfolio_config']['least_squares']['max_nfev'] = 2
        specification['cross_theory_rescue_passes'] = 0
        specification['adaptive_completion_config'].update(continuation_max_nfev=3,
            route_max_nfev=3, precision_max_nfev=3, max_route_seeds=0, max_precision_seeds=0,
            cross_max_passes=0, cross_max_nfev=3, fresh_runs=0, fresh_maxiter=0,
            fresh_max_local_seeds=0, fresh_local_max_nfev=3)
        # Baseline demo retains its original bounded paired precision recovery.
        # Extreme keeps the prior route until its targeted objective is reviewed.
        specification['integration_recovery_config']['local_max_nfev'] = 3
        if payload.get('variant', payload['template'].split('_', 1)[0]) != 'baseline':
            specification['integration_recovery_config']['max_levels'] = 0
    scale_budget_limits(specification, payload.get('budget_factor', 1.0))
    specification['global_config']['mutation'] = tuple(specification['global_config']['mutation'])
    for key, cls in (('global_config', DifferentialEvolutionConfig), ('local_config', LeastSquaresConfig),
                    ('certification_config', FitCertificationConfig), ('adaptive_completion_config', AdaptiveCompletionConfig),
                    ('nominal_settings', CoordinateTimeSettings), ('tight_settings', CoordinateTimeSettings),
                    ('integration_recovery_config', IntegrationRecoveryConfig)):
        specification[key] = cls(**specification[key])
    for key, cls in (('portfolio_config', AdaptivePortfolioConfig), ('screening_config', LocalScreeningConfig)):
        if specification[key] is not None:
            specification[key]['least_squares'] = LeastSquaresConfig(**specification[key]['least_squares'])
            specification[key] = cls(**specification[key])
    return ExperimentProfile(**specification), document


def scale_budget_limits(specification, factor, section=None):
    """Scale evaluation ceilings only, leaving route counts and gates intact."""
    try:
        valid_factor = not isinstance(factor, bool) and isinstance(factor, (int, float)) and math.isfinite(factor) and factor >= 1
    except (OverflowError, ValueError):
        valid_factor = False
    if not valid_factor:
        raise ValueError('budget_factor must be finite and at least 1')
    for key, value in specification.items():
        if isinstance(value, dict):
            scale_budget_limits(value, factor, key)
        elif value is not None and (key.endswith('max_nfev') or key in ('max_forward_calls', 'maxcalls')):
            scaled = math.ceil(value * factor)
            # This frozen recovery dataclass explicitly caps local_max_nfev
            # at 750. Increase the other work budgets without relaxing it.
            specification[key] = min(scaled, 750) if section == 'integration_recovery_config' and key == 'local_max_nfev' else scaled
        elif value is not None and key in ('maxiter', 'fresh_maxiter'):
            # A demo with zero DE generations still grows on its next attempt.
            specification[key] = (math.ceil(factor) - 1 if value == 0 else math.ceil(value * factor))
    return specification


def endpoint_precision_check(record, weighted, raw, tolerance):
    """Check the saved endpoint against the original absolute chi2 criterion.

    This is a numerical precision check only. Route agreement and workflow
    completion are separately reported by the original certification code.
    """
    import numpy as np
    weighted, raw = np.asarray(weighted, dtype=float), np.asarray(raw, dtype=float)
    theta = np.asarray(record['best_theta'], dtype=float)
    score = float(weighted @ weighted)
    saved = float(record['chi2_min'])
    integration = record.get('integration_check', {})
    integration_scores = [integration.get(key) for key in ('nominal_chi2', 'tight_chi2')]
    finite_integration = all(isinstance(value, (int, float, np.number)) and np.isfinite(value)
                             for value in integration_scores)
    finite = bool(weighted.ndim == 1 and raw.shape == weighted.shape and weighted.size > 0
        and weighted.size % 2 == 0 and theta.shape == (6,) and np.all(np.isfinite(theta))
        and np.all(np.isfinite(weighted)) and np.all(np.isfinite(raw))
        and np.isfinite(score) and np.isfinite(saved) and saved >= 0
        and finite_integration)
    consistency = abs(score - saved)
    passed = bool(finite and integration.get('within_tolerance') is True and consistency <= tolerance)
    return dict(passed=passed, finite_endpoint=finite,
        original_integration_check_passed=integration.get('within_tolerance') is True,
        saved_chi2=saved, recomputed_chi2=score, absolute_chi2_change=consistency,
        tolerance=float(tolerance), criterion='original_absolute_delta_chi2')


@contextmanager
def balanced_recovery_route(payload, directory, study):
    """Baseline demo only; original full workflow still owns paired adoption."""
    if payload.get('variant') != 'baseline' or payload.get('profile') != 'demo':
        yield
        return
    from workflow import integration_recovery as recovery
    # This file runs both as an isolated script and as a module in pure tests.
    try:
        from ._legacy_balanced import run_balanced, evidence_wire
    except ImportError:
        from _legacy_balanced import run_balanced, evidence_wire
    original = study.complete_integration_recovery
    with (Path(directory)/'balanced_recovery_raw.jsonl').open('x',encoding='utf-8') as journal:
        def record(event):
            journal.write(json.dumps(evidence_wire(event),allow_nan=False)+'\n')
            journal.flush()
        def balanced(data, profile, results, *, state, checkpoint=None, nominal_settings=None):
            return run_balanced(recovery,data,profile,results,state=state,
                checkpoint=checkpoint,nominal_settings=nominal_settings,
                deadline=payload['pair_deadline_monotonic'],record=record)
        study.complete_integration_recovery = balanced
        try:
            yield
        finally:
            study.complete_integration_recovery = original


def apply_extreme_targeted(payload, directory, study, profile, data, models, results):
    """Additional ER candidates only AFTER the complete original paired stages."""
    if payload['variant'] != 'extreme':
        return
    import numpy as np
    from spherical_geodesics import CoordinateTimeSettings
    from spherical_geodesics.astrometry import TheoryForwardModel, residual, certify_fit_candidates
    from spherical_geodesics.astrometry.optimization import FitCandidate
    from metric_library import build_theory
    if __package__:
        from . import extreme_targeted
    else:
        import extreme_targeted
    case = deepcopy(payload['cases']['ER'])
    case.setdefault('nominal_integration', study._jsonable(profile.nominal_settings))
    case.setdefault('tight_integration', study._jsonable(profile.tight_settings))
    case.setdefault('precision_criterion', dict(kind='absolute_delta_chi2', tolerance=profile.integration_check_tolerance))
    model_cache = {}
    def evaluate(theta, settings):
        key = json.dumps(settings, sort_keys=True)
        if key not in model_cache:
            model_cache[key] = TheoryForwardModel('ER', build_theory, settings=CoordinateTimeSettings(**settings),
                charge_parameter='q', theory_options=study._theory_options(profile, 'ER'))
        return residual(theta, model_cache[key], data)
    def certify(rows):
        from scipy.stats import chi2 as chi2_distribution
        candidates = tuple(FitCandidate(z=np.asarray(row['z']), theta=np.asarray(row['theta']),
            chi2=row['chi2'], source=row['source'], run_index=row['run_index'], success=row['success'],
            message=row['message'], optimality=row.get('optimality')) for row in rows)
        # No old certificate is an input to this new source assessment.
        if not candidates:
            return dict(status='COMPUTATIONALLY_UNRESOLVED', reason='No successful checked local endpoints')
        dof = int(models['ER']['diagnostics']['degrees_of_freedom'])
        quantile = profile.certification_config.goodness_of_fit_quantile
        threshold = None if dof <= 0 or quantile is None else float(chi2_distribution.ppf(quantile, dof))
        goodness_alarm = bool(threshold is not None and min(row['chi2'] for row in rows) > threshold)
        numerical_threshold = (None if profile.portfolio_config is None
            else profile.portfolio_config.scaled_optimality_threshold)
        # Recompute from NEW solver endpoints, never reuse or suppress native alarms.
        best_row = min(rows, key=lambda row: row['chi2'])
        numerical_warning = bool(best_row['success'] is True and (best_row.get('optimality') is None or
            (numerical_threshold is not None and 'xtol' in best_row['message'].lower() and
             best_row['optimality']*case['residual_sigma']**2 > numerical_threshold)))
        certificate = study._jsonable(certify_fit_candidates(candidates, goodness_alarm=goodness_alarm,
            numerical_warning=numerical_warning, config=profile.certification_config).as_mapping())
        certificate.update(goodness_threshold=threshold, degrees_of_freedom=dof,
            scaled_optimality_threshold=numerical_threshold)
        return certificate
    try:
        if (case['bounds'].get('q') != [0., math.sqrt(12./11.)] or
                case['precision_criterion'].get('kind') != 'absolute_delta_chi2' or
                case['precision_criterion'].get('tolerance') != .01):
            document = dict(status='SKIPPED_UNSUPPORTED', triggered=False, scientific_checks_passed=False,
                new_independent_DE_sources=0, reason='Targeted evidence applies only to the original extreme ER domain and precision rule')
            _write(Path(directory) / 'extreme_targeted.json', document)
        else:
            # Exclusive identity, one flushed row per completed actual call;
            # all writes consume the same original parent wall allowance.
            with (Path(directory) / 'extreme_targeted_evaluations.jsonl').open('x', encoding='utf-8') as journal:
                def record_evaluation(row):
                    journal.write(json.dumps(study._jsonable(row), allow_nan=False) + '\n')
                    journal.flush()
                document = extreme_targeted.run(case, study._jsonable(models['ER']),
                    limits=extreme_targeted.limits_for(payload['profile'], payload['pair_deadline_monotonic']),
                    evaluate=evaluate, certify=certify, certification_config=study._jsonable(profile.certification_config),
                    record_evaluation=record_evaluation,
                    save=lambda value: _write(Path(directory) / 'extreme_targeted.json', study._jsonable(value)))
    except Exception as exc:
        document = dict(status='NEEDS_REVIEW', triggered=True, scientific_checks_passed=False,
            selected=None, errors=[repr(exc)], new_independent_DE_sources=0)
        _write(Path(directory) / 'extreme_targeted.json', document)
    result = results['ER']
    result['targeted_remediation'] = dict(evidence_file='extreme_targeted.json', status=document['status'],
        triggered=document['triggered'], scientific_checks_passed=document['scientific_checks_passed'],
        new_independent_DE_sources=0, certification=document.get('certification'),
        evaluation_journal='extreme_targeted_evaluations.jsonl')
    if not document['triggered']:
        return
    result['native_legacy_record'] = deepcopy(models['ER'])
    result['native_comparison'] = deepcopy(result['comparison'])
    result['scientific_checks_passed'] = bool(document['scientific_checks_passed'])
    result['status'] = 'COMPLETED' if document['scientific_checks_passed'] else 'NEEDS_REVIEW'
    unresolved = []
    for index, candidate in enumerate(document.get('lower_unverified', [])):
        unresolved.append(dict(deepcopy(candidate), evidence_file='extreme_targeted.json',
            evidence_field='lower_unverified', evidence_index=index,
            disposition='UNRESOLVED_LOWER_ACTUAL_SAME_PRECISION'))
    if document.get('known_lower_unresolved') is True and not unresolved:
        unresolved.append(dict(kind='INCOMPLETE_CANDIDATE_EVIDENCE',
            evidence_file='extreme_targeted.json', targeted_status=document['status'],
            reason='Shared budget or failed validation left the full candidate/precision inventory unresolved; no score is inferred'))
    result['unresolved_lower_actual_candidates'] = unresolved
    lowest = document.get('lowest_actual_tight')
    if lowest:
        result['diagnostic_best'] = dict(theta=lowest['theta'], chi2=lowest['chi2'],
            checks_passed=False, id='targeted_lowest_actual_tight', source_file='extreme_targeted.json',
            objective='legacy_common_tight', residual_accuracy='tight',
            residual_integration=case['tight_integration'], residuals=lowest.get('raw_residuals'))
    if not document['scientific_checks_passed']:
        comparison = deepcopy(result['comparison'])
        comparison.update(usable_for_comparison=False, targeted_ER_requires_review=True)
        for row in results.values():
            row['comparison'] = comparison
    selected = document.get('selected')
    if selected is None or not selected.get('passed'):
        result['targeted_lower_candidates_require_review'] = True
        return
    nominal, tight = (selected['levels'][key] for key in ('nominal', 'tight'))
    record = deepcopy(models['ER'])
    record.update(best_theta=selected['theta'], chi2_min=tight['chi2'],
        best_z=((np.asarray(selected['theta'])-np.asarray([case['bounds'][key][0] for key in extreme_targeted.NAMES])) /
                np.asarray([case['bounds'][key][1]-case['bounds'][key][0] for key in extreme_targeted.NAMES])).tolist(),
        best_source='targeted_lowest_actual_candidate', local_candidates=document.get('certification_candidates', []),
        fit_objective=dict(level=1, settings=case['tight_integration'], source='targeted_common_tight_objective'),
        integration_check=dict(nominal_chi2=nominal['chi2'], tight_chi2=tight['chi2'], within_tolerance=True,
            nominal_settings=case['nominal_integration'], tight_settings=case['tight_integration'],
            tolerance=profile.integration_check_tolerance, theta=selected['theta'], targeted_three_precision=selected),
        targeted_certification=document.get('certification'), native_record_preserved_separately=True)
    record['best_fit_parameters'] = dict(zip(extreme_targeted.NAMES, selected['theta']))
    record['best_fit_parameters']['Q'] = selected['theta'][0]*selected['theta'][1]
    certificate = document.get('certification') or {}
    endpoint_certificate = certificate.get('original_certifier_successful_endpoints', {})
    record['native_diagnostics'] = record.pop('diagnostics')
    record['diagnostics'] = dict(workflow_complete=True,
        degrees_of_freedom=record['native_diagnostics']['degrees_of_freedom'],
        certification_status=certificate.get('status', 'COMPUTATIONALLY_UNRESOLVED'),
        certification=certificate, integration_check_within_tolerance=True,
        certification_reason='Fresh targeted endpoint/source evidence; native certificate not transferred',
        certification_goodness_alarm=endpoint_certificate.get('goodness_alarm'),
        certification_goodness_threshold=endpoint_certificate.get('goodness_threshold'),
        portfolio_post_numerical_alarm=endpoint_certificate.get('numerical_warning'),
        fit_quality=endpoint_certificate.get('fit_quality'), global_optimum_proven=False,
        local_candidate_count=len(document.get('certification_candidates', [])))
    weighted = np.asarray(tight['weighted_residuals'])
    raw = np.asarray(tight['raw_residuals'])
    endpoint = endpoint_precision_check(record, weighted, raw, profile.integration_check_tolerance)
    result.update(theta=selected['theta'], chi2=tight['chi2'], residuals=raw.tolist(),
        residual_check_chi2=tight['chi2'], residual_accuracy='tight', residual_integration=case['tight_integration'],
        fit_objective=record['fit_objective'], legacy_record=record,
        best_candidate_checks_passed=endpoint['passed'], endpoint_precision_check=endpoint,
        numerical_policy=result['numerical_policy'] + '; bounded inherited-DE extreme ER face/adaptive candidates; fresh certificate')
    paired = dict(models, ER=record)
    comparison = study.comparison_rows(paired, ('ER', 'RN'))[0]
    comparison['native_paired_stages_unchanged'] = True
    comparison['targeted_ER_certificate_separate'] = True
    if not document['scientific_checks_passed']:
        comparison['usable_for_comparison'] = False
    for name in results:
        results[name].setdefault('native_comparison', deepcopy(results[name]['comparison']))
        results[name]['comparison'] = comparison


def execute(payload, directory, study=None):
    study = bootstrap(payload['variant']) if study is None else study
    import numpy as np
    import scipy
    from spherical_geodesics import CoordinateTimeSettings
    from spherical_geodesics.astrometry import PlanarAstrometryData, TheoryForwardModel, residual
    from metric_library import build_theory
    profile, template = build_profile(payload)
    er = payload['cases']['ER']
    xy = np.asarray(payload['xy_observed'], dtype=float)
    sigma = float(er['residual_sigma'])
    data = PlanarAstrometryData(times=profile.times, x_obs=xy[:, 0], y_obs=xy[:, 1],
        sigma_x=np.full(len(xy), sigma), sigma_y=np.full(len(xy), sigma))
    models, state = {}, {}
    directory = Path(directory)
    def checkpoint():
        _write(directory / 'checkpoint.json', study._jsonable(dict(models=models, workflow_state=state,
            profile=profile, optimizer_seed=payload['optimizer_seed'], template_provenance=template)))
    checkpoint()
    # This is the original complete paired entry, including both cross-theory
    # stages and common-objective integration recovery. Do not split into arms.
    with balanced_recovery_route(payload, directory, study):
        study.fit_dataset(data, profile, experiment_seed=payload['optimizer_seed'],
            completed_models=models, workflow_state=state, checkpoint=checkpoint)
    comparison = study.comparison_rows(models, ('ER', 'RN'))[0]
    results = {}
    for name, record in models.items():
        case = payload['cases'][name]
        objective = record['fit_objective']
        integration = CoordinateTimeSettings(**objective['settings'])
        model = TheoryForwardModel(name, build_theory, settings=integration,
            charge_parameter='q', theory_options=study._theory_options(profile, name))
        weighted = residual(np.asarray(record['best_theta']), model, data)
        raw = weighted * sigma
        endpoint_check = endpoint_precision_check(record, weighted, raw, profile.integration_check_tolerance)
        checked = bool(state['complete'] and endpoint_check['passed'] and
            record['diagnostics']['certification_status'] in ('REPEATABLE_SOLUTION', 'MULTIPLE_NEAR_EQUAL_SOLUTIONS'))
        results[name] = dict(case_id=case['case_id'], fit_theory=name,
            status='COMPLETED', run_complete=bool(state['complete']), scientific_checks_passed=checked,
            best_candidate_checks_passed=endpoint_check['passed'], endpoint_precision_check=endpoint_check,
            theta=record['best_theta'], chi2=record['chi2_min'], residuals=raw.tolist(),
            residual_accuracy='tight' if objective['level'] else 'nominal',
            residual_semantics='Unweighted observed-coordinate residuals, interleaved x/y; chi2=sum((residual/sigma)^2)',
            residual_integration=objective['settings'], residual_check_chi2=float(weighted @ weighted),
            fit_objective=objective, legacy_record=record, comparison=comparison,
            run_seeds=[run['random_seed'] for run in record.get('global_runs', [])],
            optimizer_seed=payload['optimizer_seed'] + (1000 if name == 'RN' else 0),
            numpy_version=np.__version__, scipy_version=scipy.__version__,
            historical_python_version=template['runtime_versions']['python'],
            python_version=sys.version.split()[0], template_manifest_sha256=template['source_manifest_sha256'],
            numerical_policy='Original legacy DE/TRF workflow; explicit dataset nominal/tight integration settings; original absolute delta chi2 precision criterion; portable factor scales evaluation/iteration budgets within frozen hard caps; demo reduces budgets only',
            portable_budget_factor=payload.get('budget_factor', 1.0),
            original_hard_budget_caps={'integration_recovery_config.local_max_nfev':750},
            nominal_integration=study._jsonable(profile.nominal_settings),
            tight_integration=study._jsonable(profile.tight_settings),
            precision_criterion=dict(kind='absolute_delta_chi2', tolerance=profile.integration_check_tolerance))
        balanced = record['diagnostics'].get('balanced_actual_review')
        if balanced is not None:
            results[name]['balanced_recovery_evidence'] = dict(
                raw_journal='balanced_recovery_raw.jsonl', actual_review=balanced,
                schedule=state.get('integration_recovery',{}).get('balanced_schedule'),
                new_independent_DE_votes=0)
            if balanced['known_lower_unresolved']:
                results[name]['unresolved_lower_actual_candidates'] = [dict(
                    balanced['actual_minimum'], disposition='UNRESOLVED_LOWER_ACTUAL_SAME_PRECISION',
                    evidence_file='balanced_recovery_raw.jsonl')]
    apply_extreme_targeted(payload, directory, study, profile, data, models, results)
    comparison = results['ER']['comparison']
    _write(directory / 'pair_result.json', dict(results=results, comparison=comparison))
    return results


def main():
    payload = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    directory = Path(sys.argv[2])
    try:
        execute(payload, directory)
    except BaseException as exc:
        _write(directory / 'worker_error.json', dict(type=type(exc).__name__, message=str(exc), traceback=traceback.format_exc()))
        raise


if __name__ == '__main__':
    main()
