"""Standalone child entry: only archived legacy modules enter this interpreter."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / 'vendor' / 'legacy'


def _write(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    os.replace(temporary, path)


def bootstrap(variant):
    if variant not in ('baseline', 'extreme'):
        raise ValueError('Unknown legacy variant')
    source = VENDOR / variant
    sys.path.insert(0, str(source))
    import numpy as np
    import scipy
    if (np.__version__, scipy.__version__) != ('1.26.4', '1.13.0'):
        raise RuntimeError('Legacy reproduction requires numpy==1.26.4 and scipy==1.13.0')
    from workflow import study
    if Path(study.__file__).resolve().parent.parent != source.resolve():
        raise RuntimeError('Foreign workflow import in isolated legacy worker')
    return study


def build_profile(payload):
    """Deserialize frozen original budgets and apply the actual paired dataset."""
    import numpy as np
    from spherical_geodesics import CoordinateTimeSettings
    from spherical_geodesics.astrometry import (AdaptivePortfolioConfig, DifferentialEvolutionConfig,
        FitCertificationConfig, LeastSquaresConfig, LocalScreeningConfig)
    from workflow.config import ExperimentProfile
    from workflow.completion_config import AdaptiveCompletionConfig
    from workflow.integration_recovery import IntegrationRecoveryConfig
    document = json.loads((VENDOR / 'configs' / (payload['template'] + '.json')).read_text(encoding='utf-8'))
    specification = deepcopy(document['profile'])
    cases = payload['cases']
    er = cases['ER']
    specification.update(times=np.asarray(er['times'], dtype=float),
        noise_levels=(float(er['residual_sigma']),), realizations=1,
        parameter_bounds=deepcopy(er['bounds']),
        theory_parameter_bounds={name: deepcopy(case['bounds']) for name, case in cases.items()},
        nature='ER', theory_names=('ER', 'RN'))
    # Theory options describe the physical model; never use true parameters as seeds.
    specification['theory_options'] = {name: deepcopy(case.get('fit_theory_options', {})) for name, case in cases.items()}
    for source, destination in (('nominal_integration', 'nominal_settings'), ('tight_integration', 'tight_settings')):
        if source in er:
            specification[destination] = deepcopy(er[source])
    if payload['profile'] == 'demo':
        specification['global_config'].update(runs=2, maxiter=0, popsize=2,
            candidates_per_run=2, archive_candidates_per_run=4, max_local_seeds=2)
        specification['local_config']['max_nfev'] = 3
        specification['portfolio_config'].update(baseline_seeds=2, screening_seeds=2,
            max_promoted_seeds=1, alarm_promoted_seeds=1)
        specification['portfolio_config']['least_squares']['max_nfev'] = 2
        specification['cross_theory_rescue_passes'] = 0
        specification['adaptive_completion_config'].update(continuation_max_nfev=3,
            route_max_nfev=3, precision_max_nfev=3, max_route_seeds=0, max_precision_seeds=0,
            cross_max_passes=0, cross_max_nfev=3, fresh_runs=0, fresh_maxiter=0,
            fresh_max_local_seeds=0, fresh_local_max_nfev=3)
        specification['integration_recovery_config'].update(max_levels=0, local_max_nfev=3)
    specification['global_config']['mutation'] = tuple(specification['global_config']['mutation'])
    for key, cls in (('global_config', DifferentialEvolutionConfig), ('local_config', LeastSquaresConfig),
                    ('certification_config', FitCertificationConfig), ('adaptive_completion_config', AdaptiveCompletionConfig),
                    ('nominal_settings', CoordinateTimeSettings), ('tight_settings', CoordinateTimeSettings),
                    ('integration_recovery_config', IntegrationRecoveryConfig)):
        specification[key] = cls(**specification[key])
    for key, cls in (('portfolio_config', AdaptivePortfolioConfig), ('screening_config', LocalScreeningConfig)):
        if specification[key] is not None:
            specification[key]['least_squares'] = LeastSquaresConfig(**specification[key]['least_squares'])
            specification[key] = cls(**specification[key])
    return ExperimentProfile(**specification), document


def endpoint_precision_check(record, weighted, raw, tolerance):
    """Check the saved endpoint against the original absolute chi2 criterion.

    This is a numerical precision check only. Route agreement and workflow
    completion are separately reported by the original certification code.
    """
    import numpy as np
    weighted, raw = np.asarray(weighted, dtype=float), np.asarray(raw, dtype=float)
    theta = np.asarray(record['best_theta'], dtype=float)
    score = float(weighted @ weighted)
    saved = float(record['chi2_min'])
    integration = record.get('integration_check', {})
    integration_scores = [integration.get(key) for key in ('nominal_chi2', 'tight_chi2')]
    finite_integration = all(isinstance(value, (int, float, np.number)) and np.isfinite(value)
                             for value in integration_scores)
    finite = bool(weighted.ndim == 1 and raw.shape == weighted.shape and weighted.size > 0
        and weighted.size % 2 == 0 and theta.shape == (6,) and np.all(np.isfinite(theta))
        and np.all(np.isfinite(weighted)) and np.all(np.isfinite(raw))
        and np.isfinite(score) and np.isfinite(saved) and saved >= 0
        and finite_integration)
    consistency = abs(score - saved)
    passed = bool(finite and integration.get('within_tolerance') is True and consistency <= tolerance)
    return dict(passed=passed, finite_endpoint=finite,
        original_integration_check_passed=integration.get('within_tolerance') is True,
        saved_chi2=saved, recomputed_chi2=score, absolute_chi2_change=consistency,
        tolerance=float(tolerance), criterion='original_absolute_delta_chi2')


def execute(payload, directory, study=None):
    study = bootstrap(payload['variant']) if study is None else study
    import numpy as np
    import scipy
    from spherical_geodesics import CoordinateTimeSettings
    from spherical_geodesics.astrometry import PlanarAstrometryData, TheoryForwardModel, residual
    from metric_library import build_theory
    profile, template = build_profile(payload)
    er = payload['cases']['ER']
    xy = np.asarray(payload['xy_observed'], dtype=float)
    sigma = float(er['residual_sigma'])
    data = PlanarAstrometryData(times=profile.times, x_obs=xy[:, 0], y_obs=xy[:, 1],
        sigma_x=np.full(len(xy), sigma), sigma_y=np.full(len(xy), sigma))
    models, state = {}, {}
    directory = Path(directory)
    def checkpoint():
        _write(directory / 'checkpoint.json', study._jsonable(dict(models=models, workflow_state=state,
            profile=profile, optimizer_seed=payload['optimizer_seed'], template_provenance=template)))
    checkpoint()
    # This is the original complete paired entry, including both cross-theory
    # stages and common-objective integration recovery. Do not split into arms.
    study.fit_dataset(data, profile, experiment_seed=payload['optimizer_seed'],
        completed_models=models, workflow_state=state, checkpoint=checkpoint)
    comparison = study.comparison_rows(models, ('ER', 'RN'))[0]
    results = {}
    for name, record in models.items():
        case = payload['cases'][name]
        objective = record['fit_objective']
        integration = CoordinateTimeSettings(**objective['settings'])
        model = TheoryForwardModel(name, build_theory, settings=integration,
            charge_parameter='q', theory_options=study._theory_options(profile, name))
        weighted = residual(np.asarray(record['best_theta']), model, data)
        raw = weighted * sigma
        endpoint_check = endpoint_precision_check(record, weighted, raw, profile.integration_check_tolerance)
        checked = bool(state['complete'] and endpoint_check['passed'] and
            record['diagnostics']['certification_status'] in ('REPEATABLE_SOLUTION', 'MULTIPLE_NEAR_EQUAL_SOLUTIONS'))
        results[name] = dict(case_id=case['case_id'], fit_theory=name,
            status='COMPLETED', run_complete=bool(state['complete']), scientific_checks_passed=checked,
            best_candidate_checks_passed=endpoint_check['passed'], endpoint_precision_check=endpoint_check,
            theta=record['best_theta'], chi2=record['chi2_min'], residuals=raw.tolist(),
            residual_accuracy='tight' if objective['level'] else 'nominal',
            residual_semantics='Unweighted observed-coordinate residuals, interleaved x/y; chi2=sum((residual/sigma)^2)',
            residual_integration=objective['settings'], residual_check_chi2=float(weighted @ weighted),
            fit_objective=objective, legacy_record=record, comparison=comparison,
            run_seeds=[run['random_seed'] for run in record.get('global_runs', [])],
            optimizer_seed=payload['optimizer_seed'] + (1000 if name == 'RN' else 0),
            numpy_version=np.__version__, scipy_version=scipy.__version__,
            historical_python_version=template['runtime_versions']['python'],
            python_version=sys.version.split()[0], template_manifest_sha256=template['source_manifest_sha256'],
            numerical_policy='Original legacy DE/TRF workflow and budgets; explicit dataset nominal/tight integration settings; original absolute delta chi2 precision criterion; demo reduces budgets only',
            nominal_integration=study._jsonable(profile.nominal_settings),
            tight_integration=study._jsonable(profile.tight_settings),
            precision_criterion=dict(kind='absolute_delta_chi2', tolerance=profile.integration_check_tolerance))
    _write(directory / 'pair_result.json', dict(results=results, comparison=comparison))
    return results


def main():
    payload = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    directory = Path(sys.argv[2])
    try:
        execute(payload, directory)
    except BaseException as exc:
        _write(directory / 'worker_error.json', dict(type=type(exc).__name__, message=str(exc), traceback=traceback.format_exc()))
        raise


if __name__ == '__main__':
    main()
