"""Auditable endpoint and injected-parameter checks, never optimizer seeds.

Passing these necessary checks is not a global-minimum certificate. The
historical multi-source/precision gates remain separate and are not relaxed.
"""
from copy import deepcopy
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

import numpy as np


def _cancel(cancel_event):
    if cancel_event is not None and cancel_event.is_set():
        raise KeyboardInterrupt('Fixed-point validation cancelled')


def _finite_scalar(value):
    return (not isinstance(value, (bool, str)) and isinstance(value, (int, float))
            and math.isfinite(value))


def _roundoff(*values):
    return 64 * np.finfo(float).eps * max(1., *(abs(value) for value in values))


def _fixed_point_check(case, result, payload, evidence):
    """Pure checks, also exercised by regression tests using audit counterexamples."""
    sigma = payload['sigma']
    criterion = payload.get('precision_criterion', case.get('precision_criterion', {}))
    historical = criterion.get('kind') == 'absolute_delta_chi2'
    tolerance = criterion.get('tolerance') if historical else case.get('precision_vector_ceiling', case.get('threshold_D'))
    if not _finite_scalar(tolerance) or tolerance <= 0:
        raise ValueError('Missing positive original precision tolerance')

    def precision(levels):
        if historical:
            discrepancy = abs(levels['nominal']['chi2'] - levels['tight']['chi2'])
            nominal = np.asarray(levels['nominal']['residuals'])
            tight = np.asarray(levels['tight']['residuals'])
            vector_difference = float(np.linalg.norm(nominal-tight))
            scale = (2*float(np.linalg.norm(tight))*vector_difference + vector_difference**2)/sigma**2
            return dict(passed=discrepancy <= tolerance, measured=discrepancy,
                        tolerance=tolerance, kind='absolute_delta_chi2', chi2_scale=scale,
                        measured_residual_difference=vector_difference)
        tight = np.asarray(levels['tight']['residuals'])
        selected = np.asarray(levels['selected']['residuals'])
        discrepancy = float(np.linalg.norm(tight - selected))
        scale = (2 * float(np.linalg.norm(selected)) * discrepancy + discrepancy**2) / sigma**2
        return dict(passed=discrepancy <= tolerance, measured=discrepancy,
                    tolerance=tolerance, kind='tight_selected_residual_vector', chi2_scale=scale)

    fitted = evidence['fitted']['levels']
    fitted_precision = precision(fitted)
    saved = float(result['chi2'])
    measured = float(fitted['selected']['chi2'])
    raw_saved = np.asarray(result['residuals'], dtype=float).ravel()
    raw_measured = np.asarray(fitted['selected']['residuals'], dtype=float)
    # The same runtime/settings/point must reproduce both value and residuals.
    # This is not a new optimization tolerance or permission to change data.
    scalar_tolerance = _roundoff(saved, measured)
    vector_tolerance = _roundoff(float(np.linalg.norm(raw_saved)), float(np.linalg.norm(raw_measured)))
    consistent = (abs(saved - measured) <= scalar_tolerance
                  and float(np.linalg.norm(raw_saved - raw_measured)) <= vector_tolerance)
    checks = dict(endpoint_precision=fitted_precision,
        saved_endpoint_reproduced=dict(passed=bool(consistent), saved_chi2=saved,
            recomputed_chi2=measured, tolerance=scalar_tolerance,
            residual_difference=float(np.linalg.norm(raw_saved - raw_measured)),
            residual_tolerance=vector_tolerance))
    comparison_level = 'comparison' if payload.get('pipeline') == 'legacy' else 'selected'
    comparison = fitted[comparison_level]
    comparison_score = comparison['chi2']

    def comparison_precision(levels):
        # A common ranking objective is not automatically a checked objective.
        # Retain the original criterion when comparing it with the selected
        # endpoint. For S301 these are the same third-precision evaluation.
        checked = precision(dict(nominal=levels[comparison_level],
                                 tight=levels['selected'] if historical else levels[comparison_level],
                                 selected=levels['selected']))
        checked['comparison_level'] = comparison_level
        checked['reference_level'] = 'selected'
        if not historical:
            checked['kind'] = 'comparison_selected_residual_vector'
        return checked

    fitted_comparison_precision = comparison_precision(fitted)
    checks['comparison_endpoint_precision'] = fitted_comparison_precision
    if 'injected' in evidence:
        injected = evidence['injected']['levels']
        injected_precision = precision(injected)
        injected_comparison_precision = comparison_precision(injected)
        truth_score = float(injected[comparison_level]['chi2'])
        # Keep the original precision gate, but do not reuse its acceptance
        # ceiling as permission to ignore a measurably better feasible point.
        # This is an empirical residual-difference scale, not an error bound.
        scales = dict(fitted_precision=fitted_precision['chi2_scale'],
            injected_precision=injected_precision['chi2_scale'],
            fitted_comparison=fitted_comparison_precision['chi2_scale'],
            injected_comparison=injected_comparison_precision['chi2_scale'])
        allowance = sum(scales.values()) + 1e-8
        baseline_passed = comparison_score <= truth_score + allowance
        checks['injected_precision'] = injected_precision
        checks['injected_comparison_precision'] = injected_comparison_precision
        baseline = dict(applicable=True, passed=bool(baseline_passed),
            fitted_chi2=comparison_score, injected_chi2=truth_score,
            excess=comparison_score-truth_score, numerical_allowance=allowance,
            numerical_allowance_components=scales,
            allowance_policy='Measured residual-difference scales plus 1e-8; original precision gate unchanged',
            reference_used_as_optimizer_seed=False,
            interpretation='Necessary feasible-candidate check; not proof of a global minimum.')
    else:
        baseline = dict(applicable=False, passed=None, reason=payload['truth_skip_reason'],
                        reference_used_as_optimizer_seed=False)
    numerical_passed = bool(consistent and fitted_precision['passed'] and fitted_comparison_precision['passed'])
    passed = (numerical_passed and
              (not baseline['applicable'] or (baseline['passed'] and checks['injected_precision']['passed']
                                             and checks['injected_comparison_precision']['passed'])))
    return dict(passed=bool(passed), numerical_checks_passed=numerical_passed,
                status='PASSED' if passed else 'NEEDS_REVIEW',
                checks=checks, truth_baseline=baseline, fixed_point_evidence=evidence,
                comparison_endpoint=dict(chi2=comparison_score, residuals=comparison['residuals'],
                    residual_accuracy='tight' if payload.get('pipeline') == 'legacy' else 'third',
                    residual_integration=comparison['settings']),
                comparison_policy='Same fixed-point objective across attempts: legacy tight / S301 third.',
                no_global_optimum_certificate=True)


def _payload(case, result):
    from spherical_geodesics.astrometry.parameters import resolve_theory_bounds
    from hybrid_support import third_settings
    bounds = resolve_theory_bounds(case['fit_theory'], case['bounds'])
    theta = np.asarray(result.get('theta', []), dtype=float)
    observed = np.asarray(case['xy_observed'] if 'xy_observed' in case else case['xy_true'], dtype=float)
    raw = np.asarray(result.get('residuals', []), dtype=float).ravel()
    sigma = case.get('residual_sigma')
    score = result.get('chi2')
    if (result.get('best_candidate_checks_passed') is not True or theta.shape != (6,)
            or not np.all(np.isfinite(theta)) or np.any(theta < bounds.lower) or np.any(theta > bounds.upper)
            or observed.ndim != 2 or observed.shape[1] != 2 or raw.size != observed.size
            or not np.all(np.isfinite(raw)) or not _finite_scalar(sigma) or sigma <= 0
            or not _finite_scalar(score) or score < 0):
        raise ValueError('No numerically checked, finite, bounded endpoint with complete residuals')
    reconstructed = float((raw/sigma) @ (raw/sigma))
    if abs(reconstructed-score) > _roundoff(reconstructed, score):
        raise ValueError('Saved chi2 disagrees with the saved residual vector')
    if case.get('fit_pipeline') == 'legacy':
        settings = result.get('residual_integration', result.get('fit_objective', {}).get('settings'))
        if not isinstance(settings, dict):
            raise ValueError('Legacy endpoint lacks its actual integration settings')
    else:
        config_path = Path(__file__).resolve().parents[1] / 'vendor' / 'numerical_template.json'
        settings = third_settings(case, json.loads(config_path.read_text(encoding='utf-8'))['third_integration'])
    vectors = dict(fitted=theta.tolist())
    truth = case.get('metadata', {}).get('theta_true', case.get('reference_theta'))
    if case.get('generating_theory') != case.get('fit_theory'):
        reason = 'Generating and fitted theories differ; injected ER truth is not an RN benchmark.'
    elif truth is None:
        reason = 'No injected parameter vector is available.'
    else:
        truth = np.asarray(truth, dtype=float)
        if truth.shape != (6,) or not np.all(np.isfinite(truth)):
            raise ValueError('Invalid injected parameter vector')
        if np.any(truth < bounds.lower) or np.any(truth > bounds.upper):
            reason = 'Injected parameters lie outside the effective fit bounds.'
        else:
            vectors['injected'] = truth.tolist()
            reason = None
    # The public legacy adapter also accepts inputs that use its frozen
    # defaults; those effective settings are saved in the native result.
    nominal = case.get('nominal_integration', result.get('nominal_integration'))
    tight = case.get('tight_integration', result.get('tight_integration'))
    if not isinstance(nominal, dict) or not isinstance(tight, dict):
        raise ValueError('Endpoint lacks effective nominal/tight integration settings')
    integrations = dict(nominal=nominal, tight=tight, selected=settings)
    if case.get('fit_pipeline') == 'legacy':
        # An archived integration-recovery stage can legitimately replace the
        # original nominal/tight pair by tight/stricter. Validate that actual
        # pair, while ranking every attempt at the same catalogue tight level.
        checked_pair = result.get('legacy_record', {}).get('integration_check', {})
        for key in ('nominal', 'tight'):
            actual = checked_pair.get(key + '_settings')
            if isinstance(actual, dict):
                integrations[key] = deepcopy(actual)
        integrations['comparison'] = deepcopy(tight)
    return dict(pipeline=case.get('fit_pipeline', 's301'), legacy_variant=case.get('legacy_variant'),
        theory=case['fit_theory'], theory_options=deepcopy(case.get('fit_theory_options', case.get('theory_options', {}))),
        observed=observed.tolist(), times=case['times'], sigma=sigma, vectors=vectors,
        integrations=integrations,
        precision_criterion=deepcopy(case.get('precision_criterion', result.get('precision_criterion', {}))),
        truth_skip_reason=reason,
        observation_sha256=hashlib.sha256(np.ascontiguousarray(observed, dtype='<f8').tobytes()).hexdigest(),
        effective_bounds=dict(lower=bounds.lower.tolist(), upper=bounds.upper.tolist()))


def validate_endpoint(case, result, deadline, cancel_event=None, absolute_deadline=None):
    """Bounded fixed-point re-evaluation, with no fits and no truth seeding.

    ``deadline`` retains the original absolute time.time() interface. The optional
    internal ``absolute_deadline`` is a time.monotonic() cap. Convert once at
    entry, before payload preparation, and never reset that monotonic deadline.
    A failed/timed-out validation stays unpassed; it never changes the score.
    """
    _cancel(cancel_event)
    started, epoch = time.monotonic(), time.time()
    if not _finite_scalar(deadline) or (absolute_deadline is not None and not _finite_scalar(absolute_deadline)):
        raise ValueError('Validation deadlines must be finite clock values')
    finish = started + max(0.0, deadline - epoch)
    if absolute_deadline is not None:
        finish = min(finish, absolute_deadline)
    remaining = max(0.0, finish - started)

    def expired():
        _cancel(cancel_event)  # Cancellation always takes priority over budget.
        return time.monotonic() >= finish

    def timeout():
        return dict(passed=False, status='VALIDATION_BUDGET_EXHAUSTED',
            time_limit_seconds=remaining, absolute_deadline_monotonic=finish)

    if expired():
        return timeout()
    try:
        payload = _payload(case, result)
    except (ValueError, TypeError, KeyError) as exc:
        if expired():
            return timeout()
        return dict(passed=False, numerical_checks_passed=False, status='NO_VALID_ENDPOINT', error=str(exc))
    if expired():
        return timeout()
    worker = Path(__file__).with_name('_validation_worker.py')
    process = None
    try:
        with tempfile.TemporaryDirectory(prefix='er_rn_validation_') as folder:
            directory = Path(folder)
            request, response = directory/'input.json', directory/'result.json'
            request.write_text(json.dumps(payload, allow_nan=False), encoding='utf-8')
            environment = os.environ.copy()
            for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'BLIS_NUM_THREADS'):
                environment[key] = '1'
            with (directory/'worker.log').open('w', encoding='utf-8') as log:
                if expired():
                    return timeout()
                process = subprocess.Popen([sys.executable, '-E', '-B', str(worker), str(request), str(response)],
                    stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, cwd=directory,
                    env=environment, creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
                try:
                    while process.poll() is None:
                        if expired():
                            return timeout()
                        time.sleep(min(.05, max(0.0, finish-time.monotonic())))
                    _cancel(cancel_event)
                finally:
                    if process.poll() is None:
                        process.kill()
                    process.wait(timeout=10)
            if expired():
                return timeout()
            if not response.is_file():
                return dict(passed=False, status='VALIDATION_FAILED',
                            error=(directory/'worker.log').read_text(encoding='utf-8')[-4000:])
            document = json.loads(response.read_text(encoding='utf-8'))
            if expired():
                return timeout()
            if process.returncode != 0 or document.get('ok') is not True:
                return dict(passed=False, status='VALIDATION_FAILED', error=document.get('error'))
            checked = _fixed_point_check(case, result, payload, document['evidence'])
            checked.update(observation_sha256=payload['observation_sha256'],
                           effective_bounds=payload['effective_bounds'],
                           parameter_order=case.get('parameter_order'),
                           validation_runtime=payload['pipeline'])
        # Include decoding, pure checks and temporary-artifact cleanup. Complete
        # evidence returned after the cutoff is not a successful validation.
        if expired():
            return timeout()
        return checked
    except KeyboardInterrupt:
        raise
    except Exception as exc:
        if expired():
            return timeout()
        return dict(passed=False, status='VALIDATION_FAILED', error=type(exc).__name__ + ': ' + str(exc))
