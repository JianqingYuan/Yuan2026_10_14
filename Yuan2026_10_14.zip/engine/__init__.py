"""Public numerical interfaces; importing never starts a fit.

S301: fit_case; archived paired workflow: engine.legacy.fit_pair.
"""

from .api import fit_case, predict, verify_vendor

__all__ = ['fit_case', 'predict', 'verify_vendor']
