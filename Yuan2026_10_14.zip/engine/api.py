"""S301-oriented portable DE -> diverse candidates -> hybrid TRF workflow.

The physics and numerical methods in vendor/ are byte-for-byte copies. This
module replaces platform allocation, sealed-account paths and process routing;
it does not replace the optimizers or silently turn budget exhaustion into a
successful fit. The original paired workflow is separately preserved in
engine.legacy; the launcher chooses explicitly. Neither adapter promises
bitwise reproduction of historical cluster executions.
"""
from ._bootstrap import CORE, VENDOR

import copy
import hashlib
import json
import multiprocessing as mp
import os
from pathlib import Path
import queue
import signal
import threading
import time

import numpy as np
import scipy

from hybrid_support import (ArmRun, CrossFitArmRun, Interrupted, feasible_z,
                            nonzero_residual_mode, worker_init, worker_predict,
                            third_settings, write, utc)
from runner import run_de_search, select_candidates
from closure_runner import ClosureRun, COMPLETE as CLOSURE_COMPLETE
from candidate_policy import verify_vectors, rank_candidates
from production_review import boundary_review
from spherical_geodesics import CoordinateTimeSettings
from spherical_geodesics.astrometry import TheoryForwardModel
from spherical_geodesics.astrometry.parameters import resolve_theory_bounds
from metric_library import build_theory, effective_theory_options


def verify_vendor():
    """Verify every copied numerical source before computation."""
    document = json.loads((VENDOR / 'MANIFEST.json').read_text(encoding='utf-8'))
    for relative, expected in document['hashes'].items():
        if hashlib.sha256((VENDOR / relative).read_bytes()).hexdigest() != expected:
            raise RuntimeError('Vendored numerical source changed: ' + relative)
    return document


def predict(theta, times, theory='ER', integration=None, theory_options=None):
    """Return planar (N,2) positions from the frozen DOP853 forward model."""
    model = TheoryForwardModel(theory, build_theory,
        settings=CoordinateTimeSettings(**(integration or {})),
        theory_options=theory_options or {})
    prediction = model.predict(np.asarray(theta, dtype=float), np.asarray(times, dtype=float))
    return np.column_stack((prediction.x, prediction.y))


class _RuntimeRoot:
    """Filesystem adapter for unchanged scientific classes, not a fake seal.

    Their package hashes resolve to the real verified vendor/core files. All
    mutable inputs/checkpoints resolve to this task's own output directory.
    """
    def __init__(self, directory):
        self.directory = Path(directory)

    def __truediv__(self, key):
        if str(key) == 'package':
            return CORE
        return self.directory / key


def _check_cancel(cancel_event):
    if cancel_event is not None and cancel_event.is_set():
        raise KeyboardInterrupt('Calculation cancelled')


def _worker_init(package, case, third, ready):
    # The owning controller handles Ctrl+C and terminates its own pool. A
    # worker must not vanish mid-evaluation and leave an iterator waiting.
    try:
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        worker_init(package, case, third)
    except BaseException as exc:
        # Return an idle worker, not a dead initializer that Pool keeps
        # replacing. The parent will terminate the whole pool before use.
        ready.put((os.getpid(), type(exc).__name__ + ': ' + str(exc)))
        return
    ready.put((os.getpid(), None))


class _WorkerPool:
    """Keep the startup channel alive until all owned workers are joined."""
    def __init__(self, pool, ready):
        self.pool, self.ready = pool, ready

    def __getattr__(self, name):
        return getattr(self.pool, name)

    def join(self):
        self.pool.join()
        self.ready.close()
        self.ready.join_thread()


def _pool(case, config, workers, guard=None):
    # A real worker is necessary even for one core: a slow forward call must
    # remain interruptible at the shared case deadline.
    check = guard if guard is not None else lambda: None
    check()
    # Validate all constructors synchronously, before starting any process.
    # This catches wrong theory options or precision settings without respawn.
    levels = (case['nominal_integration'], case['tight_integration'],
              third_settings(case, config['third_integration']))
    for settings in levels:
        TheoryForwardModel(case.get('fit_theory', 'ER'), build_theory,
            settings=CoordinateTimeSettings(**settings),
            theory_options=case.get('fit_theory_options', case.get('theory_options', {})))
    check()
    context = mp.get_context('spawn')
    ready = context.Queue()
    pool = None
    try:
        pool = context.Pool(workers, initializer=_worker_init,
            initargs=(str(CORE), case, config['third_integration'], ready))
        expires = time.monotonic() + 60.0  # Startup guard, not a new fit budget.
        initialized = set()
        while len(initialized) < workers:
            check()
            remaining = expires - time.monotonic()
            if remaining <= 0:
                raise RuntimeError('Worker startup timed out before all workers were ready')
            try:
                pid, error = ready.get(timeout=min(.1, remaining))
            except queue.Empty:
                continue
            check()
            if error is not None:
                raise RuntimeError('Worker initialization failed: ' + error)
            initialized.add(pid)
        check()
        return _WorkerPool(pool, ready)
    except BaseException:
        # The caller has not yet received this pool, so cleanup belongs here.
        if pool is not None:
            pool.terminate()
            pool.join()
        ready.close()
        ready.join_thread()
        raise


class _PortableIO:
    """Reduce platform/logging overhead without changing numerical methods."""
    def start_pool(self):
        self.pool = _pool(self.case, self.config, self.config['workers_per_arm'], guard=self.guard)

    def guard(self):
        if getattr(self, 'interrupt_requested', [False])[0]:
            raise KeyboardInterrupt('Calculation cancelled by Ctrl+C')
        _check_cancel(getattr(self, 'cancel_event', None))
        super().guard()

    def run(self):
        try:
            super().run()
        finally:
            # A frozen runner saves its terminal checkpoint before closing
            # its pool. Even if that save raises, reclaim this stage's owned
            # workers and startup channel before propagating the exception.
            pool = getattr(self, 'pool', None)
            if pool is not None:
                try:
                    pool.terminate()
                    pool.join()
                finally:
                    self.pool = None
        if getattr(self, 'interrupt_requested', [False])[0]:
            raise KeyboardInterrupt('Calculation cancelled by Ctrl+C')
        _check_cancel(getattr(self, 'cancel_event', None))
        # Frozen numerical classes retain BaseException as a diagnostic. Do
        # not interpret a caught Ctrl+C as permission to start another solve.
        trace = self.state.get('traceback', '').strip().splitlines()
        if trace and trace[-1].startswith('KeyboardInterrupt'):
            raise KeyboardInterrupt('Calculation interrupted during refinement')

    def append(self, name, value):
        # Full FD matrices and per-forward vectors are unnecessary for readers;
        # endpoint vectors, candidate selection and solver messages are kept.
        if name == 'improvements.jsonl':
            return super().append(name, value)

    def save(self):
        # The frozen runners force saves when a stage finishes or fails. Only
        # throttle running updates; terminal evidence must reach the checkpoint.
        if (self.last_save == 0 or self.state.get('status') != 'RUNNING'
                or self.state.get('phase') == 'finished'
                or time.monotonic() - self.last_save >= self.config['checkpoint_seconds']):
            super().save()


class _SelfRun(_PortableIO, ArmRun):
    def run(self):
        super().run()
        archived = self.case.get('archived_reference_D')
        measured = self.state.get('reference_reproduction', {}).get('D')
        if archived is not None and measured is not None:
            report = dict(policy=self.case['reference_check_policy'],
                archived_D=archived, measured_D=measured,
                absolute_difference={key:abs(measured[key]-archived[key]) for key in archived},
                historical_norm_matches={key:bool(np.isclose(measured[key], archived[key],
                    rtol=1e-5, atol=1e-7)) for key in archived},
                fixed_ceiling=self.case['reference_ceiling_D'],
                historical_norm_match_required=False,
                reference_is_not_optimizer_seed=True, fit_acceptance_gate_unchanged=True)
            self.state['portable_reference_check'] = report
            self.save()
            write(self.out / 'reference_compatibility.json', report)
            write(self.out / 'result.json', self.state)


class _NonzeroRun(_PortableIO, CrossFitArmRun):
    pass


class _FaceRun(_PortableIO, ClosureRun):
    def __init__(self, root, config, arm, seed, case, case_path, attempt,
                 seed_source, output_override, shared_deadline):
        # Reuse the exact ClosureRun numerical run/full_z/Jacobian/retention
        # methods. Only its historical ten-day/platform constructor is replaced.
        self.face = True
        self.active = [0, 2, 3, 4, 5]
        CrossFitArmRun.__init__(self, root, config, arm, seed, case, case_path,
            attempt, reference_theta=None, seed_source=seed_source,
            output_override=output_override, shared_deadline=shared_deadline)
        if list(self.bounds.free_names) != ['M', 'q', 'rho0', 'drho_dt0', 'phi0', 'dphi_dt0']:
            raise ValueError('Conditional q=0 refinement requires six free parameters')
        if self.bounds.lower[1] != 0 or self.z0[1] != 0:
            raise ValueError('Charge-zero face is not present in the declared bounds')
        self.source_theta = np.asarray(seed['source_theta'], dtype=float)
        self.full_start = self.z0.copy()
        self.state.update(mode='face_q0', active_solver_names=[self.bounds.free_names[i] for i in self.active],
            independent_stochastic_source_count=0, new_independent_DE_source=False,
            truth_parameter_reference_used_for_fit=False)


def _config(case, workers, profile):
    config = json.loads((VENDOR / 'numerical_template.json').read_text(encoding='utf-8'))
    config['workers_per_arm'] = workers
    config['local_workers_per_candidate'] = workers
    config['de']['workers'] = workers
    config['wall_seconds_per_arm'] = float(case.get('wall_seconds', 432000))
    if not np.isfinite(config['wall_seconds_per_arm']) or config['wall_seconds_per_arm'] <= 0:
        raise ValueError('wall_seconds must be finite and positive')
    config['resume'] = 'Existing task output is never overwritten. No automatic retry or budget reset.'
    config['interpretation'] = 'Unified portable adapter; optimizer completion is distinct from finite numerical checks.'
    if profile == 'demo':
        config['de'].update(maxiter=2, popsize=2, max_forward_calls=36)
        config['max_nfev_per_solve'] = 8
        config['candidate_selection']['maximum'] = 1
        config['max_fit_forward_calls_per_arm'] = 1000
    elif profile != 'paper':
        raise ValueError('profile must be paper or demo')
    return config


def _prepare(directory, case, config):
    directory.mkdir(parents=True, exist_ok=False)
    (directory / 'science').mkdir()
    write(directory / 'science/config.json', config)
    write(directory / 'case.json', case)
    files = {p:hashlib.sha256((directory / p).read_bytes()).hexdigest()
             for p in ('science/config.json', 'case.json')}
    vendor = verify_vendor()
    hashes = {p.removeprefix('core/'):h for p,h in vendor['hashes'].items() if p.startswith('core/')}
    write(directory / 'science/manifest.json', dict(files_sha256=files, package_sha256=hashes))
    return _RuntimeRoot(directory)


def _validate_case(case):
    case = copy.deepcopy(case)
    if 'xy_true' not in case and 'xy_observed' in case:
        case['xy_true'] = case['xy_observed']
    times, xy = np.asarray(case['times'], dtype=float), np.asarray(case['xy_true'], dtype=float)
    if times.ndim != 1 or len(times) < 2 or np.any(np.diff(times) <= 0) or not np.all(np.isfinite(times)):
        raise ValueError('At least two finite, strictly increasing observation times are required')
    if xy.shape != (len(times), 2) or not np.all(np.isfinite(xy)):
        raise ValueError('xy_true / xy_observed must be a finite (N,2) observation array')
    if 'xy_observed' in case and not np.array_equal(
            xy, np.asarray(case['xy_observed'], dtype=float)):
        raise ValueError('xy_true and xy_observed must describe exactly the same observations')
    case['fit_theory'] = case.get('fit_theory', 'ER')
    effective_theory_options(case['fit_theory'],
        case.get('fit_theory_options', case.get('theory_options', {})))
    bounds = resolve_theory_bounds(case['fit_theory'], case['bounds'])
    if bounds.ndim != 6:
        raise ValueError('This released workflow requires the six fitted parameters of the paper')
    if 'precision_criterion' in case:
        criterion = case['precision_criterion']
        if criterion.get('kind') not in ('absolute_delta_chi2', 'frozen_s301_precision_vector_ceiling'):
            raise ValueError('Unknown or invalid historical precision criterion')
    if _historical_criterion(case):
        criterion = case['precision_criterion']
        if not np.isfinite(criterion['tolerance']) or criterion['tolerance'] <= 0:
            raise ValueError('Historical chi-square tolerance must be positive and finite')
        if not nonzero_residual_mode(case):
            raise ValueError('Historical chi-square criterion cannot enable a zero-residual gate')
        # The immutable nonzero class requires a positive scalar in its input
        # schema. It NEVER applies its self-recovery gate in this mode. Actual
        # selection below exclusively uses the declared historical chi2 test;
        # this compatibility placeholder is not a scientific tolerance.
        case['threshold_D'] = 1.0
        case['precision_vector_ceiling'] = 1.0
        case['internal_threshold_is_schema_placeholder'] = True
    for name in ('residual_sigma', 'threshold_D'):
        value = float(case.get(name, 1.) if name == 'residual_sigma' else case[name])
        if not np.isfinite(value) or value <= 0:
            raise ValueError(name + ' must be finite and positive')
        case[name] = value
    for accuracy in ('nominal_integration', 'tight_integration'):
        CoordinateTimeSettings(**case[accuracy])
    if not nonzero_residual_mode(case) and 'reference_theta' not in case:
        raise ValueError('Noiseless ER self-recovery requires a separately declared reference_theta for checks, never seeds')
    return case, bounds


def _historical_criterion(case):
    criterion = case.get('precision_criterion')
    return criterion if criterion and criterion.get('kind') == 'absolute_delta_chi2' else None


def _configure_portable_reference(case):
    """Use the original self-recovery ceiling, not another machine's norm.

    This changes only the archived-reference portability check for the bundled
    S301 noiseless ER cases. It neither changes the fit gate nor introduces
    the reference parameter vector into candidate selection or optimization.
    """
    metadata = case.get('metadata', {})
    if (case.get('fit_theory') != 'ER' or case.get('generating_theory') != 'ER'
            or nonzero_residual_mode(case) or metadata.get('suite') != 's301'
            or metadata.get('add_noise') is not False or 'reference_theta' not in case):
        return
    archived = case.get('reference_D', {})
    if (not isinstance(archived, dict) or set(archived) != {'nominal', 'tight'} or any(
            isinstance(value, bool) or not isinstance(value, (int, float)) or not np.isfinite(value) or value < 0
            for value in archived.values())):
        raise ValueError('Portable S301 reference requires both finite archived norms')
    case['archived_reference_D'] = copy.deepcopy(archived)
    case['reference_D'] = {'nominal': None, 'tight': None}
    case['reference_ceiling_D'] = case['threshold_D']
    case['reference_check_policy'] = 'portable_reference_with_original_fixed_self_gate'


def _stage_record(identifier, run):
    record = dict(id=identifier, status=run.state['status'], solver=run.state.get('solver_accepted'))
    for key in ('error', 'reason', 'manifest_error', 'traceback', 'portable_reference_check'):
        if key in run.state:
            record[key] = run.state[key]
    return record


def _stage_outcome(stages):
    complete = {'RECOVERY_VALIDATED', 'DUAL_GATE_PASSED_THIRD_REVIEW',
        'CROSS_FIT_DIAGNOSTIC_COMPLETE_REQUIRES_REVIEW', CLOSURE_COMPLETE}
    iterations = {'LOCAL_NFEV_BUDGET_EXHAUSTED',
        'CROSS_FIT_LOCAL_BUDGET_EXHAUSTED_DIAGNOSTICS_RETAINED',
        'CLOSURE_NFEV_BUDGET_EXHAUSTED_REQUIRES_REVIEW'}
    failed = [stage for stage in stages if stage['status'] in {
        'FAILED', 'CLOSURE_FAILED_REQUIRES_REVIEW', 'CLOSURE_MANIFEST_FAILURE_REQUIRES_REVIEW'}]
    if failed:
        first = failed[0]
        return False, 'FAILED', first['id'] + ': ' + str(
            first.get('error') or first.get('manifest_error') or first['status'])
    statuses = {stage['status'] for stage in stages}
    if stages and statuses <= complete:
        return True, 'COMPLETED', None
    if statuses & {'WALL_BUDGET_EXHAUSTED', 'FORWARD_BUDGET_EXHAUSTED'}:
        return False, 'BUDGET_OR_INTERRUPTION', 'A shared time or forward-call budget was exhausted'
    if any('INTERRUPTED' in status for status in statuses):
        return False, 'BUDGET_OR_INTERRUPTION', 'A numerical stage was interrupted'
    if statuses & iterations and statuses <= complete | iterations:
        return False, 'INCOMPLETE_OR_BUDGET_LIMIT', 'Local iteration limit reached'
    return False, 'NEEDS_REVIEW', 'A stage did not complete its numerical checks'


class _DEMap:
    def __init__(self, case, config, bounds, pool, deadline, out, cancel_event=None):
        self.case, self.config, self.bounds = case, config, bounds
        self.pool, self.deadline, self.out = pool, deadline, out
        self.cancel_event = cancel_event
        self.events, self.calls = [], 0

    def guard(self):
        _check_cancel(self.cancel_event)
        if time.time() >= self.deadline:
            raise Interrupted('shared_case_wall_budget_exhausted')

    def __call__(self, unused_function, points):
        self.guard()
        points = list(points)
        if self.calls + len(points) > self.config['de']['max_forward_calls']:
            raise Interrupted('DE_forward_budget_exhausted')
        tasks = []
        for z in points:
            self.calls += 1
            tasks.append(dict(id=self.calls, theta=self.bounds.denormalize(z).tolist(),
                z=np.asarray(z).tolist(), accuracy='nominal'))
        iterator = self.pool.imap(worker_predict, tasks, chunksize=1)
        events = []
        while len(events) < len(tasks):
            self.guard()
            try:
                event = iterator.next(timeout=min(1.0, max(.001, self.deadline-time.time())))
            except mp.TimeoutError:
                continue
            self.guard()
            events.append(event)
        costs = []
        for task, event in zip(tasks, events):
            event = dict(task, **event)
            if event['status'] == 'COMPLETE':
                event['D'] = float(np.linalg.norm(event['residual']))
                # Preserve DEBatch's actual weighted-dot arithmetic and finite
                # cap, not a mathematically equivalent norm-then-square order.
                weighted = np.asarray(event['residual']) / self.case['residual_sigma']
                value = min(float(weighted @ weighted), self.config['de']['invalid_chi2'])
                event['chi2'] = value if np.isfinite(value) else self.config['de']['invalid_chi2']
            else:
                event['chi2'] = self.config['de']['invalid_chi2']
            costs.append(event['chi2'])
            self.events.append({k:v for k,v in event.items() if k not in ('residual', 'xy', 'traceback')})
        return costs

    def checkpoint(self, result):
        write(self.out / 'de_checkpoint.json', dict(generation=int(result.nit),
            calls=self.calls, best_chi2=float(result.fun), normalized_best=result.x,
            population=result.population, population_energies=result.population_energies,
            rng_state=result.rng_state, updated_utc=utc(), status='DE_RUNNING'))
        return False


def _collect(run, source, bounds, case, points, rejected):
    """Read saved same-point residuals, retain every finite candidate explicitly."""
    nonzero = nonzero_residual_mode(case)
    path = run.out / ('diagnostic_residuals.json' if nonzero else 'accepted_residuals.json')
    if not path.exists():
        rejected.append(dict(source=source, status=run.state['status'], reason=run.state.get('error', 'No complete three-precision endpoint')))
        return
    document = json.loads(path.read_text(encoding='utf-8'))
    if nonzero:
        raw_candidates = document['candidates']
        audits = run.state['crossfit_audits']
    else:
        raw_candidates = {'self_recovered':document}
        audits = {'self_recovered':run.state['final_audit']}
    historical = _historical_criterion(case)
    for label, raw in raw_candidates.items():
        identifier = run.out.name + '/' + label
        record = dict(id=identifier, source=source, theta=raw['theta'], raw_residuals=raw,
            solver_status=run.state['status'], numerical_evidence_valid=False,
            lineage_id=str(source), comparison_key=case.get('case_id', 'case'),
            counts_as_independent_source=True, truth_seed_used=False)
        # Always retain finite minima, even when the numerical check fails.
        record['chi2'] = {k:float(np.linalg.norm(raw[k]) / case['residual_sigma'])**2
                          for k in ('nominal', 'tight', 'third')}
        if not all(np.isfinite(value) for value in record['chi2'].values()):
            rejected.append(dict(source=source, status=run.state['status'], reason='Nonfinite candidate objective'))
            continue
        try:
            checked = verify_vectors(raw, audits[label], sigma=case['residual_sigma'],
                bounds=dict(lower=bounds.lower, upper=bounds.upper), expected_size=np.asarray(case['xy_true']).size,
                ceiling=np.finfo(float).max if historical else case.get('precision_vector_ceiling', case['threshold_D']),
                self_gate=None if nonzero else case['threshold_D'])
            if historical:
                discrepancy = abs(checked['chi2']['nominal'] - checked['chi2']['tight'])
                checked['historical_precision_check'] = dict(**historical, measured=discrepancy,
                    passed=bool(discrepancy <= historical['tolerance']),
                    third_level_is_additional_diagnostic=True)
                if discrepancy > historical['tolerance']:
                    raise ValueError('Original nominal/tight absolute chi2 tolerance exceeded')
            record.update(checked)
        except ValueError as exc:
            record['check_reason'] = str(exc)
        points.append(record)


def _source_best(points):
    best = {}
    for point in sorted(points, key=lambda x:(x['chi2']['third'], x['id'])):
        if point['numerical_evidence_valid']:
            best.setdefault(point['lineage_id'], point)
    return best


def _boundary_check(run, point, case, bounds):
    run.start_pool()
    try:
        report = ClosureRun.all_boundary_diagnostics(run, feasible_z(point['theta'], bounds))
    finally:
        run.pool.terminate(); run.pool.join(); run.pool = None
    historical = _historical_criterion(case)
    context = dict(bounds=dict(lower=bounds.lower, upper=bounds.upper),
        expected_size=np.asarray(case['xy_true']).size, sigma=case['residual_sigma'],
        ceiling=np.finfo(float).max if historical else case.get('precision_vector_ceiling', case['threshold_D']))
    checked = boundary_review(report, point, context, run.config['crossfit_review'])
    # The original historical precision check is nominal/tight at the fit,
    # not a newly invented L2 ceiling for tight/third boundary probes.
    checked['precision_criterion'] = historical or {'kind':'tight_third_vector', 'ceiling':context['ceiling']}
    return checked


def fit_case(case, output_dir, workers=1, profile='paper', cancel_event=None):
    """Fit one observation/model case and save independent task-local results.

    The caller owns parallelism across cases. workers controls only this case's
    forward calls; both DE lineages and local candidates run sequentially.
    cancel_event may be a shared Event; cancellation is saved and re-raised as
    KeyboardInterrupt so the caller cannot silently continue to another case.
    Output directory must not exist: unfinished jobs are never silently reset.
    Demo uses two tiny DE lineages and eight TRF evaluations, and is labelled
    DEMO regardless of success. No submission, network or external data writes.
    """
    from experiments.api import PIPELINE_VERSIONS
    if case.get('fit_pipeline', 's301') != 's301':
        raise ValueError('The legacy workflow requires engine.legacy.fit_pair with both ER/RN cases')
    pipeline_version = case.get('fit_pipeline_version', PIPELINE_VERSIONS['s301'])
    if pipeline_version != PIPELINE_VERSIONS['s301']:
        raise ValueError('Unknown S301 workflow version')
    pipeline_requested = case.get('fit_pipeline_requested', 's301')
    if pipeline_requested not in ('paper', 'legacy', 's301'):
        raise ValueError('Unknown requested fitting workflow')
    if type(workers) is not int or workers < 1:
        raise ValueError('workers must be a positive integer')
    cancel_event = threading.Event() if cancel_event is None else cancel_event
    _check_cancel(cancel_event)
    verify_vendor()
    if (np.__version__, scipy.__version__) != ('1.26.4', '1.13.0'):
        raise RuntimeError('Use the pinned numpy==1.26.4 and scipy==1.13.0 numerical environment')
    case, bounds = _validate_case(case)
    _configure_portable_reference(case)
    seeds = list(case.get('run_seeds', [104729, 130363]))
    if len(seeds) != 2 or len(set(seeds)) != 2 or any(type(x) is not int or not 0 <= x < 2**32 for x in seeds):
        raise ValueError('Exactly two distinct explicit uint32 DE seeds are required')
    reference = case.pop('reference_theta', None)
    # Reference parameters never enter the DE observation case or seed selection.
    case.pop('theta_true', None)
    input_metadata = case.pop('metadata', {})
    config = _config(case, workers, profile)
    directory = Path(output_dir).resolve()
    root = _prepare(directory, case, config)
    started = time.time()
    deadline = started + config['wall_seconds_per_arm']
    points, rejected, stages, de_sources = [], [], [], []
    result = dict(schema='unified-paper-fit-v1', case_id=case.get('case_id', directory.name),
        fit_pipeline='s301', fit_pipeline_requested=pipeline_requested,
        fit_pipeline_version=pipeline_version, residual_accuracy='third',
        profile=profile, fit_theory=case['fit_theory'], status='RUNNING', run_complete=False,
        scientific_checks_passed=False, started_utc=utc(), run_seeds=seeds,
        numpy_version=np.__version__, scipy_version=scipy.__version__, workers=workers,
        sigma=case['residual_sigma'], optimizer_truth_seed_used=False,
        precision_criterion=case.get('precision_criterion', {'kind':'frozen_s301_precision_vector_ceiling'}),
        input_metadata=input_metadata,
        reference_check_policy=case.get('reference_check_policy', 'original_case_reference'),
        archived_reference_D=case.get('archived_reference_D'),
        historical_run_reproduced=False, candidates=points, rejected_stages=rejected,
        stages=stages, sources=de_sources)
    write(directory / 'result.json', result)
    current_pool = None
    interrupted = False
    interrupt_requested = [False]
    original_handler = None
    if threading.current_thread() is threading.main_thread():
        original_handler = signal.getsignal(signal.SIGINT)
        def handle_interrupt(signum, frame):
            # Signals may interrupt Event.is_set() while its non-reentrant
            # lock is held. Never acquire an Event lock inside this handler.
            interrupt_requested[0] = True
            raise KeyboardInterrupt('Calculation cancelled by Ctrl+C')
        signal.signal(signal.SIGINT, handle_interrupt)
    try:
        for source in seeds:
            _check_cancel(cancel_event)
            source_dir = directory / ('source_' + str(source))
            source_dir.mkdir()
            def startup_guard():
                _check_cancel(cancel_event)
                if time.time() >= deadline:
                    raise Interrupted('shared_case_wall_budget_exhausted')
            current_pool = _pool(case, config, workers, guard=startup_guard)
            mapper = _DEMap(case, config, bounds, current_pool, deadline, source_dir, cancel_event)
            de = run_de_search(mapper, bounds.ndim, config['de'], source, callback=mapper.checkpoint)
            current_pool.terminate(); current_pool.join(); current_pool = None
            selected = select_candidates(mapper.events, de.population, de.population_energies, bounds, config, source)
            de_report = dict(seed=source, calls=mapper.calls, generations=int(de.nit),
                success=bool(de.success), message=str(de.message), selected_candidates=selected,
                complete_search_stage=True, reached_iteration_limit=bool(de.nit >= config['de']['maxiter']))
            de_sources.append(de_report)
            write(source_dir / 'de_result.json', dict(de_report, events=mapper.events,
                population=de.population, population_energies=de.population_energies))
            if not selected:
                raise RuntimeError('DE returned no valid forward candidates')
            for index, seed in enumerate(selected):
                _check_cancel(cancel_event)
                if time.time() >= deadline:
                    raise Interrupted('shared_case_wall_budget_exhausted')
                seed_path = source_dir / ('candidate_' + str(index) + '.json')
                write(seed_path, seed)
                arm = dict(id=f'source_{source}_candidate_{index}', hybrid_phi=True, x_scale='jac')
                cls = _NonzeroRun if nonzero_residual_mode(case) else _SelfRun
                run = cls(root, config, arm, seed, case, directory / 'case.json', 'initial',
                    reference_theta=reference, seed_source=seed_path,
                    output_override=directory / arm['id'], shared_deadline=deadline)
                run.cancel_event = cancel_event
                run.interrupt_requested = interrupt_requested
                run.run()
                stages.append(_stage_record(arm['id'], run))
                _collect(run, source, bounds, case, points, rejected)
                if not nonzero_residual_mode(case) and run.state['status'] == 'RECOVERY_VALIDATED':
                    break  # Same source: finite zero-gate recovery stops its second local candidate.
        valid = [p for p in points if p['numerical_evidence_valid']]
        ranking = rank_candidates(valid) if nonzero_residual_mode(case) else dict(
            passed=len(_source_best(points)) == 2, status='TWO_SOURCE_SELF_GATE_CHECK')
        # Existing single conditional q=0 closure; never a new DE lineage,
        # never drops a better original candidate, never resets the deadline.
        best = _source_best(points)
        if nonzero_residual_mode(case) and not ranking['passed'] and len(best) == 2 and bounds.lower[1] == 0:
            for lineage, point in best.items():
                _check_cancel(cancel_event)
                changed = list(point['theta']); changed[1] = 0.
                seed = dict(theta=changed, source_theta=point['theta'], source_id=lineage,
                    lineage_id=lineage, random_seed=int(lineage),
                    expected_baseline={k:dict(D=point['D'][k]) for k in ('nominal','tight','third')})
                seed_path = directory / ('closure_seed_' + lineage + '.json')
                write(seed_path, seed)
                arm = dict(id='source_' + lineage + '_q0', mode='face_q0', hybrid_phi=True, x_scale='jac')
                run = _FaceRun(root, config, arm, seed, case, directory / 'case.json', 'closure',
                    seed_source=seed_path, output_override=directory / arm['id'], shared_deadline=deadline)
                run.cancel_event = cancel_event
                run.interrupt_requested = interrupt_requested
                run.run()
                stages.append(_stage_record(arm['id'], run))
                _collect(run, int(lineage), bounds, case, points, rejected)
            valid = [p for p in points if p['numerical_evidence_valid']]
            ranking = rank_candidates(valid)
        boundaries = {}
        if nonzero_residual_mode(case):
            for lineage, point in _source_best(points).items():
                _check_cancel(cancel_event)
                seed = dict(theta=point['theta'])
                seed_path = directory / ('boundary_seed_' + lineage + '.json')
                write(seed_path, seed)
                arm = dict(id='boundary_' + lineage, hybrid_phi=True, x_scale='jac')
                run = _NonzeroRun(root, config, arm, seed, case, directory / 'case.json', 'boundary',
                    reference_theta=None, seed_source=seed_path,
                    output_override=directory / arm['id'], shared_deadline=deadline)
                run.cancel_event = cancel_event
                run.interrupt_requested = interrupt_requested
                boundaries[lineage] = _boundary_check(run, point, case, bounds)
                write(run.out / 'boundary.json', boundaries[lineage])
        clean_boundaries = all(not b['issues'] and not b['significant_fixed_nuisance_descent'] for b in boundaries.values())
        all_stages_complete, status, stop_reason = _stage_outcome(stages)
        result.update(run_complete=all_stages_complete,
            scientific_checks_passed=bool(ranking['passed'] and clean_boundaries and not rejected and all_stages_complete),
            ranking=ranking, boundary_checks=boundaries,
            status=status)
        if stop_reason is not None:
            result['stop_reason'] = stop_reason
    except Interrupted as exc:
        result.update(status='BUDGET_OR_INTERRUPTION', stop_reason=str(exc))
    except KeyboardInterrupt:
        interrupted = True
        cancel_event.set()
        result.update(status='INTERRUPTED', stop_reason='User interruption')
    except Exception as exc:
        result.update(status='FAILED', stop_reason=type(exc).__name__ + ': ' + str(exc))
    finally:
        try:
            if current_pool is not None:
                current_pool.terminate(); current_pool.join()
            valid = [point for point in points if point['numerical_evidence_valid']]
            if points:
                diagnostic = min(points, key=lambda p:(p['chi2']['third'], p['id']))
                result['diagnostic_best'] = dict(id=diagnostic['id'], theta=diagnostic['theta'],
                    chi2=diagnostic['chi2']['third'], checks_passed=diagnostic['numerical_evidence_valid'])
            if valid:
                best = min(valid, key=lambda p:(p['chi2']['third'], p['id']))
                result.update(theta=best['theta'], chi2=best['chi2']['third'],
                    best_candidate_id=best['id'], residuals=best['raw_residuals']['third'],
                    best_candidate_checks_passed=best['numerical_evidence_valid'],
                    candidate_selection='Minimum third-precision chi2 among valid retained endpoints; rejected lower endpoints remain in diagnostic_best and candidates')
            # A later budget exception must not hide an earlier hard failure.
            # Genuine user cancellation below retains precedence.
            if not interrupted:
                _, stage_status, stage_reason = _stage_outcome(stages)
                if stage_status == 'FAILED':
                    result.update(status='FAILED', run_complete=False,
                        scientific_checks_passed=False, stop_reason=stage_reason)
            if cancel_event.is_set():
                interrupted = True
                result.update(status='INTERRUPTED', run_complete=False,
                    scientific_checks_passed=False, stop_reason='User interruption')
            result.update(finished_utc=utc(), elapsed_seconds=time.time()-started,
                result_is_demo=profile == 'demo', no_global_optimum_certificate=True)
            write(directory / 'result.json', result)
        finally:
            if original_handler is not None:
                signal.signal(signal.SIGINT, original_handler)
    if interrupted or cancel_event.is_set():
        raise KeyboardInterrupt('Calculation cancelled; partial results were preserved')
    return json.loads((directory / 'result.json').read_text(encoding='utf-8'))
