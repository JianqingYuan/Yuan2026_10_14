"""Bounded fixed-point evidence completion; never an optimizer or new source.

The caller supplies the unchanged numerical evaluators and owns their deadline,
call cap, persistence and input binding. This module only orders a finite set of
audits. Any newly selected endpoint needs its own exact boundary report.
"""
from copy import deepcopy
import math


def _theta(value):
    if (not isinstance(value, (list, tuple)) or len(value) != 6 or
            any(isinstance(x, bool) or not isinstance(x, (float, int)) or
                not math.isfinite(x) for x in value)):
        raise ValueError('A finite, exact six-coordinate parameter vector is required')
    return tuple(value)


def finalize(points, actual, lineages, *, fixed_requests, evaluate_point,
             boundary_check, rank, source_best, lower_guard, max_rounds=2,
             max_points=27):
    """Mutate the supplied evidence union, retaining failures and all lower points.

    evaluate_point(lineage, theta, parent_id, reason) returns one complete
    candidate; boundary_check(lineage, point, round_index) returns a mapping
    with ``checked``, ``samples``, ``point_theta`` and ``lineage_id``. Its
    physical observations must already be appended to ``actual`` by the caller.
    A callback exception propagates: partial records remain the caller's files,
    and no success disposition is produced. At most two rounds are permitted.
    """
    if type(max_rounds) is not int or not 1 <= max_rounds <= 2:
        raise ValueError('Fixed-point completion permits only one or two rounds')
    if type(max_points) is not int or not 1 <= max_points <= 27:
        raise ValueError('Fixed-point completion permits at most 27 audited points')
    sources = tuple(str(s) for s in lineages)
    if len(sources) != 2 or len(set(sources)) != 2:
        raise ValueError('The original two distinct lineages must be retained')
    if any(str(p.get('lineage_id')) not in sources for p in points):
        raise ValueError('Candidate belongs to a different lineage')
    seen = {(str(p['lineage_id']), _theta(p['theta'])) for p in points}
    count = 0
    cap_hit = False
    audits = []
    records = []
    history = []

    def ensure(source, theta, parent, reason):
        nonlocal count, cap_hit
        source = str(source)
        if source not in sources:
            raise ValueError('Cannot transfer a fixed-point audit across sources')
        key = (source, _theta(theta))
        if key in seen:
            return
        if count >= max_points:
            cap_hit = True
            return
        count += 1
        candidate = evaluate_point(source, list(key[1]), parent, reason)
        if (not isinstance(candidate, dict) or str(candidate.get('lineage_id')) != source
                or _theta(candidate.get('theta')) != key[1]
                or candidate.get('truth_seed_used') is not False
                or candidate.get('new_independent_DE_source') is not False):
            raise ValueError('Fixed-point callback changed theta, lineage or source provenance')
        scores = candidate.get('chi2', {})
        if (set(scores) != {'nominal', 'tight', 'third'} or
                any(isinstance(x, bool) or not isinstance(x, (int, float)) or
                    not math.isfinite(x) or x < 0 for x in scores.values())):
            raise ValueError('Fixed-point audit lacks finite three-precision scores')
        if type(candidate.get('numerical_evidence_valid')) is not bool:
            raise ValueError('Fixed-point audit lacks its genuine numerical disposition')
        if any(p['id'] == candidate.get('id') for p in points):
            raise ValueError('Fixed-point candidate ID is not unique')
        points.append(candidate)
        seen.add(key)
        audits.append(dict(id=candidate['id'], lineage_id=source, theta=list(key[1]),
            reason=reason, numerical_evidence_valid=candidate['numerical_evidence_valid']))

    for request in fixed_requests:
        ensure(request['lineage_id'], request['theta'], request.get('stage_id'),
               'Previously recorded lower actual point')

    for round_index in range(max_rounds):
        if cap_hit:
            break
        best = source_best(points)
        if set(best) != set(sources):
            break
        before = {s: deepcopy(best[s]['theta']) for s in sources}
        for source in sources:
            point = best[source]
            report = boundary_check(source, point, round_index)
            if (str(report.get('lineage_id')) != source or
                    _theta(report.get('point_theta')) != _theta(point['theta'])):
                raise ValueError('Boundary report is not bound to the exact retained source point')
            checked = report.get('checked')
            if (not isinstance(checked, dict) or 'issues' not in checked or
                    type(checked.get('significant_fixed_nuisance_descent')) is not bool):
                raise ValueError('Boundary report lacks the original numerical review')
            records.append(deepcopy(report))
            for sample in report['samples']:
                if sample.get('status') == 'COMPLETE':
                    ensure(source, sample['theta'], point['id'], 'Original fixed-nuisance boundary probe')
            # The boundary observer may also have retained a lower non-sample
            # actual point. It cannot be silently omitted from final accounting.
            for row in lower_guard(points, actual)['unresolved_lower_actual_candidates']:
                ensure(row['lineage_id'], row['theta'], row.get('stage_id'),
                       'Lower actual observation during fixed-point finalization')
            if cap_hit:
                break
        after = source_best(points)
        history.append(dict(round=round_index + 1, source_theta_before=before,
            source_theta_after={s:deepcopy(p['theta']) for s,p in after.items()}))
        if (set(after) == set(sources) and
                all(_theta(after[s]['theta']) == _theta(before[s]) for s in sources)):
            break

    best = source_best(points)
    bound = {}
    for source, point in best.items():
        matches = [r for r in records if r['lineage_id'] == source and
                   _theta(r['point_theta']) == _theta(point['theta'])]
        if matches:
            bound[source] = matches[-1]['checked']
    ranking = rank([p for p in points if p['numerical_evidence_valid']])
    guard = lower_guard(points, actual)
    complete = bool(not cap_hit and set(bound) == set(sources) and
        ranking.get('passed') is True and guard['passed'] is True and
        all(not r['issues'] and not r['significant_fixed_nuisance_descent'] for r in bound.values()))
    return dict(schema='finite-fixed-point-finalization-v1', complete=complete,
        ranking=ranking, lower_guard=guard, boundary_checks=bound,
        boundary_records=records, audit_records=audits, rounds=history,
        audited_point_count=count, point_cap_reached=cap_hit,
        max_points=max_points, max_rounds=max_rounds,
        selected_source_theta={s:deepcopy(p['theta']) for s,p in best.items()},
        new_independent_DE_sources=0, optimizer_calls=0,
        scientific_acceptance=False, no_global_optimum_certificate=True)
