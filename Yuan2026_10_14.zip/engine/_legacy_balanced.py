"""Private bounded ordering for baseline demo's existing paired recovery.

No fitting algorithm or scientific threshold lives here. Stage interruption is
not an ordinary numerical error that a least-squares solver may turn into a
penalty, and is never an optimizer-success endpoint.
"""
from copy import deepcopy
from dataclasses import asdict
import math
import time


def evidence_wire(value):
    if isinstance(value, dict):
        return {str(k): evidence_wire(v) for k,v in value.items()}
    if isinstance(value, (list,tuple)):
        return [evidence_wire(v) for v in value]
    if hasattr(value, 'tolist'):
        return evidence_wire(value.tolist())
    if isinstance(value, float) and not math.isfinite(value):
        return {'nonfinite': repr(value)}
    return value


class RecoveryDeadline(BaseException):
    pass


class RecoveryActionDeadline(BaseException):
    pass


class BalancedRecoverySchedule:
    policy = 'baseline-demo-balanced-recovery-v1'
    interruptions = (RecoveryActionDeadline,)

    def __init__(self, deadline, *, record, verification_reserve=None,
                 clock=time.monotonic):
        if (isinstance(deadline, bool) or not isinstance(deadline, (int, float))
                or not math.isfinite(deadline)):
            raise ValueError('Recovery requires the inherited finite monotonic deadline')
        self.clock, self.deadline, self.record = clock, float(deadline), record
        remaining = max(0., self.deadline-clock())
        reserve = min(300., remaining/6.) if verification_reserve is None else verification_reserve
        if (isinstance(reserve, bool) or not isinstance(reserve, (int, float))
                or not math.isfinite(reserve) or not 0 <= reserve <= remaining):
            raise ValueError('Verification reserve must fit inside the existing deadline')
        self.reserve, self.work_deadline = float(reserve), self.deadline-float(reserve)
        self.context, self.action_deadline, self.state = {}, None, None

    def hard_guard(self):
        if self.clock() >= self.deadline:
            raise RecoveryDeadline('Inherited paired recovery deadline exhausted')

    def guard(self):
        self.hard_guard()
        if self.action_deadline is not None and self.clock() >= self.action_deadline:
            raise RecoveryActionDeadline('Balanced recovery action allowance exhausted')
        if self.context.get('phase') == 'rescore' and self.clock() >= self.work_deadline:
            raise RecoveryDeadline('Full paired rescoring did not finish before validation reserve')

    def bind(self, state):
        identity = dict(policy=self.policy, deadline_monotonic=self.deadline,
                        work_deadline_monotonic=self.work_deadline,
                        verification_reserve_seconds=self.reserve)
        existing = state.get('balanced_schedule')
        if existing is not None and existing.get('identity') != identity:
            raise ValueError('Balanced recovery identity/deadline changed; no silent resume extension')
        if existing is None:
            state['balanced_schedule'] = dict(identity=identity, stages=[],
                skipped_optional=[], evaluated_calls=0, actual_minima={}, invalid_actual_minima={},
                full_actual_evidence_requires_review=True, new_independent_DE_votes=0)
        self.state = state['balanced_schedule']

    def _stage(self, name, phase, index, seconds=None):
        self.hard_guard()
        now = self.clock()
        self.action_deadline = None if seconds is None else min(self.deadline, now+max(0.,seconds))
        self.context = dict(theory=name, phase=phase, seed_index=index,
                            started_monotonic=now, action_deadline_monotonic=self.action_deadline)
        self.state['stages'].append(deepcopy(self.context))
        return name, phase, index

    def steps(self, names, state, route, candidate):
        for name in names:
            yield self._stage(name, 'rescore', None)
        required, optional = {}, {}
        for name in names:
            seeds = state['models'][name]['seeds']
            own, votes = [], set()
            for i, row in enumerate(seeds):
                identity = route(candidate(row))
                if identity.startswith('de-run-') and identity not in votes and len(own) < 2:
                    own.append(i)
                    votes.add(identity)
            required[name] = own
            optional[name] = [i for i in range(len(seeds)) if i not in own]
        self.state['required_seed_indices'] = deepcopy(required)
        self.state['optional_seed_indices'] = deepcopy(optional)
        actions = [(name, required[name][round_]) for round_ in range(2)
                   for name in names if round_ < len(required[name])]
        for j, (name, index) in enumerate(actions):
            allowance = max(0., self.work_deadline-self.clock())/(len(actions)-j)
            yield self._stage(name, 'local', index, allowance)
        extras = [(name, optional[name][round_]) for round_ in range(4)
                  for name in names if round_ < len(optional[name])]
        for j, (name, index) in enumerate(extras):
            remaining = self.work_deadline-self.clock()
            if remaining <= 0:
                self.state['skipped_optional'].extend(
                    dict(theory=n, seed_index=i, reason='verification_reserve') for n,i in extras[j:])
                break
            yield self._stage(name, 'local', index, remaining/(len(extras)-j))
        for j, name in enumerate(names):
            remaining = max(0., self.deadline-self.clock())
            yield self._stage(name, 'verify', None, remaining/(len(names)-j))
        self.action_deadline = None
        self.hard_guard()

    def wrap(self, function, theory, settings, data, *, bounds=None):
        def evaluate(theta):
            import numpy as np
            self.guard()
            event = dict(context=deepcopy(self.context), theory=theory,
                theta=np.asarray(theta,dtype=float).tolist(), settings=asdict(settings),
                submitted_monotonic=self.clock(), status='SUBMITTED')
            self.state['evaluated_calls'] += 1
            event['sequence'] = self.state['evaluated_calls']
            self.record(deepcopy(event))
            try:
                self.guard()
                event['dispatched_monotonic'] = self.clock()
                values = np.asarray(function(theta),dtype=float)
                raw = values * np.column_stack((data.sigma_x,data.sigma_y)).ravel()
                score = float(values @ values)
                event.update(status='RETURNED',returned_monotonic=self.clock(),
                    weighted_residuals=values.tolist(),raw_residuals=raw.tolist(),chi2=score)
                self.record(deepcopy(event))
                if math.isfinite(score) and np.isfinite(values).all():
                    key = theory + ':' + str(settings)
                    point = np.asarray(theta,dtype=float)
                    legal = point.shape == (6,) and np.isfinite(point).all()
                    if legal and bounds is not None:
                        z = bounds.normalize(point)
                        legal = bool(np.all(z >= 0.) and np.all(z <= 1.))
                    # A still lower invalid point cannot hide a legal low point.
                    minima = self.state['actual_minima' if legal else 'invalid_actual_minima']
                    old = minima.get(key)
                    if old is None or score < old['chi2']:
                        minima[key] = deepcopy(event)
                self.guard()  # Returned raw is durable even when this rejects a late return.
                return values
            except BaseException as exc:
                if event['status'] != 'RETURNED':
                    event.update(status='RAISED' if 'dispatched_monotonic' in event else 'NEVER_DISPATCHED',
                        returned_monotonic=self.clock(),error=type(exc).__name__+': '+str(exc))
                    self.record(deepcopy(event))
                raise
        return evaluate

    def actual_review(self, theory, record, settings, profile):
        """No probe becomes a fit/vote. A separated actual low point stays open."""
        from workflow.study import _bounds_from_fit_record
        import numpy as np
        point = self.state['actual_minima'].get(theory+':'+str(settings))
        bounds = _bounds_from_fit_record(record)
        theta = None if point is None else np.asarray(point['theta'],dtype=float)
        valid = point is not None and theta.shape == (6,) and np.isfinite(theta).all()
        if valid:
            z = bounds.normalize(theta)
            valid = bool(np.all(z >= 0.) and np.all(z <= 1.))
        difference = None if not valid else float(record['chi2_min'])-point['chi2']
        # This is the original legacy source-agreement scale, not a new FD
        # precision tolerance. Smaller diagnostic differences stay recorded.
        scale = profile.certification_config.chi2_agreement
        return dict(actual_minimum=deepcopy(point), original_chi2_agreement=scale,
            selected_minus_actual=difference, legal_in_original_bounds=bool(valid),
            known_lower_unresolved=bool(valid and difference > scale),
            probe_is_optimizer_endpoint=False, new_independent_DE_votes=0)


def run_balanced(recovery, data, profile, results, *, state, deadline, record,
                 checkpoint=None, nominal_settings=None, verification_reserve=None):
    schedule = BalancedRecoverySchedule(deadline, record=record,
        verification_reserve=verification_reserve)
    return recovery.complete_integration_recovery(data,profile,results,state=state,
        checkpoint=checkpoint,nominal_settings=nominal_settings,schedule=schedule)
