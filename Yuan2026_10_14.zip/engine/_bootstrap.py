"""Locate the unchanged, vendored physics independently of the working directory."""
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / 'vendor'
CORE = VENDOR / 'core'
SCIENCE = VENDOR / 'science'

# One BLAS thread per task prevents nested oversubscription. Parallelism is
# configured explicitly by the public launcher / workers argument.
for key in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS',
            'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[key] = '1'
for directory in (CORE, SCIENCE):
    if str(directory) not in sys.path:
        sys.path.insert(0, str(directory))
