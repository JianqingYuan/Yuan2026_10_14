"""Independently regenerate numerical inputs for the first five paper figures.

This is a scientific recalculation (quadrature and DOP853), unlike paper replay.
It does not call the statistical fitter or read the bundled paper cache.
"""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import brentq
from . import _geometry_core as g


def _circular_arrays():
    fig, _ = g.circular_figure()
    data = {}
    for ai, ax in enumerate(fig.axes):
        data[f'axis{ai}_xlim'] = ax.get_xlim()
        data[f'axis{ai}_ylim'] = ax.get_ylim()
        for i, line in enumerate(ax.lines):
            data[f'axis{ai}_line{i}'] = line.get_xydata().copy()
        for i, collection in enumerate(ax.collections):
            data[f'axis{ai}_fill{i}'] = collection.get_paths()[0].vertices.copy()
    plt.close(fig)
    return data


def _bound_arrays():
    fig, rows = g.orbit_figure()
    data = {}
    for i, (ax, row) in enumerate(zip(fig.axes, rows)):
        data[f'panel{i}_limits'] = np.array([ax.get_xlim(), ax.get_ylim()])
        data[f'panel{i}_bound'] = row['bound']
        data[f'panel{i}_parameters'] = [row['E'], row['L_over_M0'], row['eta']]
        if row['bound']:
            data[f'panel{i}_xy'] = ax.lines[0].get_xydata().copy()
            data[f'panel{i}_apo'] = np.asarray(ax.collections[0].get_offsets()).copy()
            data[f'panel{i}_nu'] = row['precession_nu']
            data[f'panel{i}_horizon'] = ax.patches[0].get_radius()
    plt.close(fig)
    return data


def recompute_geometry(cache_dir, figure_ids=None):
    """Compute caches for Figs. 1--5; return paths written, without plotting PDFs.

    ``figure_ids`` may select an integer subset of 1..5. This provides a separate
    bounded scientific entry point; no network or fitting campaign is started.
    """
    target = Path(cache_dir)
    target.mkdir(parents=True, exist_ok=True)
    ids = set(range(1, 6) if figure_ids is None else figure_ids)
    if not ids <= set(range(1, 6)):
        raise ValueError('Geometry figure IDs must lie in 1..5')
    outputs = []

    def store(name, data):
        p = target/name
        np.savez_compressed(p, **data)
        outputs.append(p)

    if 1 in ids:
        q = np.linspace(0., 1., 1001)
        rp, rm = g.parameters(q)
        data = dict(q=q, rho_horizon_ER=g.areal(rp, rm),
                    rho_photon_ER=g.areal(g.er_photon_r(rp, rm), rm),
                    rho_horizon_RN=1+np.sqrt(1-q*q),
                    rho_photon_RN=(3+np.sqrt(9-8*q*q))/2)
        for i, charge in enumerate([0., .3, .6, .9, 1.]):
            er_rp, er_rm = map(float, g.parameters(charge))
            rmax = brentq(lambda r: g.areal(r, er_rm)-8., er_rp, 9.,
                          xtol=1e-13, rtol=1e-14)
            r = np.linspace(er_rp, rmax, 4001)
            rn_rho = np.linspace(1+np.sqrt(1-charge*charge), 8., 4001)
            data.update({f'q{i}_rho_ER':g.areal(r, er_rm),
                         f'q{i}_U_ER':g.er_potential_r(r, er_rp, er_rm),
                         f'q{i}_rho_RN':rn_rho, f'q{i}_U_RN':g.rn_potential(rn_rho, charge)})
        store('geometry.npz', data)
    if 2 in ids:
        data = {}
        for mode in ['r', 'rho']:
            for charge in [0., .1, .3, .5, .7, .9, 1.]:
                for theory in ['ER', 'RN']:
                    _, _, a, rec = g.integrate(theory, charge, mode)
                    stem = f'{mode}_{theory}_q{charge:.1f}'
                    data[stem+'_X'], data[stem+'_Y'] = a[5], a[6]
                    data[stem+'_horizon'] = rec['plotted_horizon_radius_M']
        store('photons.npz', data)
    if 3 in ids:
        data = {}
        for i, charge in enumerate([0., .3, .6, .9, 1.]):
            for theory in ['ER', 'RN']:
                geom = g.DeflectionGeometry(theory, charge)
                impact = geom.critical*(1+np.geomspace(.00001, 7.5/geom.critical-1, 400))
                result = np.array([geom.alpha(b) for b in impact])
                data[f'q{i}_{theory}_impact'] = impact
                data[f'q{i}_{theory}_alpha'] = result[:, 0]
                data[f'q{i}_{theory}_r_turn'] = result[:, 2]
                data[f'q{i}_{theory}_rho_turn'] = geom.rho(result[:, 2])
                data[f'q{i}_{theory}_quad_error_estimate'] = result[:, 1]
        q = np.linspace(0, 1, 1001)
        data['critical_q'] = q
        for theory in ['ER', 'RN']:
            data[f'critical_{theory}'] = np.array([g.DeflectionGeometry(theory, x).critical for x in q])
        store('deflection.npz', data)
    if 4 in ids:
        store('circular.npz', _circular_arrays())
    if 5 in ids:
        store('bound.npz', _bound_arrays())
    return outputs
