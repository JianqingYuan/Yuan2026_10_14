"""Reproduce all 13 manuscript figures from portable numerical data.

Use ``data_dir`` to plot a new campaign. An explicit alternate directory never
falls back to archived paper values: a missing input raises FileNotFoundError.
"""
from pathlib import Path
import json
import math
import numpy as np

FIGURES = {
    1: ('geometry_areal_v5_en', 'geometry.npz'),
    2: ('photon_coordinate_comparison_v6_en', 'photons.npz'),
    3: ('deflection_angle_v12_en', 'deflection.npz'),
    4: ('circular_bound_structure_v3_en', 'circular.npz'),
    5: ('bound_orbits_areal_en', 'bound.npz'),
    6: ('mock_true_parameter_grid_en', 'fits.npz'),
    7: ('mock_noiseless_objective_en', 'fits.npz'),
    8: ('mock_noiseless_parameter_shifts_en', 'fits.npz'),
    9: ('mock_noiseless_residuals_v17_en', 'fits.npz'),
    10: ('mock_parameter_recovery_v2_en', 'fits.npz'),
    11: ('mock_charge_slices_v2_en', 'fits.npz'),
    12: ('mock_extreme_charges_v17_en', 'extreme.npz'),
    13: ('s301_noisy_delta_chi2_30uas_en', 's301.json'),
}
DEFAULT_DATA = Path(__file__).resolve().parents[1]/'data'/'paper'
PARAMETERS = ['M', 'q', 'rho0', 'drho_dt0', 'phi0', 'dphi_dt0']
MODELS = ('ER', 'RN')


def _read_npz(path):
    with np.load(path, allow_pickle=False) as data:
        return dict(data)


def _validate_s301(data):
    """Reject inconsistent Figure 13 caches; never repair or relabel their data."""
    def finite_number(value):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return False
        try:
            return math.isfinite(value)
        except OverflowError:
            return False

    if (not isinstance(data, dict) or not finite_number(data.get('noise_uas'))
            or data['noise_uas'] != 30):
        raise ValueError('Figure 13 requires noise_uas=30.')
    rows = data.get('rows')
    if not isinstance(rows, list) or len(rows) != 48:
        raise ValueError('Figure 13 requires exactly 48 paired results.')
    expected = {(orbit, charge, realization) for orbit in ('A', 'B')
                for charge in range(3) for realization in range(8)}
    seen = set()
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            raise ValueError(f'Figure 13 row {index} must be an object.')
        orbit, charge, realization = (row.get(name) for name in
                                      ('orbit', 'charge_index', 'realization'))
        if (not isinstance(orbit, str) or type(charge) is not int
                or type(realization) is not int):
            raise ValueError(f'Figure 13 row {index} has an invalid pairing key.')
        key = (orbit, charge, realization)
        if key not in expected or key in seen:
            raise ValueError(f'Figure 13 has an unexpected or duplicate pairing key: {key}.')
        seen.add(key)
        er, rn, delta = (row.get(name) for name in ('chi2_ER', 'chi2_RN', 'delta_chi2'))
        if not all(finite_number(value) for value in (er, rn, delta)) or er < 0 or rn < 0:
            raise ValueError(f'Figure 13 row {index} requires finite, nonnegative chi-squared values and a finite difference.')
        # Permit harmless floating-point serialization roundoff, not stale deltas.
        if not math.isclose(delta, rn - er, rel_tol=1e-12, abs_tol=1e-10):
            raise ValueError(f'Figure 13 row {index}: delta_chi2 disagrees with chi2_RN-chi2_ER.')
    if seen != expected:
        raise ValueError('Figure 13 does not cover the complete 2 x 3 x 8 grid.')


def _noiseless(data):
    rows=[]
    for i,(q,peri) in enumerate(zip(data['noiseless_q'],data['noiseless_peri'])):
        models={t:dict(chi2=data['noiseless_chi2'][i,j],D=data['noiseless_D'][i,j],
                      parameters=dict(zip(PARAMETERS,data['noiseless_parameters'][i,j]))) for j,t in enumerate(MODELS)}
        rows.append(dict(q=q,rho_peri=peri,q_index=int(round(q*10))-1,
                         peri_index=int(round((peri-4.5)*2)),areal_eccentricity=(30-peri)/(30+peri),
                         noiseless=dict(models=models)))
    return rows


def _noisy(data):
    return [dict(q=q,peri=data['noisy_peri'][i],noise=int(data['noisy_noise'][i]),
                 realization=int(data['noisy_realization'][i]),sigma=data['noisy_sigma'][i],
                 error={t:data['noisy_error'][i,j] for j,t in enumerate(MODELS)},
                 delta=data['noisy_chi2'][i,1]-data['noisy_chi2'][i,0])
            for i,q in enumerate(data['noisy_q'])]


def _extreme(data):
    cases=[dict(q_label=str(tag),rho_peri=data['noiseless_peri'][i],
                noiseless=dict(sigma_ref=data['noiseless_sigma_ref'][i],
                    models={t:dict(chi2=data['noiseless_chi2'][i,j]) for j,t in enumerate(MODELS)}))
           for i,tag in enumerate(data['noiseless_tag'])]
    pairs=[dict(q_label=str(tag),rho_peri=data['noisy_peri'][i],noise_index=int(data['noisy_noise'][i]),
                realization=int(data['noisy_realization'][i]),
                delta_chi2=data['noisy_chi2'][i,1]-data['noisy_chi2'][i,0])
           for i,tag in enumerate(data['noisy_tag'])]
    return dict(cases=cases,pairs=pairs)


def _style(kind):
    import matplotlib.pyplot as plt
    plt.rcdefaults()
    plt.rcParams.update({'font.family':'DejaVu Sans','mathtext.fontset':'stix',
        'font.size':10,'axes.titlesize':11,'axes.labelsize':10,'xtick.labelsize':9,'ytick.labelsize':9,
        'axes.linewidth':.7,'axes.unicode_minus':False,'legend.frameon':False,
        'axes.spines.top':False,'axes.spines.right':False,'axes.axisbelow':True,
        'pdf.fonttype':42,'ps.fonttype':42,'savefig.facecolor':'white','grid.alpha':.25,'grid.linewidth':.5})
    if kind in (4,5):
        plt.rcParams.update({'font.family':'DejaVu Serif','font.size':9,
                             'axes.labelsize':10,'xtick.labelsize':8,'ytick.labelsize':8,
                             'legend.fontsize':8,'axes.linewidth':.65,'lines.linewidth':1.5})
    if kind == 8:
        plt.rcParams.update({'font.size':9,'axes.titlesize':10,'axes.labelsize':9,
                             'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'axes.linewidth':.6})
    if kind in (9,10,11,12):
        plt.rcParams.update({'font.size':10.5,'axes.titlesize':11.5,'axes.labelsize':10.5,
                             'xtick.labelsize':9.5,'ytick.labelsize':9.5,'legend.fontsize':10,'axes.linewidth':.6})


def render_all(output_dir, figure_ids=None, *, data_dir=None, dpi=220, adaptive_limits=None):
    """Write selected paper figures as PDF + PNG, returning the PDF paths.

    Parameters
    ----------
    output_dir : path-like
        Destination; may be anywhere writable.
    figure_ids : iterable of int, optional
        Default is every figure, in manuscript order (1--13).
    data_dir : path-like, optional
        Defaults to the immutable numerical paper snapshot. Passing another
        directory is strict: no absent data will be filled from paper caches.
    dpi : int
        PNG resolution (PDF curves and text remain vector graphics).
    adaptive_limits : bool, optional
        Defaults to True for an explicit data_dir and False for paper replay.
        Expand the shared S301 axis range only if new points require it. Signed
        differences and genuine zero residuals are never replaced or dropped.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from . import _plots, _geometry_plots
    ids=list(FIGURES if figure_ids is None else figure_ids)
    if len(ids)!=len(set(ids)) or any(i not in FIGURES for i in ids):
        raise ValueError('Use distinct figure IDs from 1 through 13')
    directory=DEFAULT_DATA if data_dir is None else Path(data_dir)
    if adaptive_limits is None:
        adaptive_limits = data_dir is not None
    # Validate every requested input before generating any output.
    for i in ids:
        path=directory/FIGURES[i][1]
        if not path.is_file():
            raise FileNotFoundError(f'Figure {i} requires {path}; no archived-data fallback is used.')
    loaded = {}
    if 13 in ids:
        filename = FIGURES[13][1]
        loaded[filename] = json.loads((directory/filename).read_text(encoding='utf-8'))
        _validate_s301(loaded[filename])
    out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    saved=[]
    for i in ids:
        stem,filename=FIGURES[i]
        if filename not in loaded:
            path=directory/filename
            loaded[filename]=json.loads(path.read_text(encoding='utf-8')) if path.suffix=='.json' else _read_npz(path)
        data=loaded[filename]
        with plt.rc_context():
            _style(i)
            if i in (1,2,3):
                fig={1:_plots.geometry,2:_plots.photon_paths,3:_plots.deflection}[i](data)
            elif i in (4,5):
                fig={4:_geometry_plots.circular,5:_geometry_plots.bound}[i](data)
            elif i in (6,7,8,9):
                fig={6:_plots.true_grid,7:_plots.objective,8:_plots.parameter_shift,9:_plots.residuals}[i](_noiseless(data))
            elif i in (10,11):
                fig={10:_plots.recovery,11:_plots.differences}[i](_noisy(data))
            elif i==12:
                fig=_plots.extreme(_extreme(data))
            else:
                fig=_plots.s301(data['rows'], adaptive_limits=adaptive_limits)
            for text in fig.findobj(match=matplotlib.text.Text):
                text.set_fontfamily('DejaVu Serif' if i in (4,5) else 'DejaVu Sans')
            pad=.035 if i in (1,3) else (.12 if i==13 else .055)
            pdf=out/(stem+'.pdf')
            fig.savefig(pdf,bbox_inches='tight',pad_inches=pad)
            fig.savefig(out/(stem+'.png'),dpi=dpi,bbox_inches='tight',pad_inches=pad)
            plt.close(fig)
            saved.append(pdf)
    return saved
