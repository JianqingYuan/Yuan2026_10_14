"""Analytical metrics, quadratures and DOP853 checks used by Figures 1--5.

Extracted from the validated geometry builders. No saved artwork is consumed.
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import brentq
from scipy.integrate import quad, cumulative_simpson, solve_ivp
QSTAR=np.sqrt(143/132)
QREAL=np.sqrt(12/11)
BLUE,RED,GRAY,TEAL='#24649b','#bc453b','#555d66','#2a8977'
INITIAL_RADIUS=3.02
FINAL_RADIUS=12.
SAMPLES=5001


class Geometry:
    def __init__(self, theory='ER', q=0., a=None, b=None):
        self.theory=theory
        if a is None:
            d=np.sqrt(max(0.,1-(11/12 if theory=='ER' else 1)*q*q))
            self.a=1+d
            self.b=(13/11 if theory=='ER' else 1)*(1-d)
        else:
            self.a,self.b=float(a),float(b)
        self.n=11/13 if theory=='ER' else 1.
        self.c=2/13 if theory=='ER' else 0.
        self.mass=(self.a+self.n*self.b)/2
        self.charge=np.sqrt((12/13 if theory=='ER' else 1)*self.a*self.b)

    def rho(self,r):
        return np.asarray(r)*(1-self.b/np.asarray(r))**(self.c/2)
    def A(self,r):
        return (1-self.a/np.asarray(r))*(1-self.b/np.asarray(r))**self.n
    def C(self,r):
        return self.rho(r)**2
    def slope(self,r):
        ac=self.a/(r*(r-self.a))+self.n*self.b/(r*(r-self.b))
        cc=2/r+self.c*self.b/(r*(r-self.b))
        return ac,cc
    def derivatives(self,r):
        ac,cc=self.slope(r)
        ap=-self.a*(2*r-self.a)/(r*r*(r-self.a)**2)-self.n*self.b*(2*r-self.b)/(r*r*(r-self.b)**2)
        cp=-2/r**2-self.c*self.b*(2*r-self.b)/(r*r*(r-self.b)**2)
        return ac,cc,ap,cp
    def circ(self,r):
        ac,cc=self.slope(r)
        return self.A(r)*cc/(cc-ac),self.C(r)*ac/(cc-ac)
    def dL2(self,r):
        ac,cc,ap,cp=self.derivatives(r)
        return self.C(r)*(cc*ac/(cc-ac)+(ap*cc-ac*cp)/(cc-ac)**2)
    def photon(self):
        # d(A/C)/dr=0; use only the outer physical root.
        k=3*self.a+(2+self.n-self.c)*self.b
        return (k+np.sqrt(k*k-8*(3+self.n-self.c)*self.a*self.b))/4
    def critical(self):
        ph=self.photon()
        ri=brentq(self.dL2,ph*(1+1e-6),100*self.mass,xtol=1e-12)
        rb=brentq(lambda r:self.circ(r)[0]-1,ph*(1+1e-6),ri,xtol=1e-12)
        return ph,ri,rb
    def V(self,r,L):
        return self.A(r)*(1+L*L/self.C(r))
    def dV(self,r,L):
        ac,cc=self.slope(r)
        return self.A(r)*(ac+(L*L/self.C(r))*(ac-cc))
    def bound(self,E,L):
        r0=max(self.a,self.b)*(1+1e-8)
        xx=np.geomspace(r0,1e5,8000)
        vals=E*E-self.V(xx,L)
        roots=[brentq(lambda r:E*E-self.V(r,L),x,y,xtol=1e-12)
               for x,y,u,v in zip(xx[:-1],xx[1:],vals[:-1],vals[1:]) if u*v<0]
        if len(roots)!=3 or E>=1: return None
        return roots[-2],roots[-1]

def angular_integrand(g,E,L,rp,ra,chi):
    # r=m-d*cos(chi), 0..pi maps periapsis..apoapsis and removes square-root endpoints.
    mid=(rp+ra)/2;half=(ra-rp)/2
    r=mid-half*np.cos(chi)
    v=E*E-g.V(r,L)
    if np.ndim(chi)==0:
        if chi<1e-7: return L/g.C(rp)*np.sqrt(2*half/(-g.dV(rp,L)))
        if np.pi-chi<1e-7: return L/g.C(ra)*np.sqrt(2*half/g.dV(ra,L))
    else:
        v=np.maximum(v,1e-300)
    return L/g.C(r)*half*np.sin(chi)/np.sqrt(v)

def circular_figure():
    fig,axs=plt.subplots(1,2,figsize=(7.5,3.15),layout='constrained')
    rows=[]
    for th,qs,col in [('RN',np.linspace(0,1,180),BLUE),('ER',np.linspace(0,QSTAR-1e-6,200),RED)]:
        ys=[]
        for q in qs:
            g=Geometry(th,q); ph,ri,rb=g.critical()
            ys.append([g.rho(ri),g.rho(rb)])
        ys=np.asarray(ys)
        axs[0].plot(qs,ys[:,0],color=col,label=f'{th}: ISCO')
        axs[0].plot(qs,ys[:,1],color=col,ls='--',label=f'{th}: marginally bound')
        rows.append({'theory':th,'last_q':float(qs[-1]),'last_radii':ys[-1].tolist()})
    axs[0].axvline(QSTAR,color=GRAY,ls=':',lw=.65)
    axs[0].set(xlabel=r'Charge-to-mass ratio $q$',ylabel=r'Areal radius $\rho/M$',xlim=(0,1.06),ylim=(2,6.15))
    axs[0].legend(frameon=False,loc='lower left',fontsize=7.2)
    ax=axs[1]
    for q,col,lab in [(0,GRAY,r'ER, $q=0$ limit'),(.5,TEAL,r'ER, $q=0.5$'),(1,RED,r'ER, $q=1$')]:
        g=Geometry('ER',q);ph,ri,rb=g.critical()
        ru=np.linspace(rb,ri,500); rs=np.geomspace(ri,80,1200)
        eu,lu=g.circ(ru);es,ls=g.circ(rs)
        L=np.linspace(np.sqrt(g.circ(ri)[1])+1e-6,4.6,350)
        lower=np.interp(L,np.sqrt(ls),np.sqrt(es))
        upper=np.interp(L,np.sqrt(lu[::-1]),np.sqrt(eu[::-1]),right=1)
        ax.fill_between(L,lower,upper,color=col,alpha=.08)
        ax.plot(L,lower,color=col,label=lab,lw=1.3)
        ax.plot(L,upper,color=col,lw=1.3)
    # RN q=1 reference outlines (same ADM mass, unlike the draft reconstruction).
    g=Geometry('RN',1);ph,ri,rb=g.critical()
    ru=np.linspace(rb,ri,500);rs=np.geomspace(ri,80,1200)
    eu,lu=g.circ(ru);es,ls=g.circ(rs)
    L=np.linspace(np.sqrt(g.circ(ri)[1])+1e-6,4.6,350)
    ax.plot(L,np.interp(L,np.sqrt(ls),np.sqrt(es)),color=BLUE,ls='--',label=r'RN, $q=1$',lw=1.1)
    ax.plot(L,np.interp(L,np.sqrt(lu[::-1]),np.sqrt(eu[::-1]),right=1),color=BLUE,ls='--',lw=1.1)
    ax.set(xlabel=r'Angular momentum $L/M$',ylabel=r'Specific energy $E$',xlim=(2.75,4.6),ylim=(.912,1.003))
    ax.legend(frameon=False,loc='lower right',fontsize=7.3)
    for i,ax in enumerate(axs):
        ax.text(.035,.90 if i==0 else .97,f'({chr(97+i)})',transform=ax.transAxes,va='top');ax.grid(alpha=.14,lw=.5)
    return fig, rows

def orbit_figure():
    pairs=[(.960,3.750),(.970,3.950),(.985,4.050),(.990,4.250)]
    etas=[0,.05,.10,.20]
    expected=[[.701,1.178,None,None],[.507,.628,.894,None],[.525,.668,1.115,None],[.390,.453,.542,1.269]]
    rows=[]
    fig,axs=plt.subplots(4,4,figsize=(7.65,8.7),layout='constrained')
    for j,eta in enumerate(etas):
        axs[0,j].set_title(r'$r_-/r_+='+f'{eta:.2f}'+r'$',fontsize=10,pad=9)
    for i,(E,L) in enumerate(pairs):
        row_data=[]
        for j,eta in enumerate(etas):
            ax=axs[i,j];g=Geometry('ER',a=2,b=2*eta)
            bound=g.bound(E,L)
            row={'E':E,'L_over_M0':L,'eta':eta,'M_over_M0':g.mass,'q':g.charge/g.mass,'bound':bool(bound)}
            if bound:
                rp,ra=bound
                phih=quad(lambda chi:angular_integrand(g,E,L,rp,ra,chi),0,np.pi,
                          epsabs=2e-10,epsrel=2e-10,limit=150)[0]
                pre=phih/np.pi-1
                row.update({'rp':rp,'ra':ra,'rho_p':float(g.rho(rp)),'rho_a':float(g.rho(ra)),'precession_nu':pre})
                chi=np.linspace(0,np.pi,10001)
                integrand=angular_integrand(g,E,L,rp,ra,chi)
                integrand[0]=angular_integrand(g,E,L,rp,ra,0.)
                integrand[-1]=angular_integrand(g,E,L,rp,ra,np.pi)
                phi=cumulative_simpson(integrand,x=chi,initial=0)
                row['quadrature_relative_discrepancy']=abs(phi[-1]-phih)/phih
                assert row['quadrature_relative_discrepancy']<1e-7
                rr=(rp+ra)/2-(ra-rp)/2*np.cos(chi)
                allphi=[];allr=[]
                for cycle in range(6):
                    allphi.extend(phi+2*phih*cycle);allr.extend(rr)
                    allphi.extend(2*phih-phi[-2::-1]+2*phih*cycle);allr.extend(rr[-2::-1])
                p=np.array(allphi);rho=g.rho(np.array(allr))
                ax.plot(rho*np.cos(p),rho*np.sin(p),c=BLUE,lw=.45)
                ap=(2*np.arange(6)+1)*phih
                ax.scatter(g.rho(ra)*np.cos(ap),g.rho(ra)*np.sin(ap),s=7,color=RED,zorder=4)
                panel_note=(rf'$E={E:.3f},\ L/M_0={L:.3f}$'+'\n' if j==0 else '')+rf'$\nu={pre:.3f}$'
                ax.text(.045,.97,panel_note,transform=ax.transAxes,va='top',fontsize=7.3,
                        bbox={'facecolor':'white','edgecolor':'none','alpha':.85,'pad':1.0})
                # Independent time-domain Hamiltonian check on one radial period.
                def rhs(t,y): return [y[1],-.5*g.dV(y[0],L),L/g.C(y[0])]
                def peri(t,y): return y[1]
                peri.direction=1;peri.terminal=True
                def apo(t,y): return y[1]
                apo.direction=-1;apo.terminal=True
                sol=solve_ivp(rhs,(0,1e6),[ra,0,0],events=peri,method='DOP853',rtol=2e-11,atol=2e-12,max_step=5)
                assert sol.success and len(sol.t_events[0])==1
                row['ode_half_period_phi']=float(sol.y_events[0][0,2])
                row['ode_vs_quadrature_phi_relative']=abs(row['ode_half_period_phi']-phih)/phih
                row['ode_energy_max_abs']=float(np.max(np.abs(sol.y[1]**2+g.V(sol.y[0],L)-E*E)))
                assert row['ode_vs_quadrature_phi_relative']<2e-7
                assert row['ode_energy_max_abs']<2e-9
                # The PDF rounded values are consistency references, not fitting targets.
                assert expected[i][j] is not None and abs(pre-expected[i][j])<.003
            else:
                ax.text(.5,.5,'No bound orbit',ha='center',va='center',transform=ax.transAxes,fontsize=9,color=GRAY)
                assert expected[i][j] is None
            if bound:
                circle=plt.Circle((0,0),float(g.rho(g.a)),fill=False,color=GRAY,lw=.65,ls='--')
                ax.add_artist(circle)
            ax.set_aspect('equal');ax.grid(alpha=.13,lw=.4)
            row_data.append(row)
        lim=1.07*max(r.get('rho_a',0) for r in row_data)
        for j,ax in enumerate(axs[i]):
            ax.set(xlim=(-lim,lim),ylim=(-lim,lim))
            ax.tick_params(labelsize=6.5)
            if j: ax.tick_params(labelleft=False)
        axs[i,0].set_ylabel(r'$Y/M_0$',fontsize=9)
        rows.extend(row_data)
    for ax in axs[-1]: ax.set_xlabel(r'$X/M_0$',fontsize=9)
    return fig, rows

class Metric:
    def __init__(self, theory, q):
        self.theory, self.q = theory, q
        d = np.sqrt(1-(11/12 if theory == 'ER' else 1)*q*q)
        self.rp = 1+d
        self.rm = (13/11 if theory == 'ER' else 1)*(1-d)
        self.n = 11/13 if theory == 'ER' else 1.
        self.c = 2/13 if theory == 'ER' else 0.
        self.k = self.n-self.c

    def rho(self, r):
        r = np.asarray(r)
        return r*(1-self.rm/r)**(self.c/2)

    def r_from_rho(self, rho):
        if self.c == 0:
            return rho
        return brentq(lambda r:self.rho(r)-rho, max(rho,self.rm*(1+1e-12)),rho+2,xtol=5e-15)

    def A(self, r):
        return (1-self.rp/r)*(1-self.rm/r)**self.n

    def U(self, r):
        return (1-self.rp/r)*(1-self.rm/r)**self.k/r**2

    def dU(self, r):
        h, f = 1-self.rm/r, 1-self.rp/r
        return (self.rp*h**self.k+self.k*self.rm*f*h**(self.k-1))/r**4-2*f*h**self.k/r**3

    def rph(self):
        k = 3*self.rp+(2+self.n-self.c)*self.rm
        return (k+np.sqrt(k*k-8*(3+self.n-self.c)*self.rp*self.rm))/4

    def d2U(self, r):
        # Product log derivatives are regular at the initial point r0>r_ph.
        a = self.rp/(r*(r-self.rp))+self.k*self.rm/(r*(r-self.rm))-2/r
        da = -self.rp*(2*r-self.rp)/(r*r*(r-self.rp)**2)-self.k*self.rm*(2*r-self.rm)/(r*r*(r-self.rm)**2)+2/r**2
        return self.U(r)*(a*a+da)

def integrate(theory, q, mode, strict=False):
    g=Metric(theory,q)
    r0 = INITIAL_RADIUS if mode=='r' else g.r_from_rho(INITIAL_RADIUS)
    r1 = FINAL_RADIUS if mode=='r' else g.r_from_rho(FINAL_RADIUS)
    L=1/np.sqrt(g.U(r0))
    assert r0>g.rph() and g.dU(r0)<0
    def rhs(lam,z):
        r,v,phi=z
        return [v,-.5*L*L*g.dU(r),L/g.rho(r)**2]
    def finish(lam,z): return z[0]-r1
    finish.terminal,finish.direction=True,1
    rtol,atol,step=(2e-13,2e-15,.025) if strict else (2e-11,2e-13,.10)
    sol=solve_ivp(rhs,(0,250),[r0,0.,0.],method='DOP853',rtol=rtol,atol=atol,
                  max_step=step,events=finish,dense_output=True)
    assert sol.success and len(sol.t_events[0])==1
    tt=np.linspace(0,sol.t[-1],SAMPLES)
    r,v,phi=sol.sol(tt)
    rho=g.rho(r)
    R=r if mode=='r' else rho
    xy=np.array([R*np.cos(phi),R*np.sin(phi)])
    constraint=v*v+L*L*g.U(r)-1
    nullnorm=constraint/g.A(r)
    slope=-L*L*g.dU(r0)
    curvature=-L*L*g.d2U(r0)
    def regularized(s):
        rr=r0+s*s
        # Series avoids subtracting nearly equal U values at the turning point.
        if s<3e-4:
            radial=slope+.5*curvature*s*s
        else:
            radial=(1-L*L*g.U(rr))/(s*s)
        return 2*L/(g.rho(rr)**2*np.sqrt(radial))
    angle=quad(regularized,0,np.sqrt(r1-r0),epsabs=2e-10,epsrel=2e-10,limit=200)[0]
    rec=dict(mode=mode,theory=theory,q=q,E=1.,L=float(L),b_M=float(L),r0_M=float(r0),
             rho0_M=float(g.rho(r0)),phi0=0.,dr_dlambda0=0.,drho_dlambda0=0.,
             local_static_emission_angle_degrees=90.,initial_radial_acceleration=float(-.5*L*L*g.dU(r0)),
             r_photon_M=float(g.rph()),rho_photon_M=float(g.rho(g.rph())),
             r_horizon_M=float(g.rp),rho_horizon_M=float(g.rho(g.rp)),
             plotted_horizon_radius_M=float(g.rp if mode=='r' else g.rho(g.rp)),
             stop_radius_M=FINAL_RADIUS,stop_radius_kind=mode,
             affine_end=float(sol.t[-1]),phi_end=float(phi[-1]),azimuth_turns=float(phi[-1]/(2*np.pi)),
             r_end_M=float(r[-1]),rho_end_M=float(rho[-1]),termination='outward escape',
             first_integral_max_abs=float(np.max(abs(constraint))),
             null_constraint_max_abs=float(np.max(abs(nullnorm))),
             independent_radial_integral_phi=float(angle),
             independent_radial_integral_phi_error=float(abs(phi[-1]-angle)),
             rtol=rtol,atol=atol,max_step=step,nfev=sol.nfev)
    assert rec['first_integral_max_abs']<3e-10
    assert rec['null_constraint_max_abs']<3e-9
    assert rec['independent_radial_integral_phi_error']<3e-7
    return g,sol,np.vstack([tt,r,v,phi,rho,xy]),rec

class DeflectionGeometry:
    def __init__(self, theory, q):
        assert theory in ('ER', 'RN') and 0 <= q <= 1
        self.theory, self.q = theory, float(q)
        if theory == 'ER':
            root = np.sqrt(1 - 11*q*q/12)
            self.rp, self.rm = 1+root, (13/11)*(1-root)
            self.exponent, self.area_exponent = 9/13, 2/13
        else:
            root = np.sqrt(1-q*q)
            self.rp, self.rm = 1+root, 1-root
            self.exponent, self.area_exponent = 1.0, 0.0
        coefficient = 3*self.rp + (2+self.exponent)*self.rm
        constant = (3+self.exponent)*self.rp*self.rm
        disc = np.sqrt(coefficient**2-8*constant)
        self.photon = (coefficient+disc)/4
        self.inner_stationary = (coefficient-disc)/4
        self.critical = self.impact(self.photon)

    def rho(self, r):
        return r*(1-self.rm/r)**(self.area_exponent/2)

    def potential(self, r):
        return (1-self.rp/r)*(1-self.rm/r)**self.exponent/r**2

    def impact(self, r):
        return 1/np.sqrt(self.potential(r))

    def turning(self, impact):
        if not impact > self.critical:
            raise ValueError('No outer scattering turning point: ell <= ell_c')
        return brentq(lambda r: self.impact(r)-impact, self.photon,
                      impact+self.rp+self.rm+1, xtol=5e-14, rtol=1e-14)

    def alpha(self, impact, tolerance=2e-11):
        rt = self.turning(impact)
        # Normalize the potential by U(rt), avoiding residual root error at z=0.
        ell = self.impact(rt)
        ap, am = self.rp/(rt-self.rp), self.rm/(rt-self.rm)
        # This factorization stays accurate near the photon sphere.
        k = (2*(rt-self.photon)*(rt-self.inner_stationary)
             / ((rt-self.rp)*(rt-self.rm)))
        assert k > 0
        def integrand(z):
            if z == 0:
                return (1-self.rm/rt)**(-self.area_exponent)/np.sqrt(k)
            if z == 1:
                return 1.0
            z2 = z*z
            log_ratio = (2*np.log1p(-z2) + np.log1p(ap*z2)
                         + self.exponent*np.log1p(am*z2))
            radicand = -np.expm1(log_ratio)
            if radicand <= 0:
                raise ArithmeticError('Nonpositive scattering radicand')
            h = 1-self.rm/rt*(1-z2)
            return z/(h**self.area_exponent*np.sqrt(radicand))
        value, error = quad(integrand, 0, 1, epsabs=tolerance,
                            epsrel=tolerance, points=[0.02, 0.2, 0.7], limit=200)
        factor = 4*ell/rt
        return factor*value-np.pi, factor*error, rt, abs(ell/impact-1)

def parameters(q):
    disc = np.sqrt(1.0 - 11.0 * np.asarray(q)**2 / 12.0)
    return 1.0 + disc, (13.0 / 11.0) * (1.0 - disc)

def areal(r, rm):
    return r * (1.0 - rm / r)**(1.0 / 13.0)

def er_potential_r(r, rp, rm):
    h = 1.0 - rm / r
    # U=f/rho^2 = (1-rp/r) H^(9/13) / r^2.
    return (1.0 - rp / r) * h**(9.0 / 13.0) / r**2

def er_photon_r(rp, rm):
    b = 39.0 * rp + 35.0 * rm
    return (b + np.sqrt(b*b - 4.0*26.0*48.0*rp*rm)) / 52.0

def rn_potential(rho, q):
    return (1.0 - 2.0/rho + q*q/rho**2) / rho**2
