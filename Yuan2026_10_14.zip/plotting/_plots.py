"""Paper plotting functions: numerical arrays in, Matplotlib figures out.

No optimization, local paths, network access or import-time figure generation.
These functions retain the published plot definitions and point selections.
"""
import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Circle
from matplotlib.colors import LogNorm, TwoSlopeNorm, ListedColormap, BoundaryNorm, SymLogNorm
from matplotlib.ticker import ScalarFormatter, LogFormatterMathtext
from matplotlib.text import Text
PARAMS = ['M', 'q', 'rho0', 'drho_dt0', 'phi0', 'dphi_dt0']
SYMS = [r'M', r'q', r'\rho_0', r'\dot\rho_0', r'\phi_0', r'\dot\phi_0']
COLORS = {'ER': '#21618c', 'RN': '#cc661d'}

def stat(x):
    a=np.asarray(x,dtype=float)
    return dict(n=a.size,min=a.min(),median=np.median(a),max=a.max())


def _sparse_symlog_ticks(ax):
    """Avoid overlapped labels around zero on very wide signed scales."""
    ax.yaxis.get_major_locator().set_params(numticks=7)
    lower, upper = ax.get_ylim()
    transform = ax.yaxis.get_transform()
    lo, hi = transform.transform(np.array([lower, upper]))
    candidates = [float(t) for t in ax.get_yticks() if lower <= t <= upper]
    position = lambda t: float((transform.transform(np.asarray([t]))[0]-lo)/(hi-lo))
    kept = [0.] if lower <= 0 <= upper else []
    for value in sorted(candidates, key=lambda t: abs(position(t)-position(0.)), reverse=True):
        if all(abs(position(value)-position(other)) >= .13 for other in kept):
            kept.append(value)
    ax.set_yticks(sorted(kept))


def _nonnegative_scale(ax, values):
    """Keep genuine zero values visible without replacing them by epsilon."""
    a = np.asarray(values, dtype=float).ravel()
    if not np.isfinite(a).all() or (a < 0).any():
        raise ValueError('Residuals, chi-squared and absolute recovery errors must be finite and nonnegative')
    if (a > 0).all():
        ax.set_yscale('log')
    else:
        positive = a[a > 0]
        if positive.size:
            ax.set_yscale('symlog', linthresh=float(positive.min()), linscale=.7)
            _sparse_symlog_ticks(ax)
            note = 'Symmetric-log scale; zeros retained'
        else:
            ax.set_yscale('linear')
            note = 'Linear scale; all values are zero'
        ax.text(1., 1.025, note.replace('; ', '\n'), transform=ax.transAxes,
                fontsize=7, va='bottom', ha='right')



def grid(cases, get):
    a = np.full((8, 10), np.nan)
    for r in cases:
        i = int(round((r['rho_peri']-4.5)*2))
        j = int(round(r['q']*10))-1
        assert not np.isfinite(a[i, j])
        a[i, j] = get(r)
    assert np.isfinite(a).all()
    return a


def heat_axes(ax):
    ax.set_xticks([0, 3, 6, 9], ['0.1', '0.4', '0.7', '1.0'])
    ax.set_yticks([0, 3, 7], ['4.5', '6.0', '8.0'])
    ax.set_xlabel(r'True charge ratio $q$')
    ax.set_ylabel(r'Areal periapsis $\rho_{\rm p}/M_{\rm true}$')


def boxes(ax, values, xpos, width=.42):
    bp = ax.boxplot(values, positions=xpos, widths=width, showfliers=False, patch_artist=True,
        boxprops={'facecolor':'none', 'edgecolor':'#1b2838', 'linewidth':.7},
        medianprops={'color':'#101010', 'linewidth':1})
    for a in bp['whiskers']+bp['caps']: a.set_visible(False)
    for y, med in zip(values, bp['medians']):
        assert np.allclose(med.get_ydata(), np.median(y), rtol=0, atol=0)


def geometry(data):
    qgrid = data['q']
    horizons_er = data['rho_horizon_ER']
    photons_er = data['rho_photon_ER']
    horizons_rn = data['rho_horizon_RN']
    photons_rn = data['rho_photon_RN']
    cases = []
    qcases = [0.0, 0.3, 0.6, 0.9, 1.0]
    colors = ['#385b84', '#3b8d91', '#66a573', '#cb9b3c', '#cc6551']
    fig, axs = plt.subplots(1, 2, figsize=(8.0, 3.45))
    fig.subplots_adjust(left=0.075, right=0.985, bottom=0.175, top=0.855, wspace=0.27)
    for ax in axs:
        ax.spines[['top', 'right']].set_visible(False)
        ax.grid(axis='y', color='#e7ebef', linewidth=0.55, zorder=0)
        ax.tick_params(direction='out', length=3, width=0.65)
        ax.set_axisbelow(True)
    blue, red = ('#2f718e', '#bf655b')
    axs[0].plot(qgrid, photons_er, color=blue, lw=1.85)
    axs[0].plot(qgrid, photons_rn, color=blue, lw=1.45, ls=(0, (4.0, 2.6)))
    axs[0].plot(qgrid, horizons_er, color=red, lw=1.85)
    axs[0].plot(qgrid, horizons_rn, color=red, lw=1.45, ls=(0, (4.0, 2.6)))
    axs[0].set(xlim=(0.0, 1.01), ylim=(0.82, 3.12), xlabel='Charge ratio $q=|Q|/M$', ylabel='Areal radius $\\rho/M$')
    axs[0].set_xticks(np.arange(0.0, 1.01, 0.2))
    axs[0].set_yticks([1, 1.5, 2, 2.5, 3])
    axs[0].set_title('(a) Horizons and photon spheres', loc='left', pad=12)
    radii_legend = axs[0].legend(handles=[Line2D([], [], color=blue, lw=1.8, label='Photon sphere $\\rho_{\\rm ph}$'), Line2D([], [], color=red, lw=1.8, label='Outer horizon $\\rho_+$')], loc='lower left', bbox_to_anchor=(0.015, 0.03), borderaxespad=0.0, handlelength=2.4, labelspacing=0.7, fontsize=9)
    axs[0].add_artist(radii_legend)
    axs[0].legend(handles=[Line2D([], [], color='#273847', lw=1.8, label='ER'), Line2D([], [], color='#273847', lw=1.45, ls=(0, (4.0, 2.6)), label='RN')], loc='upper right', borderaxespad=0.1, handlelength=2.4, fontsize=9)
    for index, (q, color) in enumerate(zip(qcases, colors)):
        er_rho, er_u = (data[f'q{index}_rho_ER'], data[f'q{index}_U_ER'])
        rn_rho, rn_u = (data[f'q{index}_rho_RN'], data[f'q{index}_U_RN'])
        axs[1].plot(er_rho, er_u, color=color, lw=1.55, zorder=3)
        axs[1].plot(rn_rho, rn_u, color=color, lw=1.3, ls=(0, (4.0, 2.6)), zorder=4)
    axs[1].set(xlim=(0.8, 8.0), ylim=(0, 0.069), xlabel='Areal radius $\\rho/M$', ylabel='Null potential $M^2 U=M^2 A/\\rho^2$')
    axs[1].set_xticks([1, 2, 3, 4, 5, 6, 7, 8])
    axs[1].set_title('(b) Null effective potential', loc='left', pad=12)
    axs[1].legend(handles=[Line2D([], [], color=c, lw=1.8, label=f'$q={q:g}$') for q, c in zip(qcases, colors)], loc='upper right', borderaxespad=0.1, handlelength=2.0, labelspacing=0.35, fontsize=9)
    return fig


def deflection(data):
    qcases = [0.0, 0.3, 0.6, 0.9, 1.0]
    colors = ['#385b84', '#3b8d91', '#66a573', '#cb9b3c', '#cc6551']
    blue, red = ('#2f718e', '#bf655b')
    dash = (0, (4.0, 2.6))
    fig, axs = plt.subplots(1, 2, figsize=(8.7, 3.85), gridspec_kw={'width_ratios': [1.25, 1]})
    fig.subplots_adjust(left=0.072, right=0.985, bottom=0.17, top=0.86, wspace=0.29)
    for ax in axs:
        ax.spines[['top', 'right']].set_visible(False)
        ax.grid(axis='y', color='#e7ebef', linewidth=0.55)
        ax.set_axisbelow(True)
        ax.tick_params(direction='out', length=3, width=0.65)
    maxerr, maxroot = (0.0, 0.0)
    for i, (q, color) in enumerate(zip(qcases, colors)):
        for theory in ('ER', 'RN'):
            bvals = data[f'q{i}_{theory}_impact']
            rows = np.column_stack((data[f'q{i}_{theory}_alpha'],))
            axs[0].plot(bvals, rows[:, 0], color=color, lw=1.6 if theory == 'ER' else 1.25, ls='-' if theory == 'ER' else dash, zorder=3 if theory == 'ER' else 4)
    axs[0].set(xlim=(3.94, 7.5), ylim=(0, 9.5), xlabel='Impact parameter $\\ell_\\gamma/M$', ylabel='Deflection angle $\\alpha$ [rad]')
    axs[0].set_xticks([4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5])
    axs[0].set_yticks([0, 2, 4, 6, 8])
    axs[0].set_title('(a) Deflection of rays from infinity', loc='left', pad=13)
    qlegend = axs[0].legend(handles=[Line2D([], [], color=c, lw=1.7, label=f'$q={q:g}$') for q, c in zip(qcases, colors)], loc='upper right', fontsize=9, labelspacing=0.32, handlelength=2.3)
    axs[0].add_artist(qlegend)
    axs[0].legend(handles=[Line2D([], [], color='#334652', lw=1.6, label='ER'), Line2D([], [], color='#334652', lw=1.3, ls=dash, label='RN')], loc='upper center', bbox_to_anchor=(0.62, 1.0), fontsize=9, handlelength=2.3)
    qgrid = data['critical_q']
    data['critical_q'] = qgrid
    for theory, color in [('ER', red), ('RN', blue)]:
        vals = data[f'critical_{theory}']
        data[f'critical_{theory}'] = vals
        axs[1].plot(qgrid, vals, color=color, lw=1.85, ls='-' if theory == 'ER' else dash, label=theory)
        axs[1].plot([1], [vals[-1]], marker='o', color=color, ms=3.2)
    axs[1].set(xlim=(0, 1.015), ylim=(3.94, 5.25), xlabel='Charge ratio $q=|Q|/M$', ylabel='Critical impact parameter $\\ell_{\\gamma,c}/M$')
    axs[1].set_title('(b) Capture-scattering threshold', loc='left', pad=13)
    axs[1].set_xticks(np.arange(0, 1.01, 0.2))
    axs[1].legend(loc='upper right', fontsize=9, handlelength=2.5)
    inset = axs[1].inset_axes([0.18, 0.12, 0.44, 0.43])
    inset.set_facecolor('white')
    for theory, color in [('ER', red), ('RN', blue)]:
        inset.plot(qgrid, data[f'critical_{theory}'], color=color, lw=1.35, ls='-' if theory == 'ER' else dash)
        inset.plot([1], [data[f'critical_{theory}'][-1]], 'o', color=color, ms=2.6)
    inset.set(xlim=(0.968, 1.002), ylim=(3.986, 4.128))
    inset.set_xticks([0.97, 1])
    inset.set_yticks([4.0, 4.06, 4.12])
    inset.tick_params(labelsize=7.5, length=2, width=0.5, pad=2)
    inset.set_title('High-charge zoom', fontsize=8, pad=4)
    for spine in inset.spines.values():
        spine.set_color('#aeb9c2')
        spine.set_linewidth(0.55)
    return fig


def photon_paths(data):
    QS = [0.0, 0.1, 0.3, 0.5, 0.7, 0.9, 1.0]
    COLORS = ['#3B4252', '#6278AA', '#2996AD', '#52A775', '#C8AB35', '#DA8359', '#B44967']
    INITIAL_RADIUS = 3.02
    plt.rcParams.update({'font.family': ['DejaVu Sans', 'DejaVu Sans'], 'font.size': 10, 'mathtext.fontset': 'stix', 'axes.labelsize': 11, 'axes.titlesize': 11, 'xtick.labelsize': 9, 'ytick.labelsize': 9, 'legend.fontsize': 10, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.linewidth': 0.65, 'savefig.dpi': 260})
    fig, axs = plt.subplots(1, 2, figsize=(9.4, 5.25))
    fig.subplots_adjust(left=0.068, right=0.988, bottom=0.13, top=0.795, wspace=0.19)
    records = []
    trajectories = {}
    for mode, ax, panel, title in zip(['r', 'rho'], axs, ['(a)', '(b)'], ['Matched coordinate radius', 'Matched areal radius']):
        for q, color in zip(QS, COLORS):
            for theory, linestyle, zorder in [('ER', '-', 3), ('RN', (0, (4.6, 2.5)), 4)]:
                stem = f'{mode}_{theory}_q{q:.1f}'
                a = {5: data[stem + '_X'], 6: data[stem + '_Y']}
                rec = {'plotted_horizon_radius_M': float(data[stem + '_horizon'])}
                ax.add_patch(Circle((0, 0), rec['plotted_horizon_radius_M'], fill=False, color=color, ls=linestyle, lw=0.7 if theory == 'ER' else 0.58, alpha=0.63, zorder=2))
                ax.plot(a[5], a[6], color=color, ls=linestyle, lw=1.75 if theory == 'ER' else 1.2, zorder=zorder)
        ax.scatter([INITIAL_RADIUS], [0], s=22, facecolors='white', edgecolors='#242A31', lw=0.8, zorder=9)
        ax.scatter([0], [0], marker='+', s=20, c='#646F77', lw=0.7, zorder=7)
        ax.annotate('Horizons', xy=(-1.05, -0.9), xytext=(-5.8, -5.4), color='#6A7278', fontsize=9, arrowprops=dict(arrowstyle='-', color='#8B949B', lw=0.55), ha='center')
        ax.set(xlim=(-12.6, 12.6), ylim=(-12.6, 12.6), aspect='equal')
        ax.set_xticks([-10, -5, 0, 5, 10])
        ax.set_yticks([-10, -5, 0, 5, 10])
        radius = 'r' if mode == 'r' else '\\rho'
        ax.set_xlabel('$X/M=(' + radius + '/M)\\cos\\phi$')
        ax.set_ylabel('$Y/M=(' + radius + '/M)\\sin\\phi$')
        ax.set_title(panel + '  ' + title + '\n$' + radius + '_0/M=3.02$', pad=10)
        ax.grid(color='#E7EAEE', lw=0.5, zorder=0)
        for sp in ax.spines.values():
            sp.set_color('#9CA6AD')
            sp.set_linewidth(0.65)
    qhandles = [Line2D([0], [0], color=c, lw=2.2, label='$q=' + f'{q:g}' + '$') for q, c in zip(QS, COLORS)]
    fig.legend(handles=qhandles, loc='upper center', bbox_to_anchor=(0.53, 0.985), ncol=7, handlelength=1.6, columnspacing=1.2, frameon=False)
    thandles = [Line2D([0], [0], color='#485663', lw=1.8, label='ER'), Line2D([0], [0], color='#485663', lw=1.4, ls=(0, (4.6, 2.5)), label='RN')]
    fig.legend(handles=thandles, loc='upper center', bbox_to_anchor=(0.53, 0.93), ncol=2, handlelength=2.8, columnspacing=2.2, frameon=False)
    return fig


def true_grid(rows):
    ZH = False
    fig, ax = plt.subplots(figsize=(10.2, 5.0), layout='constrained')
    ax.imshow(np.tile(np.arange(10) % 2, (8, 1)), origin='lower', aspect='auto', cmap=ListedColormap(['#eef5f8', '#dcebf1']), vmin=0, vmax=1)
    group_numbers = []
    for row in rows:
        group = row['q_index'] * 8 + row['peri_index'] + 1
        group_numbers.append(group)
        ax.text(row['q_index'], row['peri_index'], f'{group:02d}', ha='center', va='center', fontsize=11, color='#253943')
    assert sorted(group_numbers) == list(range(1, 81))
    peris = np.arange(4.5, 8.1, 0.5)
    ecc = (30 - peris) / (30 + peris)
    assert np.allclose(ecc, [r['areal_eccentricity'] for r in rows if r['q'] == 0.1], rtol=0, atol=1e-15)
    ax.set_yticks(np.arange(8), [f'{p:.1f} / {e:.4f}' for p, e in zip(peris, ecc)])
    ax.set_xticks(np.arange(10), [f'{q / 10:.1f}' for q in range(1, 11)])
    ax.set_xticks(np.arange(-0.5, 10, 1), minor=True)
    ax.set_yticks(np.arange(-0.5, 8, 1), minor=True)
    ax.grid(which='minor', color='white', linewidth=1.4)
    ax.tick_params(which='both', length=0)
    ax.set_xlabel('True charge ratio $q$')
    ax.set_ylabel('Periapsis $\\rho_{\\rm p}/M_{\\rm true}$ / eccentricity $e$', labelpad=10)
    ax.set_title('80 true-parameter groups: group number in each cell', loc='left', pad=12)
    return fig


def objective(rows):
    ZH = False
    fig, ax = plt.subplots(figsize=(5.3, 3.8), layout='constrained')
    jitter = np.random.default_rng(260927).uniform(-0.17, 0.17, 80)
    charges = np.asarray([r['q'] for r in rows])
    cmap = plt.get_cmap('viridis', 10)
    norm = BoundaryNorm(np.arange(0.05, 1.06, 0.1), cmap.N)
    statistics = {}
    all_values = []
    for i, theory in enumerate(('ER', 'RN')):
        y = np.asarray([r['noiseless']['models'][theory]['chi2'] for r in rows])
        all_values.extend(y)
        d = np.asarray([r['noiseless']['models'][theory]['D'] for r in rows])
        assert np.allclose(y, (d / 0.0001) ** 2, rtol=1e-12)
        dots = ax.scatter(i + jitter, y, c=charges, cmap=cmap, norm=norm, s=24, edgecolors='#40515d', linewidths=0.25, alpha=1)
        assert np.array_equal(dots.get_offsets()[:, 1], y)
        ax.plot([i - 0.24, i + 0.24], [np.median(y)] * 2, color='black', lw=1.3)
        statistics[theory] = {'count': len(y), 'min': float(y.min()), 'median': float(np.median(y)), 'max': float(y.max())}
    ax.set_xticks([0, 1], ['ER fit', 'RN fit'])
    ax.set_xlim(-0.55, 1.55)
    _nonnegative_scale(ax, all_values)
    ax.set_ylabel('Noiseless $\\chi^2_0$ ($\\sigma_{\\rm ref}=10^{-4}$)')
    ax.set_title('ER-generated data; 80 orbital groups', pad=10)
    ax.grid(axis='y', alpha=0.2)
    bar = fig.colorbar(dots, ax=ax, pad=0.055, fraction=0.055, ticks=np.arange(0.1, 1.01, 0.1))
    bar.set_label('True generating charge ratio $q$')
    return fig


def parameter_shift(cases):
    fig, axes = plt.subplots(2, 3, figsize=(7.35, 4.65), layout='constrained')
    for p, sym, ax in zip(PARAMS, SYMS, axes.flat):
        a = grid(cases, lambda r: r['noiseless']['models']['RN']['parameters'][p] - r['noiseless']['models']['ER']['parameters'][p])
        bound = np.abs(a).max()
        if bound == 0:
            # This is an explicitly labelled display extent, not fake data.
            bound = 1.
            ax.text(.5, .5, 'All differences are zero', ha='center', va='center',
                    transform=ax.transAxes, fontsize=8, zorder=5)
        im = ax.imshow(a, origin='lower', aspect='auto', cmap='RdBu_r', norm=TwoSlopeNorm(vmin=-bound, vcenter=0, vmax=bound), interpolation='nearest')
        ax.set_title('$\\widehat{' + sym + '}_{\\rm RN}-\\widehat{' + sym + '}_{\\rm ER}$')
        heat_axes(ax)
        cb = fig.colorbar(im, ax=ax, location='bottom', pad=0.09, fraction=0.08, aspect=28)
        sf = ScalarFormatter(useMathText=True)
        sf.set_powerlimits((0, 0))
        cb.formatter = sf
        cb.update_ticks()
        cb.ax.tick_params(labelsize=7, length=2)
    return fig


def recovery(rows):
    fig, axes = plt.subplots(3, 2, figsize=(6.5, 7.35))
    fig.subplots_adjust(left=0.12, right=0.98, bottom=0.07, top=0.92, wspace=0.28, hspace=0.46)
    handles = [Line2D([0], [0], color=COLORS[t], linestyle='-' if t == 'ER' else '--', marker='o', ms=4, label=t + ' fit') for t in COLORS]
    fig.legend(handles=handles, loc='upper center', ncol=2, bbox_to_anchor=(0.56, 0.986))
    for j, (p, sym, ax) in enumerate(zip(PARAMS, SYMS, axes.flat)):
        all_values = []
        for t in COLORS:
            values = np.array([[r['error'][t][j] for r in rows if r['noise'] == k] for k in range(10)])
            assert values.shape == (10, 640)
            all_values.extend(values.ravel())
            qs = np.quantile(values, [0.16, 0.5, 0.84], axis=1)
            ax.fill_between(range(10), qs[0], qs[2], color=COLORS[t], alpha=0.16, linewidth=0)
            ax.plot(range(10), qs[1], color=COLORS[t], ls='-' if t == 'ER' else '--', marker='o', ms=3.2, lw=1.2)
        _nonnegative_scale(ax, all_values)
        ax.set_xticks(range(10))
        ax.set_xlim(-0.2, 9.2)
        ax.set_title('(' + chr(97 + j) + ') $' + sym + '$', loc='left', pad=4)
        ax.set_xlabel('Noise level $\\ell$')
        if j % 2 == 0:
            ax.set_ylabel('Normalized absolute error')
        ax.grid(axis='y')
    return fig


def differences(rows):
    fig, axes = plt.subplots(3, 1, figsize=(6.5, 8.25))
    fig.subplots_adjust(left=0.15, right=0.98, bottom=0.065, top=0.965, hspace=0.44)
    for j, (q, ax) in enumerate(zip((0.1, 0.5, 1.0), axes)):
        rs = [r for r in rows if r['q'] == q]
        assert len(rs) == 640
        values = [[r['delta'] for r in rs if r['noise'] == i] for i in range(10)]
        color = plt.colormaps['viridis'](0.8 * (q - 0.1) / 0.9)
        for k in range(10):
            rr = [r for r in rs if r['noise'] == k]
            ax.scatter([k + (r['realization'] - 3.5) * 0.08 for r in rr], [r['delta'] for r in rr], color=color, s=11, alpha=0.7, edgecolors='none', rasterized=True)
        boxes(ax, values, range(10), width=0.46)
        ax.set_yscale('symlog', linthresh=0.001, linscale=0.7)
        max_abs = max((abs(v) for ys in values for v in ys))
        ymax = 10 ** math.ceil(math.log10(max_abs)) if max_abs > 0 else .001
        ax.set_ylim(-ymax, ymax)
        max_exp = int(round(math.log10(ymax)))
        exponents = range(-3, max_exp + 1) if max_exp <= 0 else range(-2, max_exp + 1, 2)
        positive_ticks = [10.0 ** e for e in exponents]
        ax.set_yticks([-v for v in positive_ticks[::-1]] + [0] + positive_ticks)
        ax.yaxis.set_major_formatter(LogFormatterMathtext(base=10, linthresh=0.001))
        ax.axhline(0, color='#777777', lw=0.65)
        ax.set_xlim(-0.5, 9.5)
        ax.set_xticks(range(10))
        ax.set_title('(' + chr(97 + j) + ') $q=' + f'{q:.1f}' + '$', loc='left', pad=5)
        ax.set_xlabel('Noise level $\\ell$ (decreasing noise)')
        ax.set_ylabel('$\\Delta\\chi^2$')
        ax.grid(axis='y')
    return fig


def residuals(cases):
    fig, axes = plt.subplots(1, 2, figsize=(7.7, 3.25), layout='constrained')
    arrays = [grid(cases, lambda r: r['noiseless']['models'][fit]['D']) for fit in ('ER', 'RN')]
    all_values = np.asarray(arrays)
    if not np.isfinite(all_values).all() or (all_values < 0).any():
        raise ValueError('Residual lengths must be finite and nonnegative')
    norm = LogNorm(1e-12, 0.01)
    contains_zero = bool((all_values == 0).any())
    if contains_zero:
        positive = all_values[all_values > 0]
        threshold = float(positive.min()) if positive.size else 1.
        norm = SymLogNorm(linthresh=threshold, vmin=0, vmax=max(.01,float(all_values.max()),threshold))
    for j, (fit, ax) in enumerate(zip(('ER', 'RN'), axes)):
        a = grid(cases, lambda r: r['noiseless']['models'][fit]['D'])
        im = ax.imshow(a, origin='lower', aspect='auto', cmap='viridis', norm=norm, interpolation='nearest')
        ax.set_title(f'({chr(97 + j)}) {fit} fit')
        heat_axes(ax)
        ax.set_xticks(np.arange(10), [f'{i / 10:.1f}' for i in range(1, 11)])
        ax.set_yticks(np.arange(8), [f'{4.5 + i / 2:.1f}' for i in range(8)])
        ax.tick_params(axis='x', labelsize=8.5)
        ax.set_xlabel('True charge ratio $q$')
        ax.set_ylabel('Areal periapsis $\\rho_{\\rm p}/M_{\\rm true}$')
    cb = fig.colorbar(im, ax=axes, location='right', pad=0.025, aspect=28)
    cb.set_label('Residual length $D/M_{\\rm true}$')
    if contains_zero:
        cb.set_label('Residual length $D/M_{\\rm true}$ (symmetric-log; zeros retained)')
    assert all((len(ax.get_xticklabels()) == 10 and len(ax.get_yticklabels()) == 8 for ax in axes))
    assert all((np.array_equal(ax.images[0].get_array(), grid(cases, lambda r: r['noiseless']['models'][fit]['D'])) for ax, fit in zip(axes, ('ER', 'RN'))))
    return fig


def extreme(core):
    fig, axes = plt.subplots(4, 1, figsize=(6.5, 9.75))
    fig.subplots_adjust(left=0.145, right=0.98, bottom=0.055, top=0.971, hspace=0.56)
    pairs = [('eq26', '\\sqrt{12/11}'), ('eq27', '\\sqrt{143/132}')]
    for j, (tag, formula) in enumerate(pairs):
        cases = sorted([r for r in core['cases'] if r['q_label'] == tag], key=lambda r: r['rho_peri'])
        rows = [r for r in core['pairs'] if r['q_label'] == tag]
        assert len(cases) == 8 and len(rows) == 640
        assert len({(r['rho_peri'], r['noise_index'], r['realization']) for r in rows}) == 640
        ax = axes[j]
        all_values = []
        for t in COLORS:
            y = np.array([math.sqrt(r['noiseless']['models'][t]['chi2']) * r['noiseless']['sigma_ref'] for r in cases])
            all_values.extend(y)
            x = np.array([r['rho_peri'] for r in cases])
            ax.plot(x, y, color=COLORS[t], lw=1.15, ls='-' if t == 'ER' else '--')
            points = ax.scatter(x, y, color=COLORS[t], s=29, zorder=3)
            np.testing.assert_array_equal(points.get_offsets(), np.column_stack([x, y]))
        _nonnegative_scale(ax, all_values)
        ax.grid(axis='y')
        ax.set_xticks(np.arange(4.5, 8.1, 0.5))
        ax.set_xlabel('Areal periapsis $\\rho_{\\rm p}/M_{\\rm true}$')
        ax.set_ylabel('Noiseless residual $D/M_{\\rm true}$')
        ax.set_title('(' + chr(97 + j) + ') $q=' + formula + '$: noiseless', loc='left', pad=6)
        handles = [Line2D([0], [0], color=COLORS[t], ls='-' if t == 'ER' else '--', marker='o', ms=4, label=t + ' fit') for t in COLORS]
        ax.legend(handles=handles, loc='center right', ncol=2, fontsize=8.7, columnspacing=1.0)
        ax = axes[j + 2]
        values = [[r['delta_chi2'] for r in rows if r['noise_index'] == i] for i in range(10)]
        if not np.isfinite(np.asarray(values)).all():
            raise ValueError('Paired chi-squared differences must be finite')
        nonpositive = any(v <= 0 for ys in values for v in ys)
        for k in range(10):
            rr = [r for r in rows if r['noise_index'] == k]
            assert len(rr) == 64
            xy = np.array([[k + (r['realization'] - 3.5) * 0.08, r['delta_chi2']] for r in rr])
            points = ax.scatter(xy[:, 0], xy[:, 1], s=12, facecolors='#62568e', edgecolors='#62568e', linewidths=0.5, alpha=0.67, rasterized=True)
            np.testing.assert_array_equal(points.get_offsets(), xy)
            assert points.get_facecolors().shape[0] > 0
        boxes(ax, values, range(10), width=0.46)
        if nonpositive:
            ax.set_yscale('symlog', linthresh=1e-3, linscale=.7)
            _sparse_symlog_ticks(ax)
            ax.axhline(0, color='#777777', lw=.65)
            ax.text(1., 1.025, 'Symmetric-log scale\nnonpositive values retained',
                    transform=ax.transAxes, fontsize=7, va='bottom', ha='right')
        else:
            ax.set_yscale('log')
        ax.set_xlim(-0.5, 9.5)
        ax.set_xticks(range(10))
        ax.grid(axis='y')
        ax.set_ylabel('Saved $\\Delta\\chi^2$')
        ax.set_xlabel('Noise level $\\ell$ (decreasing noise)')
        ax.set_title('(' + chr(99 + j) + ') $q=' + formula + '$: noisy', loc='left', pad=6)
    return fig


def s301(rows, *, adaptive_limits=False):
    plt.rcParams.update({
        'font.family': 'DejaVu Sans', 'mathtext.fontset': 'stix',
        'font.size': 10.5, 'axes.labelsize': 11, 'axes.titlesize': 11.5,
        'xtick.labelsize': 10.5, 'ytick.labelsize': 10, 'legend.fontsize': 9.5,
        'axes.spines.top': False, 'axes.spines.right': False,
        'axes.linewidth': .7, 'pdf.fonttype': 42, 'savefig.facecolor': 'white',
        'grid.alpha': .2, 'grid.linewidth': .55,
    })
    colors = plt.colormaps['viridis']([.10, .50, .90])
    labels = [r'$q=1$', r'$q=0.999q_{\rm H}$', r'$q=q_{\rm H}$']
    values = np.asarray([r['delta_chi2'] for r in rows], dtype=float)
    if not values.size or not np.isfinite(values).all():
        raise ValueError('S301 paired differences must be finite and nonempty')
    limits = (-1.5, 12.)
    expanded = bool(values.min() <= limits[0] or values.max() >= limits[1])
    if expanded:
        if not adaptive_limits:
            raise ValueError('New S301 results exceed the paper axis range; enable adaptive_limits')
        limits = (min(limits[0], 1.15*float(values.min())), max(limits[1], 1.15*float(values.max())))
    fig, axes = plt.subplots(2, 1, figsize=(7.4, 8.4), sharey=True)
    fig.subplots_adjust(left=.14, right=.975, bottom=.17, top=.875, hspace=.36)
    fig.suptitle(r'S301-scale ER-generated data: $\sigma=30\,\mu\mathrm{as}$',
                 y=.98, fontsize=13)
    for ai, (ax, orbit) in enumerate(zip(axes, ('A','B'))):
        for qi in range(3):
            group = sorted([r for r in rows if r['orbit']==orbit and r['charge_index']==qi],
                           key=lambda r: r['realization'])
            yy = np.array([r['delta_chi2'] for r in group])
            q1, med, q3 = np.quantile(yy, [.25,.5,.75])
            ax.fill_between([qi-.29, qi+.29], q1, q3, color=colors[qi], alpha=.17,
                            linewidth=.8, edgecolor=colors[qi], zorder=2)
            ax.plot([qi-.29, qi+.29], [med,med], color='#20252a', lw=1.6, zorder=4)
            ax.scatter(qi + np.linspace(-.23,.23,8), yy, s=36,
                       marker='o' if orbit=='A' else 's', color=colors[qi],
                       edgecolors='#33434b', linewidths=.45, zorder=5)
        ax.axhline(0, color='#727b84', lw=.8, ls=(0,(4,3)), zorder=1)
        ax.set_yscale('symlog', linthresh=1e-3, linscale=.75)
        ax.set_ylim(*limits)
        ticks = [-1,-.1,-.01,-.001,0,.001,.01,.1,1,10]
        if expanded:
            largest_exp = int(math.floor(math.log10(max(abs(limits[0]),limits[1]))))
            step = max(1, math.ceil((largest_exp+4)/7))
            positive = [10.**k for k in range(-3, largest_exp+1, step)]
            ticks = [-x for x in positive[::-1] if -x > limits[0]]+[0]+[x for x in positive if x < limits[1]]
        ax.set_yticks(ticks)
        ax.yaxis.set_major_formatter(LogFormatterMathtext(base=10, linthresh=1e-3))
        ax.set_xticks(range(3),labels)
        ax.set_xlim(-.55,2.55)
        ax.grid(axis='y',which='major')
        if ai == 1:
            ax.set_xlabel('Injected charge',labelpad=9)
        ax.set_title((r'(a) Case A: $\rho_{\rm p}=272,\ e=0.9832$' if orbit=='A' else
                      r'(b) Case B: $\rho_{\rm p}=284,\ e=0.9821$'),pad=12)
    fig.text(.025,.525,r'$\Delta\chi^2=\chi^2_{\rm RN}-\chi^2_{\rm ER}$',
             va='center',rotation=90,fontsize=12)
    fig.text(.55,.935,'8 noise realizations per group; all 48 paired fits shown',
             ha='center',fontsize=10,color='#394853')
    legend=[Line2D([],[],color='#20252a',lw=1.6,label='Median'),
            Line2D([],[],color='#90a8b1',lw=7,alpha=.45,label='25-75% interval')]
    fig.legend(handles=legend,loc='lower center',bbox_to_anchor=(.55,.045),ncol=2,
               frameon=False,columnspacing=2.5,handlelength=1.5)
    if expanded:
        fig.text(.55,.012,'Shared vertical range expanded to retain every new result',
                 ha='center',fontsize=8,color='#394853')
    # The caption defines q_H, the sign convention, and the symmetric-log scale.
    # Keep only the visual key below the axes, with more room below the x label.
    # Explicitly ensure that every actual point is within the shared plotted range.
    assert all(axes[0].get_ylim()[0] < r['delta_chi2'] < axes[0].get_ylim()[1] for r in rows)
    return fig
