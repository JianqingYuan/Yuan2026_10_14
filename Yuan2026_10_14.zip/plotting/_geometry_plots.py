"""Replot the cached circular and bound-orbit numerical samples."""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D


def circular(data):
    fig, (left, right) = plt.subplots(1, 2, figsize=(7.9, 3.95))
    fig.subplots_adjust(left=.078, right=.982, bottom=.19, top=.91, wspace=.26)
    blue, orange, gray, pale = '#1f77b4', '#e77925', '#69727c', '#c5a073'
    for ai, (ax, title) in enumerate(zip((left,right), ['(a) Critical circular orbits', '(b) Allowed bound-orbit region'])):
        ax.set_xlim(data[f'axis{ai}_xlim']); ax.set_ylim(data[f'axis{ai}_ylim'])
        for spine in ax.spines.values():
            spine.set_visible(True); spine.set_color('#555d65'); spine.set_linewidth(.65)
        ax.tick_params(axis='both', direction='in', length=3.2, width=.65,
                       color='#555d65', labelcolor='#222222', labelsize=8.9, top=True, right=True, pad=4)
        ax.set_axisbelow(True); ax.grid(True,color='#cbd0d5',alpha=.50,linewidth=.48)
        ax.set_title(title,loc='left',fontsize=11.2,color='#20252b',pad=9)
    for i,(color,label) in enumerate(zip([blue,blue,orange,orange], ['RN: ISCO','RN: IBCO','ER: ISCO','ER: IBCO'])):
        xy=data[f'axis0_line{i}']
        left.plot(xy[:,0],xy[:,1],color=color,label=label,lw=1.75,
                  ls='--' if i%2 else '-',solid_capstyle='round',dash_capstyle='butt')
    # This reference marker uses an axes-fraction vertical extent, not data y.
    left.axvline(data['axis0_line4'][0,0],color='#969da5',ls=':',lw=.8)
    left.set_xlabel(r'Charge-to-mass ratio $q=|Q|/M$',fontsize=10.5,labelpad=7)
    left.set_ylabel(r'Areal radius $\rho/M$',fontsize=10.5,labelpad=7)
    left.legend(loc='lower left',bbox_to_anchor=(.025,.035),ncol=2,frameon=True,fancybox=False,
                edgecolor='#d7dce0',facecolor='white',framealpha=.97,borderpad=.65,labelspacing=.7,
                columnspacing=1.1,handlelength=2.3,handletextpad=.55,prop={'family':'DejaVu Serif','size':8.5})
    colors=[gray,gray,pale,pale,orange,orange,blue,blue]
    labels=[r'ER, $q=0$ limit','_nolegend_',r'ER, $q=0.5$','_nolegend_',r'ER, $q=1$','_nolegend_',r'RN, $q=1$','_nolegend_']
    for i,(color,label) in enumerate(zip(colors,labels)):
        xy=data[f'axis1_line{i}']
        right.plot(xy[:,0],xy[:,1],color=color,label=label,lw=1.65 if 'RN' in label else 1.6,ls='--' if i>=6 else '-')
    for i,color in enumerate([gray,pale,orange]):
        xy=data[f'axis1_fill{i}']; right.fill(xy[:,0],xy[:,1],color=color,alpha=.105,edgecolor='none')
    right.set_xlabel(r'Angular momentum $L/M$',fontsize=10.5,labelpad=7)
    right.set_ylabel(r'Specific energy $E$',fontsize=10.5,labelpad=7)
    right.legend(loc='lower right',bbox_to_anchor=(.985,.015),frameon=True,fancybox=False,
                 edgecolor='#d7dce0',facecolor='white',framealpha=.98,borderpad=.65,
                 labelspacing=.52,handlelength=2.5,handletextpad=.7,prop={'family':'DejaVu Serif','size':8.5})
    fig.text(.078,.042,r'Fixed ADM mass $M=1$; ISCO: innermost stable circular orbit; IBCO: marginally bound circular orbit.',
             fontfamily='DejaVu Serif',fontsize=8.1,color='#555d65')
    return fig


def bound(data):
    fig, axes = plt.subplots(4,4,figsize=(7.65,8.7),layout='constrained')
    for j,eta in enumerate([0,.05,.10,.20]):
        axes[0,j].set_title(r'$r_-/r_+='+f'{eta:.2f}'+r'$',fontsize=10,pad=9)
    for index,ax in enumerate(axes.flat):
        i,j=divmod(index,4)
        E,L,_=data[f'panel{index}_parameters']
        if data[f'panel{index}_bound']:
            xy=data[f'panel{index}_xy'];apo=data[f'panel{index}_apo']
            ax.plot(xy[:,0],xy[:,1],c='#24649b',lw=.45)
            ax.scatter(apo[:,0],apo[:,1],s=7,color='#bc453b',zorder=4)
            nu=float(data[f'panel{index}_nu'])
            text=(rf'$E={E:.3f},\ L/M_0={L:.3f}$'+'\n' if j==0 else '')+rf'$\nu={nu:.3f}$'
            ax.text(.045,.97,text,transform=ax.transAxes,va='top',fontsize=7.3,
                    bbox={'facecolor':'white','edgecolor':'none','alpha':.85,'pad':1.0})
            ax.add_artist(plt.Circle((0,0),float(data[f'panel{index}_horizon']),fill=False,color='#555d66',lw=.65,ls='--'))
        else:
            ax.text(.5,.5,'No bound orbit',ha='center',va='center',transform=ax.transAxes,fontsize=9,color='#555d66')
        ax.set_aspect('equal');ax.grid(alpha=.13,lw=.4)
        lim=data[f'panel{index}_limits'];ax.set(xlim=lim[0],ylim=lim[1])
        ax.tick_params(labelsize=6.5)
        if j:ax.tick_params(labelleft=False)
        else:ax.set_ylabel(r'$Y/M_0$',fontsize=9)
    for ax in axes[-1]:ax.set_xlabel(r'$X/M_0$',fontsize=9)
    return fig
