"""Public figure-reproduction API. Importing this package creates no files."""

from .paper import render_all

__all__ = ['render_all']
