"""Paper-shaped demonstrations, not full-campaign statistics.

Figures 1--5 replay explicitly labelled geometric curves. Figures 6--13 use
only this run's finite endpoints: no optimizer calls and no archived fit data.
Missing/failed fits remain missing; a single draw is a point, not a box plot.
The strict full-campaign renderers in paper.py are intentionally unchanged.
"""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize, SymLogNorm, TwoSlopeNorm
from matplotlib.ticker import MaxNLocator, ScalarFormatter
from .paper import FIGURES, DEFAULT_DATA, _read_npz, _style
from . import _plots, _geometry_plots

MODELS = ('ER', 'RN')
COLORS = _plots.COLORS
PARAMETERS = _plots.PARAMS


def _prepare(rows):
    from postprocess import _demo_endpoint
    from run_state import pair_input_fingerprint, pipeline_provenance
    prepared, grouped = [], {}
    for row in rows:
        point = _demo_endpoint(row)
        if point is not None:
            point = dict(point)
            theta = np.asarray(point.get('theta'), dtype=float)
            point['theta'] = theta if theta.shape == (6,) and np.isfinite(theta).all() else None
            point['D'] = float(np.sqrt(point['chi2']) * row['case']['residual_sigma'])
        item = dict(row, endpoint=point)
        prepared.append(item)
        key = (row['metadata']['suite'], row['metadata']['dataset_id'])
        group = grouped.setdefault(key, {})
        theory = row['case']['fit_theory']
        if theory in group:
            raise ValueError(f'Duplicate demo result: {key}/{theory}')
        group[theory] = item
    pairs = []
    for key, group in grouped.items():
        if set(group) != set(MODELS):
            continue
        er, rn = (group[t] for t in MODELS)
        if pipeline_provenance(er['case']) != pipeline_provenance(rn['case']):
            raise ValueError(f'Demo pair uses different fitting workflows: {key}')
        for name in ('dataset_id', 'times', 'xy_true', 'residual_sigma'):
            if er['case'][name] != rn['case'][name]:
                raise ValueError(f'Demo pair has different observations/weights: {key}')
        for name in ('truth_id', 'truth_index', 'theta_true', 'q', 'peri', 'add_noise', 'noise_index',
                     'realization', 'sigma', 'noise_seed', 'orbit', 'charge_index', 'charge_tag', 'noise_uas'):
            if er['metadata'].get(name) != rn['metadata'].get(name):
                raise ValueError(f'Demo pair metadata disagree on {name}: {key}')
        if er['case']['fit_pipeline'] == 'legacy':
            fingerprint = pair_input_fingerprint(er['case'], rn['case'])
            if any(r['result'].get('pair_input_sha256') != fingerprint for r in (er, rn)):
                raise ValueError(f'Demo legacy pair fingerprints disagree: {key}')
        if all(r['endpoint'] is not None for r in (er, rn)):
            pairs.append((er, rn))
    return prepared, pairs


def _select(rows, suite='baseline', noisy=False):
    return [r for r in rows if r['metadata']['suite'] == suite
            and bool(r['metadata']['add_noise']) == noisy]


def _pair_select(pairs, suite, noisy):
    return [p for p in pairs if p[0]['metadata']['suite'] == suite
            and bool(p[0]['metadata']['add_noise']) == noisy]


def _empty(ax):
    ax.text(.5, .5, 'No paired demo endpoint\n(not sampled or fit unavailable)',
            transform=ax.transAxes, ha='center', va='center', color='#6a737d', fontsize=9)


def _grid_axes(ax, charges, peris):
    ax.set_xticks(range(len(charges)), [f'{q:g}' for q in charges])
    ax.set_yticks(range(len(peris)), [f'{p:g}' for p in peris])
    ax.set_xlabel(r'True charge ratio $q$')
    ax.set_ylabel(r'Periapsis $\rho_{\rm p}/M_{\rm true}$')


def _heatmap(ax, values, charges, peris, *, signed=False):
    array = np.full((len(peris), len(charges)), np.nan)
    for q, peri, value in values:
        array[peris.index(peri), charges.index(q)] = value
    finite = array[np.isfinite(array)]
    if not finite.size:
        _empty(ax)
        return None
    if signed:
        bound = float(np.abs(finite).max()) or 1.
        norm = TwoSlopeNorm(vmin=-bound, vcenter=0, vmax=bound)
        cmap = plt.colormaps['RdBu_r'].copy()
    else:
        positive = finite[finite > 0]
        threshold = float(positive.min()) if positive.size else 1.
        norm = SymLogNorm(linthresh=threshold, vmin=0, vmax=max(threshold, float(finite.max())))
        cmap = plt.colormaps['viridis'].copy()
    cmap.set_bad('#e9edf1')
    im = ax.imshow(np.ma.masked_invalid(array), origin='lower', aspect='auto', cmap=cmap, norm=norm)
    _grid_axes(ax, charges, peris)
    for i, j in np.ndindex(array.shape):
        if np.isfinite(array[i, j]):
            ax.text(j, i, f'{array[i,j]:.2g}', ha='center', va='center', fontsize=8,
                    bbox=dict(facecolor='white', alpha=.8, edgecolor='none', pad=1))
    return im


def _baseline_figure(number, rows, pairs):
    quiet = _select(rows)
    paired = _pair_select(pairs, 'baseline', False)
    charges = sorted({r['metadata']['q'] for r in quiet})
    peris = sorted({r['metadata']['peri'] for r in quiet})
    if number == 6:
        fig, ax = plt.subplots(figsize=(7.5, 3.6), layout='constrained')
        if not quiet:
            _empty(ax)
            return fig
        ax.imshow(np.zeros((len(peris), len(charges))), origin='lower', aspect='auto',
                  cmap='Blues', vmin=0, vmax=1)
        truths = {r['metadata']['truth_id']: r['metadata'] for r in quiet}
        for m in truths.values():
            ax.text(charges.index(m['q']), peris.index(m['peri']),
                    f"Group {m['group']:02d}\n$q={m['q']:g}$", ha='center', va='center')
        _grid_axes(ax, charges, peris)
        ax.set_title(f'{len(truths)} selected true-parameter groups (original group IDs)')
        return fig
    if number == 7:
        fig, ax = plt.subplots(figsize=(6, 4.2), layout='constrained')
        values = []
        for i, theory in enumerate(MODELS):
            points = [r for r in quiet if r['case']['fit_theory'] == theory and r['endpoint'] is not None]
            if points:
                y = [r['endpoint']['chi2'] for r in points]
                values.extend(y)
                offset = np.linspace(-.16, .16, len(points)) if len(points) > 1 else np.zeros(1)
                dots = ax.scatter(i + offset, y, c=[r['metadata']['q'] for r in points],
                                  cmap='viridis', norm=Normalize(.1, 1.), s=48, edgecolor='#33434b')
        if values:
            _plots._nonnegative_scale(ax, values)
            fig.colorbar(dots, ax=ax, label=r'True charge ratio $q$')
        else:
            _empty(ax)
        ax.set_xticks([0, 1], ['ER fit', 'RN fit'])
        ax.set(xlim=(-.5, 1.5), ylabel=r'Noiseless $\chi^2_0$')
        return fig
    shape, size = ((2, 3), (9, 5.8)) if number == 8 else ((1, 2), (8, 3.7))
    fig, axes = plt.subplots(*shape, figsize=size, layout='constrained')
    for i, ax in enumerate(axes.flat):
        if number == 8:
            values = [(er['metadata']['q'], er['metadata']['peri'],
                       rn['endpoint']['theta'][i] - er['endpoint']['theta'][i])
                      for er, rn in paired if all(r['endpoint']['theta'] is not None for r in (er, rn))]
            ax.set_title(r'$\widehat{' + _plots.SYMS[i] + r'}_{\rm RN}-\widehat{' + _plots.SYMS[i] + r'}_{\rm ER}$')
        else:
            values = [(r['metadata']['q'], r['metadata']['peri'], r['endpoint']['D'])
                      for r in quiet if r['case']['fit_theory'] == MODELS[i] and r['endpoint'] is not None]
            ax.set_title(MODELS[i] + ' residual length')
        im = _heatmap(ax, values, charges, peris, signed=number == 8)
        if im is not None:
            cb = fig.colorbar(im, ax=ax, location='bottom', fraction=.09, pad=.18)
            if number == 8:
                cb.locator = MaxNLocator(nbins=3)
                cb.formatter = ScalarFormatter(useMathText=True)
                cb.formatter.set_powerlimits((-2, 2))
                cb.update_ticks()
            cb.ax.tick_params(labelsize=7)
    return fig


def _recovery(rows):
    fig, axes = plt.subplots(3, 2, figsize=(7.5, 8), layout='constrained')
    noisy = _select(rows, noisy=True)
    for i, ax in enumerate(axes.flat):
        values = []
        for theory in MODELS:
            group = [r for r in noisy if r['case']['fit_theory'] == theory
                     and r['endpoint'] is not None and r['endpoint']['theta'] is not None]
            errors = [abs(r['endpoint']['theta'][i] - r['metadata']['theta_true'][i]) /
                      np.diff(r['case']['bounds'][PARAMETERS[i]])[0] for r in group]
            if errors:
                ax.scatter([r['metadata']['noise_index'] + (-.08 if theory == 'ER' else .08) for r in group],
                           errors, color=COLORS[theory], marker='o' if theory == 'ER' else 'x', label=theory)
                values.extend(errors)
        if values:
            _plots._nonnegative_scale(ax, values)
            if i == 0:
                ax.legend()
        else:
            _empty(ax)
        ax.set(title='$' + _plots.SYMS[i] + '$', xlabel=r'Noise level $\ell$',
               ylabel='Normalized absolute error', xlim=(-.5, 9.5), xticks=range(10))
    return fig


def _delta(ax, pairs, xkey='noise_index'):
    if pairs:
        ax.scatter([er['metadata'][xkey] for er, rn in pairs],
                   [rn['endpoint']['chi2'] - er['endpoint']['chi2'] for er, rn in pairs],
                   s=38, color='#62568e')
    else:
        _empty(ax)
    ax.axhline(0, color='#777777', lw=.7)
    ax.set_yscale('symlog', linthresh=1e-3, linscale=.7)
    _plots._sparse_symlog_ticks(ax)
    ax.set_ylabel(r'$\Delta\chi^2=\chi^2_{\rm RN}-\chi^2_{\rm ER}$')
    ax.grid(axis='y')
    if xkey == 'noise_index':
        ax.set(xlim=(-.5, 9.5), xticks=range(10), xlabel=r'Noise level $\ell$ (decreasing noise)')


def _differences(pairs):
    fig, axes = plt.subplots(3, 1, figsize=(7.5, 8), layout='constrained')
    noisy = _pair_select(pairs, 'baseline', True)
    for ax, q in zip(axes, (.1, .5, 1.)):
        _delta(ax, [p for p in noisy if np.isclose(p[0]['metadata']['q'], q)])
        ax.set_title(f'$q={q:g}$')
    return fig


def _extreme(rows, pairs):
    fig, axes = plt.subplots(4, 1, figsize=(7.5, 10), layout='constrained')
    for i, (tag, label) in enumerate((('eq26', r'\sqrt{12/11}'), ('eq27', r'\sqrt{13/12}'))):
        values = []
        for theory in MODELS:
            group = [r for r in _select(rows, 'extreme') if r['metadata']['charge_tag'] == tag
                     and r['case']['fit_theory'] == theory and r['endpoint'] is not None]
            if group:
                y = [r['endpoint']['D'] for r in group]
                axes[i].scatter([r['metadata']['peri'] for r in group], y,
                                color=COLORS[theory], marker='o' if theory == 'ER' else 'x', label=theory)
                values.extend(y)
        if values:
            _plots._nonnegative_scale(axes[i], values)
            axes[i].legend()
        else:
            _empty(axes[i])
        axes[i].set(title=f'$q={label}$: noiseless', ylabel=r'Residual length $D/M_{\mathrm{true}}$',
                    xlabel=r'Periapsis $\rho_{\rm p}/M_{\rm true}$')
        _delta(axes[i+2], [p for p in _pair_select(pairs, 'extreme', True)
                           if p[0]['metadata']['charge_tag'] == tag])
        axes[i+2].set_title(f'$q={label}$: noisy')
    return fig


def _s301(pairs):
    fig, axes = plt.subplots(2, 1, figsize=(7.5, 7.2), layout='constrained', sharey=True)
    noisy = _pair_select(pairs, 's301', True)
    if any(p[0]['metadata'].get('noise_uas') != 30 for p in noisy):
        raise ValueError('S301 demonstration requires the declared 30-microarcsecond data.')
    for ax, orbit in zip(axes, ('A', 'B')):
        _delta(ax, [p for p in noisy if p[0]['metadata']['orbit'].removeprefix('s301_scale_') == orbit],
               xkey='charge_index')
        ax.set(title=rf'Case {orbit}: $\sigma=30\,\mu\mathrm{{as}}$', xlim=(-.5, 2.5), xlabel='Injected charge')
        ax.set_xticks(range(3), [r'$q=1$', r'$q=0.999q_{\rm H}$', r'$q=q_{\rm H}$'])
    # Both axes have now contributed to shared limits: regenerate shared ticks.
    axes[0].set_yscale('symlog', linthresh=1e-3, linscale=.7)
    _plots._sparse_symlog_ticks(axes[0])
    return fig


def render_demo(rows, output_dir, *, dpi=160):
    """Write 13 labelled demo layouts plus an exact, auditable data summary."""
    from run_state import write_json
    rows, pairs = _prepare(rows)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    files = []
    titles = {6: 'True-parameter grid', 7: 'Noiseless objectives', 8: 'Fitted parameter shifts',
              9: 'Noiseless residuals', 10: 'Parameter recovery', 11: 'Charge slices',
              12: 'Strong-field high charges', 13: 'S301 paired differences'}
    geometry = {1: _plots.geometry, 2: _plots.photon_paths, 3: _plots.deflection,
                4: _geometry_plots.circular, 5: _geometry_plots.bound}
    for number in range(1, 14):
        with plt.rc_context():
            _style(number)
            if number <= 5:
                fig = geometry[number](_read_npz(DEFAULT_DATA / FIGURES[number][1]))
                heading = f'Figure {number} | Reference geometry (bundled numerical curves)'
                note = 'Redrawn without new integration; independent of the demonstration fits.'
            else:
                if number <= 9:
                    fig = _baseline_figure(number, rows, pairs)
                elif number == 10:
                    fig = _recovery(rows)
                elif number == 11:
                    fig = _differences(pairs)
                elif number == 12:
                    fig = _extreme(rows, pairs)
                else:
                    fig = _s301(pairs)
                heading = f'Figure {number} | DEMO: {titles[number]}'
                note = ('Finite-budget endpoints, not convergence or discrimination evidence.\n'
                        'Points only: no Monte Carlo intervals; missing results are not filled from paper data.')
            fig.text(.5, 1.025, heading, ha='center', va='bottom', fontsize=11, weight='bold')
            fig.text(.5, -.035, note, ha='center', va='top', fontsize=8, color='#54606c')
            path = output / f'demo_figure_{number:02d}_{FIGURES[number][0]}.pdf'
            try:
                fig.savefig(path, bbox_inches='tight', pad_inches=.12)
                fig.savefig(path.with_suffix('.png'), dpi=dpi, bbox_inches='tight', pad_inches=.12)
            finally:
                plt.close(fig)
            files.append(path)
    report = dict(reference_geometry_figures=list(range(1, 6)),
                  reference_geometry_source='data/paper (geometry only)',
                  demo_fit_figures=list(range(6, 14)), historical_fit_results_used=False,
                  optimizer_calls=0, integration_calls=0,
                  endpoints=[dict(case_id=r['case']['case_id'], suite=r['metadata']['suite'],
                      add_noise=r['metadata']['add_noise'], noise_index=r['metadata']['noise_index'],
                      chi2=r['endpoint']['chi2'], D=r['endpoint']['D'],
                      theta=None if r['endpoint']['theta'] is None else r['endpoint']['theta'].tolist())
                      for r in rows if r['endpoint'] is not None],
                  paired_differences=[dict(dataset_id=er['case']['dataset_id'],
                      add_noise=er['metadata']['add_noise'],
                      delta_chi2=rn['endpoint']['chi2'] - er['endpoint']['chi2']) for er, rn in pairs])
    write_json(output.parent / 'demo_plot_data.json', report)
    return files, report
