"""Plot NEW run results without falling back to historical fitted values.

Partial/demo campaigns get their own clearly labelled summary. Paper-layout
statistical figures are generated only when their entire paired input is present.
"""
from pathlib import Path
import hashlib
import json
import shutil
import numpy as np
from run_state import load_task, write_json as _write, pipeline_provenance, pair_input_fingerprint

PARAMETERS = ("M", "q", "rho0", "drho_dt0", "phi0", "dphi_dt0")


def _load(run_dir):
    rows = []
    pipelines = {}
    for path in sorted((Path(run_dir) / "tasks").glob("*/result.json")):
        case, result, receipt = load_task(path.parent)
        meta = case.get("metadata", {})
        provenance = pipeline_provenance(case)
        suite = meta.get('suite')
        if suite in pipelines and pipelines[suite] != provenance:
            raise ValueError(f'Mixed fitting pipelines or versions within {suite}.')
        pipelines[suite] = provenance
        valid = result.get("best_candidate_checks_passed") is True
        theta, chi2 = result.get("theta"), result.get("chi2")
        available = (valid and theta is not None and len(theta) == 6 and chi2 is not None
                    and np.isfinite(chi2) and chi2 >= 0 and np.all(np.isfinite(theta)))
        paper = (result["profile"] == "paper" and result["result_is_demo"] is False
                 and case.get("execution_mode") == "paper")
        rows.append(dict(case=case, metadata=meta, result=result, available=bool(available),
                         eligible=bool(available and result["run_complete"] and paper)))
    return rows


def _paired(rows, suite):
    groups = {}
    provenance = None
    for row in rows:
        m = row["metadata"]
        if m.get("suite") != suite or not row["eligible"]:
            continue
        current = pipeline_provenance(row['case'])
        if provenance is not None and current != provenance:
            raise ValueError(f'Mixed fitting pipelines or versions within {suite}.')
        provenance = current
        key = m["dataset_id"]
        models = groups.setdefault(key, {})
        theory = row["case"]["fit_theory"]
        if theory in models:
            raise ValueError(f"Duplicate new result for {key}/{theory}.")
        models[theory] = row
    pairs = []
    for key, models in sorted(groups.items()):
        if set(models) != {"ER", "RN"}:
            continue
        er, rn = models["ER"], models["RN"]
        if er['case']['fit_pipeline'] == 'legacy':
            expected_hash = pair_input_fingerprint(er['case'], rn['case'])
            if any(row['result'].get('pair_input_sha256') != expected_hash for row in (er, rn)):
                raise ValueError(f'Legacy pair fingerprints disagree with the paired inputs: {key}.')
        if er["case"]["times"] != rn["case"]["times"] or er["case"]["xy_true"] != rn["case"]["xy_true"]:
            raise ValueError(f"Paired models do not use the same observations: {key}.")
        if er["case"]["residual_sigma"] != rn["case"]["residual_sigma"]:
            raise ValueError(f"Paired model weights disagree: {key}.")
        for name in ("dataset_id", "truth_id", "truth_index", "q", "peri", "add_noise", "noise_index", "realization", "sigma", "noise_seed", "theta_true"):
            if er["metadata"].get(name) != rn["metadata"].get(name):
                raise ValueError(f"Paired model metadata disagree on {name}: {key}.")
        pairs.append((er, rn))
    return pairs


def _matches_declared_grid(pairs, suite, noisy):
    """Counts alone cannot establish a complete, correctly labelled grid."""
    root = Path(__file__).resolve().parent
    design = json.loads((root/"configs"/(suite+".json")).read_text(encoding="utf-8"))
    expected = {d["dataset_id"]:d for d in design["datasets"] if bool(d["add_noise"]) == noisy}
    seen = set()
    for er, rn in pairs:
        meta = er["metadata"]
        key = meta["dataset_id"]
        if key in seen or key not in expected:
            raise ValueError(f"Unexpected or duplicate {suite} dataset key: {key}.")
        seen.add(key)
        entry = expected[key]
        truth = design["truths"][entry["truth_index"]]
        for field in ("noise_index", "realization", "sigma", "noise_seed", "add_noise", "truth_index"):
            if meta[field] != entry[field]:
                raise ValueError(f"New-result metadata disagree with declared {suite} {key}: {field}.")
        for field, source in (("truth_id","truth_id"),("q","q"),("peri","rho_peri"),("theta_true","theta_true")):
            if meta[field] != truth[source]:
                raise ValueError(f"Truth/grid metadata disagree with declared {suite} {key}: {field}.")
    return seen == set(expected)


def _is_noisy(pair):
    return bool(pair[0]["metadata"]["add_noise"])


def _chi2(pairs):
    return np.array([[row["result"]["chi2"] for row in pair] for pair in pairs], dtype=float)


def _parameters(pairs):
    return np.array([[row["result"]["theta"] for row in pair] for pair in pairs], dtype=float)


def _meta(pairs, key, dtype=float):
    return np.array([pair[0]["metadata"][key] for pair in pairs], dtype=dtype)


def _baseline_cache(pairs, path):
    quiet = sorted([p for p in pairs if not _is_noisy(p)], key=lambda p:(p[0]["metadata"]["q"], p[0]["metadata"]["peri"]))
    noisy = sorted([p for p in pairs if _is_noisy(p)], key=lambda p:(p[0]["metadata"]["q"], p[0]["metadata"]["peri"], p[0]["metadata"]["noise_index"], p[0]["metadata"]["realization"]))
    figures = []
    data = {}
    if _matches_declared_grid(quiet, "baseline", False):
        data.update(noiseless_q=_meta(quiet,"q"), noiseless_peri=_meta(quiet,"peri"),
                    noiseless_parameters=_parameters(quiet), noiseless_chi2=_chi2(quiet),
                    noiseless_D=np.sqrt(_chi2(quiet))*_meta(quiet,"sigma")[:,None])
        figures += [6, 7, 8, 9]
    if _matches_declared_grid(noisy, "baseline", True):
        errors = []
        for pair in noisy:
            one = []
            for row in pair:
                widths = np.array([row["case"]["bounds"][key][1]-row["case"]["bounds"][key][0] for key in PARAMETERS])
                one.append(np.abs(np.array(row["result"]["theta"])-row["metadata"]["theta_true"])/widths)
            errors.append(one)
        data.update(noisy_q=_meta(noisy,"q"), noisy_peri=_meta(noisy,"peri"),
                    noisy_noise=_meta(noisy,"noise_index",int), noisy_realization=_meta(noisy,"realization",int),
                    noisy_sigma=_meta(noisy,"sigma"), noisy_error=np.array(errors), noisy_chi2=_chi2(noisy))
        figures += [10, 11]
    if figures:
        np.savez_compressed(path, **data)
    return figures


def _extreme_cache(pairs, path):
    quiet = sorted([p for p in pairs if not _is_noisy(p)], key=lambda p:(p[0]["metadata"]["charge_tag"],p[0]["metadata"]["peri"]))
    noisy = sorted([p for p in pairs if _is_noisy(p)], key=lambda p:(p[0]["metadata"]["charge_tag"],p[0]["metadata"]["peri"],p[0]["metadata"]["noise_index"],p[0]["metadata"]["realization"]))
    if not (_matches_declared_grid(quiet,"extreme",False) and _matches_declared_grid(noisy,"extreme",True)):
        return []
    np.savez_compressed(path, noiseless_tag=_meta(quiet,"charge_tag",str),
                        noiseless_peri=_meta(quiet,"peri"), noiseless_chi2=_chi2(quiet),
                        noiseless_sigma_ref=_meta(quiet,"sigma"), noisy_tag=_meta(noisy,"charge_tag",str),
                        noisy_peri=_meta(noisy,"peri"), noisy_noise=_meta(noisy,"noise_index",int),
                        noisy_realization=_meta(noisy,"realization",int), noisy_chi2=_chi2(noisy))
    return [12]


def _s301_cache(pairs, path):
    noisy = [p for p in pairs if _is_noisy(p)]
    if not _matches_declared_grid(noisy,"s301",True):
        return []
    rows = []
    seen = set()
    for er, rn in noisy:
        m = er["metadata"]
        charge_index = m.get("charge_index")
        if charge_index is None:
            charge_index = {"q1_control":0,"qH_regular_0999":1,"qH_singular_endpoint":2}[m["charge_tag"]]
        orbit = m["orbit"].removeprefix("s301_scale_")
        key = (orbit, int(charge_index), int(m["realization"]))
        if key in seen:
            raise ValueError("Duplicate S301 pairing key.")
        seen.add(key)
        er_chi, rn_chi = er["result"]["chi2"], rn["result"]["chi2"]
        rows.append(dict(orbit=orbit,charge_index=int(charge_index),realization=int(m["realization"]),
                         chi2_ER=er_chi,chi2_RN=rn_chi,delta_chi2=rn_chi-er_chi))
    expected = {(o,q,r) for o in ("A","B") for q in range(3) for r in range(8)}
    if seen != expected:
        raise ValueError("S301 rows do not match the declared 2 x 3 x 8 grid.")
    _write(path,dict(noise_uas=30,rows=rows,selection_rule="Per-model best numerically valid candidate from this new run only"))
    return [13]


def _summary(rows, output_dir, mode):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    good = [r for r in rows if r["available"] or (mode == "demo" and _demo_endpoint(r) is not None)]
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    if good:
        labels = [r["case"]["case_id"] for r in good]
        values = [r["result"]["chi2"] if r["available"] else _demo_endpoint(r)["chi2"] for r in good]
        for i, row in enumerate(good):
            ax.scatter(i, values[i], c="#277d8e" if row["case"]["fit_theory"]=="ER" else "#be6c35",
                       s=40, marker="o" if row["available"] else "x")
        ax.set_yscale("symlog", linthresh=1e-10)
        if len(good) <= 16:
            ax.set_xticks(range(len(good)), [x.replace("__", "\n") for x in labels], rotation=35, ha="right", fontsize=7)
        else:
            ax.set_xlabel("New model result index")
    else:
        ax.text(.5,.5,"No numerically valid fitted endpoint yet.\nSee task results for stopping reasons.",ha="center",va="center",transform=ax.transAxes)
    ax.set_ylabel(r"Best retained $\chi^2$")
    ax.set_title("Small live demonstration - not paper statistics" if mode=="demo" else "New recomputation - available model results")
    ax.grid(axis="y",alpha=.2)
    incomplete = sum(not r["result"].get("run_complete", False) for r in good)
    fig.text(.5,.015,f"ER: teal; RN: orange. {incomplete} displayed endpoint(s) have incomplete solves.\nCrosses: unchecked demo endpoints. No historical fit values are used.",ha="center",fontsize=8)
    fig.tight_layout(rect=(0,.06,1,1))
    path = Path(output_dir)/"new_run_summary.pdf"
    fig.savefig(path,bbox_inches="tight")
    fig.savefig(path.with_suffix(".png"),dpi=160,bbox_inches="tight")
    plt.close(fig)
    return path


def _demo_endpoint(row):
    """An unverified demo endpoint is for illustration, never paper statistics."""
    result = row['result']
    # The legacy controller evaluates its published endpoint at tight precision.
    # Use the declared residual vector directly instead of inventing a third pass.
    if result.get('residual_accuracy') in ('nominal', 'tight', 'third') and 'residuals' in result:
        residual = np.asarray(result['residuals'], dtype=float)
        observation = np.asarray(row['case']['xy_true'], dtype=float)
        chi2 = result.get('chi2')
        if (residual.size == observation.size and np.all(np.isfinite(residual))
                and chi2 is not None and np.isfinite(chi2) and chi2 >= 0):
            return dict(prediction=observation + residual.reshape(observation.shape), chi2=float(chi2))
    identifier = result.get('best_candidate_id') if row['available'] else result.get('diagnostic_best',{}).get('id')
    point = next((p for p in result.get('candidates',[]) if p.get('id')==identifier),None)
    if point is None:
        return None
    residual = np.asarray(point.get('raw_residuals',{}).get('third',[]),dtype=float)
    observation = np.asarray(row['case']['xy_true'],dtype=float)
    if residual.size != observation.size or not np.all(np.isfinite(residual)):
        return None
    chi2 = point.get('chi2',{}).get('third')
    if chi2 is None or not np.isfinite(chi2) or chi2 < 0:
        return None
    return dict(prediction=observation+residual.reshape(observation.shape),chi2=float(chi2))


def _demo_trajectories(rows, output_dir):
    import matplotlib.pyplot as plt
    datasets = {}
    for row in rows:
        point = _demo_endpoint(row)
        if point is not None:
            datasets.setdefault(row['metadata']['dataset_id'],[]).append((row,point))
    if not datasets:
        return []
    paths = []
    for index, (name, models) in enumerate(datasets.items(),1):
        fig, axes = plt.subplots(1,2,figsize=(10,3.8),sharex=True)
        reference = models[0][0]['case']
        observed = np.asarray(reference['xy_true'])
        times = np.asarray(reference['times'])
        for dimension, ax in enumerate(axes):
            ax.plot(times,observed[:,dimension],'.',color='#333333',ms=3,label='Observed target')
            for row, point in models:
                theory = row['case']['fit_theory']
                ax.plot(times,point['prediction'][:,dimension],
                    color='#277d8e' if theory=='ER' else '#be6c35',ls='-' if theory=='ER' else '--',
                    lw=1,label=theory+' finite-budget endpoint')
            ax.set(xlabel='Coordinate time (adopted units)',ylabel=('x' if dimension==0 else 'y')+' (adopted units)')
            ax.grid(alpha=.2)
        axes[0].legend(fontsize=8)
        fig.suptitle('Live demonstration: '+name,fontsize=11)
        fig.text(.5,.015,'Illustrative low-budget fits; not a converged result or a model-discrimination claim.',ha='center',fontsize=8)
        fig.tight_layout(rect=(0,.045,1,.95))
        path=Path(output_dir)/f'demo_timeseries_{index:02d}.pdf'
        fig.savefig(path,bbox_inches='tight')
        fig.savefig(path.with_suffix('.png'),dpi=160,bbox_inches='tight')
        plt.close(fig)
        paths.append(path)
    return paths


def _collection_geometry(run_dir, rows, figures, data_dir):
    """Recompute geometry once, only for a complete new full-design collection."""
    plan_path = run_dir / 'run.json'
    if (set(figures) != set(range(6, 14)) or not rows
            or not all(row['eligible'] for row in rows) or not plan_path.is_file()):
        return []
    plan = json.loads(plan_path.read_text(encoding='utf-8'))
    if plan.get('mode') != 'collection':
        return []
    from experiments.api import list_case_ids
    expected = set(list_case_ids(suite='all', mode='paper', models=('ER', 'RN')))
    actual = [row['case']['case_id'] for row in rows]
    if len(actual) != len(expected) or set(actual) != expected:
        return []
    from main import _scientific_source_hash
    source_hash = _scientific_source_hash()
    if plan.get('source_science_sha256') != source_hash:
        raise ValueError('Full collection fingerprint differs from this package.')
    from plotting.paper import FIGURES
    caches = {FIGURES[i][1]: data_dir / FIGURES[i][1] for i in range(1, 6)}
    marker = run_dir / 'geometry_recompute.json'
    previous = json.loads(marker.read_text(encoding='utf-8')) if marker.is_file() else {}
    hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest()
              for name, path in caches.items() if path.is_file()}
    if (previous.get('source_science_sha256') != source_hash
            or previous.get('cache_sha256') != hashes or len(hashes) != len(caches)):
        from plotting.geometry_data import recompute_geometry
        recompute_geometry(data_dir, figure_ids=list(range(1, 6)))
        hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest()
                  for name, path in caches.items()}
        _write(marker, dict(source_science_sha256=source_hash, cache_sha256=hashes,
                            original_paper_snapshot_used=False))
    return list(range(1, 6))


def render_run(run_dir, mode="recompute"):
    run_dir = Path(run_dir)
    output = run_dir / "figures"
    output.mkdir(parents=True, exist_ok=True)
    rows = _load(run_dir)
    files = [_summary(rows, output, mode)]
    if mode == 'demo':
        files.extend(_demo_trajectories(rows,output))
    data_dir = run_dir / "plot_data"
    data_dir.mkdir(exist_ok=True)
    figures = []
    if mode != "demo":
        figures += _baseline_cache(_paired(rows,"baseline"), data_dir/"fits.npz")
        figures += _extreme_cache(_paired(rows,"extreme"), data_dir/"extreme.npz")
        figures += _s301_cache(_paired(rows,"s301"), data_dir/"s301.json")
        figures = _collection_geometry(run_dir, rows, figures, data_dir) + figures
        if figures:
            from plotting.paper import render_all
            files.extend(render_all(output,figure_ids=figures,data_dir=data_dir))
    _write(run_dir / "plot_status.json", dict(
        mode=mode,model_results=len(rows),available_endpoints=sum(r["available"] for r in rows),
        fit_pipelines={r['metadata']['suite']:pipeline_provenance(r['case']) for r in rows},
        eligible_endpoints=sum(r["eligible"] for r in rows),
        paper_layout_figures_generated=figures,
        note="Statistical paper layouts require the entire relevant paired dataset. Geometry is recomputed only for a complete, plot-eligible full-design collection. Plot eligibility is not a claim that every scientific check passed. Missing points are never filled from the historical archive.",
        original_paper_snapshot_used=False))
    return files


def _declared_model_ids(plan):
    """Older runs may omit selection metadata; declared selections are binding."""
    selection = plan.get('work_unit_selection')
    if selection is None:
        if plan.get('signature', {}).get('task_range') is not None:
            raise ValueError('Ranged run lacks its declared model-task selection.')
        return None
    ids = selection.get('model_case_ids') if isinstance(selection, dict) else None
    if (not isinstance(ids, list) or not ids
            or any(not isinstance(identity, str) or not identity for identity in ids)
            or len(set(ids)) != len(ids)):
        raise ValueError('Run must declare a nonempty, unique model_case_ids list.')
    return set(ids)


def collect_runs(input_dirs, output_dir):
    """Merge explicit same-policy run folders, never choose between rerun minima.

    The caller creates an empty destination. All inputs are checked before any
    task copies. Conflicting duplicate identities require a human decision.
    """
    output_dir=Path(output_dir).resolve()
    if any(output_dir.iterdir()):
        raise ValueError('Collection destination must be empty.')
    source_hash=None
    requested_pipeline=None
    pipeline_versions={}
    tasks={}
    legacy_pairs={}
    from main import _scientific_source_hash
    current_source_hash=_scientific_source_hash()
    for directory in input_dirs:
        directory=Path(directory).resolve()
        plan=json.loads((directory/'run.json').read_text(encoding='utf-8'))
        signature=plan.get('signature',{})
        if signature.get('mode')!='recompute' or not signature.get('science_sha256'):
            raise ValueError('Only new recompute runs with scientific fingerprints can be collected.')
        requested = signature.get('fit_pipeline_requested')
        declared = signature.get('fit_pipelines')
        if requested not in ('paper', 'legacy', 's301') or not isinstance(declared, dict):
            raise ValueError('Run lacks explicit fitting pipeline provenance; use its originating release.')
        if requested_pipeline is None:
            requested_pipeline = requested
        if requested != requested_pipeline:
            raise ValueError('Requested fitting pipelines differ between runs.')
        for suite, info in declared.items():
            if suite in pipeline_versions and pipeline_versions[suite] != info:
                raise ValueError(f'Fitting pipeline versions differ for {suite}.')
            pipeline_versions[suite] = info
        if source_hash is None:
            source_hash=signature['science_sha256']
        if signature['science_sha256']!=source_hash:
            raise ValueError('Scientific source fingerprints differ between runs.')
        if source_hash!=current_source_hash:
            raise ValueError('Run fingerprint differs from this package; use its matching release to collect.')
        declared_ids = _declared_model_ids(plan)
        actual_ids = set()
        run_legacy_pairs = {}
        for task in (directory/'tasks').iterdir() if (directory/'tasks').is_dir() else []:
            if not task.is_dir():
                continue
            case,result,saved=load_task(task,profile='paper')
            identity=case['case_id']
            actual_ids.add(identity)
            provenance=pipeline_provenance(case)
            suite=case.get('metadata',{}).get('suite')
            expected=declared.get(suite)
            if (provenance['fit_pipeline_requested'] != requested or not isinstance(expected,dict)
                    or any(provenance.get(name) != expected.get(name)
                           for name in ('fit_pipeline','fit_pipeline_version'))):
                raise ValueError(f'Task pipeline disagrees with its run plan: {identity}.')
            if case.get('execution_mode') != 'paper':
                raise ValueError(f'Only declared paper inputs can enter a paper collection: {identity}.')
            task_hash=hashlib.sha256(b''.join((task/name).read_bytes() for name in
                ('case.json','result.json','task_receipt.json'))).hexdigest()
            if identity in tasks and tasks[identity][0]!=task_hash:
                raise ValueError(f'Conflicting duplicate results for {identity}; no automatic best-of-reruns selection.')
            tasks[identity]=(task_hash,task)
            if case['fit_pipeline']=='legacy':
                legacy_pairs.setdefault(case['dataset_id'],{})[case['fit_theory']]=(case,result)
                run_legacy_pairs.setdefault(case['dataset_id'], set()).add(case['fit_theory'])
        if declared_ids is not None:
            if actual_ids != declared_ids:
                missing, extra = declared_ids - actual_ids, actual_ids - declared_ids
                raise ValueError(f'Run task set disagrees with model_case_ids: '
                                 f'{len(missing)} missing, {len(extra)} extra in {directory.name}.')
            for dataset, models in run_legacy_pairs.items():
                if models != {'ER', 'RN'}:
                    raise ValueError(f'A declared run cannot split a legacy pair: {dataset}.')
    if not tasks:
        raise ValueError('No saved new-run task results to collect.')
    for dataset,models in legacy_pairs.items():
        if set(models) != {'ER','RN'}:
            raise ValueError(f'Collection requires both members of a legacy pair: {dataset}.')
        expected_hash=pair_input_fingerprint(models['ER'][0],models['RN'][0])
        if any(result['pair_input_sha256'] != expected_hash for case,result in models.values()):
            raise ValueError(f'Legacy paired inputs disagree with saved fingerprints: {dataset}.')
    for identity, (digest,task) in tasks.items():
        destination=output_dir/'tasks'/identity
        destination.mkdir(parents=True,exist_ok=False)
        for name in ('case.json','result.json','task_receipt.json'):
            shutil.copy2(task/name,destination/name)
    _write(output_dir/'run.json',dict(mode='collection',fit_calls=0,
        source_science_sha256=source_hash,model_tasks=len(tasks),
        fit_pipeline_requested=requested_pipeline,fit_pipelines=pipeline_versions,
        original_paper_snapshot_used=False))
    return render_run(output_dir,mode='recompute')
