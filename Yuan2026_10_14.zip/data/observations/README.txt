Observation archive format
==========================
baseline.npz and extreme.npz contain times_NNN and xy_NNN for each true orbit.
xy_NNN is a 101 by 2 double-precision array of noiseless x,y coordinates. The
catalogue fixes uncertainty, random seed, and the exact noise draw ordering.
experiments.api materializes noisy observations without integrating an orbit.

s301.npz contains times_NNN and xy_NNN for each retained original TNNN data set;
these xy arrays are the actual observed fitting targets (including the noise
when applicable). Only T(17*g+j), g=0..5, j=0..8, are retained. Each g begins
with one noiseless data set and is followed by eight 30-microarcsecond sets.

These files contain experimental INPUTS, not fitted solutions. They do not
warm-start either model. Metadata in configs/*.json records provenance and
the one explicitly regenerated old extreme truth. NumPy's NPZ format is read
with allow_pickle=False.
