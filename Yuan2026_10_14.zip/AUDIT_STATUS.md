# Audit status / 审计状态 — 2026-10-16

The targeted scientific campaign and the portable software tests are different
evidence. The campaign closed the reviewed counterexamples within a finite
scope; it did not prove global minima or test every archived fit. This package
integrates conditional remediation. The saved `data/paper/` snapshot now
includes the reviewed four S301 pairs and 77 extreme ER corrections used in
the revised manuscript Figures 13 and 12. All other saved values are retained.
See `VALIDATION.json` for software tests and the separate data-sync record.

## 1. Four selected S301 pairs

T054, T071, T088 and T091 were traced and reviewed using the original
observations, weights, bounds and three integration precisions. Independent
DE lineages, their derived continuations, and nonvoting warm candidates are
distinguished. The retained third-precision RN-minus-ER differences are:

- T054: 3.0002628444023856
- T071: 4.748174996904481
- T088: 4.794801997768417
- T091: 0.23726324591945058 (historical value: 6.920452575488611)

The T091 change is substantial, not rounding or merely a plotting-cache error.
Its retained ER value includes an explicitly nonvoting, reevaluated historical
warm candidate; it must not be described as an additional independent DE vote.
These are four selected difficult pairs, not a revalidation of all 48 noisy
S301 pairs. The other three differences are still above one. Figure 13 keeps
all 48 pairs, of which 45 have absolute differences below one after correction.
The numbers above retain the original audit report; the exported cache sums
squared raw third-precision residuals with math.fsum, giving T091
0.23726324591950743 (a last-bit arithmetic difference, not a new fit).

## 2. The 77 known extreme ER counterexamples

All 77 identified cases have traceable dispositions and 154 retained
source-endpoint records. The selected results comprise 37 thin-interior points
and 40 exact-charge-boundary points. Neither one universal fixed charge nor
one universal inward offset reproduces this result. The original fit upper
bound is sqrt(12/11), distinct from the horizon endpoint sqrt(13/12).

ER chi-square improvements range from 1.309709414 to 101.498740085. Holding the
historical RN scalars fixed, the smallest retained RN-minus-ER difference is
about 1.31645e9 and the largest relative change is about 2.443e-9. This supports
negligible impact on the enormous separation **under that stated condition**;
historical extreme RN parameter vectors and minima were not revalidated.

## 3. Evidence and portable integration

New runs retain parameters, residuals, effective bounds, integration settings,
source identities, actual termination reasons, failed attempts and finite
budgets. A lower unresolved actual candidate can veto a higher consensus.
Truth is a feasible comparison, not an optimization seed. Continuations and
warm candidates do not add independent DE votes. A solver success flag alone
cannot supply scientific acceptance.

The separate [audit evidence](../audit_evidence_20261015.zip) contains selected endpoint evidence
for these four pairs and 77 ER cases, original observations and exact old-cache
identities. Its standard-library verifier checks hashes and saved residual
arithmetic without running fits. It is a subset of the archived campaign, not
all exploratory trajectories and not a test of the new portable implementation.

Two original ordinary-orbit controls, noisy and noiseless, also closed without
an observed regression in the reviewed parameters. Those original-workflow
controls cannot substitute for testing the integrated release. Its actual
tests, budgets and unresolved outcomes are recorded separately in
`VALIDATION.json`; short demo success is not full-budget scientific validation.

## 4. Exact ER endpoint and quick start

The earlier explicit endpoint repair is retained and tested. It gives the
analytic zero areal-horizon radius at the exact endpoint and rejects division
by that zero radius; nearby points are not snapped onto it. See
`vendor/ER_ENDPOINT_PATCH.md` for the patch and original hashes.

The launcher and both READMEs agree on `MODE="paper"`, `WORKERS=1` by default.
That mode redraws the partially corrected paper snapshot, with no new fitting.
The saved-data revision is separate from software testing or fresh full-campaign
verification. Demo/recompute perform new fits and do not use paper fits as seeds.

## 中文结论

- 已完成限定范围的科学复核：四对S301、77个已知极端ER反例及两个原普通轨道对照。
- T091的配对差从约6.92045降至0.23726，是实质修正；不是可忽略尾数或缓存显示错误。
- 77例分别需要薄内层或精确边界，不能简单统一固定电荷。旧extreme RN没有被本轮重验。
- 本版把有证据支持的有限补算整合进调用层；历史专项成功不代替新版程序的实际测试。
- 默认论文数据已同步四对S301及77个ER修正，与修订稿图12/13一致；其他历史值保留。
- 原证据附件仍原样保留旧值、新值及来源，不能把局部修正称为全量重验。
- 不证明全局最优、所有历史样本正确或普适上位版本；见验证记录中的实际范围和限制。
