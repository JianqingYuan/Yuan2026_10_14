"""One entry point: redraw the paper, try a live demo, or recompute new fits.

No cluster access, network requests or package installation. New fits use a
bounded, recorded reliability retry policy; interrupted runs are not restarted.
Importing this module does not perform an experiment.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
from datetime import datetime, timezone
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import sys
import signal
import threading
import traceback

# Set before NumPy/SciPy import, including in Windows child processes.
for _variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
                  "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[_variable] = "1"

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
_STOP_EVENT = None


from run_state import (write_json as _write_json, digest as _digest, load_task,
                       pipeline_provenance, pair_input_fingerprint)


def _scientific_source_hash():
    digest = hashlib.sha256()
    for name in ('main.py', 'run_state.py', 'postprocess.py'):
        digest.update(name.encode())
        digest.update((ROOT / name).read_bytes())
    for folder in ("engine", "vendor", "configs", "experiments", "data/observations", "plotting"):
        base = ROOT / folder
        for path in sorted(base.rglob("*")):
            if not path.is_file() or "__pycache__" in path.parts:
                continue
            digest.update(path.relative_to(ROOT).as_posix().encode())
            digest.update(path.read_bytes())
    return digest.hexdigest()


def _run_task(case, destination, cores_per_fit, profile):
    """A task owns one directory; truth metadata are not optimizer seeds."""
    from engine.reliability import fit_case_reliable

    if _STOP_EVENT is not None and _STOP_EVENT.is_set():
        raise KeyboardInterrupt
    task_dir = Path(destination)
    receipt = task_dir / "task_receipt.json"
    provenance = pipeline_provenance(case)
    if provenance['fit_pipeline'] != 's301':
        raise ValueError('Legacy fitting requires an atomic ER/RN pair.')
    case_hash = _digest(case)
    if task_dir.exists():
        raise FileExistsError(f"Refusing to overwrite a task directory: {task_dir}")
    task_dir.mkdir(parents=True)
    _write_json(task_dir / "case.json", case)
    _write_json(receipt, {"case_id": case["case_id"], "case_sha256": case_hash,
                          "state": "RUNNING", "profile": profile, **provenance})
    try:
        result = fit_case_reliable(case, task_dir / "fit", workers=cores_per_fit, profile=profile,
                          cancel_event=_STOP_EVENT, policy=case.get('reliability_policy'))
        if any(result.get(key) != value for key, value in provenance.items()):
            raise ValueError('Engine returned incompatible pipeline provenance.')
        _write_json(task_dir / "result.json", result)
        state = "FINISHED" if result.get("run_complete") else "INCOMPLETE"
        _write_json(receipt, {"case_id": case["case_id"], "case_sha256": case_hash,
                              "state": state, "profile": profile, **provenance,
                              "engine_status": result.get("status"),
                              "scientific_checks_passed": result.get("scientific_checks_passed", False),
                              "note": "Execution finished; not a claim of global optimality."})
        return {"case_id": case["case_id"], "state": state,
                "engine_status": result.get("status"),
                "scientific_checks_passed": result.get("scientific_checks_passed", False)}
    except BaseException as exc:
        _write_json(receipt, {"case_id": case["case_id"], "case_sha256": case_hash,
                              "state": "FAILED_OR_INTERRUPTED", "profile": profile, **provenance,
                              "exception": type(exc).__name__, "message": str(exc),
                              "traceback": traceback.format_exc()})
        if isinstance(exc, (KeyboardInterrupt, SystemExit)):
            raise
        return {"case_id": case["case_id"], "state": "FAILED_OR_INTERRUPTED",
                "message": str(exc)}


def _run_pair(cases, destinations, cores_per_fit, profile):
    """Run the historical coupled ER/RN controller once for this data set."""
    from engine.reliability import fit_pair_reliable
    if _STOP_EVENT is not None and _STOP_EVENT.is_set():
        raise KeyboardInterrupt
    by_model = {case['fit_theory']: (case, Path(path)) for case, path in zip(cases, destinations)}
    if len(cases) != 2 or set(by_model) != {'ER', 'RN'}:
        raise ValueError('Legacy execution requires both ER and RN exactly once.')
    er, rn = by_model['ER'][0], by_model['RN'][0]
    provenance = pipeline_provenance(er)
    if provenance['fit_pipeline'] != 'legacy' or pipeline_provenance(rn) != provenance:
        raise ValueError('Legacy pair pipeline identities disagree.')
    if er['dataset_id'] != rn['dataset_id']:
        raise ValueError('Legacy pair data-set identities disagree.')
    pair_hash = pair_input_fingerprint(er, rn)
    if (not er['dataset_id'] or er['dataset_id'] in ('.', '..') or any(
            c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-'
            for c in er['dataset_id'])):
        raise ValueError('Unsafe legacy data-set identity.')
    paths = [by_model[model][1] for model in ('ER', 'RN')]
    if any(path.exists() for path in paths):
        raise FileExistsError('Refusing to overwrite either member of a legacy pair.')
    pair_dir = paths[0].parents[1] / 'pair_fits' / er['dataset_id']
    if pair_dir.exists():
        raise FileExistsError(f'Refusing to overwrite a legacy paired fit: {pair_dir}')
    for model in ('ER', 'RN'):
        case, path = by_model[model]
        path.mkdir(parents=True)
        _write_json(path / 'case.json', case)
        _write_json(path / 'task_receipt.json', dict(case_id=case['case_id'],
            case_sha256=_digest(case), state='RUNNING', profile=profile,
            pair_input_sha256=pair_hash, **provenance))
    try:
        results = fit_pair_reliable(er, rn, pair_dir, workers=cores_per_fit, profile=profile,
                           cancel_event=_STOP_EVENT, policy=er.get('reliability_policy'))
        if set(results) != {'ER', 'RN'}:
            raise ValueError('Legacy engine did not return both model results.')
        for model in ('ER', 'RN'):
            case, path = by_model[model]
            result = results[model]
            if (result.get('case_id') != case['case_id'] or result.get('fit_theory') != model
                    or any(result.get(key) != value for key, value in provenance.items())):
                raise ValueError('Legacy engine returned incompatible case/pipeline identity.')
            result['pair_input_sha256'] = pair_hash
        outcomes = []
        # Publish both result documents before either completion receipt.
        for model in ('ER', 'RN'):
            _write_json(by_model[model][1] / 'result.json', results[model])
        for model in ('ER', 'RN'):
            case, path = by_model[model]
            result = results[model]
            state = 'FINISHED' if result.get('run_complete') else 'INCOMPLETE'
            outcome = dict(case_id=case['case_id'], state=state,
                engine_status=result.get('status'),
                scientific_checks_passed=result.get('scientific_checks_passed', False))
            _write_json(path / 'task_receipt.json', dict(outcome,
                case_sha256=_digest(case), profile=profile, pair_input_sha256=pair_hash, **provenance))
            outcomes.append(outcome)
        return outcomes
    except BaseException as exc:
        outcomes = []
        for model in ('ER', 'RN'):
            case, path = by_model[model]
            outcome = dict(case_id=case['case_id'], state='FAILED_OR_INTERRUPTED', message=str(exc))
            _write_json(path / 'task_receipt.json', dict(outcome,
                case_sha256=_digest(case), profile=profile, exception=type(exc).__name__,
                traceback=traceback.format_exc(), pair_input_sha256=pair_hash, **provenance))
            outcomes.append(outcome)
        if isinstance(exc, (KeyboardInterrupt, SystemExit)):
            raise
        return outcomes


def _case_units(cases):
    """Catalogue order keeps paired models adjacent; retain only one pair in memory."""
    iterator = iter(cases)
    for case in iterator:
        if case.get('fit_pipeline') != 'legacy':
            yield (case,)
            continue
        other = next(iterator, None)
        if (other is None or other.get('fit_pipeline') != 'legacy'
                or case['dataset_id'] != other['dataset_id']
                or {case['fit_theory'], other['fit_theory']} != {'ER', 'RN'}):
            raise ValueError('Legacy tasks must contain complete adjacent ER/RN pairs.')
        yield (case, other)


def _unit_call(unit, output, cores_per_fit, profile):
    destinations = [Path(output) / 'tasks' / case['case_id'] for case in unit]
    if len(unit) == 1:
        return _run_task, (unit[0], str(destinations[0]), cores_per_fit, profile)
    return _run_pair, (unit, tuple(map(str, destinations)), cores_per_fit, profile)


def _worker_init(stop_event):
    global _STOP_EVENT
    _STOP_EVENT = stop_event
    signal.signal(signal.SIGINT, signal.SIG_IGN)


def _resource_layout(total, per_fit):
    if type(total) is not int or type(per_fit) is not int or total < 1 or per_fit < 1 or per_fit > total:
        raise ValueError("Require 1 <= cores-per-fit <= workers.")
    available = os.cpu_count() or 1
    if hasattr(os, "sched_getaffinity"):
        available = min(available, len(os.sched_getaffinity(0)))
    allocated = os.environ.get("SLURM_CPUS_PER_TASK")
    if allocated:
        available = min(available, int(allocated))
    if total > available:
        raise ValueError(f"Requested {total} CPUs; this process has at most {available}.")
    concurrency = total // per_fit
    if sys.platform == "win32":
        concurrency = min(concurrency, 61)
    return concurrency


def _parser():
    import settings
    parser = argparse.ArgumentParser(description=__doc__)
    common = parser.add_argument_group("Common options")
    advanced = parser.add_argument_group("Advanced options")
    common.add_argument("--mode", choices=("paper", "demo", "recompute"), default=settings.MODE,
                        help="paper: redraw saved figures; demo: short fits; recompute: full-budget fits.")
    common.add_argument("--suite", choices=("all", "baseline", "extreme", "s301"), default=settings.SUITE,
                        help="Dataset suite for demo/recompute.")
    common.add_argument('--fit-pipeline', choices=('paper', 'legacy', 's301'), default=settings.FIT_PIPELINE,
                        help='paper: historical per-suite flows; legacy or s301: force a fitting flow. Ignored for paper redraws.')
    common.add_argument("--workers", type=int, default=settings.WORKERS,
                        help="Total CPU allocation (default: %(default)s).")
    common.add_argument("--task-range", nargs=2, metavar=("FIRST", "LAST"),
                        help="Recompute only: inclusive 1-based work-unit range; legacy ER/RN pairs stay together.")
    common.add_argument("--output", type=Path, help="New output directory, must not already exist.")
    common.add_argument("--dry-run", action="store_true", help="Print the plan without fitting or writing outputs.")
    advanced.add_argument("--cores-per-fit", type=int, default=settings.CORES_PER_FIT,
                          help="CPUs per fit; other allocated CPUs run parallel fits.")
    advanced.add_argument("--resume", type=Path,
                        help="Reuse finished tasks of this identical plan; interrupted tasks are not restarted.")
    advanced.add_argument("--max-tasks", type=int, help="Limit the number of selected model fits.")
    advanced.add_argument("--task-index", type=int, help="Select one zero-based model task in the chosen suite.")
    advanced.add_argument("--models", nargs="+", choices=("ER", "RN"), default=["ER", "RN"])
    advanced.add_argument("--figures", type=int, nargs="+", help="Figure IDs for saved-data redraws (1-13).")
    advanced.add_argument("--verify", action="store_true", help="Check release-file hashes and exit.")
    advanced.add_argument("--collect", nargs="+", type=Path,
                        help="Merge named new-run directories and draw complete grids; no fitting.")
    return parser


def _effective_task_range(options):
    """Ignore range settings outside recompute, including invalid unused values."""
    if options.mode != 'recompute':
        return None
    import settings
    value = getattr(options, 'task_range', None)
    if value is not None:
        try:
            value = tuple(int(item) for item in value)
        except (TypeError, ValueError):
            raise ValueError('task-range requires two integer task numbers.') from None
    else:
        value = settings.TASK_RANGE
    if value is None:
        return None
    if (not isinstance(value, (tuple, list)) or len(value) != 2
            or any(type(item) is not int for item in value)
            or value[0] < 1 or value[1] < value[0]):
        raise ValueError('TASK_RANGE must be None or (first, last), with integer 1 <= first <= last.')
    if options.max_tasks is not None or options.task_index is not None:
        raise ValueError('Choose task-range OR max-tasks/task-index, not both.')
    return tuple(value)


def _identifier_units(identifiers, fit_pipeline, *, validate_pairs=True):
    """Group cheap catalogue IDs exactly like the execution-level case units."""
    from experiments.api import resolve_fit_pipeline
    from itertools import groupby
    for (suite, dataset), items in groupby(identifiers, key=lambda item: tuple(item.split('__')[:2])):
        unit = tuple(items)
        if resolve_fit_pipeline(suite, fit_pipeline) != 'legacy':
            yield from ((identifier,) for identifier in unit)
            continue
        if validate_pairs and (len(unit) != 2 or {item.split('__')[2] for item in unit} != {'ER', 'RN'}):
            raise ValueError('Legacy fitting is a coupled ER/RN computation. Select both models and complete pairs; '
                             '--task-index cannot select a legacy pair. Use --task-range for complete work units.')
        yield unit


def _selection_plan(options):
    """Plan only with catalogue metadata; do not load observation arrays."""
    from experiments.api import list_case_ids
    selected_range = _effective_task_range(options)
    mode = 'demo' if options.mode == 'demo' else 'paper'
    identifiers = list_case_ids(options.suite, mode, models=tuple(options.models))
    # Unselected legacy slots may be incomplete with an advanced --models filter.
    # Validate only the actual selection, retaining old --task-index semantics.
    units = list(_identifier_units(identifiers, options.fit_pipeline, validate_pairs=False))
    total = len(units)
    first, last = 1, total
    if selected_range is not None:
        first, last = selected_range
        if last > total:
            raise ValueError(f'task-range outside [1, {total}]; the upper bound is inclusive.')
        selected_units = units[first - 1:last]
    elif options.task_index is not None:
        if options.task_index < 0 or options.task_index >= len(identifiers):
            raise ValueError(f'task-index outside [0, {len(identifiers) - 1}].')
        selected_units = list(_identifier_units([identifiers[options.task_index]], options.fit_pipeline))
        first = last = next(i for i, unit in enumerate(units, 1) if identifiers[options.task_index] in unit)
    elif options.max_tasks is not None:
        if options.max_tasks < 1:
            raise ValueError('max-tasks must be positive.')
        selected_units = list(_identifier_units(identifiers[:options.max_tasks], options.fit_pipeline))
        last = len(selected_units)
    else:
        selected_units = units
    selected_ids = [identifier for unit in selected_units for identifier in unit]
    selected_units = list(_identifier_units(selected_ids, options.fit_pipeline))
    return dict(total=total, selected=len(selected_units), first=first, last=last,
                model_case_ids=selected_ids)


def _select_inputs(options):
    from itertools import islice
    from experiments.api import iter_cases, list_case_ids
    mode = "demo" if options.mode == "demo" else "paper"
    if _effective_task_range(options) is not None:
        from itertools import groupby
        identifiers = _selection_plan(options)['model_case_ids']
        # A slice can cut through a single-model workflow's edge data sets.
        # Batch only consecutive data sets with the same selected model list:
        # no preceding observations or unselected edge models are loaded.
        datasets = []
        for (suite, dataset), items in groupby(identifiers, key=lambda value: tuple(value.split('__')[:2])):
            datasets.append((suite, dataset, tuple(item.split('__')[2] for item in items)))
        for (suite, models), items in groupby(datasets, key=lambda item: (item[0], item[2])):
            yield from iter_cases(suite, mode, models=models,
                                  indices=tuple(item[1] for item in items), fit_pipeline=options.fit_pipeline)
    elif options.task_index is not None:
        identifier = list_case_ids(options.suite, mode, models=tuple(options.models))[options.task_index]
        suite, dataset, model = identifier.split('__')
        yield from iter_cases(suite, mode, models=(model,), indices=(dataset,), fit_pipeline=options.fit_pipeline)
    else:
        yield from islice(iter_cases(options.suite, mode, models=tuple(options.models),
                                    fit_pipeline=options.fit_pipeline), options.max_tasks)


def _reliability_policy():
    import settings
    from engine.reliability import validate_policy
    return validate_policy(dict(max_attempts=settings.RELIABILITY_MAX_ATTEMPTS,
                                budget_multiplier=settings.RELIABILITY_BUDGET_MULTIPLIER))


def _select_cases(options):
    policy = _reliability_policy()
    for case in _select_inputs(options):
        # Policy is part of the saved task identity, including on worker hosts.
        case['reliability_policy'] = dict(policy)
        yield case


def _pipeline_plan(options):
    """Validate coupled selections using metadata only, before outputs or arrays."""
    from experiments.api import resolve_fit_pipeline, PIPELINE_VERSIONS
    identifiers = _selection_plan(options)['model_case_ids']
    paired = {}
    resolved = {}
    for identifier in identifiers:
        suite, dataset, model = identifier.split('__')
        pipeline = resolve_fit_pipeline(suite, options.fit_pipeline)
        resolved[suite] = dict(fit_pipeline=pipeline, fit_pipeline_version=PIPELINE_VERSIONS[pipeline])
        if pipeline == 'legacy':
            paired.setdefault((suite, dataset), set()).add(model)
    if any(models != {'ER', 'RN'} for models in paired.values()):
        raise ValueError('Legacy fitting is a coupled ER/RN computation. Select both models and complete pairs; '
                         '--task-index selects one model and cannot select a legacy pair. Use --fit-pipeline s301 for independent model tasks.')
    if paired and options.cores_per_fit != 1:
        raise ValueError('Legacy pairs preserve the historical single-core optimizer. Use --cores-per-fit 1 '
                         'and --workers to run multiple pairs concurrently.')
    return resolved


def _new_output(options):
    import settings
    if options.resume:
        if options.output:
            raise ValueError("Use --resume OR --output, not both.")
        output = options.resume.resolve()
        if not (output / "run.json").is_file():
            raise ValueError("Resume directory has no run.json.")
        return output
    if options.output:
        output = options.output.resolve()
    else:
        label = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
        output = ROOT / settings.OUTPUT_ROOT / f"{options.mode}_{label}"
    output.mkdir(parents=True, exist_ok=False)
    return output


def run(argv=None):
    options = _parser().parse_args(argv)
    if options.mode not in ('paper', 'demo', 'recompute') or options.suite not in ('all', 'baseline', 'extreme', 's301'):
        raise ValueError('Unknown MODE or SUITE in settings.py.')
    if options.fit_pipeline not in ('paper', 'legacy', 's301'):
        raise ValueError('Unknown FIT_PIPELINE in settings.py.')
    if options.verify:
        from release_checks import verify_release
        verify_release(ROOT)
        print("Release file hashes match.")
        return 0
    if options.collect:
        if options.resume:
            raise ValueError("Collection writes a new directory; it does not resume fits.")
        if options.dry_run:
            print(f"Collection plan: {len(options.collect)} explicit run directories; no fitting.")
            return 0
        options.mode = "collect"
        output = _new_output(options)
        from postprocess import collect_runs
        files = collect_runs(options.collect, output)
        print(f"Collected new-run results and generated {len(files)} figures: {output}")
        return 0
    if options.max_tasks is not None and options.max_tasks < 1:
        raise ValueError("max-tasks must be positive.")
    if options.task_index is not None and options.max_tasks is not None:
        raise ValueError('Choose task-index OR max-tasks, not both.')
    if options.task_index is not None and options.task_index < 0:
        raise ValueError("task-index must be nonnegative.")
    if options.figures and any(x not in range(1, 14) for x in options.figures):
        raise ValueError("Figure IDs must be between 1 and 13.")
    if options.figures and options.mode != 'paper':
        raise ValueError('figures selects saved-data redraws in paper mode only.')

    if options.mode == "paper":
        print('Paper snapshot: includes the reviewed four S301 pairs and 77 extreme ER corrections; '
              'see AUDIT_STATUS.md. Redrawing is not a full-campaign recertification.', flush=True)
        if options.resume:
            raise ValueError("Redraws are inexpensive; use a fresh paper output directory.")
        if options.dry_run:
            print("Paper redraw: saved numerical arrays -> figures; no optimization.")
            print("Figure IDs:", options.figures or list(range(1, 14)))
            return 0
        output = _new_output(options)
        from plotting.paper import render_all
        paths = render_all(output / "figures", figure_ids=options.figures)
        _write_json(output / "run.json", {"mode": "paper", "fit_calls": 0,
                                          "fit_pipeline_applied": False,
                                          "data": "paper snapshot with targeted 2026-10-16 corrections",
                                          "paper_snapshot": "2026.10.16-paper-sync",
                                          "scientific_recertification": False,
                                          "targeted_corrections_applied": {"s301_pairs": 4, "extreme_ER_cases": 77},
                                          "full_campaign_revalidated": False,
                                          "audit_status_document": "AUDIT_STATUS.md (in the code package)",
                                          "figures": [Path(x).name for x in paths]})
        print(f"Redrew {len(paths)} figures from numerical data: {output}")
        return 0

    reliability_policy = _reliability_policy()
    concurrency = _resource_layout(options.workers, options.cores_per_fit)
    selection = _selection_plan(options)
    selected_range = _effective_task_range(options)
    count = len(selection['model_case_ids'])
    pipeline_plan = _pipeline_plan(options)
    print(f"{options.mode}: {count} model fits; at most {concurrency} concurrent work units; "
          f"{options.cores_per_fit} CPU(s) per work unit.", flush=True)
    print(f"Work units: {selection['selected']} selected of {selection['total']}; "
          f"inclusive numbers {selection['first']}--{selection['last']}.", flush=True)
    print('Fitting pipelines: ' + ', '.join(f"{suite}={info['fit_pipeline']}"
          for suite, info in pipeline_plan.items()), flush=True)
    factors = [reliability_policy['budget_multiplier'] ** i for i in range(reliability_policy['max_attempts'])]
    print(f"Reliability: at most {len(factors)} rounds per work unit; budget factors {factors}. "
          "Thresholds unchanged; unresolved minima stay marked NEEDS_REVIEW.", flush=True)
    if options.dry_run:
        print("Plan only. No forward integrations, optimizer calls, output writes, or cluster submissions.")
        return 0

    output = _new_output(options)
    signature = {"mode": options.mode, "suite": options.suite, "models": options.models,
                 "max_tasks": options.max_tasks, "task_index": options.task_index,
                 "fit_pipeline_requested": options.fit_pipeline,
                 "fit_pipelines": pipeline_plan,
                 "reliability_policy": reliability_policy,
                 "science_sha256": _scientific_source_hash()}
    if selected_range is not None:
        signature['task_range'] = list(selected_range)
    plan = {"signature": signature, "task_count": count, "state": "RUNNING",
            "work_unit_selection": selection,
            "resource_layout": {"total_cpus": options.workers, "cpus_per_fit": options.cores_per_fit},
            "data_policy": "new results only; no fallback to supplied historical fit values"}
    if options.resume:
        old_plan = json.loads((output / "run.json").read_text(encoding="utf-8"))
        if old_plan["signature"] != signature:
            raise ValueError("Resume requires identical science, task selection, and mode.")
    pending = set()
    finished = []
    blocked = []
    profile = "demo" if options.mode == "demo" else "paper"
    pending_units = 0
    for unit in _case_units(_select_cases(options)):
        pair_hash = None
        if len(unit) == 2:
            by_model = {case['fit_theory']:case for case in unit}
            pair_hash = pair_input_fingerprint(by_model['ER'], by_model['RN'])
        present = [(output / 'tasks' / case['case_id']).exists() for case in unit]
        if len(unit) == 2 and any(present) and not all(present):
            raise ValueError('A partially saved legacy pair is preserved, not automatically restarted.')
        if not any(present):
            pending_units += 1
        for case in unit:
            case_id = case["case_id"]
            if not case_id or case_id in ('.', '..') or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-" for c in case_id):
                raise ValueError(f"Unsafe case identifier: {case_id!r}")
            task_dir = output / "tasks" / case_id
            if task_dir.exists():
                _, result, receipt = load_task(task_dir, expected_case=case, profile=profile)
                if pair_hash is not None and result['pair_input_sha256'] != pair_hash:
                    raise ValueError('Saved legacy pair fingerprint differs from the selected paired inputs.')
                if result['run_complete']:
                    finished.append({"case_id": case_id, "state": "FINISHED",
                                     "scientific_checks_passed": result.get('scientific_checks_passed', False)})
                else:
                    blocked.append(case_id)
            else:
                pending.add(case_id)
    if blocked:
        raise ValueError("Unfinished tasks are preserved, not automatically restarted: " + ", ".join(blocked[:8]))
    # Validate all existing records before replacing the saved run state.
    _write_json(output / "run.json", plan)
    def record(result):
        if isinstance(result, list):
            for item in result:
                record(item)
            return
        finished.append(result)
        _write_json(output / "progress.json", {"finished": len(finished), "planned": count,
                                               "tasks": finished})
        print(f"[{len(finished)}/{count}] {result['case_id']}: {result['state']}", flush=True)

    global _STOP_EVENT
    context = multiprocessing.get_context('spawn')
    old_event, _STOP_EVENT = _STOP_EVENT, context.Event()
    previous_handler = None
    def stop_requested(signum, frame):
        # Broadcast only after stack unwinding: a signal may interrupt an
        # Event.is_set() call while its non-reentrant lock is still held.
        raise KeyboardInterrupt
    if threading.current_thread() is threading.main_thread():
        previous_handler = signal.signal(signal.SIGINT, stop_requested)
    waiting = (_unit_call(unit, output, options.cores_per_fit, profile)
               for unit in _case_units(_select_cases(options)) if unit[0]['case_id'] in pending)
    geometry_paths = []
    try:
        if (options.mode == "recompute" and options.suite == "all" and options.max_tasks is None
                and options.task_index is None and selected_range is None):
            from plotting.geometry_data import recompute_geometry
            from plotting.paper import render_all, FIGURES
            geometry_dir = output / "plot_data"
            missing = [i for i in range(1, 6) if not (geometry_dir / FIGURES[i][1]).is_file()]
            if missing:
                print("Recomputing the geometry/orbit figures from their equations.", flush=True)
                recompute_geometry(geometry_dir, figure_ids=missing)
            geometry_paths = render_all(output / "figures", figure_ids=list(range(1, 6)), data_dir=geometry_dir)
        if concurrency == 1:
            for function, arguments in waiting:
                record(function(*arguments))
        else:
            with ProcessPoolExecutor(max_workers=concurrency, mp_context=context,
                                     initializer=_worker_init, initargs=(_STOP_EVENT,)) as pool:
                active = set()
                try:
                    for _ in range(min(concurrency, pending_units)):
                        function, arguments = next(waiting)
                        active.add(pool.submit(function, *arguments))
                    while active:
                        done, active = wait(active, timeout=1., return_when=FIRST_COMPLETED)
                        for future in done:
                            record(future.result())
                        # Observe every completed result before submitting more.
                        for _ in done:
                            item = next(waiting, None)
                            if item is None:
                                break
                            function, arguments = item
                            active.add(pool.submit(function, *arguments))
                except BaseException:
                    _STOP_EVENT.set()  # Running engines exit their polling loops and clean their own children.
                    for future in active:
                        future.cancel()
                    raise
        if len(finished) != count:
            raise RuntimeError('Task selection changed during dispatch; saved results are retained.')
    except KeyboardInterrupt:
        _STOP_EVENT.set()
        plan['state'] = 'INTERRUPTED'
        _write_json(output / 'run.json', plan)
        print('Stopped. Saved results are retained; no further tasks were dispatched.', flush=True)
        return 130
    except BaseException:
        _STOP_EVENT.set()
        plan['state'] = 'FAILED'
        _write_json(output / 'run.json', plan)
        raise
    finally:
        if previous_handler is not None:
            signal.signal(signal.SIGINT, previous_handler)
        _STOP_EVENT = old_event

    failures = [row for row in finished if row["state"] != "FINISHED"]
    plan["state"] = "HAS_FAILED_TASKS" if failures else "FINISHED"
    if options.mode == "demo" and failures and all(row.get("engine_status") == "INCOMPLETE_OR_BUDGET_LIMIT" for row in failures):
        plan["state"] = "DEMO_FINISHED_WITH_ITERATION_LIMITS"
    plan["failed_tasks"] = len(failures)
    unresolved = sum(row.get('scientific_checks_passed') is not True for row in finished)
    plan['scientifically_passed_tasks'] = len(finished) - unresolved
    plan['scientifically_unresolved_tasks'] = unresolved
    if not failures and unresolved:
        plan['state'] = 'FINISHED_WITH_UNRESOLVED_RESULTS'
    _write_json(output / "run.json", plan)
    from postprocess import render_run
    rendered = render_run(output, mode=options.mode)
    if geometry_paths:
        # These figures were successfully saved earlier in this same run.
        # Final statistical plotting must not erase them from the status/count.
        status_path = output / 'plot_status.json'
        plot_status = json.loads(status_path.read_text(encoding='utf-8'))
        plot_status['paper_layout_figures_generated'] = sorted(
            set(plot_status['paper_layout_figures_generated']) | set(range(1, 6)))
        _write_json(status_path, plot_status)
        rendered = list(geometry_paths) + list(rendered)
    print(f"New-run results saved to {output}; generated {len(rendered)} figure(s).", flush=True)
    print(f"Scientific checks: {len(finished)-unresolved} passed; {unresolved} unresolved. "
          "Finishing the bounded run is not scientific acceptance.", flush=True)
    return 2 if failures and plan["state"] != "DEMO_FINISHED_WITH_ITERATION_LIMITS" else 0


if __name__ == "__main__":
    multiprocessing.freeze_support()
    try:
        raise SystemExit(run())
    except (ModuleNotFoundError, ImportError) as exc:
        print(f"Missing or incompatible dependency: {exc}\n"
              "Install once: python -m pip install -r requirements.txt", file=sys.stderr)
        raise SystemExit(1)
    except (ValueError, OSError) as exc:
        print(f"Stopped safely: {exc}", file=sys.stderr)
        raise SystemExit(2)
