"""Common settings for main.py. Advanced options: python main.py --help."""

MODE = "demo"                                         # "paper"; "demo"; "recompute"
SUITE = "all"                                                # "all", "baseline", "extreme", "s301"
FIT_PIPELINE = "paper"                               # "paper"; "legacy"; "s301"
WORKERS = 10                                             # Total CPU budget across fits and their internal ordered maps.
CORES_PER_FIT = 1                                    # Advanced: split WORKERS between fits and their ordered maps.
OUTPUT_ROOT = "output"
TASK_RANGE = None                                    # Recompute only;None = all.
