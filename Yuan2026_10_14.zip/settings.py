"""Common settings for main.py. Advanced options: python main.py --help."""

MODE = "paper"                                        # "paper"; "demo"; "recompute"
SUITE = "all"                                                # "all", "baseline", "extreme", "s301"
FIT_PIPELINE = "paper"                               # "paper"; "legacy"; "s301"
WORKERS = 1                                              # Total CPU budget across fits and their internal ordered maps.
CORES_PER_FIT = 1                                    # Advanced: split WORKERS between fits and their ordered maps.
OUTPUT_ROOT = "output"
TASK_RANGE = None                                    # Recompute only;None = all.

# Applies to demo and recompute, not paper redraws. Initial round + retries.
# Budgets grow by 1, 2, 4 with these defaults; scientific thresholds do not.
# Every round is retained. A lowest value after exhaustion is NOT a pass.
RELIABILITY_MAX_ATTEMPTS = 3
RELIABILITY_BUDGET_MULTIPLIER = 2.0
