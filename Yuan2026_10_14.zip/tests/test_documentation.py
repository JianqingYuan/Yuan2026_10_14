"""Check novice command-line instructions without launching numerical fits."""
import ast
import re
import shlex
import subprocess
import sys
import unittest
from unittest.mock import patch

import main


class DocumentationTests(unittest.TestCase):
    def test_documented_task_counts_match_the_live_catalogue(self):
        for name in ('README.md', 'README.zh-CN.md'):
            text = (main.ROOT/name).read_text(encoding='utf-8')
            rows = re.findall(r'(?m)^(baseline|extreme|s301|all)\s+([\d,]+)\s+([\d,]+)\s+([\d,]+)\s+([\d,]+)\s*$', text)
            self.assertEqual(len(rows), 4)
            with patch('settings.TASK_RANGE', None), patch('experiments.api._observations',
                    side_effect=AssertionError('Documentation check must not load observations')):
                for suite, *counts in rows:
                    counts = [int(value.replace(',', '')) for value in counts]
                    for index, pipeline in enumerate(('paper', 'legacy', 's301')):
                        options = main._parser().parse_args(['--mode', 'recompute',
                            '--suite', suite, '--fit-pipeline', pipeline, '--workers', '1'])
                        plan = main._selection_plan(options)
                        self.assertEqual(plan['total'], counts[index])
                        self.assertEqual(len(plan['model_case_ids']), counts[3])

    def test_readme_commands_parse_and_translations_agree(self):
        command_sets = []
        for name in ('README.md', 'README.zh-CN.md'):
            commands = [line.strip() for line in (main.ROOT / name).read_text(encoding='utf-8').splitlines()
                        if line.startswith('python main.py')]
            self.assertGreaterEqual(len(commands), 4)
            for command in commands:
                with self.subTest(document=name, command=command):
                    main._parser().parse_args(shlex.split(command)[2:])
            command_sets.append(commands)
        self.assertEqual(*command_sets)

    def test_setup_and_settings_examples_agree(self):
        recipes, configurations = [], []
        for name in ('README.md', 'README.zh-CN.md'):
            text = (main.ROOT / name).read_text(encoding='utf-8')
            self.assertIn('py -3.12 -m venv .venv', text)
            self.assertIn(r'.venv\Scripts\activate', text)
            self.assertIn('notepad settings.py', text)
            self.assertNotIn('START_HERE.bat', text)
            self.assertNotRegex(text, r'(?m)^\s*\|')
            recipes.append(re.findall(r'```console\n(.*?)```', text, re.S))
            blocks = re.findall(r'```python\n(.*?)```', text, re.S)
            self.assertGreaterEqual(len(blocks), 3)
            for block in blocks:
                for statement in ast.parse(block).body:
                    self.assertIsInstance(statement, ast.Assign)
                    self.assertEqual(len(statement.targets), 1)
                    ast.literal_eval(statement.value)
            configurations.append(blocks)
        self.assertEqual(*recipes)
        self.assertEqual(*configurations)
        self.assertFalse((main.ROOT / 'START_HERE.bat').exists())

    def test_command_line_entry_and_error_exit(self):
        for arguments, expected_code, message in (
                (['--mode', 'paper', '--dry-run'], 0, 'Paper redraw:'),
                (['--mode', 'paper', '--figures', '99', '--dry-run'], 2, 'Stopped safely:')):
            with self.subTest(arguments=arguments):
                result = subprocess.run([sys.executable, '-B', 'main.py', *arguments],
                                        capture_output=True, text=True, errors='replace',
                                        cwd=main.ROOT, timeout=15)
                self.assertEqual(result.returncode, expected_code, result.stdout + result.stderr)
                self.assertIn(message, result.stdout + result.stderr)


if __name__ == '__main__':
    unittest.main()
