"""Independent work-unit slicing tests; no optimizer, integration or worker pool.

The metadata oracle below deliberately does not use the launcher's grouping
helper. Real observations are materialized only for tiny selected ranges.
"""
from concurrent.futures import Future
from contextlib import ExitStack, redirect_stdout
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

import main
import experiments.api as catalogue
from run_state import digest, pipeline_provenance, write_json


def expected_units(suite='all', pipeline='paper', models=('ER', 'RN'), mode='paper'):
    identifiers = catalogue.list_case_ids(suite, mode, models=models)
    units, index = [], 0
    while index < len(identifiers):
        identifier = identifiers[index]
        selected_suite, dataset, model = identifier.split('__')
        if catalogue.resolve_fit_pipeline(selected_suite, pipeline) == 'legacy':
            other = identifiers[index + 1]
            other_suite, other_dataset, other_model = other.split('__')
            assert (selected_suite, dataset) == (other_suite, other_dataset)
            assert {model, other_model} == {'ER', 'RN'}
            units.append((identifier, other))
            index += 2
        else:
            units.append((identifier,))
            index += 1
    return units


def flattened(units):
    return [identifier for unit in units for identifier in unit]


class ImmediateExecutor:
    """Exercise the real dispatch/refill loop without starting any child."""
    def __init__(self, *args, **kwargs):
        self.submissions = []

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def submit(self, function, *arguments):
        self.submissions.append((function, arguments))
        future = Future()
        try:
            future.set_result(function(*arguments))
        except BaseException as exc:
            future.set_exception(exc)
        return future


def save_completed(case, destination, cores_per_fit, profile):
    """Persist a genuine task receipt contract, without numerical fitting."""
    destination = Path(destination)
    provenance = pipeline_provenance(case)
    write_json(destination/'case.json', case)
    write_json(destination/'result.json', dict(case_id=case['case_id'],
        fit_theory=case['fit_theory'], profile=profile, result_is_demo=profile == 'demo',
        run_complete=True, status='COMPLETED', scientific_checks_passed=False, **provenance))
    write_json(destination/'task_receipt.json', dict(case_id=case['case_id'],
        case_sha256=digest(case), profile=profile, state='FINISHED', engine_status='COMPLETED',
        **provenance))
    return dict(case_id=case['case_id'], state='FINISHED', engine_status='COMPLETED')


class TaskRangeTests(unittest.TestCase):
    def setUp(self):
        setting = patch('settings.TASK_RANGE', None, create=True)
        setting.start()
        self.addCleanup(setting.stop)

    def options(self, *arguments):
        return main._parser().parse_args(['--mode', 'recompute', '--suite', 'all',
            '--fit-pipeline', 'paper', '--workers', '1', '--cores-per-fit', '1', *arguments])

    def plan(self, *arguments):
        with patch('experiments.api._observations', side_effect=AssertionError('Metadata plan read observations')):
            return main._selection_plan(self.options(*arguments))

    def test_default_and_forced_pipeline_work_unit_counts(self):
        for pipeline, total in (('paper', 7884), ('legacy', 7830), ('s301', 15660)):
            with self.subTest(pipeline=pipeline):
                plan = self.plan('--fit-pipeline', pipeline)
                self.assertEqual((plan['total'], plan['selected'], plan['first'], plan['last']),
                                 (total, total, 1, total))
                self.assertEqual(plan['model_case_ids'], flattened(expected_units(pipeline=pipeline)))

    def test_suite_and_model_filter_define_the_numbering(self):
        for suite, pipeline, models, total in (
            ('baseline', 'paper', ('ER', 'RN'), 6480),
            ('extreme', 'paper', ('ER', 'RN'), 1296),
            ('s301', 'paper', ('ER', 'RN'), 108),
            ('all', 's301', ('RN',), 7830),
            ('s301', 'paper', ('RN',), 54),
            ('s301', 'paper', ('RN', 'ER'), 108),
        ):
            with self.subTest(suite=suite, pipeline=pipeline, models=models):
                plan = self.plan('--suite', suite, '--fit-pipeline', pipeline,
                    '--models', *models, '--task-range', '1', '2')
                self.assertEqual(plan['total'], total)
                self.assertEqual(plan['selected'], 2)
                self.assertEqual(plan['model_case_ids'],
                                 flattened(expected_units(suite, pipeline, models)[:2]))

    def test_mixed_pipeline_boundaries_do_not_split_pairs(self):
        units = expected_units()
        for first, last in ((6480, 6480), (6481, 6481), (6480, 6481),
                            (7776, 7776), (7777, 7777), (7776, 7777), (7884, 7884)):
            with self.subTest(first=first, last=last):
                plan = self.plan('--task-range', str(first), str(last))
                self.assertEqual((plan['first'], plan['last'], plan['selected']),
                                 (first, last, last - first + 1))
                self.assertEqual(plan['model_case_ids'], flattened(units[first-1:last]))
        self.assertEqual(units[6479][0].split('__')[0], 'baseline')
        self.assertEqual(units[6480][0].split('__')[0], 'extreme')
        self.assertEqual(len(units[7775]), 2)
        self.assertEqual(units[7776], ('s301__T000__ER',))

    def test_all_slices_reassemble_every_case_once_for_each_pipeline(self):
        for pipeline in ('paper', 'legacy', 's301'):
            units = expected_units(pipeline=pipeline)
            combined = []
            for first in range(1, len(units) + 1, 997):
                last = min(first + 996, len(units))
                plan = self.plan('--fit-pipeline', pipeline, '--task-range', str(first), str(last))
                self.assertEqual(plan['model_case_ids'], flattened(units[first-1:last]))
                self.assertEqual(plan['selected'], last - first + 1)
                combined.extend(plan['model_case_ids'])
            self.assertEqual(combined, catalogue.list_case_ids())
            self.assertEqual(len(combined), len(set(combined)))

    def test_settings_range_and_cli_override_even_invalid_setting(self):
        with patch('settings.TASK_RANGE', (6480, 6481)):
            self.assertEqual(self.plan()['model_case_ids'], flattened(expected_units()[6479:6481]))
        with patch('settings.TASK_RANGE', ('bad', True)):
            plan = self.plan('--task-range', '7777', '7778')
            self.assertEqual((plan['first'], plan['last'], plan['selected']), (7777, 7778, 2))
            self.assertEqual(plan['model_case_ids'], ['s301__T000__ER', 's301__T000__RN'])

    def _assert_invalid_before_io(self, arguments, setting=None):
        with patch('settings.TASK_RANGE', setting), \
             patch('main._new_output', side_effect=AssertionError('Invalid range created output')) as output, \
             patch('experiments.api._observations', side_effect=AssertionError('Invalid range read observations')) as read, \
             redirect_stdout(io.StringIO()):
            with self.assertRaises(ValueError):
                main.run(['--mode', 'recompute', '--suite', 'all', '--fit-pipeline', 'paper',
                    '--workers', '1', '--cores-per-fit', '1', *arguments])
        output.assert_not_called()
        read.assert_not_called()

    def test_invalid_settings_ranges_fail_before_data_or_output(self):
        for value in ([], [1], [1, 2, 3], {}, '1 2', (True, 2), (1, False),
                      (1.0, 2), (1, 2.0), ('1', 2), (1, '2'), (0, 1), (-1, 2),
                      (2, 1), (1, 7885)):
            with self.subTest(value=value):
                self._assert_invalid_before_io([], setting=value)

    def test_invalid_cli_ranges_fail_before_data_or_output(self):
        for first, last in (('0', '1'), ('-1', '1'), ('2', '1'), ('1', '7885'),
                            ('1.0', '2'), ('True', '2'), ('bad', 'other')):
            with self.subTest(first=first, last=last):
                self._assert_invalid_before_io(['--task-range', first, last])

    def test_range_conflicts_with_either_older_task_selector(self):
        for selector in (['--max-tasks', '2'], ['--task-index', '0']):
            with self.subTest(selector=selector):
                self._assert_invalid_before_io(['--task-range', '1', '2', *selector])
                self._assert_invalid_before_io(selector, setting=(1, 2))

    def test_legacy_still_rejects_a_single_model_selection(self):
        self._assert_invalid_before_io(['--models', 'RN', '--task-range', '1', '2'])

    def test_paper_and_demo_ignore_even_invalid_settings_and_cli_values(self):
        for mode in ('paper', 'demo'):
            for extra in ([], ['--task-range', 'bogus', 'other'], ['--task-range', '0', '-3']):
                with self.subTest(mode=mode, extra=extra), patch('settings.TASK_RANGE', (True, 'bad')):
                    plan = self.plan('--mode', mode, *extra)
                    expected = expected_units(mode='demo' if mode == 'demo' else 'paper')
                    self.assertEqual(plan['model_case_ids'], flattened(expected))
                    self.assertEqual(plan['selected'], plan['total'])
                    with patch('main._new_output') as output, patch('experiments.api._observations') as read, \
                         redirect_stdout(io.StringIO()):
                        code = main.run(['--mode', mode, '--suite', 'all', '--workers', '1', '--dry-run', *extra])
                    self.assertEqual(code, 0)
                    output.assert_not_called()
                    read.assert_not_called()

    def test_selection_materializes_only_the_chosen_models(self):
        options = self.options('--task-range', '7776', '7777')
        original = catalogue._observations
        with patch('experiments.api._observations', wraps=original) as read:
            cases = list(main._select_cases(options))
        self.assertEqual(read.call_count, 3)
        self.assertEqual([case['case_id'] for case in cases], flattened(expected_units()[7775:7777]))

    def test_reordered_models_partial_edges_and_cross_suite_materialization(self):
        # Stub only observation storage, leaving the actual catalogue and case
        # construction in use. Each call identifies exactly which data set was
        # materialized; no unselected edge model may cause an extra call.
        for suite, pipeline, models, first, last in (
            ('all', 'paper', ('RN', 'ER'), 6480, 6481),
            ('all', 'paper', ('RN', 'ER'), 7776, 7777),
            ('s301', 'paper', ('ER', 'RN'), 2, 5),
            ('s301', 'paper', ('RN', 'ER'), 2, 5),
            ('s301', 'paper', ('RN', 'ER'), 107, 108),
            ('s301', 'paper', ('RN',), 1, 1),
            ('s301', 'paper', ('RN',), 54, 54),
            ('all', 's301', ('RN',), 6480, 6481),
            ('all', 's301', ('ER', 'RN'), 12960, 12961),
            ('all', 'legacy', ('RN', 'ER'), 7776, 7777),
        ):
            with self.subTest(suite=suite, pipeline=pipeline, models=models, first=first, last=last):
                options = self.options('--suite', suite, '--fit-pipeline', pipeline,
                    '--models', *models, '--task-range', str(first), str(last))
                expected = flattened(expected_units(suite, pipeline, models)[first-1:last])
                with patch('experiments.api._observations',
                           return_value=(np.array([0., 1.]), np.zeros((2, 2)))) as read:
                    cases = list(main._select_cases(options))
                self.assertEqual([case['case_id'] for case in cases], expected)
                self.assertEqual(read.call_count, len(expected))
                observed = [(call.args[0], call.args[2]['dataset_id']) for call in read.call_args_list]
                self.assertEqual(observed, [tuple(identifier.split('__')[:2]) for identifier in expected])
                self.assertEqual([case['fit_theory'] for case in cases],
                                 [identifier.split('__')[2] for identifier in expected])

    def test_old_task_index_can_select_s301_without_unselected_legacy_models(self):
        for mode in ('recompute', 'demo'):
            catalogue_mode = 'demo' if mode == 'demo' else 'paper'
            for model in ('ER', 'RN'):
                identifiers = catalogue.list_case_ids('all', catalogue_mode, models=(model,))
                index = identifiers.index(f's301__T000__{model}')
                with self.subTest(mode=mode, model=model), \
                     patch('experiments.api._observations', side_effect=AssertionError('Dry run read observations')), \
                     patch('main._new_output') as output, redirect_stdout(io.StringIO()):
                    code = main.run(['--mode', mode, '--suite', 'all', '--models', model,
                        '--fit-pipeline', 'paper', '--task-index', str(index), '--workers', '1', '--dry-run'])
                self.assertEqual(code, 0)
                output.assert_not_called()

    def test_single_model_all_range_may_select_only_s301_but_not_a_legacy_slot(self):
        for model in ('ER', 'RN'):
            identifiers = catalogue.list_case_ids('all', models=(model,))
            for first, last in ((7777, 7778), (7830, 7830)):
                with self.subTest(model=model, first=first, last=last):
                    plan = self.plan('--models', model, '--task-range', str(first), str(last))
                    self.assertEqual(plan['total'], 7830)
                    self.assertEqual(plan['selected'], last - first + 1)
                    self.assertEqual(plan['model_case_ids'], identifiers[first-1:last])
                    self.assertTrue(all(identifier.startswith('s301__') for identifier in plan['model_case_ids']))
            self._assert_invalid_before_io(['--models', model, '--task-range', '7776', '7777'])

    def test_old_selectors_keep_model_count_semantics_without_a_range(self):
        for suite, pipeline, models, selector, expected_ids in (
            ('all', 'paper', ('RN', 'ER'), ['--max-tasks', '4'],
             catalogue.list_case_ids(models=('RN', 'ER'))[:4]),
            ('s301', 'paper', ('ER', 'RN'), ['--max-tasks', '3'],
             catalogue.list_case_ids('s301')[:3]),
            ('all', 's301', ('RN',), ['--task-index', '7830'], None),
            ('all', 'paper', ('ER', 'RN'), ['--max-tasks', '3'], None),
        ):
            with self.subTest(suite=suite, pipeline=pipeline, models=models, selector=selector):
                arguments = ['--suite', suite, '--fit-pipeline', pipeline, '--models', *models, *selector]
                if expected_ids is None:
                    with self.assertRaises(ValueError):
                        self.plan(*arguments)
                else:
                    self.assertEqual(self.plan(*arguments)['model_case_ids'], expected_ids)

    def test_dry_run_reports_counts_and_range_without_observations_or_output(self):
        text = io.StringIO()
        with patch('experiments.api._observations', side_effect=AssertionError('Dry run read observations')), \
             patch('main._new_output') as output, redirect_stdout(text):
            code = main.run(['--mode', 'recompute', '--suite', 'all', '--fit-pipeline', 'paper',
                '--task-range', '7776', '7777', '--workers', '1', '--dry-run'])
        self.assertEqual(code, 0)
        output.assert_not_called()
        for value in ('7884', '7776', '7777'):
            self.assertIn(value, text.getvalue())
        self.assertRegex(text.getvalue(), r'\b2\b')  # Selected work units.
        self.assertRegex(text.getvalue(), r'\b3\b')  # Selected model fits.

    def test_dispatch_sends_only_selected_units_and_skips_global_geometry(self):
        seen = []
        def pair(cases, destinations, cores_per_fit, profile):
            self.assertEqual({case['fit_theory'] for case in cases}, {'ER', 'RN'})
            self.assertEqual(len({case['dataset_id'] for case in cases}), 1)
            seen.append(tuple(case['case_id'] for case in cases))
            return [dict(case_id=case['case_id'], state='FINISHED') for case in cases]
        def single(case, destination, cores_per_fit, profile):
            seen.append((case['case_id'],))
            return dict(case_id=case['case_id'], state='FINISHED')
        pool = ImmediateExecutor()
        with tempfile.TemporaryDirectory() as name, ExitStack() as stack:
            output = Path(name)/'slice'
            stack.enter_context(patch('main._run_pair', side_effect=pair))
            stack.enter_context(patch('main._run_task', side_effect=single))
            stack.enter_context(patch('main._scientific_source_hash', return_value='a'*64))
            stack.enter_context(patch('main._resource_layout', return_value=2))
            stack.enter_context(patch('main.ProcessPoolExecutor', return_value=pool))
            geometry = stack.enter_context(patch('plotting.geometry_data.recompute_geometry'))
            paper = stack.enter_context(patch('plotting.paper.render_all'))
            stack.enter_context(patch('postprocess.render_run', return_value=[]))
            stack.enter_context(redirect_stdout(io.StringIO()))
            code = main.run(['--mode', 'recompute', '--suite', 'all', '--fit-pipeline', 'paper',
                '--task-range', '7776', '7778', '--workers', '2', '--cores-per-fit', '1', '--output', str(output)])
            self.assertEqual(code, 0)
            self.assertEqual(seen, expected_units()[7775:7778])
            self.assertEqual(len(pool.submissions), 3)  # Includes a refill after the first batch.
            geometry.assert_not_called()
            paper.assert_not_called()
            saved = json.loads((output/'run.json').read_text(encoding='utf-8'))
            self.assertEqual(saved['task_count'], 4)
            self.assertEqual(saved['signature']['task_range'], [7776, 7778])
            selection = saved['work_unit_selection']
            self.assertEqual((selection['total'], selection['selected'], selection['first'], selection['last']),
                             (7884, 3, 7776, 7778))

    def test_identical_range_resume_reuses_receipts_but_changed_range_is_rejected(self):
        with tempfile.TemporaryDirectory() as name, ExitStack() as stack:
            output = Path(name)/'slice'
            stack.enter_context(patch('main._scientific_source_hash', return_value='a'*64))
            stack.enter_context(patch('postprocess.render_run', return_value=[]))
            stack.enter_context(redirect_stdout(io.StringIO()))
            arguments = ['--mode', 'recompute', '--suite', 's301', '--fit-pipeline', 'paper',
                         '--workers', '1', '--cores-per-fit', '1']
            with patch('main._run_task', side_effect=save_completed) as fit:
                self.assertEqual(main.run([*arguments, '--task-range', '1', '1', '--output', str(output)]), 0)
                self.assertEqual(fit.call_count, 1)
            with patch('main._run_task') as fit:
                self.assertEqual(main.run([*arguments, '--task-range', '1', '1', '--resume', str(output)]), 0)
                fit.assert_not_called()
                before = (output/'run.json').read_bytes()
                with self.assertRaises(ValueError):
                    main.run([*arguments, '--task-range', '2', '2', '--resume', str(output)])
                self.assertEqual((output/'run.json').read_bytes(), before)
                fit.assert_not_called()

    def test_no_range_signature_remains_compatible_with_old_run_plan(self):
        with tempfile.TemporaryDirectory() as name, ExitStack() as stack:
            output = Path(name)/'old_style'
            stack.enter_context(patch('main._scientific_source_hash', return_value='a'*64))
            stack.enter_context(patch('postprocess.render_run', return_value=[]))
            stack.enter_context(redirect_stdout(io.StringIO()))
            arguments = ['--mode', 'recompute', '--suite', 's301', '--fit-pipeline', 'paper',
                         '--workers', '1', '--cores-per-fit', '1', '--task-index', '0']
            with patch('main._run_task', side_effect=save_completed) as fit:
                self.assertEqual(main.run([*arguments, '--output', str(output)]), 0)
                self.assertEqual(fit.call_count, 1)
            saved = json.loads((output/'run.json').read_text(encoding='utf-8'))
            self.assertNotIn('task_range', saved['signature'])
            self.assertNotIn('work_unit_selection', saved['signature'])
            saved.pop('work_unit_selection')
            write_json(output/'run.json', saved)
            with patch('main._run_task') as fit:
                self.assertEqual(main.run([*arguments, '--resume', str(output)]), 0)
                fit.assert_not_called()


if __name__ == '__main__':
    unittest.main()
