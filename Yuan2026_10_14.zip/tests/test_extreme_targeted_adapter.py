"""Pure toy-residual/negative checks; no geodesic forward or platform work."""
from copy import deepcopy
import math
from pathlib import Path
from types import SimpleNamespace
import time
import unittest
from unittest import mock

import numpy as np

from engine import extreme_targeted as target


CONFIG = dict(chi2_agreement=.1, normalized_parameter_agreement=.02,
              normalized_degeneracy_distance=.08, minimum_independent_routes=2,
              goodness_of_fit_quantile=.99)


def fixture():
    lower = np.array([.5, 0., 20., -.5, 0., 0.])
    upper = np.array([1.5, math.sqrt(12/11), 21., .5, 1., 1.])
    case = dict(fit_theory='ER', generating_theory='ER', legacy_variant='extreme',
        parameter_order=list(target.NAMES), times=list(range(8)), xy_observed=[[0., 0.]]*8,
        residual_sigma=1., bounds={key: [float(a), float(b)] for key, a, b in zip(target.NAMES, lower, upper)},
        nominal_integration=dict(max_step=4., relative_tolerance=1.e-8, absolute_tolerance=1.e-10),
        tight_integration=dict(max_step=1., relative_tolerance=1.e-10, absolute_tolerance=1.e-12),
        precision_criterion=dict(kind='absolute_delta_chi2', tolerance=.01), metadata={})
    z = np.full(6, .4); z[1] = .999
    theta = lower+z*(upper-lower)
    candidates = [dict(theta=theta.tolist(), z=z.tolist(), chi2=1., source='global-best', run_index=index)
                  for index in range(2)]
    record = dict(best_theta=theta.tolist(), chi2_min=1.,
        diagnostics=dict(certification_status='COMPUTATIONALLY_UNRESOLVED'),
        integration_check=dict(within_tolerance=False),
        global_runs=[dict(index=index, random_seed=123+index) for index in range(2)],
        global_candidates=candidates, local_candidates=[], screening_candidates=[])
    return case, record, lower, upper


def toy_evaluator(lower, upper, optimum=.5, precision_failure=False):
    def evaluate(theta, settings):
        z = (theta-lower)/(upper-lower)
        out = np.zeros(16)
        out[:5] = z[list(target.FREE)]-optimum
        out[5] = 10.*(np.sqrt(max(0., 1.-z[1]))-1.e-5)
        out[6] = .5
        if precision_failure and settings['relative_tolerance'] < 1.e-10:
            out[6] = 1.
        return out
    return evaluate


def toy_solver(fun, x, **kwargs):
    x = np.full(5, .5)
    fun(x)
    return SimpleNamespace(x=x, success=True, message='toy endpoint', nfev=1, status=1, optimality=0.)


def toy_certify(rows):
    if not rows:
        return dict(status='COMPUTATIONALLY_UNRESOLVED')
    best = min(rows, key=lambda row: row['chi2'])
    near = [row for row in rows if row['success'] is True and row['chi2'] <= best['chi2']+.1
            and np.linalg.norm(np.asarray(row['z'])-best['z']) <= .02]
    status = 'REPEATABLE_SOLUTION' if best['success'] is True and len({row['run_index'] for row in near}) >= 2 else 'COMPUTATIONALLY_UNRESOLVED'
    return dict(status=status)


def run_toy(case=None, record=None, evaluate=None, solver=toy_solver, **overrides):
    original_case, original_record, lower, upper = fixture()
    limits = dict(pair_deadline=time.monotonic()+120., local_seconds=60., validation_seconds=30.,
        forward_seconds=5., max_nfev=2, max_evaluations=1000)
    limits.update(overrides)
    return target.run(case or original_case, record or original_record, limits=limits,
        evaluate=evaluate or toy_evaluator(lower, upper), certify=toy_certify,
        certification_config=CONFIG, solver=solver)


class ExtremeTargetedTests(unittest.TestCase):
    def test_exact_original_face_and_nuisance_bounds(self):
        _, _, lo, hi = fixture()
        value = target.physical([0, 1, 0, 1, 0], hi[1], lo, hi)
        self.assertEqual(value[1], hi[1])
        self.assertTrue(np.array_equal(value[list(target.FREE)], [lo[0], hi[2], lo[3], hi[4], lo[5]]))
        with self.assertRaises(ValueError): target.physical([.5]*5, np.nextafter(hi[1], np.inf), lo, hi)

    def test_reject_rn_baseline_wrong_bound_gate_and_hash(self):
        for change in (dict(fit_theory='RN'), dict(legacy_variant='baseline'),
                       dict(precision_criterion=dict(kind='absolute_delta_chi2', tolerance=.1)),
                       dict(metadata=dict(observation_sha256='0'*64))):
            case, record, _, _ = fixture(); case.update(change)
            with self.assertRaises(ValueError): run_toy(case, record)
        case, record, _, _ = fixture(); case['bounds']['q'][1] = math.sqrt(13/12)
        with self.assertRaises(ValueError): run_toy(case, record)

    def test_missing_duplicate_and_borrowed_sources_never_gain_votes(self):
        case, record, lo, hi = fixture()
        record['global_candidates'][1]['source'] = 'cross-theory:RN:borrowed'
        self.assertEqual(len(target.inherited_sources(record, lo, hi)), 1)
        document = run_toy(case, record)
        self.assertFalse(document['scientific_checks_passed'])
        self.assertEqual(document['new_independent_DE_sources'], 0)
        record['global_candidates'][1]['source'] = 'global-best'
        record['global_runs'][1]['random_seed'] = 123
        self.assertEqual(len(target.inherited_sources(record, lo, hi)), 1)
        record['global_runs'][1]['index'] = 0
        with self.assertRaises(ValueError): target.inherited_sources(record, lo, hi)

    def test_original_de_coordinate_corruption_rejected(self):
        _, record, lo, hi = fixture()
        record['global_candidates'][0]['z'][0] += .01
        with self.assertRaises(ValueError): target.inherited_sources(record, lo, hi)

    def test_interior_is_noop_without_forward_or_truth(self):
        case, record, lo, hi = fixture()
        record['best_theta'][1] = .5*hi[1]
        document = run_toy(case, record, evaluate=mock.Mock(side_effect=AssertionError('No forward')))
        self.assertFalse(document['triggered'])
        self.assertEqual(document['evaluations'], [])

    def test_good_boundary_without_lower_truth_is_not_refitted(self):
        case, record, _, _ = fixture()
        record['diagnostics']['certification_status'] = 'REPEATABLE_SOLUTION'
        record['integration_check']['within_tolerance'] = True
        document = run_toy(case, record, solver=mock.Mock(side_effect=AssertionError('No fit')))
        self.assertFalse(document['triggered'])

    def test_true_complete_adaptive_route_can_certify_and_retains_native(self):
        case, record, _, _ = fixture()
        before = deepcopy(record)
        document = run_toy(case, record)
        self.assertEqual(record, before)
        self.assertEqual(document['original_record'], before)
        self.assertTrue(document['triggered'])
        self.assertEqual(document['status'], 'TARGETED_CERTIFIED', document['errors'])
        self.assertTrue(document['scientific_checks_passed'])
        self.assertEqual(len(document['source_selection']), 2)
        self.assertEqual(len(document['branches']), 8)
        self.assertTrue(document['native_union_complete'])
        self.assertTrue(document['selected']['passed'])
        self.assertEqual(set(document['selected']['levels']), {'nominal', 'tight', 'third'})
        self.assertLess(document['selected']['theta'][1], case['bounds']['q'][1])
        self.assertEqual(document['new_independent_DE_sources'], 0)

    def test_catalogue_precision_metadata_does_not_disable_original_domain(self):
        from experiments.api import iter_cases
        actual = next(iter_cases('extreme', indices=['erlim_eq26_p00_s09_r01'], models=['ER']))
        self.assertIn('definition', actual['precision_criterion'])
        target.bounds_and_levels(actual)  # Zero forward calls on the real catalogue.
        case, record, _, _ = fixture()
        case['precision_criterion'] = deepcopy(actual['precision_criterion'])
        before = deepcopy(case['precision_criterion'])
        document = run_toy(case, record)
        self.assertTrue(document['triggered'])
        self.assertTrue(document['scientific_checks_passed'], document['errors'])
        self.assertEqual(case['precision_criterion'], before)

    def test_truth_triggers_only_comparison_never_solver_seed(self):
        case, record, lo, hi = fixture()
        truth_z = np.full(6, .51); truth_z[1] = 1.-1.e-10
        case['metadata']['theta_true'] = (lo+truth_z*(hi-lo)).tolist()
        record['diagnostics']['certification_status'] = 'REPEATABLE_SOLUTION'
        record['integration_check']['within_tolerance'] = True
        starts = []
        def solver(fun, x, **kwargs):
            starts.append(np.asarray(x).copy())
            return toy_solver(fun, x, **kwargs)
        document = run_toy(case, record, solver=solver)
        self.assertTrue(document['trigger_reasons']['injected_reference_lower'])
        self.assertFalse(document['truth_used_as_optimizer_seed'])
        self.assertTrue(starts)
        self.assertTrue(all(not np.array_equal(x, truth_z[list(target.FREE)]) for x in starts))

    def test_lowest_actual_point_keeps_false_success_with_separate_support(self):
        case, record, lo, hi = fixture()
        def solver(fun, x, **kwargs):
            fun(np.full(5, .499))
            return toy_solver(fun, x, **kwargs)
        document = run_toy(case, record, evaluate=toy_evaluator(lo, hi, optimum=.499), solver=solver)
        self.assertTrue(document['scientific_checks_passed'], document['errors'])
        certificate = document['certification']
        self.assertFalse(certificate['selected_solver_success'])
        self.assertEqual(certificate['original_certifier_with_lowest_actual_point']['status'], 'COMPUTATIONALLY_UNRESOLVED')
        self.assertEqual(certificate['independent_route_count'], 2)
        self.assertTrue(any(row['success'] is False for row in document['certification_candidates']))

    def test_lower_failed_far_point_is_retained_and_vetoes(self):
        case, record, lo, hi = fixture()
        def solver(fun, x, **kwargs):
            fun(np.full(5, .3))
            return toy_solver(fun, x, **kwargs)
        document = run_toy(case, record, evaluate=toy_evaluator(lo, hi, optimum=.3), solver=solver)
        self.assertFalse(document['scientific_checks_passed'])
        self.assertIsNotNone(document['lowest_actual_tight'])
        self.assertTrue(any(row['success'] is False for row in document['certification_candidates']))

    def test_original_precision_failure_never_passes(self):
        _, _, lo, hi = fixture()
        document = run_toy(evaluate=toy_evaluator(lo, hi, precision_failure=True))
        self.assertFalse(document['scientific_checks_passed'])
        self.assertFalse(document['selected']['passed'])

    def test_failed_solver_no_fake_endpoint_vote(self):
        def solver(fun, x, **kwargs):
            fun(np.full(5, .5))
            raise RuntimeError('Injected failed local stop')
        document = run_toy(solver=solver)
        self.assertFalse(document['scientific_checks_passed'])
        self.assertTrue(any(row['status'] == 'FAILED' for row in document['branches']))
        self.assertTrue(document['evaluations'])

    def test_expired_cap_and_eval_cap_cannot_accept_or_retry(self):
        for override in (dict(pair_deadline=time.monotonic()-1), dict(max_evaluations=4)):
            document = run_toy(**override)
            self.assertFalse(document['scientific_checks_passed'])
            self.assertLessEqual(len(document['evaluations']), override.get('max_evaluations', 10))
            self.assertEqual(document['new_independent_DE_sources'], 0)

    def test_nuisance_rank_defect_refuses_invented_proposal(self):
        with self.assertRaises(ValueError): target.projection(np.ones((16, 5)))

    def test_no_native_ordinary_workflow_rewrite(self):
        worker = Path(target.__file__).with_name('_legacy_worker.py').read_text(encoding='utf-8')
        self.assertLess(worker.index('study.fit_dataset(data, profile'), worker.index('apply_extreme_targeted(payload, directory, study, profile, data, models, results)\n'))
        from engine._legacy_worker import apply_extreme_targeted
        unchanged = {'ER': {'marker': object()}}
        before = unchanged['ER']['marker']
        apply_extreme_targeted({'variant': 'baseline'}, None, None, None, None, None, unchanged)
        self.assertIs(unchanged['ER']['marker'], before)

    def test_limits_are_finite_shared_and_demo_small(self):
        end = time.monotonic()+30.
        demo, paper = (target.limits_for(name, end) for name in ('demo', 'paper'))
        self.assertEqual(demo['pair_deadline'], end)
        self.assertLess(demo['max_nfev'], paper['max_nfev'])
        for value in (float('inf'), float('nan')):
            with self.assertRaises(ValueError): target.limits_for('paper', value)

    def test_evaluation_journal_receives_every_success_and_failure(self):
        case, record, lo, hi = fixture()
        recorded = []
        evaluate = toy_evaluator(lo, hi)
        calls = 0
        def occasional_failure(theta, settings):
            nonlocal calls
            calls += 1
            if calls == 10:
                raise RuntimeError('Retain this failed actual call')
            return evaluate(theta, settings)
        document = target.run(case, record, limits=target.limits_for('demo', time.monotonic()+60),
            evaluate=occasional_failure, certify=toy_certify, certification_config=CONFIG,
            solver=toy_solver, record_evaluation=lambda row: recorded.append(deepcopy(row)))
        self.assertEqual(len(recorded), len(document['evaluations']))
        self.assertEqual(recorded, document['evaluations'])
        self.assertTrue(any(row['valid'] for row in recorded))
        self.assertTrue(any(not row['valid'] and 'error' in row for row in recorded))

    def test_journal_failure_is_an_acceptance_veto(self):
        case, record, lo, hi = fixture()
        def failed_write(row):
            raise OSError('Deliberate journal failure')
        document = target.run(case, record, limits=target.limits_for('demo', time.monotonic()+60),
            evaluate=toy_evaluator(lo, hi), certify=toy_certify, certification_config=CONFIG,
            solver=toy_solver, record_evaluation=failed_write)
        self.assertFalse(document['scientific_checks_passed'])
        self.assertTrue(any('journal' in value for value in document['errors']))


if __name__ == '__main__':
    unittest.main()
