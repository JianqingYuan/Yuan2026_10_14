"""Exercise real archived certificate/worker wiring with mocked residual work."""
import json
from pathlib import Path
import subprocess
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]


class ExtremeTargetedWorkerTests(unittest.TestCase):
    def isolated(self, body):
        preamble = '''
import json, sys, tempfile, time
from copy import deepcopy
from pathlib import Path
from unittest import mock
import numpy as np
sys.path.insert(0, str(Path.cwd()/'tests'))
from test_extreme_targeted_adapter import fixture, CONFIG
from engine import _legacy_worker as worker, extreme_targeted as target
study = worker.bootstrap('extreme')
case, record, lo, hi = fixture()
case['case_id']='test_ER'; case['dataset_id']='test'; case['legacy_optimizer_seed']=31415
case['fit_theory_options']={}
rn = deepcopy(case); rn.update(fit_theory='RN', case_id='test_RN')
payload = dict(variant='extreme', profile='paper', template='extreme_noisy', cases={'ER':case,'RN':rn},
    optimizer_seed=31415, pair_deadline_monotonic=time.monotonic()+30, xy_observed=case['xy_observed'])
profile, _ = worker.build_profile(payload)
record['diagnostics'].update(workflow_complete=True, degrees_of_freedom=10)
record['fit_objective'] = dict(level=0, settings=case['nominal_integration'])
record['best_z']=((np.asarray(record['best_theta'])-lo)/(hi-lo)).tolist()
models = {'ER':record, 'RN':deepcopy(record)}
comparison = study.comparison_rows(models, ('ER','RN'))[0]
results = {name:dict(theta=record['best_theta'], chi2=1., legacy_record=deepcopy(record),
    comparison=deepcopy(comparison), scientific_checks_passed=True, status='COMPLETED',
    numerical_policy='original', best_candidate_checks_passed=True) for name in models}
'''
        completed = subprocess.run([sys.executable, '-B', '-c', preamble + body], cwd=ROOT,
            capture_output=True, text=True, timeout=25)
        self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
        return completed.stdout

    def test_original_certifier_recomputes_new_goodness_and_numerical_alarms(self):
        self.isolated('''
captured=[]
def run(case, original, **kwargs):
    rows=[dict(theta=original['best_theta'], z=original['best_z'], chi2=100., source='targeted:run:'+str(i),
        run_index=i, success=True, message='xtol termination', optimality=1.) for i in range(2)]
    cert=kwargs['certify'](rows); captured.append(cert)
    return dict(status='NOT_TRIGGERED',triggered=False,scientific_checks_passed=False)
with tempfile.TemporaryDirectory() as directory, mock.patch.object(target, 'run', side_effect=run):
    worker.apply_extreme_targeted(payload, directory, study, profile, None, models, results)
assert captured[0]['goodness_alarm'] is True, captured
assert captured[0]['numerical_warning'] is True, captured
assert captured[0]['status']=='COMPUTATIONALLY_UNRESOLVED', captured
assert captured[0]['goodness_threshold'] > 0
''')

    def test_new_original_certifier_can_pass_clean_two_lineages(self):
        self.isolated('''
def run(case, original, **kwargs):
    rows=[dict(theta=original['best_theta'], z=original['best_z'], chi2=1., source='targeted:run:'+str(i),
        run_index=i, success=True, message='gtol termination', optimality=0.) for i in range(2)]
    cert=kwargs['certify'](rows)
    assert cert['status']=='REPEATABLE_SOLUTION',cert
    assert cert['goodness_alarm'] is False
    assert cert['numerical_warning'] is False
    return dict(status='NOT_TRIGGERED',triggered=False,scientific_checks_passed=False)
with tempfile.TemporaryDirectory() as directory, mock.patch.object(target, 'run', side_effect=run):
    worker.apply_extreme_targeted(payload, directory, study, profile, None, models, results)
''')

    def test_custom_domain_explicitly_skipped_preserving_native_result(self):
        self.isolated('''
payload['cases']['ER']['bounds']['q']=[0., .9]
before=deepcopy(results)
with tempfile.TemporaryDirectory() as directory, mock.patch.object(target, 'run', side_effect=AssertionError('Must skip')):
    worker.apply_extreme_targeted(payload, directory, study, profile, None, models, results)
assert results['ER']['targeted_remediation']['status']=='SKIPPED_UNSUPPORTED'
assert results['ER']['scientific_checks_passed'] is True
assert results['ER']['theta']==before['ER']['theta']
assert results['RN']==before['RN']
''')

    def test_precision_definition_metadata_reaches_helper(self):
        self.isolated('''
case['precision_criterion']['definition']='Original catalogue explanatory metadata'
called=[]
def run(actual, original, **kwargs):
    called.append(deepcopy(actual['precision_criterion']))
    return dict(status='NOT_TRIGGERED',triggered=False,scientific_checks_passed=False)
with tempfile.TemporaryDirectory() as directory, mock.patch.object(target, 'run', side_effect=run):
    worker.apply_extreme_targeted(payload, directory, study, profile, None, models, results)
assert called and called[0]['definition']=='Original catalogue explanatory metadata'
assert results['ER']['targeted_remediation']['status']!='SKIPPED_UNSUPPORTED'
''')

    def test_budget_failure_keeps_lower_diagnostic_and_disables_comparison(self):
        self.isolated('''
document=dict(status='NEEDS_REVIEW', triggered=True, scientific_checks_passed=False, selected=None,
    lowest_actual_tight=dict(theta=record['best_theta'],chi2=.25))
with tempfile.TemporaryDirectory() as directory, mock.patch.object(target, 'run', return_value=document):
    worker.apply_extreme_targeted(payload, directory, study, profile, None, models, results)
assert results['ER']['scientific_checks_passed'] is False
assert results['ER']['diagnostic_best']['chi2']==.25
assert results['ER']['diagnostic_best']['checks_passed'] is False
assert results['ER']['chi2']==1.
assert results['ER']['native_legacy_record']==models['ER']
assert results['ER']['comparison']['usable_for_comparison'] is False
assert results['RN']['comparison']['usable_for_comparison'] is False
''')

    def test_selected_protocol_uses_new_point_certificate_and_native_stays_intact(self):
        self.isolated('''
theta=target.physical([.5]*5, hi[1], lo, hi).tolist()
levels={key:dict(chi2=.25,weighted_residuals=[.5]+[0.]*15,raw_residuals=[.5]+[0.]*15)
        for key in ('nominal','tight','third')}
selected=dict(theta=theta, passed=True,levels=levels)
cert=dict(status='REPEATABLE_SOLUTION',kind='fresh-targeted')
document=dict(status='TARGETED_CERTIFIED',triggered=True,scientific_checks_passed=True,
    selected=selected,certification=cert,certification_candidates=[])
before=deepcopy(models)
with tempfile.TemporaryDirectory() as directory, mock.patch.object(target, 'run', return_value=document):
    worker.apply_extreme_targeted(payload, directory, study, profile, None, models, results)
assert models==before
assert results['ER']['chi2']==.25
assert results['ER']['theta']==theta
assert results['ER']['best_candidate_checks_passed'] is True
assert results['ER']['legacy_record']['diagnostics']['certification']==cert
assert results['ER']['native_legacy_record']==before['ER']
assert results['RN']['legacy_record']==before['RN']
assert results['RN']['theta']==before['RN']['best_theta']
''')

    def test_journal_is_flushed_and_refuses_existing_identity(self):
        self.isolated('''
def run(case, original, **kwargs):
    for valid in (True, False):
        row=dict(theta=original['best_theta'],level='third',valid=valid,purpose='test')
        if not valid: row['error']='failed probe'
        kwargs['record_evaluation'](row)
    return dict(status='NOT_TRIGGERED',triggered=False,scientific_checks_passed=False)
with tempfile.TemporaryDirectory() as directory, mock.patch.object(target, 'run', side_effect=run):
    worker.apply_extreme_targeted(payload, directory, study, profile, None, models, results)
    path=Path(directory)/'extreme_targeted_evaluations.jsonl'
    rows=[json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
    assert [row['valid'] for row in rows]==[True,False], rows
    saved=path.read_bytes()
    worker.apply_extreme_targeted(payload, directory, study, profile, None, models, results)
    assert path.read_bytes()==saved
assert results['ER']['targeted_remediation']['status']=='NEEDS_REVIEW'
''')

    def test_cross_precision_lower_and_incomplete_gap_reach_outer_controller(self):
        self.isolated('''
lower=dict(theta=record['best_theta'],level='third',chi2=.2,valid=True,
    weighted_residuals=[.2]*16,raw_residuals=[.2]*16,integration={'max_step':.5},purpose='failed_probe')
document=dict(status='NEEDS_REVIEW',triggered=True,scientific_checks_passed=False,
    selected=None,known_lower_unresolved=True,lower_unverified=[lower])
with tempfile.TemporaryDirectory() as directory, mock.patch.object(target,'run',return_value=document):
    worker.apply_extreme_targeted(payload,directory,study,profile,None,models,results)
item=results['ER']['unresolved_lower_actual_candidates'][0]
assert item['level']=='third' and item['chi2']==.2
assert item['integration']==lower['integration']
assert item['evidence_field']=='lower_unverified' and item['evidence_index']==0
document['lower_unverified']=[]
with tempfile.TemporaryDirectory() as directory, mock.patch.object(target,'run',return_value=document):
    worker.apply_extreme_targeted(payload,directory,study,profile,None,models,results)
item=results['ER']['unresolved_lower_actual_candidates'][0]
assert item['kind']=='INCOMPLETE_CANDIDATE_EVIDENCE'
assert 'chi2' not in item
''')


if __name__ == '__main__':
    unittest.main()
