import contextlib
import copy
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import main
import postprocess
from run_state import pipeline_provenance, pair_input_fingerprint
from experiments.api import iter_cases


def fixture_pairs(suite, noisy=False):
    """Artificial scores for structural tests; never called scientific fits."""
    cases = iter(iter_cases(suite, include_noisy=noisy, include_noiseless=not noisy))
    pairs = []
    while True:
        er = next(cases, None)
        if er is None:
            return pairs
        rn = next(cases)
        rows = []
        for value, case in enumerate((er, rn), 1):
            rows.append(dict(case=case, metadata=case['metadata'], eligible=True, available=True,
                result=dict(case_id=case['case_id'], fit_theory=case['fit_theory'],
                    theta=case['metadata']['theta_true'], chi2=float(value),
                    run_complete=True, best_candidate_checks_passed=True)))
        for row in rows:
            row['result']['pair_input_sha256'] = pair_input_fingerprint(er, rn)
        pairs.append(tuple(rows))


class EntryTests(unittest.TestCase):
    def test_dry_runs_do_not_create_output(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder)/'must_not_exist'
            for mode in ('paper','demo','recompute'):
                with contextlib.redirect_stdout(io.StringIO()):
                    self.assertEqual(main.run(['--mode',mode,'--dry-run','--output',str(target)]),0)
                self.assertFalse(target.exists())

    def test_invalid_task_index_is_rejected_before_write(self):
        with contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaises(ValueError):
                main.run(['--mode','demo','--task-index','99999','--dry-run'])

    def test_cpu_layout(self):
        with patch('main.os.cpu_count',return_value=8), patch('main.os.sched_getaffinity',return_value=set(range(8)),create=True), patch.dict('main.os.environ',{},clear=True):
            self.assertEqual(main._resource_layout(8,2),4)
            with self.assertRaises(ValueError):
                main._resource_layout(9,1)
            with self.assertRaises(ValueError):
                main._resource_layout(2,3)

    def test_budget_return_is_not_finished(self):
        case={'case_id':'test_case_ER', 'fit_pipeline':'s301', 'fit_pipeline_requested':'s301',
              'fit_pipeline_version':'s301-portable-v1'}
        result={'run_complete':False,'status':'INCOMPLETE_OR_BUDGET_LIMIT','scientific_checks_passed':False,
                **pipeline_provenance(case)}
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'task'
            with patch('engine.reliability.fit_case_reliable',return_value=result):
                receipt=main._run_task(case,target,1,'demo')
            self.assertEqual(receipt['state'],'INCOMPLETE')
            self.assertEqual(json.loads((target/'task_receipt.json').read_text())['state'],'INCOMPLETE')
            with self.assertRaises(FileExistsError):
                main._run_task(case,target,1,'demo')

    def test_complete_grid_and_no_fake_duplicate(self):
        pairs=fixture_pairs('baseline')
        self.assertTrue(postprocess._matches_declared_grid(pairs,'baseline',False))
        self.assertFalse(postprocess._matches_declared_grid(pairs[:-1],'baseline',False))
        with self.assertRaises(ValueError):
            postprocess._matches_declared_grid(pairs[:-1]+[pairs[0]],'baseline',False)
        broken=copy.deepcopy(pairs[:1])
        broken[0][0]['metadata']['q']=9.
        with self.assertRaises(ValueError):
            postprocess._matches_declared_grid(broken,'baseline',False)

    def test_baseline_noiseless_cache_fields(self):
        pairs=fixture_pairs('baseline')
        with tempfile.TemporaryDirectory() as folder:
            output=Path(folder)/'fits.npz'
            figures=postprocess._baseline_cache(pairs,output)
            self.assertEqual(figures,[6,7,8,9])
            with np.load(output,allow_pickle=False) as data:
                self.assertEqual(data['noiseless_parameters'].shape,(80,2,6))
                np.testing.assert_allclose(data['noiseless_D'][:,0],1e-4)

    def test_paired_metadata_cannot_be_mixed(self):
        pair=fixture_pairs('s301')[:1]
        row1,row2=pair[0]
        row2=copy.deepcopy(row2)
        row2['metadata']['q']+=.01
        with self.assertRaises(ValueError):
            postprocess._paired([row1,row2],'s301')

    def test_incomplete_results_do_not_become_paper_statistics(self):
        case=next(iter_cases('baseline',include_noisy=False,models=('ER',),fit_pipeline='s301'))
        result=dict(case_id=case['case_id'],fit_theory='ER',theta=case['metadata']['theta_true'],
                    chi2=1.,run_complete=False,best_candidate_checks_passed=True,
                    profile='paper',result_is_demo=False, **pipeline_provenance(case))
        with tempfile.TemporaryDirectory() as folder:
            directory=Path(folder)/'tasks'/case['case_id']
            directory.mkdir(parents=True)
            (directory/'case.json').write_text(json.dumps(case))
            (directory/'result.json').write_text(json.dumps(result))
            (directory/'task_receipt.json').write_text(json.dumps(dict(
                case_id=case['case_id'],case_sha256=main._digest(case),
                state='INCOMPLETE',profile='paper', **pipeline_provenance(case))))
            rows=postprocess._load(folder)
            self.assertTrue(rows[0]['available'])
            self.assertFalse(rows[0]['eligible'])

    def test_full_s301_grid_exports_only_new_values(self):
        pairs=fixture_pairs('s301',noisy=True)
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'s301.json'
            self.assertEqual(postprocess._s301_cache(pairs,target),[13])
            data=json.loads(target.read_text())
            self.assertEqual(len(data['rows']),48)
            self.assertTrue(all(r['delta_chi2']==1. for r in data['rows']))

    def test_demo_endpoint_remains_diagnostic(self):
        case=next(iter_cases('baseline',include_noisy=False,models=('ER',)))
        raw=np.ones(np.asarray(case['xy_true']).size)*.2
        row=dict(case=case,metadata=case['metadata'],eligible=False,available=False,
            result=dict(diagnostic_best=dict(id='toy'),candidates=[dict(id='toy',
                raw_residuals=dict(third=raw.tolist()),chi2=dict(third=4.))]))
        point=postprocess._demo_endpoint(row)
        np.testing.assert_allclose(point['prediction'],np.asarray(case['xy_true'])+.2)
        self.assertFalse(row['eligible'])
        self.assertEqual(postprocess._paired([row],'baseline'),[])


if __name__=='__main__':
    unittest.main()
