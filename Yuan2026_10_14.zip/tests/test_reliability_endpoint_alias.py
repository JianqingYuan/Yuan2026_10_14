"""Pure exact-identity alias tests; no forward, optimizer or platform work."""
from copy import deepcopy
import math
from pathlib import Path
import unittest

from engine.reliability import _comparison_result, _attempt_diagnostic


def records():
    settings = dict(relative_tolerance=1e-13, absolute_tolerance=1e-15, max_step=.125)
    score = .007082792993855065
    common_score = math.nextafter(score, math.inf)
    theta = [1., .2, 30., 0., .2, .004]
    raw = [.001, -.002]
    native = dict(fit_pipeline='s301', best_candidate_id='source_a/endpoint',
        best_candidate_checks_passed=True, chi2=score, theta=theta[:], residuals=raw[:],
        run_complete=True, scientific_checks_passed=True,
        residual_accuracy='third', residual_integration=settings.copy(), third_integration=settings.copy(),
        diagnostic_best=dict(id='source_a/endpoint', chi2=score, theta=theta[:], checks_passed=True))
    common = dict(chi2=common_score, residuals=raw[:], residual_accuracy='third',
                  residual_integration=settings.copy())
    validation = dict(passed=True, numerical_checks_passed=True,
        checks=dict(saved_endpoint_reproduced=dict(passed=True, residual_difference=0.,
            saved_chi2=score, recomputed_chi2=common_score)), comparison_endpoint=common,
        fixed_point_evidence=dict(fitted=dict(theta=theta[:], levels=dict(selected=dict(
            chi2=common_score, residuals=raw[:], settings=settings.copy())))))
    return native, validation


class EndpointAliasTests(unittest.TestCase):
    def test_identical_alias_uses_common_score_without_mutating_native(self):
        native, validation = records()
        before = deepcopy(native)
        compared, comparable = _comparison_result(native, validation, False)
        self.assertTrue(comparable)
        self.assertEqual(native, before)
        self.assertEqual(compared['diagnostic_best']['chi2'], compared['chi2'])
        self.assertEqual(compared['diagnostic_alias_reproduction']['original_diagnostic'], native['diagnostic_best'])
        diagnostic, gap = _attempt_diagnostic({}, native, compared, True, False, 0, Path('unused'))
        self.assertEqual(diagnostic['chi2'], compared['chi2'])
        self.assertFalse(gap)

    def reject(self, mutate, pair=False):
        native, validation = records()
        mutate(native, validation)
        before = deepcopy(native)
        compared, _ = _comparison_result(native, validation, pair)
        self.assertEqual(native, before)
        self.assertNotIn('diagnostic_alias_reproduction', compared)
        self.assertEqual(compared['diagnostic_best'], native['diagnostic_best'])
        return native, compared

    def test_different_theta_one_ulp_lower_still_vetoes(self):
        def change(n, v):
            n['diagnostic_best']['theta'][0] = math.nextafter(n['theta'][0], math.inf)
        native, compared = self.reject(change)
        diagnostic, gap = _attempt_diagnostic({}, native, compared, True, False, 0, Path('unused'))
        self.assertLess(diagnostic['chi2'], compared['chi2'])
        self.assertFalse(gap)

    def test_other_source_id_is_never_deduplicated(self):
        self.reject(lambda n, v: n['diagnostic_best'].update(id='source_b/endpoint'))

    def test_lower_native_diagnostic_is_never_deduplicated(self):
        self.reject(lambda n, v: n['diagnostic_best'].update(chi2=math.nextafter(n['chi2'], -math.inf)))

    def test_different_raw_even_one_ulp_is_not_an_alias(self):
        def change(n, v):
            v['comparison_endpoint']['residuals'][0] = math.nextafter(n['residuals'][0], math.inf)
        self.reject(change)

    def test_failed_native_is_not_promoted(self):
        self.reject(lambda n, v: n.update(scientific_checks_passed=False))

    def test_incomplete_native_is_not_promoted(self):
        self.reject(lambda n, v: n.update(run_complete=False))

    def test_failed_endpoint_is_not_promoted(self):
        self.reject(lambda n, v: n.update(best_candidate_checks_passed=False))

    def test_failed_diagnostic_is_not_promoted(self):
        self.reject(lambda n, v: n['diagnostic_best'].update(checks_passed=False))

    def test_failed_validation_is_not_promoted(self):
        self.reject(lambda n, v: v.update(numerical_checks_passed=False))

    def test_failed_reproduction_is_not_promoted(self):
        self.reject(lambda n, v: v['checks']['saved_endpoint_reproduced'].update(passed=False))

    def test_missing_fixed_raw_is_not_an_alias(self):
        self.reject(lambda n, v: v.pop('fixed_point_evidence'))

    def test_malformed_validation_is_not_an_alias(self):
        self.reject(lambda n, v: v.update(fixed_point_evidence=None))
        self.reject(lambda n, v: v.update(checks=None))
        self.reject(lambda n, v: v['fixed_point_evidence'].update(fitted=None))
        self.reject(lambda n, v: v['fixed_point_evidence']['fitted'].update(levels=None))

    def test_different_integration_is_not_an_alias(self):
        self.reject(lambda n, v: v['comparison_endpoint']['residual_integration'].update(max_step=.25))

    def test_other_precision_is_not_an_alias(self):
        self.reject(lambda n, v: v['comparison_endpoint'].update(residual_accuracy='tight'))

    def test_known_lower_veto_is_not_erased(self):
        self.reject(lambda n, v: n.update(lower_failed_candidate_veto=True))

    def test_legacy_unchanged(self):
        self.reject(lambda n, v: n.update(fit_pipeline='legacy'), pair=True)


if __name__ == '__main__':
    unittest.main()
