"""Pure time/process mocks: no forward, optimizer or subprocess is launched."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

from engine import legacy, reliability as rel
from engine import fit_validation as validation


def cases():
    common = dict(dataset_id='clock_fixture', times=[0., 1.], xy_observed=[[0., 0.], [0., 0.]],
        residual_sigma=1., legacy_optimizer_seed=104729, run_seeds=[12345, 67890],
        fit_pipeline='legacy', legacy_variant='baseline', metadata=dict(suite='baseline'),
        wall_seconds_per_pair=300.)
    return {name:dict(deepcopy(common), case_id='clock_'+name, fit_theory=name) for name in ('ER', 'RN')}


def result(case):
    return dict(case_id=case['case_id'], fit_theory=case['fit_theory'], fit_pipeline=case['fit_pipeline'],
        status='INCOMPLETE_OR_BUDGET_LIMIT', run_complete=False,
        scientific_checks_passed=False, best_candidate_checks_passed=False)


class ControllerBudgetTests(unittest.TestCase):
    def test_public_parent_cap_applies_to_single_and_atomic_pair_without_reset(self):
        for paired in (False,True):
            with self.subTest(paired=paired),tempfile.TemporaryDirectory() as temp:
                clock,calls=[100.],[]
                pair=cases()
                if not paired: pair['ER'].update(fit_pipeline='s301',wall_seconds=300.)
                def fit(*args,**kwargs):
                    output=Path(args[2] if paired else args[1])
                    inputs=dict(ER=args[0],RN=args[1]) if paired else dict(ER=args[0])
                    calls.append(kwargs['absolute_deadline'])
                    self.assertEqual(kwargs['absolute_deadline'],125.)
                    clock[0]=125.
                    rows={name:result(case) for name,case in inputs.items()}
                    for name,row in rows.items():
                        target=output/name if paired else output
                        target.mkdir(parents=True)
                        (target/'result.json').write_text(json.dumps(row))
                    return rows if paired else rows['ER']
                def audit(case,output,deadline,**kwargs):
                    self.assertLessEqual(kwargs['absolute_deadline'],150.)
                    clock[0]=kwargs['absolute_deadline']
                    return dict(passed=False,numerical_checks_passed=None)
                with patch.object(rel.time,'monotonic',side_effect=lambda:clock[0]), \
                     patch.object(rel.time,'time',side_effect=lambda:clock[0]+10000.), \
                     patch.object(rel,'fit_pair' if paired else 'fit_case',side_effect=fit), \
                     patch.object(rel,'validate_endpoint',side_effect=audit):
                    if paired:
                        output=rel.fit_pair_reliable(pair['ER'],pair['RN'],Path(temp)/'run',profile='demo',
                            policy=dict(max_attempts=1),absolute_deadline=150.)['ER']
                    else:
                        output=rel.fit_case_reliable(pair['ER'],Path(temp)/'run',profile='demo',
                            policy=dict(max_attempts=1),absolute_deadline=150.)
                self.assertEqual(calls,[125.])
                self.assertEqual(clock[0],150.)
                self.assertEqual(output['reliability']['maximum_total_wall_seconds'],300.)
                self.assertEqual(output['reliability']['available_total_wall_seconds'],50.)
                self.assertFalse(output['scientific_checks_passed'])

    def test_expired_public_cap_never_starts_fit_and_cancel_precedes_bad_cap(self):
        with tempfile.TemporaryDirectory() as temp, \
             patch.object(rel.time,'monotonic',return_value=100.), \
             patch.object(rel,'fit_case',side_effect=AssertionError('fit must not start')):
            case=cases()['ER'];case['fit_pipeline']='s301'
            output=rel.fit_case_reliable(case,Path(temp)/'expired',profile='demo',absolute_deadline=99.)
            self.assertEqual(output['reliability']['attempts_started'],0)
            self.assertFalse(output['scientific_checks_passed'])
            for bad in (True,float('nan'),float('inf'),'100'):
                with self.subTest(bad=bad),self.assertRaises(ValueError):
                    rel.fit_case_reliable(case,Path(temp)/'invalid',absolute_deadline=bad)
            event=threading.Event();event.set()
            with self.assertRaises(KeyboardInterrupt):
                rel.fit_case_reliable(case,Path(temp)/'cancelled',cancel_event=event,absolute_deadline=float('nan'))

    def test_pair_retains_one_native_workflow_and_disjoint_validation_allowances(self):
        for early in (False, True):
            with self.subTest(early=early), tempfile.TemporaryDirectory() as temp:
                clock, native_calls, validations = [100.], [], []
                def fit(er, rn, output, **kwargs):
                    native_calls.append((deepcopy(er), deepcopy(rn), kwargs))
                    self.assertEqual(kwargs['budget_factor'], 1.)
                    self.assertEqual(er['wall_seconds_per_pair'], 180.)
                    self.assertEqual(rn['wall_seconds_per_pair'], 180.)
                    self.assertEqual(kwargs['absolute_deadline'], 280.)
                    clock[0] = kwargs['absolute_deadline']
                    rows = {'RN':result(rn), 'ER':result(er)}  # Response order cannot steal a share.
                    for name, row in rows.items():
                        target = Path(output)/name
                        target.mkdir(parents=True)
                        (target/'result.json').write_text(json.dumps(row))
                    return rows
                def audit(case, output, deadline, **kwargs):
                    allowance = deadline-(clock[0]+10000.)
                    self.assertEqual(kwargs['absolute_deadline'], clock[0]+allowance)
                    validations.append((case['fit_theory'], allowance))
                    clock[0] += 5. if early and len(validations)==1 else allowance
                    return dict(passed=False, numerical_checks_passed=None)
                pair = cases()
                with patch.object(rel.time, 'monotonic', side_effect=lambda:clock[0]), \
                     patch.object(rel.time, 'time', side_effect=lambda:clock[0]+10000.), \
                     patch.object(rel, 'fit_pair', side_effect=fit), \
                     patch.object(rel, 'validate_endpoint', side_effect=audit):
                    outputs = rel.fit_pair_reliable(pair['ER'], pair['RN'], Path(temp)/'run',
                        profile='demo', policy=dict(max_attempts=1))
                self.assertEqual(len(native_calls), 1)
                self.assertEqual(validations, [('ER', 60.), ('RN', 60.)])
                self.assertLessEqual(clock[0], 400.)
                evidence = outputs['ER']['reliability']
                self.assertEqual(evidence['maximum_total_wall_seconds'], 300.)
                self.assertEqual(evidence['absolute_deadline_monotonic'], 400.)
                self.assertFalse(outputs['ER']['scientific_checks_passed'])

    def test_controller_preparation_and_receipt_writes_cannot_reset_deadline(self):
        with tempfile.TemporaryDirectory() as temp:
            clock, seen = [100.], []
            original_plan, original_write = rel._seed_plan, rel._write
            def plan(*args):
                clock[0] += 7.
                return original_plan(*args)
            delayed = [False]
            def write(path, value):
                original_write(path, value)
                if path.name == 'reliability.json' and value['attempts'] and not delayed[0]:
                    delayed[0] = True
                    clock[0] += 11.
            def fit(case, output, **kwargs):
                seen.append((clock[0], kwargs['absolute_deadline'], case['wall_seconds']))
                clock[0] = kwargs['absolute_deadline']
                row = result(case)
                Path(output).mkdir()
                (Path(output)/'result.json').write_text(json.dumps(row))
                return row
            def audit(case, output, deadline, **kwargs):
                clock[0] = deadline
                return dict(passed=False, numerical_checks_passed=None)
            case = cases()['ER']; case.update(fit_pipeline='s301', wall_seconds=300.)
            with patch.object(rel.time, 'monotonic', side_effect=lambda:clock[0]), \
                 patch.object(rel.time, 'time', side_effect=lambda:clock[0]), \
                 patch.object(rel, '_seed_plan', side_effect=plan), \
                 patch.object(rel, '_write', side_effect=write), \
                 patch.object(rel, 'fit_case', side_effect=fit), \
                 patch.object(rel, 'validate_endpoint', side_effect=audit):
                output = rel.fit_case_reliable(case, Path(temp)/'run', profile='demo', policy=dict(max_attempts=1))
            self.assertEqual(seen, [(118., 340., 233.)])
            self.assertEqual(clock[0], 400.)
            self.assertEqual(output['reliability']['spent_wall_seconds'], 300.)
            self.assertEqual(output['reliability']['attempts'][0]['spent_wall_seconds'], 293.)

    def test_tiny_pair_keeps_positive_shares_and_original_work_factor(self):
        with tempfile.TemporaryDirectory() as temp:
            pair = cases()
            for case in pair.values(): case['wall_seconds_per_pair'] = .01
            calls, allowances = [], []
            def fit(er, rn, output, **kwargs):
                calls.append((er['wall_seconds_per_pair'] * kwargs['budget_factor'], kwargs['budget_factor']))
                rows = {name:result(case) for name,case in [('ER',er),('RN',rn)]}
                for name,row in rows.items():
                    target = Path(output)/name; target.mkdir(parents=True)
                    (target/'result.json').write_text(json.dumps(row))
                return rows
            def audit(case, output, deadline, **kwargs):
                allowances.append(deadline)
                return dict(passed=False, numerical_checks_passed=None)
            with patch.object(rel.time, 'monotonic', return_value=0.), patch.object(rel.time, 'time', return_value=0.), \
                 patch.object(rel, 'fit_pair', side_effect=fit), patch.object(rel, 'validate_endpoint', side_effect=audit):
                rel.fit_pair_reliable(pair['ER'],pair['RN'],Path(temp)/'run',profile='demo')
            self.assertEqual(calls, [(.005,1.),(.01,2.),(.02,4.)])
            self.assertEqual(allowances, [.0025,.0025,.005,.005,.01,.01])


class LegacyDeadlineTests(unittest.TestCase):
    def test_preparation_expiry_does_not_launch_and_retains_both_unpassed_results(self):
        for parent in (None, 105.):
            with self.subTest(parent=parent), tempfile.TemporaryDirectory() as temp:
                clock = [100.]
                pair = cases()
                for case in pair.values(): case['wall_seconds_per_pair'] = 10.
                def verify(): clock[0] += 20.; return {}
                with patch.object(legacy.time, 'monotonic', side_effect=lambda:clock[0]), \
                     patch.object(legacy.time, 'time', side_effect=AssertionError('epoch clock used')), \
                     patch.object(legacy, 'verify_legacy_vendor', side_effect=verify), \
                     patch.object(legacy.subprocess, 'Popen', side_effect=AssertionError('child started')) as launch:
                    rows = legacy.fit_pair(pair['ER'], pair['RN'], Path(temp)/'run',
                        profile='demo', absolute_deadline=parent)
                launch.assert_not_called()
                payload = json.loads((Path(temp)/'run/input.json').read_text())
                self.assertEqual(payload['pair_deadline_monotonic'], 110. if parent is None else parent)
                for row in rows.values():
                    self.assertEqual(row['status'], 'BUDGET_OR_INTERRUPTION')
                    self.assertEqual(row['elapsed_seconds'], 20.)
                    self.assertFalse(row['scientific_checks_passed'])
                    self.assertFalse(row['best_candidate_checks_passed'])

    def test_parent_deadline_caps_owned_child_in_same_clock_without_restarting_pair(self):
        with tempfile.TemporaryDirectory() as temp:
            clock, launches, stops = [100.], [], []
            pair = cases()
            class Child:
                returncode = None
                def poll(self): return self.returncode
            child = Child()
            def verify(): clock[0] += 3.; return {}
            def launch(*args, **kwargs):
                launches.append((args,kwargs)); clock[0] += 2.; return child
            def stop(process):
                if process.returncode is None:
                    stops.append(clock[0]); process.returncode = -9
            with patch.object(legacy.time, 'monotonic', side_effect=lambda:clock[0]), \
                 patch.object(legacy.time, 'time', side_effect=AssertionError('epoch clock used')), \
                 patch.object(legacy.time, 'sleep', side_effect=lambda seconds:clock.__setitem__(0,clock[0]+seconds)), \
                 patch.object(legacy, 'verify_legacy_vendor', side_effect=verify), \
                 patch.object(legacy.subprocess, 'Popen', side_effect=launch), \
                 patch.object(legacy, '_stop_owned_process', side_effect=stop):
                rows = legacy.fit_pair(pair['ER'],pair['RN'],Path(temp)/'run',profile='demo',absolute_deadline=107.)
            self.assertEqual(len(launches),1)
            self.assertEqual(stops,[107.])
            self.assertEqual({row['pair_deadline_monotonic'] for row in rows.values()},{107.})
            self.assertEqual({row['elapsed_seconds'] for row in rows.values()},{7.})
            self.assertEqual({row['status'] for row in rows.values()},{'BUDGET_OR_INTERRUPTION'})

    def test_later_parent_cannot_extend_relative_budget_and_invalid_parent_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            pair = cases()
            for case in pair.values(): case['wall_seconds_per_pair'] = 2.
            clock = [100.]
            def verify(): clock[0] = 102.; return {}
            with patch.object(legacy.time,'monotonic',side_effect=lambda:clock[0]), \
                 patch.object(legacy,'verify_legacy_vendor',side_effect=verify), \
                 patch.object(legacy.subprocess,'Popen',side_effect=AssertionError('must not launch')):
                rows = legacy.fit_pair(pair['ER'],pair['RN'],Path(temp)/'run',absolute_deadline=1000.)
            self.assertEqual(rows['ER']['pair_deadline_monotonic'],102.)
            for bad in (True,float('nan'),float('inf'),'100'):
                with self.subTest(bad=bad),self.assertRaises(ValueError):
                    legacy.fit_pair(pair['ER'],pair['RN'],Path(temp)/'invalid',absolute_deadline=bad)

    def test_completed_child_after_cutoff_cannot_promote_pair(self):
        with tempfile.TemporaryDirectory() as temp:
            pair, clock = cases(), [100.]
            class Child:
                returncode = 0
                def poll(self): return self.returncode
            def launch(command, **kwargs):
                directory = Path(command[-1])
                rows = {name:dict(result(case), scientific_checks_passed=True,
                    best_candidate_checks_passed=True, run_complete=True, status='COMPLETED')
                    for name,case in pair.items()}
                (directory/'pair_result.json').write_text(json.dumps(dict(results=rows)))
                clock[0] = 106.
                return Child()
            with patch.object(legacy.time,'monotonic',side_effect=lambda:clock[0]), \
                 patch.object(legacy,'verify_legacy_vendor',return_value={}), \
                 patch.object(legacy.subprocess,'Popen',side_effect=launch):
                rows = legacy.fit_pair(pair['ER'],pair['RN'],Path(temp)/'run',absolute_deadline=105.)
            self.assertFalse(any(row['scientific_checks_passed'] for row in rows.values()))
            self.assertEqual({row['status'] for row in rows.values()},{'BUDGET_OR_INTERRUPTION'})


class ValidationDeadlineTests(unittest.TestCase):
    def replay(self, phase, cancelled=False):
        clock, launches = [100.], []
        event = threading.Event()
        payload = dict(observation_sha256='pure-fixture', effective_bounds={}, pipeline='s301')
        def delay():
            clock[0] = 106.
            if cancelled: event.set()
        def prepare(*args):
            if phase=='payload': delay()
            return payload
        original_write, original_loads = Path.write_text, json.loads
        def write(path, *args, **kwargs):
            value = original_write(path, *args, **kwargs)
            if phase=='write' and path.name=='input.json': delay()
            return value
        class Child:
            returncode = 0
            def poll(self): return self.returncode
            def wait(self, timeout): return 0
            def kill(self): raise AssertionError('completed mock child must not be killed')
        def launch(command, **kwargs):
            launches.append(command)
            Path(command[-1]).write_text(json.dumps(dict(ok=True,evidence={})))
            if phase=='launch': delay()
            return Child()
        def loads(*args, **kwargs):
            value=original_loads(*args,**kwargs)
            if phase=='decode': delay()
            return value
        def check(*args):
            if phase=='check': delay()
            return dict(passed=True,numerical_checks_passed=True)
        with patch.object(validation.time,'monotonic',side_effect=lambda:clock[0]), \
             patch.object(validation.time,'time',return_value=10000.), \
             patch.object(validation,'_payload',side_effect=prepare), \
             patch.object(Path,'write_text',write), \
             patch.object(validation.json,'loads',side_effect=loads), \
             patch.object(validation.subprocess,'Popen',side_effect=launch), \
             patch.object(validation,'_fixed_point_check',side_effect=check):
            checked=validation.validate_endpoint({}, {}, 11000., event, absolute_deadline=105.)
        return checked,launches

    def test_preparation_and_late_success_never_extend_fixed_monotonic_budget(self):
        for phase in ('payload','write','launch','decode','check'):
            with self.subTest(phase=phase):
                checked,launches=self.replay(phase)
                self.assertFalse(checked['passed'])
                self.assertEqual(checked['status'],'VALIDATION_BUDGET_EXHAUSTED')
                self.assertEqual(checked['absolute_deadline_monotonic'],105.)
                self.assertEqual(len(launches),0 if phase in ('payload','write') else 1)

    def test_precutoff_result_may_pass_unchanged_scientific_checker(self):
        checked,launches=self.replay('none')
        self.assertTrue(checked['passed'])
        self.assertEqual(len(launches),1)

    def test_cancellation_takes_priority_over_expiry_even_after_checked_success(self):
        for phase in ('payload','write','launch','decode','check'):
            with self.subTest(phase=phase),self.assertRaises(KeyboardInterrupt):
                self.replay(phase,cancelled=True)

    def test_expired_and_invalid_caps_never_launch(self):
        with patch.object(validation.time,'monotonic',return_value=100.), \
             patch.object(validation.time,'time',return_value=10000.), \
             patch.object(validation.subprocess,'Popen',side_effect=AssertionError('must not launch')):
            checked=validation.validate_endpoint({}, {}, 9999., absolute_deadline=200.)
            self.assertEqual(checked['status'],'VALIDATION_BUDGET_EXHAUSTED')
            for bad in (True,float('nan'),float('inf'),'100'):
                with self.subTest(bad=bad),self.assertRaises(ValueError):
                    validation.validate_endpoint({}, {}, 10060., absolute_deadline=bad)


if __name__ == '__main__': unittest.main()
