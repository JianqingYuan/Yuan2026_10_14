"""Check full-run figure accounting without integrating or fitting."""
from contextlib import ExitStack, redirect_stdout
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import main
from run_state import write_json


class FullRunReportingTests(unittest.TestCase):
    def test_precomputed_geometry_is_counted_without_replotting(self):
        for statistical_ids in (list(range(6, 14)), []):
            with self.subTest(statistical_ids=statistical_ids), tempfile.TemporaryDirectory() as name, ExitStack() as stack:
                output = Path(name) / 'run'
                case = {'case_id': 'probe_ER', 'fit_pipeline': 's301'}
                stack.enter_context(patch('main._selection_plan', return_value=dict(
                    total=1, selected=1, first=1, last=1, model_case_ids=['probe_ER'])))
                stack.enter_context(patch('main._pipeline_plan', return_value={
                    's301': {'fit_pipeline': 's301', 'fit_pipeline_version': 'test'}}))
                stack.enter_context(patch('main._select_cases', side_effect=lambda options: iter([case])))
                stack.enter_context(patch('main._scientific_source_hash', return_value='a'*64))
                stack.enter_context(patch('main._run_task', return_value=dict(case_id='probe_ER', state='FINISHED')))
                geometry = stack.enter_context(patch('plotting.geometry_data.recompute_geometry'))
                geometry_paths = [output/'figures'/f'geometry_{index}.pdf' for index in range(1, 6)]
                drawing = stack.enter_context(patch('plotting.paper.render_all', return_value=geometry_paths))

                def final_plot(directory, mode):
                    write_json(Path(directory)/'plot_status.json', dict(
                        paper_layout_figures_generated=statistical_ids,
                        original_paper_snapshot_used=False))
                    return [output/'figures'/'summary.pdf'] + [
                        output/'figures'/f'figure_{index}.pdf' for index in statistical_ids]

                stack.enter_context(patch('postprocess.render_run', side_effect=final_plot))
                messages = stack.enter_context(redirect_stdout(io.StringIO()))
                self.assertEqual(main.run(['--mode', 'recompute', '--suite', 'all',
                    '--fit-pipeline', 'paper', '--workers', '1', '--cores-per-fit', '1',
                    '--output', str(output)]), 0)
                geometry.assert_called_once()
                drawing.assert_called_once()
                status = json.loads((output/'plot_status.json').read_text(encoding='utf-8'))
                self.assertEqual(status['paper_layout_figures_generated'], list(range(1, 6)) + statistical_ids)
                self.assertFalse(status['original_paper_snapshot_used'])
                self.assertIn(f'generated {6 + len(statistical_ids)} figure(s)', messages.getvalue())


if __name__ == '__main__':
    unittest.main()
