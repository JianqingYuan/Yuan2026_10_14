"""A corrected saved-data redraw must not imply full-campaign recertification."""
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import main


class AuditNoticeTests(unittest.TestCase):
    def test_saved_redraw_marks_targeted_corrections_without_starting_fit(self):
        with tempfile.TemporaryDirectory() as folder:
            destination = Path(folder)/'redraw'
            captured = io.StringIO()
            with patch('plotting.paper.render_all', return_value=[]), \
                 patch('engine.reliability.fit_case_reliable', side_effect=AssertionError('No fit in paper mode')), \
                 redirect_stdout(captured):
                code = main.run(['--mode','paper','--output',str(destination)])
            record = json.loads((destination/'run.json').read_text(encoding='utf-8'))
            self.assertEqual(code,0)
            self.assertFalse(record['scientific_recertification'])
            self.assertFalse(record['full_campaign_revalidated'])
            self.assertEqual(record['targeted_corrections_applied'],
                             {'s301_pairs': 4, 'extreme_ER_cases': 77})
            self.assertEqual(record['paper_snapshot'], '2026.10.16-paper-sync')
            self.assertEqual(record['fit_calls'], 0)
            self.assertIn('not a full-campaign recertification', captured.getvalue())


if __name__ == '__main__':
    unittest.main()
