"""Mocked controller regressions; these tests never launch a physical fit."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import threading
import subprocess
import sys
import unittest
from unittest.mock import patch

from engine import reliability as rel
from engine.api import _config
from engine._legacy_worker import scale_budget_limits


def case(name='ER', pair=False):
    return dict(case_id='fixture_' + name, dataset_id='fixture', fit_theory=name,
        fit_pipeline='legacy' if pair else 's301', residual_sigma=1.,
        run_seeds=[12345, 67890], legacy_optimizer_seed=104729,
        metadata=dict(suite='baseline', add_noise=False))


def result(score=1., passed=False, numeric=True, status='COMPLETED'):
    return dict(status=status, run_complete=status == 'COMPLETED',
        scientific_checks_passed=passed, best_candidate_checks_passed=numeric,
        theta=[1., .3, 30., 0., .2, .004], chi2=score, residuals=[score**.5, 0.],
        no_global_optimum_certificate=True)


class ReliabilityTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.output = Path(self.temporary.name) / 'output'
        self.calls = []

    def mock_fit(self, results, pair=False, create_output=True):
        sequence = iter(results)
        def run(*args, **kwargs):
            directory = Path(args[2] if pair else args[1])
            self.calls.append((deepcopy(args[:2] if pair else args[:1]), dict(kwargs)))
            value = next(sequence)
            if isinstance(value, BaseException):
                raise value
            value = deepcopy(value)
            for name, output in (value.items() if pair else [(None, value)]):
                source = args[0 if not pair or name == 'ER' else 1]
                for key in ('case_id', 'fit_theory', 'fit_pipeline', 'fit_pipeline_version', 'fit_pipeline_requested'):
                    if key in source:
                        output.setdefault(key, source[key])
            if create_output:
                directory.mkdir(parents=True)
                for name, output in (value.items() if pair else [(None, value)]):
                    target = directory / name if pair else directory
                    target.mkdir(exist_ok=True)
                    (target / 'result.json').write_text(json.dumps(output), encoding='utf-8')
            return deepcopy(value)
        return run

    def execute(self, results, validation=None, **kwargs):
        validation = validation or dict(passed=True, numerical_checks_passed=True)
        with patch.object(rel, 'fit_case', side_effect=self.mock_fit(results)):
            with patch.object(rel, 'validate_endpoint', return_value=validation) as audit:
                output = rel.fit_case_reliable(case(), self.output, profile='demo', **kwargs)
        return output, audit

    def test_first_pass_stops_without_retry(self):
        output, audit = self.execute([result(passed=True)])
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(audit.call_count, 1)
        self.assertTrue(output['scientific_checks_passed'])
        self.assertTrue(output['run_complete'])
        self.assertTrue(output['result_is_demo'])
        self.assertTrue(output['no_global_optimum_certificate'])
        self.assertEqual(output['reliability']['maximum_total_wall_seconds'], 2100)
        self.assertEqual(output['selected_attempt_index'], 0)
        self.assertIn('not_historical', output['reliability']['implementation'])
        self.assertTrue((self.output / 'attempt_01' / 'reliability_receipt.json').exists())

    def test_escalation_new_seeds_and_selected_native_provenance(self):
        output, _ = self.execute([result(3), result(2), result(1, status='INCOMPLETE_OR_BUDGET_LIMIT')])
        self.assertEqual([kwargs['budget_factor'] for _, kwargs in self.calls], [1, 2, 4])
        seeds = [args[0]['run_seeds'] for args, _ in self.calls]
        self.assertEqual(seeds[0], case()['run_seeds'])
        self.assertEqual(len(set(sum(seeds, []))), 6)
        self.assertEqual(output['chi2'], 1)
        self.assertFalse(output['scientific_checks_passed'])
        self.assertTrue(output['run_complete'])
        self.assertFalse(output['selected_native_run_complete'])
        self.assertEqual(output['status'], 'NEEDS_REVIEW_BEST_FOUND')
        self.assertEqual(output['best_attempt'], 2)
        self.assertEqual(len(output['reliability_attempts']), 3)

    def test_higher_passed_attempt_cannot_hide_lower_unresolved(self):
        output, _ = self.execute([result(1), result(3, True), result(2, True)])
        self.assertEqual(output['chi2'], 1)
        self.assertEqual(output['selected_attempt_index'], 0)
        self.assertFalse(output['scientific_checks_passed'])
        self.assertEqual(len(self.calls), 3)

    def test_lower_rejected_numeric_candidate_is_diagnostic_only(self):
        output, _ = self.execute([result(.5, numeric=False), result(2, True), result(1, True)])
        self.assertEqual(output['chi2'], 1)
        self.assertEqual(output['diagnostic_best']['chi2'], .5)
        self.assertFalse(output['scientific_checks_passed'])

    def test_fixed_point_disagreement_removes_native_claim_from_usable(self):
        output, _ = self.execute([result(1, True)] * 3,
            validation=dict(passed=False, numerical_checks_passed=False))
        self.assertNotIn('theta', output)
        self.assertNotIn('chi2', output)
        self.assertEqual(output['diagnostic_best']['chi2'], 1)
        self.assertFalse(output['best_candidate_checks_passed'])
        self.assertEqual(output['status'], 'NEEDS_REVIEW_NO_VALID_CANDIDATE')

    def test_validation_timeout_preserves_native_numeric_minimum_as_unpassed(self):
        output, _ = self.execute([result(3, True), result(2, True), result(1, True)],
            validation=dict(passed=False, numerical_checks_passed=None, status='BUDGET_EXHAUSTED'))
        self.assertEqual(output['chi2'], 1)
        self.assertTrue(output['best_candidate_checks_passed'])
        self.assertFalse(output['scientific_checks_passed'])

    def test_no_finite_endpoint_cannot_become_success(self):
        missing = dict(status='BUDGET_OR_INTERRUPTION', run_complete=False,
            scientific_checks_passed=False, best_candidate_checks_passed=False)
        output, _ = self.execute([missing] * 3)
        self.assertNotIn('chi2', output)
        self.assertFalse(output['scientific_checks_passed'])
        self.assertEqual(len(self.calls), 3)

    def test_missing_output_is_hard_failure_and_never_retried(self):
        with patch.object(rel, 'fit_case', side_effect=self.mock_fit([result()], create_output=False)):
            with patch.object(rel, 'validate_endpoint') as audit:
                output = rel.fit_case_reliable(case(), self.output, profile='demo')
        self.assertEqual(output['status'], 'FAILED')
        self.assertFalse(output['run_complete'])
        self.assertEqual(len(self.calls), 1)
        audit.assert_not_called()

    def test_hard_failure_stops_and_retains_earlier_best(self):
        output, audit = self.execute([result(2), result(3, status='FAILED')])
        self.assertEqual(output['status'], 'FAILED')
        self.assertEqual(output['chi2'], 2)
        self.assertFalse(output['run_complete'])
        self.assertEqual(len(self.calls), 2)
        self.assertEqual(audit.call_count, 1)

    def test_exception_is_not_a_convergence_retry(self):
        output, audit = self.execute([RuntimeError('worker missing')])
        self.assertEqual(output['status'], 'FAILED')
        self.assertIn('worker missing', output['stop_reason'])
        self.assertEqual(len(self.calls), 1)
        audit.assert_not_called()

    def test_validation_worker_failure_is_not_a_convergence_retry(self):
        output, audit = self.execute([result(1, True)],
            validation=dict(passed=False, status='VALIDATION_FAILED', error='missing worker output'))
        self.assertEqual(output['status'], 'FAILED')
        self.assertEqual(output['chi2'], 1)
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(audit.call_count, 1)
        self.assertFalse(output['run_complete'])

    def test_interrupt_retains_receipt_and_propagates_without_retry(self):
        with self.assertRaises(KeyboardInterrupt):
            self.execute([result(2), KeyboardInterrupt('cancel')])
        saved = json.loads((self.output / 'result.json').read_text())
        self.assertEqual(saved['status'], 'INTERRUPTED')
        self.assertEqual(saved['chi2'], 2)
        self.assertEqual(len(self.calls), 2)
        self.assertFalse(saved['run_complete'])

    def test_pre_cancel_does_not_create_output(self):
        event = threading.Event()
        event.set()
        with self.assertRaises(KeyboardInterrupt):
            rel.fit_case_reliable(case(), self.output, cancel_event=event)
        self.assertFalse(self.output.exists())

    def test_total_wall_budget_includes_validation_and_never_resets(self):
        clock = [100.]
        native = self.mock_fit([result(3), result(2), result(1)])
        def fit(*args, **kwargs):
            clock[0] += args[0]['wall_seconds'] * kwargs['budget_factor']
            return native(*args, **kwargs)
        validation_deadlines = []
        def audit(case, output, deadline, **kwargs):
            allowance = max(0., deadline - clock[0])
            validation_deadlines.append(allowance)
            clock[0] += allowance
            return dict(passed=False, numerical_checks_passed=None)
        with patch.object(rel.time, 'monotonic', side_effect=lambda:clock[0]), patch.object(rel.time, 'time', side_effect=lambda:clock[0]):
            with patch.object(rel, 'fit_case', side_effect=fit), patch.object(rel, 'validate_endpoint', side_effect=audit):
                output = rel.fit_case_reliable(case(), self.output, profile='demo')
        allocated = [args[0]['wall_seconds'] * kwargs['budget_factor'] for args, kwargs in self.calls]
        self.assertEqual(allocated, [240., 480., 960.])
        self.assertEqual(validation_deadlines, [60., 120., 240.])
        self.assertEqual(output['reliability']['validation_wall_seconds_per_model_by_attempt'], [60., 120., 240.])
        self.assertEqual(output['reliability']['spent_wall_seconds'], 2100)
        self.assertEqual(output['reliability']['remaining_wall_seconds'], 0)

    def test_validation_allowances_escalate_when_shared_budget_is_available(self):
        deadlines = []
        def audit(case, output, deadline, **kwargs):
            deadlines.append(deadline - 100.)
            return dict(passed=False, numerical_checks_passed=True)
        with patch.object(rel.time, 'time', return_value=100.), patch.object(rel.time, 'monotonic', return_value=100.):
            with patch.object(rel, 'fit_case', side_effect=self.mock_fit([result(3), result(2), result(1)])):
                with patch.object(rel, 'validate_endpoint', side_effect=audit):
                    output = rel.fit_case_reliable(case(), self.output, profile='demo')
        self.assertEqual(deadlines, [60., 120., 240.])
        self.assertEqual([row['models']['ER']['allocated_validation_wall_seconds'] for row in output['reliability_attempts']], deadlines)

    def test_cancel_raised_immediately_after_validation_returns_passed(self):
        event = threading.Event()
        def audit(*args, **kwargs):
            event.set()
            return dict(passed=True, numerical_checks_passed=True)
        with patch.object(rel, 'fit_case', side_effect=self.mock_fit([result(1, True)])):
            with patch.object(rel, 'validate_endpoint', side_effect=audit):
                with self.assertRaises(KeyboardInterrupt):
                    rel.fit_case_reliable(case(), self.output, profile='demo', cancel_event=event)
        saved = json.loads((self.output / 'result.json').read_text())
        self.assertEqual(saved['status'], 'INTERRUPTED')
        self.assertFalse(saved['scientific_checks_passed'])
        self.assertFalse(saved['run_complete'])
        self.assertEqual(len(self.calls), 1)

    def test_cancel_after_completed_receipt_is_checked_before_success_save(self):
        event = threading.Event()
        original_write = rel._write
        def cancelling_write(path, value):
            original_write(path, value)
            if path.name == 'reliability_receipt.json' and value.get('status') == 'COMPLETED':
                event.set()
        with patch.object(rel, '_write', side_effect=cancelling_write):
            with patch.object(rel, 'fit_case', side_effect=self.mock_fit([result(1, True)])):
                with patch.object(rel, 'validate_endpoint', return_value=dict(passed=True, numerical_checks_passed=True)):
                    with self.assertRaises(KeyboardInterrupt):
                        rel.fit_case_reliable(case(), self.output, profile='demo', cancel_event=event)
        saved = json.loads((self.output / 'result.json').read_text())
        self.assertEqual(saved['status'], 'INTERRUPTED')
        self.assertEqual(saved['chi2'], 1.)
        self.assertFalse(saved['scientific_checks_passed'])
        self.assertFalse(saved['run_complete'])

    def test_wrong_provenance_is_hard_failure(self):
        broken = result()
        broken['case_id'] = 'different_dataset'
        output, audit = self.execute([broken])
        self.assertEqual(output['status'], 'FAILED')
        self.assertIn('provenance mismatch', output['stop_reason'])
        self.assertEqual(len(self.calls), 1)
        audit.assert_not_called()

    def test_saved_and_returned_record_mismatch_is_hard_failure(self):
        native = self.mock_fit([result()])
        def changed(*args, **kwargs):
            value = native(*args, **kwargs)
            value['chi2'] = 9.
            return value
        with patch.object(rel, 'fit_case', side_effect=changed), patch.object(rel, 'validate_endpoint') as audit:
            output = rel.fit_case_reliable(case(), self.output, profile='demo')
        self.assertEqual(output['status'], 'FAILED')
        self.assertIn('differs from the returned', output['stop_reason'])
        audit.assert_not_called()

    def test_invalid_finite_endpoint_shape_is_never_promoted(self):
        broken = result()
        broken['theta'] = [1, 2]
        output, _ = self.execute([broken] * 3)
        self.assertNotIn('theta', output)
        self.assertNotIn('chi2', output)
        self.assertIsNone(output['diagnostic_best']['theta'])

    def test_deterministic_collision_free_all_legacy_streams(self):
        cases = {name:case(name, True) for name in ('ER', 'RN')}
        plan = rel._seed_plan(cases, True, 'paper', 3)
        self.assertEqual(plan, rel._seed_plan(cases, True, 'paper', 3))
        self.assertEqual(plan[0]['legacy_optimizer_seed'], 104729)
        seeds = [seed for item in plan for seed in item['reserved_seeds']]
        self.assertEqual(len(seeds), len(set(seeds)))
        self.assertEqual(len(plan[0]['reserved_seeds']), 20)

    def test_legacy_pair_retries_atomically_and_does_not_graft_certificates(self):
        values = [dict(ER=result(1), RN=result(3)),
                  dict(ER=result(2, True), RN=result(2, True)),
                  dict(ER=result(3, True), RN=result(1, True))]
        with patch.object(rel, 'fit_pair', side_effect=self.mock_fit(values, pair=True)):
            with patch.object(rel, 'validate_endpoint', return_value=dict(passed=True)):
                outputs = rel.fit_pair_reliable(case('ER', True), case('RN', True), self.output, profile='demo')
        self.assertEqual(len(self.calls), 3)
        self.assertEqual([outputs[name]['chi2'] for name in ('ER', 'RN')], [1, 1])
        self.assertFalse(any(output['scientific_checks_passed'] for output in outputs.values()))
        self.assertFalse(outputs['ER']['reliability']['selected_pair_same_attempt'])
        for args, _ in self.calls:
            self.assertEqual(args[0]['legacy_optimizer_seed'], args[1]['legacy_optimizer_seed'])

    def test_pair_either_hard_failure_prevents_validation_or_retry(self):
        values = [dict(ER=result(1, True), RN=result(2, status='FAILED'))]
        with patch.object(rel, 'fit_pair', side_effect=self.mock_fit(values, pair=True)):
            with patch.object(rel, 'validate_endpoint') as audit:
                outputs = rel.fit_pair_reliable(case('ER', True), case('RN', True), self.output, profile='demo')
        audit.assert_not_called()
        self.assertEqual(len(self.calls), 1)
        self.assertEqual({r['status'] for r in outputs.values()}, {'FAILED'})

    def test_common_objective_rescoring_controls_legacy_selection(self):
        values = [dict(ER=result(.1), RN=result(.2)),
                  dict(ER=result(.3, True), RN=result(.4, True))]
        common_scores = iter([3., 4., 1., 2.])
        def audit(case, result, deadline, **kwargs):
            value = next(common_scores)
            return dict(passed=True, numerical_checks_passed=True,
                comparison_endpoint=dict(chi2=value, residuals=[value**.5, 0.],
                    residual_accuracy='tight', residual_integration={'max_step':.1}))
        with patch.object(rel, 'fit_pair', side_effect=self.mock_fit(values, pair=True)):
            with patch.object(rel, 'validate_endpoint', side_effect=audit):
                outputs = rel.fit_pair_reliable(case('ER', True), case('RN', True), self.output, profile='demo')
        self.assertEqual(len(self.calls), 2)
        self.assertEqual(outputs['ER']['chi2'], 1.)
        self.assertEqual(outputs['ER']['native_chi2'], .3)
        self.assertEqual(outputs['RN']['chi2'], 2.)
        self.assertTrue(all(value['scientific_checks_passed'] for value in outputs.values()))
        self.assertEqual(outputs['ER']['selected_attempt_index'], 1)
        for args, _ in self.calls:
            for item in args:
                self.assertEqual(len(item['run_seeds']), 5)

    def test_unranked_legacy_endpoint_prevents_unfounded_lowest_claim(self):
        values = [dict(ER=result(.1), RN=result(.2)),
                  dict(ER=result(.3, True), RN=result(.4, True)),
                  dict(ER=result(.3, True), RN=result(.4, True))]
        count = [0]
        def audit(case, result, deadline, **kwargs):
            count[0] += 1
            if count[0] <= 2:
                return dict(passed=False, numerical_checks_passed=None)
            return dict(passed=True, numerical_checks_passed=True,
                comparison_endpoint=dict(chi2=1., residuals=[1., 0.], residual_accuracy='tight', residual_integration={}))
        with patch.object(rel, 'fit_pair', side_effect=self.mock_fit(values, pair=True)):
            with patch.object(rel, 'validate_endpoint', side_effect=audit):
                outputs = rel.fit_pair_reliable(case('ER', True), case('RN', True), self.output, profile='demo')
        self.assertEqual(len(self.calls), 3)
        self.assertEqual(outputs['ER']['chi2'], 1.)
        self.assertFalse(outputs['ER']['scientific_checks_passed'])
        self.assertTrue(outputs['ER']['reliability_attempts'][0]['models']['ER']['native_endpoint_unranked'])

    def test_policy_validation_rejects_malformed_and_unbounded_inputs(self):
        bad = [False, [], {'extra':1}, {'max_attempts':True}, {'max_attempts':0},
               {'max_attempts':33}, {'budget_multiplier':True}, {'budget_multiplier':.5},
               {'budget_multiplier':float('nan')}, {'budget_multiplier':float('inf')},
               {'budget_multiplier':'2'}, {'budget_multiplier':1e300}]
        for policy in bad:
            with self.subTest(policy=policy), self.assertRaises(ValueError):
                rel.validate_policy(policy)
        self.assertEqual(rel.validate_policy(), rel.DEFAULT_POLICY)

    def test_budget_scale_preserves_all_nonbudget_scientific_fields(self):
        original = _config(case(), 1, 'demo')
        scaled = _config(case(), 1, 'demo', 4)
        self.assertEqual(original['wall_seconds_per_arm'], 300)
        self.assertEqual(scaled['wall_seconds_per_arm'], 1200)
        self.assertEqual(scaled['de']['maxiter'], 8)
        self.assertEqual(scaled['de']['max_forward_calls'], 144)
        self.assertEqual(scaled['max_nfev_per_solve'], 32)
        self.assertEqual(scaled['de']['popsize'], original['de']['popsize'])
        for key in ('ftol', 'xtol', 'gtol', 'crossfit_review', 'candidate_selection', 'third_integration'):
            self.assertEqual(scaled[key], original[key])
        frozen = dict(global_config=dict(maxiter=0, runs=2, popsize=2, tol=1e-7),
            local_config=dict(max_nfev=3, xtol=1e-12),
            adaptive=dict(fresh_maxiter=0, fresh_runs=0, cross_max_nfev=3, max_route_seeds=0))
        scaled_legacy = scale_budget_limits(deepcopy(frozen), 4)
        self.assertEqual(scaled_legacy['global_config']['maxiter'], 3)
        self.assertEqual(scaled_legacy['local_config']['max_nfev'], 12)
        self.assertEqual(scaled_legacy['adaptive']['cross_max_nfev'], 12)
        self.assertEqual(scaled_legacy['adaptive']['fresh_runs'], 0)
        self.assertEqual(scale_budget_limits(deepcopy(frozen), 1), frozen)
        for bad in (False, .5, float('inf'), '2'):
            with self.assertRaises(ValueError):
                scale_budget_limits(deepcopy(frozen), bad)
            with self.assertRaises(ValueError):
                _config(case(), 1, 'demo', bad)

    def test_all_original_legacy_templates_construct_at_every_budget_factor(self):
        # Isolated imports preserve the two frozen workflow namespaces; this
        # constructs all 24 profiles but performs no forward/optimizer call.
        worker = Path(rel.__file__).with_name('_legacy_worker.py')
        code = """
import importlib.util, json, sys
s=importlib.util.spec_from_file_location('worker', sys.argv[1]); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)
variant=sys.argv[2]; m.bootstrap(variant)
rows=[]
for noise in ('noiseless','noisy'):
 for mode in ('paper','demo'):
  for factor in (1,2,4):
   document=json.loads((m.VENDOR/'configs'/(variant+'_'+noise+'.json')).read_text())['profile']
   cases={name:dict(times=document['times'],residual_sigma=.01,bounds=document['parameter_bounds'],fit_theory_options={}) for name in ('ER','RN')}
   profile,_=m.build_profile(dict(template=variant+'_'+noise,profile=mode,cases=cases,budget_factor=factor))
   assert profile.integration_recovery_config.local_max_nfev <= 750
   assert profile.global_config.runs == (2 if mode == 'demo' else 5)
   assert profile.global_config.maxiter == (factor-1 if mode == 'demo' else 50*factor)
   rows.append([noise,mode,factor])
print(json.dumps(rows))
"""
        for variant in ('baseline', 'extreme'):
            completed = subprocess.run([sys.executable, '-E', '-B', '-c', code, str(worker), variant],
                capture_output=True, text=True, timeout=30)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertEqual(len(json.loads(completed.stdout)), 12)


if __name__ == '__main__':
    unittest.main()
