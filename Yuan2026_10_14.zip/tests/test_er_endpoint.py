"""Exact ER boundary regressions; isolated runtimes, no fitting or long orbits."""
import json
from pathlib import Path
import subprocess
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]


def probe(variant):
    import numpy as np
    from types import SimpleNamespace

    runtime = ROOT / 'vendor' / variant
    sys.path.insert(0, str(runtime))
    from spherical_geodesics.metrics import EREinsteinMetric, er_entangled_metric, ReissnerNordstromMetric
    from spherical_geodesics.frames import er_theory_described_in_entangled_frame
    from spherical_geodesics.plotting import normalization_scale, radial_values
    from spherical_geodesics.prescriptions import RadiusSpecification
    from spherical_geodesics.experiment import RadiusSpec, _normalized_horizon

    check = unittest.TestCase()
    qh = np.sqrt(13.0 / 12.0)
    masses = (1.e-6, .1, .9, 1., 1.1, 10., 1.e6)
    endpoint_count = 0
    for mass in masses:
        for sign in (-1., 1.):
            endpoint = mass * qh
            metric = EREinsteinMetric(mass, sign * endpoint)
            rh = (13.0 / 12.0) * mass
            check.assertTrue(metric.is_exact_black_hole_endpoint)
            check.assertEqual(metric.r_plus, rh)
            check.assertEqual(metric.r_minus, rh)
            check.assertFalse(metric.is_valid_radius(rh))
            check.assertTrue(metric.is_valid_radius(np.nextafter(rh, np.inf)))
            theory = er_theory_described_in_entangled_frame(mass, sign * endpoint)
            with np.errstate(all='raise'):
                outside = np.array([2. * rh, 10. * rh])
                u = 1. - rh / outside
                np.testing.assert_array_equal(metric.A(outside), u * u**(11. / 13.))
                np.testing.assert_array_equal(metric.C(outside), outside**2 * u**(2. / 13.))
                for frame in theory.frame_names():
                    framed = theory.metric(frame)
                    check.assertEqual(float(framed.C(rh)), 0.)
                    check.assertEqual(float(framed.areal_radius(rh)), 0.)
                    radii = np.array([rh, 2 * rh])
                    rho = framed.areal_radius(radii)
                    check.assertEqual(rho[0], 0.)
                    check.assertGreater(rho[1], 0.)
                    check.assertTrue(np.all(np.isfinite(rho)))
                    check.assertEqual(normalization_scale(framed, 'r', 'horizon'), rh)
                    check.assertEqual(_normalized_horizon(framed, 'rho', 'none'), 0.)
                    with check.assertRaisesRegex(ValueError, 'finite.*positive'):
                        normalization_scale(framed, 'rho', 'horizon')
                    with check.assertRaises(ValueError):
                        RadiusSpecification(2., 'rho', 'horizon').radius(framed)
                    with check.assertRaises(ValueError):
                        RadiusSpec(2., 'rho', frame=frame, scale='horizon').resolve_r(theory)
                    with check.assertRaises(ValueError):
                        _normalized_horizon(framed, 'rho', 'horizon')
                    sample = SimpleNamespace(r=np.array([2 * rh]), rho=lambda m: m.areal_radius(np.array([2 * rh])))
                    with check.assertRaises(ValueError):
                        radial_values(sample, framed, coordinate='rho', normalization='horizon')
            # An adjacent inward Q is not the endpoint; an outward Q is rejected.
            inward = EREinsteinMetric(mass, sign * np.nextafter(endpoint, 0.))
            check.assertFalse(inward.is_exact_black_hole_endpoint)
            check.assertGreater(inward.r_plus, inward.r_minus)
            check.assertGreater(float(inward.areal_radius(inward.outer_horizon)), 0.)
            with check.assertRaises(ValueError):
                EREinsteinMetric(mass, sign * np.nextafter(endpoint, np.inf))
            endpoint_count += 1

    # Preserve the old arithmetic at every ordinary and genuinely near endpoint input.
    regression_count = 0
    for mass in masses:
        for ratio in (0., .1, .5, 1., qh * (1 - 1.e-10), np.nextafter(qh, 0.)):
            charge = mass * ratio
            if charge == mass * qh:
                continue  # The multiplication itself can round to the declared endpoint.
            metric = EREinsteinMetric(mass, charge)
            root = np.sqrt(mass**2 - (11.0 / 12.0) * charge**2)
            rp, rm = mass + root, (13.0 / 11.0) * (mass - root)
            check.assertEqual(metric.r_plus, rp)
            check.assertEqual(metric.r_minus, rm)
            radii = mass * np.array([2.5, 10., 1000.])
            u = 1. - rm / radii
            old_a = (1. - rp / radii) * u**(11.0 / 13.0)
            old_c = radii**2 * u**(2.0 / 13.0)
            np.testing.assert_array_equal(metric.A(radii), old_a)
            np.testing.assert_array_equal(metric.B(radii), 1. / old_a)
            np.testing.assert_array_equal(metric.C(radii), old_c)
            # The conformal correction acts only at the exact boundary.
            entangled = er_entangled_metric(metric)
            theory = er_theory_described_in_entangled_frame(mass, charge)
            old_geo_c = u**(-4.0 / 13.0) * entangled.C(radii)
            np.testing.assert_array_equal(theory.geodesic_metric.C(radii), old_geo_c)
            regression_count += 1

    # RN's finite extremal area must not be treated as the ER zero-area endpoint.
    rn = ReissnerNordstromMetric(1., 1.)
    check.assertEqual(normalization_scale(rn, 'rho', 'horizon'), 1.)

    if variant != 'legacy/baseline':
        from spherical_geodesics.er_exterior import ERExteriorMetric, build_er_exterior
        for mass in masses:
            endpoint = mass * qh
            theory = build_er_exterior(mass=mass, charge=endpoint)
            with np.errstate(all='raise'):
                check.assertEqual(float(theory.geodesic_metric.areal_radius(theory.geodesic_metric.outer_horizon)), 0.)
            above = ERExteriorMetric(mass, np.nextafter(endpoint, np.inf))
            check.assertFalse(above.is_exact_black_hole_endpoint)
            check.assertFalse(above.is_black_hole_branch)
            check.assertIsNone(above.outer_horizon)
            with check.assertRaises(ValueError):
                normalization_scale(above, 'rho', 'horizon')
            real_limit = mass * np.sqrt(12. / 11.)
            with check.assertRaises(ValueError):
                ERExteriorMetric(mass, np.nextafter(real_limit, np.inf))

    return dict(runtime=variant, signed_scaled_endpoints=endpoint_count,
                nonendpoint_regressions=regression_count, fits_started=0)


class EREndpointTests(unittest.TestCase):
    def test_all_three_runtimes_in_isolated_interpreters(self):
        for variant in ('core', 'legacy/baseline', 'legacy/extreme'):
            with self.subTest(runtime=variant):
                completed = subprocess.run([sys.executable, '-E', '-B', str(Path(__file__).resolve()), '--probe', variant],
                    capture_output=True, text=True, timeout=30)
                self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
                report = json.loads(completed.stdout)
                self.assertEqual(report['signed_scaled_endpoints'], 14)
                self.assertGreaterEqual(report['nonendpoint_regressions'], 35)
                self.assertEqual(report['fits_started'], 0)

    def test_independent_geometry_builders_have_zero_exact_endpoint(self):
        import numpy as np
        from plotting import _geometry_core as geometry
        qh = np.sqrt(13. / 12.)
        for q in (qh, -qh):
            curve = geometry.Geometry('ER', q)
            photon = geometry.Metric('ER', q)
            self.assertEqual(float(curve.rho(curve.a)), 0.)
            self.assertEqual(float(photon.rho(photon.rp)), 0.)
        qs = np.array([.1, 1., np.nextafter(qh, 0.), qh])
        rp, rm = geometry.parameters(qs)
        radii = geometry.areal(rp, rm)
        self.assertEqual(radii[-1], 0.)
        self.assertTrue(np.all(radii[:-1] > 0.))
        disc = np.sqrt(1. - 11. * qs[:-1]**2 / 12.)
        np.testing.assert_array_equal(rp[:-1], 1. + disc)
        np.testing.assert_array_equal(rm[:-1], (13. / 11.) * (1. - disc))


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--probe':
        print(json.dumps(probe(sys.argv[2])))
    else:
        unittest.main()
