"""Fast public plotting-contract checks; full replay is a separate smoke test."""
from pathlib import Path
import json
import hashlib
import tempfile
import unittest
import numpy as np

from plotting.paper import DEFAULT_DATA, FIGURES, render_all


class PaperDataTests(unittest.TestCase):
    def test_archived_numeric_input_fingerprints(self):
        manifest=json.loads((DEFAULT_DATA/'figures.json').read_text(encoding='utf-8'))
        for name, record in manifest['numerical_files'].items():
            self.assertEqual(hashlib.sha256((DEFAULT_DATA/name).read_bytes()).hexdigest(), record['sha256'])

    def test_all_thirteen_inputs_exist_without_pickle(self):
        self.assertEqual(list(FIGURES), list(range(1, 14)))
        for filename in {record[1] for record in FIGURES.values()}:
            path = DEFAULT_DATA/filename
            self.assertTrue(path.is_file())
            if path.suffix == '.npz':
                with np.load(path, allow_pickle=False) as data:
                    for value in data.values():
                        self.assertNotEqual(value.dtype.kind, 'O')

    def test_paper_sample_counts_and_finite_results(self):
        with np.load(DEFAULT_DATA/'fits.npz', allow_pickle=False) as d:
            self.assertEqual(d['noiseless_chi2'].shape, (80, 2))
            self.assertEqual(d['noisy_chi2'].shape, (6400, 2))
            self.assertEqual(d['noisy_error'].shape, (6400, 2, 6))
            self.assertTrue(np.isfinite(d['noisy_error']).all())
            np.testing.assert_allclose(d['noiseless_chi2'], (d['noiseless_D']/1e-4)**2, rtol=1e-12)
        with np.load(DEFAULT_DATA/'extreme.npz', allow_pickle=False) as d:
            self.assertEqual(d['noiseless_chi2'].shape, (16, 2))
            self.assertEqual(d['noisy_chi2'].shape, (1280, 2))
        rows=json.loads((DEFAULT_DATA/'s301.json').read_text(encoding='utf-8'))['rows']
        self.assertEqual(len(rows), 48)
        self.assertEqual(len({(r['orbit'],r['charge_index'],r['realization']) for r in rows}), 48)
        self.assertTrue(any(r['delta_chi2'] < 0 for r in rows))
        for row in rows:
            self.assertEqual(row['delta_chi2'], row['chi2_RN']-row['chi2_ER'])

    def test_alternate_cache_never_falls_back_to_paper(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            with self.assertRaises(FileNotFoundError):
                render_all(root/'out', [13], data_dir=root/'missing')
            self.assertFalse((root/'out').exists())

    def test_small_render(self):
        with tempfile.TemporaryDirectory() as folder:
            output=render_all(folder, [13], dpi=72)
            self.assertEqual(len(output), 1)
            self.assertGreater(output[0].stat().st_size, 1000)
            self.assertTrue(output[0].with_suffix('.png').is_file())


if __name__ == '__main__':
    unittest.main()
