"""Independent collection/launcher regressions; no fitting or real plotting."""
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import main
import postprocess
from run_state import digest, load_task, write_json


SCIENCE = 'a' * 64
PIPELINE = dict(fit_pipeline='s301', fit_pipeline_requested='s301', fit_pipeline_version='s301-portable-v1')
PIPELINE_PLAN = dict(fit_pipeline_requested='s301', fit_pipelines={
    'baseline':dict(fit_pipeline='s301', fit_pipeline_version='s301-portable-v1')})


def save(path, document):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document, sort_keys=True, indent=2) + '\n', encoding='utf-8')


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def fixture_run(root, name='run_a', case_id='case_a_ER', *, signature_mode='recompute',
                science=SCIENCE, complete=True, reliability_policy=None):
    directory = root/name
    directory.mkdir()
    signature = {'mode':signature_mode,'science_sha256':science, **PIPELINE_PLAN}
    if reliability_policy is not None:
        signature['reliability_policy'] = dict(reliability_policy)
    save(directory/'run.json', {'signature':signature,'task_count':1,'state':'FINISHED'})
    case = {'case_id':case_id,'fit_theory':'ER','execution_mode':'paper','times':[0.,1.], **PIPELINE,
            'xy_true':[[30.,0.],[30.,.1]],'residual_sigma':1.,
            'metadata':{'suite':'baseline','dataset_id':case_id,'add_noise':False}}
    result = {'case_id':case_id,'fit_theory':'ER','profile':'paper','result_is_demo':False, **PIPELINE,
              'run_complete':complete,'status':'COMPLETED' if complete else 'INCOMPLETE_OR_BUDGET_LIMIT',
              'theta':[1.,.1,30.,0.,.2,.004],'chi2':1.,
              'best_candidate_checks_passed':True,'scientific_checks_passed':complete}
    if reliability_policy is not None:
        case['reliability_policy'] = dict(reliability_policy)
        result['reliability'] = {'policy': dict(reliability_policy)}
    receipt = {'case_id':case_id,'case_sha256':main._digest(case),'profile':'paper', **PIPELINE,
               'state':'FINISHED' if complete else 'INCOMPLETE',
               'engine_status':result['status'],'scientific_checks_passed':complete}
    task = directory/'tasks'/case_id
    for filename, document in [('case.json',case),('result.json',result),('task_receipt.json',receipt)]:
        save(task/filename,document)
    return directory,task


class CollectionTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.hash_patch = patch('main._scientific_source_hash', return_value=SCIENCE)
        self.hash_patch.start()
        self.render_patch = patch('postprocess.render_run', return_value=[])
        self.render = self.render_patch.start()

    def tearDown(self):
        self.render_patch.stop()
        self.hash_patch.stop()
        self.temporary.cleanup()

    def collect(self, inputs, name='collected'):
        destination = self.root/name
        destination.mkdir()
        files = postprocess.collect_runs(inputs,destination)
        return destination,files

    def assert_rejected_without_copies(self, inputs, name='rejected'):
        destination = self.root/name
        destination.mkdir()
        with self.assertRaises((ValueError,FileNotFoundError,KeyError)):
            postprocess.collect_runs(inputs,destination)
        self.assertEqual(list(destination.iterdir()),[],'Validation must precede task copies')

    def test_explicit_new_runs_merge_without_fitting(self):
        a,ta=fixture_run(self.root)
        b,tb=fixture_run(self.root,'run_b','case_b_ER')
        before={p:p.read_bytes() for t in (ta,tb) for p in t.iterdir()}
        destination,files=self.collect([a,b])
        self.assertEqual(files,[])
        self.assertEqual(load(destination/'run.json')['model_tasks'],2)
        self.assertEqual(load(destination/'run.json')['fit_calls'],0)
        self.assertFalse(load(destination/'run.json')['original_paper_snapshot_used'])
        self.assertEqual({p.name for p in (destination/'tasks').iterdir()},{'case_a_ER','case_b_ER'})
        self.assertTrue(all(p.read_bytes()==raw for p,raw in before.items()))
        self.render.assert_called_once_with(destination,mode='recompute')

    def test_identical_duplicate_is_deduplicated(self):
        a,_=fixture_run(self.root)
        b=self.root/'run_b'
        shutil.copytree(a,b)
        destination,_=self.collect([a,b,a])
        self.assertEqual(load(destination/'run.json')['model_tasks'],1)
        self.assertEqual(len(list((destination/'tasks').iterdir())),1)

    def test_conflicting_duplicate_is_not_best_chi2_selected(self):
        a,_=fixture_run(self.root)
        b,tb=fixture_run(self.root,'run_b')
        result=load(tb/'result.json');result['chi2']=.1
        save(tb/'result.json',result)
        self.assert_rejected_without_copies([a,b])

    def test_different_science_fingerprint_rejected(self):
        a,_=fixture_run(self.root)
        b,_=fixture_run(self.root,'run_b','case_b_ER',science='b'*64)
        self.assert_rejected_without_copies([a,b])

    def test_matching_reliability_policy_is_preserved_in_collection(self):
        policy = dict(max_attempts=3, budget_multiplier=2.0)
        a,_=fixture_run(self.root, reliability_policy=policy)
        b,_=fixture_run(self.root, 'run_b', 'case_b_ER', reliability_policy=policy)
        destination,_=self.collect([a,b])
        plan=load(destination/'run.json')
        self.assertEqual(plan['reliability_policy'], policy)
        self.assertTrue(plan['reliability_policy_declared'])

    def test_different_reliability_limits_rejected_before_copying(self):
        policy = dict(max_attempts=3, budget_multiplier=2.0)
        a,_=fixture_run(self.root, reliability_policy=policy)
        for index, other in enumerate((dict(max_attempts=2, budget_multiplier=2.0),
                                       dict(max_attempts=3, budget_multiplier=3.0))):
            with self.subTest(policy=other):
                b,_=fixture_run(self.root, f'run_{index}', f'case_{index}_ER', reliability_policy=other)
                self.assert_rejected_without_copies([a,b], f'rejected_{index}')

    def test_undeclared_policy_is_not_assumed_to_be_the_new_default(self):
        a,_=fixture_run(self.root)
        b,_=fixture_run(self.root, 'run_b', 'case_b_ER',
                       reliability_policy=dict(max_attempts=3, budget_multiplier=2.0))
        self.assert_rejected_without_copies([a,b])

    def test_task_policy_must_match_plan_even_with_updated_input_fingerprint(self):
        a,task=fixture_run(self.root, reliability_policy=dict(max_attempts=3, budget_multiplier=2.0))
        case=load(task/'case.json')
        case['reliability_policy']['max_attempts']=2
        receipt=load(task/'task_receipt.json')
        receipt['case_sha256']=digest(case)
        save(task/'case.json',case)
        save(task/'task_receipt.json',receipt)
        self.assert_rejected_without_copies([a])

    def test_result_policy_must_match_saved_input_and_plan(self):
        a,task=fixture_run(self.root, reliability_policy=dict(max_attempts=3, budget_multiplier=2.0))
        result=load(task/'result.json')
        result['reliability']['policy']['budget_multiplier']=3.0
        save(task/'result.json',result)
        self.assert_rejected_without_copies([a])

    def test_incomplete_or_invalid_declared_policy_is_rejected(self):
        for index, policy in enumerate((dict(max_attempts=3),
                                        dict(max_attempts=True, budget_multiplier=2.0),
                                        dict(max_attempts=3, budget_multiplier=0.5))):
            with self.subTest(policy=policy):
                a,_=fixture_run(self.root, f'run_{index}', f'case_{index}_ER', reliability_policy=policy)
                self.assert_rejected_without_copies([a], f'rejected_{index}')

    def test_same_but_stale_science_fingerprint_rejected(self):
        a,_=fixture_run(self.root,science='b'*64)
        self.assert_rejected_without_copies([a])

    def test_demo_plan_rejected(self):
        a,_=fixture_run(self.root,signature_mode='demo')
        self.assert_rejected_without_copies([a])

    def test_demo_receipt_rejected(self):
        a,task=fixture_run(self.root)
        receipt=load(task/'task_receipt.json');receipt['profile']='demo'
        save(task/'task_receipt.json',receipt)
        self.assert_rejected_without_copies([a])

    def test_demo_result_profile_rejected_despite_paper_receipt(self):
        a,task=fixture_run(self.root)
        result=load(task/'result.json');result['profile']='demo'
        save(task/'result.json',result)
        self.assertEqual(load(task/'task_receipt.json')['profile'],'paper')
        self.assert_rejected_without_copies([a])

    def test_demo_result_flag_rejected_despite_paper_profile(self):
        a,task=fixture_run(self.root)
        result=load(task/'result.json');result['result_is_demo']=True
        save(task/'result.json',result)
        self.assertEqual(result['profile'],'paper')
        self.assert_rejected_without_copies([a])

    def test_case_fingerprint_mismatch_rejected(self):
        a,task=fixture_run(self.root)
        case=load(task/'case.json');case['xy_true'][0][0]+=1.
        save(task/'case.json',case)
        self.assert_rejected_without_copies([a])

    def test_receipt_identity_mismatch_rejected(self):
        a,task=fixture_run(self.root)
        receipt=load(task/'task_receipt.json');receipt['case_id']='other_case'
        save(task/'task_receipt.json',receipt)
        self.assert_rejected_without_copies([a])

    def test_result_identity_mismatch_rejected(self):
        a,task=fixture_run(self.root)
        result=load(task/'result.json');result['fit_theory']='RN'
        save(task/'result.json',result)
        self.assert_rejected_without_copies([a])

    def test_receipt_state_matches_run_completion(self):
        for i,(complete,state) in enumerate(((True,'INCOMPLETE'),(False,'FINISHED'),(False,'RUNNING'))):
            with self.subTest(complete=complete,state=state):
                a,task=fixture_run(self.root,f'run_{i}',f'case_{i}',complete=complete)
                receipt=load(task/'task_receipt.json');receipt['state']=state
                save(task/'task_receipt.json',receipt)
                self.assert_rejected_without_copies([a],f'rejected_{i}')

    def test_incomplete_results_retained_without_relabelling(self):
        a,_=fixture_run(self.root,complete=False)
        destination,_=self.collect([a])
        receipt=load(destination/'tasks/case_a_ER/task_receipt.json')
        result=load(destination/'tasks/case_a_ER/result.json')
        self.assertEqual(receipt['state'],'INCOMPLETE')
        self.assertFalse(result['run_complete'])

    def test_any_missing_task_record_rejected(self):
        for i,name in enumerate(('case.json','result.json','task_receipt.json')):
            with self.subTest(missing=name):
                a,task=fixture_run(self.root,f'run_{i}',f'case_{i}')
                (task/name).unlink()
                self.assert_rejected_without_copies([a],f'rejected_{i}')

    def test_empty_inputs_rejected(self):
        self.assert_rejected_without_copies([])

    def test_nonempty_destination_rejected(self):
        a,_=fixture_run(self.root)
        destination=self.root/'occupied';destination.mkdir()
        save(destination/'keep.json',{'untouched':True})
        with self.assertRaises(ValueError):
            postprocess.collect_runs([a],destination)
        self.assertEqual(load(destination/'keep.json'),{'untouched':True})

    def test_main_collect_routes_explicit_inputs(self):
        a,_=fixture_run(self.root)
        destination=self.root/'main_collection'
        with redirect_stdout(io.StringIO()):
            code=main.run(['--collect',str(a),'--output',str(destination)])
        self.assertEqual(code,0)
        self.assertEqual(load(destination/'run.json')['model_tasks'],1)
        self.render.assert_called_once_with(destination,mode='recompute')

    def test_main_collect_dry_run_performs_no_writes(self):
        destination=self.root/'not_created'
        with redirect_stdout(io.StringIO()):
            code=main.run(['--collect',str(self.root/'not_read'),'--output',str(destination),'--dry-run'])
        self.assertEqual(code,0)
        self.assertFalse(destination.exists())
        self.render.assert_not_called()

    def test_demo_iteration_limit_is_normal_exit_not_convergence(self):
        destination=self.root/'demo_run'
        case={'case_id':'small_demo_ER'}
        outcome={'case_id':case['case_id'],'state':'INCOMPLETE',
                 'engine_status':'INCOMPLETE_OR_BUDGET_LIMIT','scientific_checks_passed':False}
        with patch('main._select_cases',side_effect=lambda options: iter([case])), \
             patch('main._run_task',return_value=outcome) as fit, \
             patch('main._resource_layout',return_value=1), redirect_stdout(io.StringIO()):
            code=main.run(['--mode','demo','--suite','baseline','--fit-pipeline','s301','--max-tasks','1',
                           '--output',str(destination)])
        self.assertEqual(code,0)
        fit.assert_called_once()
        self.assertEqual(fit.call_args.args[-1],'demo')
        plan=load(destination/'run.json')
        self.assertEqual(plan['state'],'DEMO_FINISHED_WITH_ITERATION_LIMITS')
        self.assertEqual(plan['failed_tasks'],1)
        progress=load(destination/'progress.json')
        self.assertFalse(progress['tasks'][0]['scientific_checks_passed'])
        self.render.assert_called_once_with(destination,mode='demo')


class TaskRecordTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.run, self.task = fixture_run(self.root)

    def tearDown(self):
        self.temporary.cleanup()

    def snapshot(self):
        return {str(p.relative_to(self.root)):p.read_bytes()
                for p in self.root.rglob('*') if p.is_file()}

    def change(self, filename, key, value):
        record=load(self.task/filename)
        record[key]=value
        save(self.task/filename,record)

    def test_complete_task_matches_expected_input_without_writing(self):
        before=self.snapshot()
        expected=load(self.task/'case.json')
        case,result,receipt=load_task(self.task,expected_case=expected,
                                      profile='paper',require_complete=True)
        self.assertEqual(case,expected)
        self.assertTrue(result['run_complete'])
        self.assertEqual(receipt['state'],'FINISHED')
        self.assertEqual(self.snapshot(),before)

    def test_changed_expected_input_is_rejected_read_only(self):
        expected=load(self.task/'case.json')
        expected['residual_sigma']=2.
        before=self.snapshot()
        with self.assertRaises(ValueError):
            load_task(self.task,expected_case=expected)
        self.assertEqual(self.snapshot(),before)

    def test_corrupted_receipt_is_rejected_read_only(self):
        self.change('task_receipt.json','case_sha256','incorrect')
        before=self.snapshot()
        with self.assertRaises(ValueError):
            load_task(self.task)
        self.assertEqual(self.snapshot(),before)
        with self.assertRaises(ValueError):
            postprocess._load(self.run)
        self.assertEqual(self.snapshot(),before)

    def test_missing_receipt_is_not_repaired(self):
        (self.task/'task_receipt.json').unlink()
        before=self.snapshot()
        with self.assertRaises(FileNotFoundError):
            postprocess._load(self.run)
        self.assertEqual(self.snapshot(),before)

    def test_directory_name_must_match_identity(self):
        wrong=self.task.with_name('different_case_ER')
        self.task.rename(wrong)
        before=self.snapshot()
        with self.assertRaises(ValueError):
            load_task(wrong)
        self.assertEqual(self.snapshot(),before)

    def test_incomplete_task_cannot_be_reused_as_complete(self):
        self.change('result.json','run_complete',False)
        self.change('task_receipt.json','state','INCOMPLETE')
        before=self.snapshot()
        self.assertFalse(load_task(self.task)[1]['run_complete'])
        with self.assertRaises(ValueError):
            load_task(self.task,require_complete=True)
        self.assertEqual(self.snapshot(),before)

    def test_completion_must_be_a_boolean(self):
        for bad_value in (1,'true',None):
            with self.subTest(value=bad_value):
                self.change('result.json','run_complete',bad_value)
                with self.assertRaises(ValueError):
                    load_task(self.task)

    def test_engine_status_must_agree_with_receipt(self):
        self.change('task_receipt.json','engine_status','INCOMPLETE_OR_BUDGET_LIMIT')
        with self.assertRaises(ValueError):
            load_task(self.task)

    def test_demo_endpoint_is_available_but_never_paper_eligible(self):
        self.change('case.json','execution_mode','demo')
        self.change('result.json','profile','demo')
        self.change('result.json','result_is_demo',True)
        self.change('task_receipt.json','profile','demo')
        self.change('task_receipt.json','case_sha256',digest(load(self.task/'case.json')))
        before=self.snapshot()
        self.assertTrue(load_task(self.task,profile='demo')[1]['run_complete'])
        with self.assertRaises(ValueError):
            load_task(self.task,profile='paper')
        rows=postprocess._load(self.run)
        self.assertTrue(rows[0]['available'])
        self.assertFalse(rows[0]['eligible'])
        self.assertEqual(postprocess._paired(rows,'baseline'),[])
        self.assertEqual(self.snapshot(),before)

    def test_missing_input_mode_is_not_paper_eligible(self):
        case=load(self.task/'case.json')
        del case['execution_mode']
        save(self.task/'case.json',case)
        self.change('task_receipt.json','case_sha256',digest(case))
        rows=postprocess._load(self.run)
        self.assertTrue(rows[0]['available'])
        self.assertFalse(rows[0]['eligible'])

    def test_input_mode_cannot_disagree_with_result_profile(self):
        self.change('case.json','execution_mode','demo')
        self.change('task_receipt.json','case_sha256',digest(load(self.task/'case.json')))
        with self.assertRaises(ValueError):
            load_task(self.task)

    def test_atomic_json_and_digest_match_original_contract(self):
        target=self.root/'nested'/'record.json'
        record={'path':Path('folder/file'),'text':'中文','sequence':[1,2.]}
        expected=main._digest(record)
        write_json(target,record)
        self.assertEqual(digest(record),expected)
        self.assertEqual(load(target),{'path':'folder/file','text':'中文','sequence':[1,2.]})
        self.assertFalse(target.with_suffix('.json.tmp').exists())


if __name__=='__main__':
    unittest.main()
