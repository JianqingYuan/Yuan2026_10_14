"""Outer-controller tests: no optimization or platform access."""
import unittest
from copy import deepcopy
from unittest.mock import patch

from engine import reliability
from engine.reliability import _native_acceptance
import test_reliability as fixtures


class TargetedAcceptanceTests(unittest.TestCase):
    def test_old_contract_preserved(self):
        self.assertTrue(_native_acceptance({'scientific_checks_passed': True, 'run_complete': True}))
        self.assertFalse(_native_acceptance({'scientific_checks_passed': False}))

    def test_incomplete_cannot_pass_by_success_flag(self):
        for complete in (False, None, 'true', 1):
            self.assertFalse(_native_acceptance(dict(scientific_checks_passed=True, run_complete=complete)))

    def test_explicit_lower_failure_overrides_success(self):
        self.assertFalse(_native_acceptance(dict(scientific_checks_passed=True,
                                                lower_failed_candidate_veto=True)))

    def test_actual_candidate_must_be_disposed(self):
        self.assertFalse(_native_acceptance(dict(scientific_checks_passed=True,
            unresolved_lower_actual_candidates=[{'id': 'lower', 'chi2': .5}])))
        self.assertTrue(_native_acceptance(dict(scientific_checks_passed=True,
            run_complete=True, unresolved_lower_actual_candidates=[], lower_failed_candidate_veto=False)))

    def test_malformed_veto_never_grants_acceptance(self):
        for value in (None, 'false', 0, [], {}):
            self.assertFalse(_native_acceptance(dict(scientific_checks_passed=True,
                                                    lower_failed_candidate_veto=value)))
        for value in (None, False, 0, '', {}):
            self.assertFalse(_native_acceptance(dict(scientific_checks_passed=True,
                                                    unresolved_lower_actual_candidates=value)))

    def test_outer_controller_does_not_launder_veto(self):
        for extra in ({'lower_failed_candidate_veto': True},
                      {'unresolved_lower_actual_candidates': [{'id': 'lower'}]}):
            fixture = fixtures.ReliabilityTests()
            fixture.setUp()
            try:
                native = dict(fixtures.result(1., passed=True), **extra)
                output, _ = fixture.execute([native], policy={'max_attempts': 1})
                self.assertFalse(output['scientific_checks_passed'])
                self.assertEqual(output['status'], 'NEEDS_REVIEW_BEST_FOUND')
                self.assertEqual(output['chi2'], 1.)
                receipt = output['reliability_attempts'][0]['models']['ER']
                self.assertFalse(receipt['native_acceptance_without_candidate_veto'])
            finally:
                fixture.doCleanups()

    def test_pair_certificate_cannot_override_one_model_veto(self):
        fixture = fixtures.ReliabilityTests()
        fixture.setUp()
        try:
            native = {'ER': fixtures.result(1., passed=True),
                      'RN': fixtures.result(2., passed=True)}
            native['ER']['lower_failed_candidate_veto'] = True
            def validate(case, result, deadline, **kwargs):
                return dict(passed=True, numerical_checks_passed=True,
                    comparison_endpoint=dict(chi2=result['chi2'], residuals=result['residuals'],
                                             residual_accuracy='tight', residual_integration={}))
            with patch.object(reliability, 'fit_pair', side_effect=fixture.mock_fit([native], pair=True)), \
                 patch.object(reliability, 'validate_endpoint', side_effect=validate):
                outputs = reliability.fit_pair_reliable(fixtures.case('ER', True),
                    fixtures.case('RN', True), fixture.output, profile='demo',
                    policy={'max_attempts': 1})
            self.assertFalse(outputs['ER']['scientific_checks_passed'])
            self.assertTrue(outputs['RN']['scientific_checks_passed'])
        finally:
            fixture.doCleanups()

    def test_unresolved_other_precision_cannot_be_laundered_by_next_attempt(self):
        fixture = fixtures.ReliabilityTests()
        fixture.setUp()
        try:
            unresolved = dict(fixtures.result(2.), unresolved_lower_actual_candidates=[
                {'theta': [1., .2, 30., 0., .2, .004], 'accuracy': 'tight', 'chi2': .5}])
            output, _ = fixture.execute([unresolved, fixtures.result(1., True)],
                                         policy={'max_attempts': 2})
            self.assertEqual(output['chi2'], 1.)
            self.assertFalse(output['scientific_checks_passed'])
            self.assertTrue(output['reliability_attempts'][0]['models']['ER']['unresolved_evidence_gap'])
        finally:
            fixture.doCleanups()

    @staticmethod
    def common_diagnostic():
        case = dict(fixtures.case('ER', True), tight_integration={'max_step': .1},
                    xy_observed=[[0., 0.]], bounds=dict(M=[.5, 2.], q=[0., 1.],
                        rho0=[10., 100.], drho_dt0=[-.1, .1], phi0=[0., 6.3], dphi_dt0=[0., .1]))
        extra = dict(theta=fixtures.result()['theta'], chi2=.25, residuals=[.5, 0.],
            objective='legacy_common_tight', residual_accuracy='tight',
            residual_integration=case['tight_integration'], id='actual_lower', checks_passed=False)
        return case, extra

    def test_common_tight_diagnostic_retained_without_certificate(self):
        case, extra = self.common_diagnostic()
        native = dict(fixtures.result(1., True), diagnostic_best=extra)
        diagnostic, gap = reliability._attempt_diagnostic(case, native, native, True, True, 0, 'saved.json')
        self.assertEqual(diagnostic['chi2'], .25)
        self.assertFalse(diagnostic['checks_passed'])
        self.assertTrue(diagnostic['comparable_across_attempts'])
        self.assertFalse(gap)

    def test_common_tight_diagnostic_must_bind_raw_score_and_settings(self):
        for change in ({'residuals': [.1, 0.]}, {'residuals': [float('nan'), 0.]},
                       {'residuals': [.5]}, {'residual_integration': {'max_step': .2}},
                       {'residual_accuracy': 'nominal'}, {'theta': [1., 2.]},
                       {'chi2': float('inf')}, {'theta': [1., 2., 30., 0., .2, .004]}):
            with self.subTest(change=change):
                case, extra = self.common_diagnostic()
                extra.update(change)
                native = dict(fixtures.result(1., True), diagnostic_best=extra)
                diagnostic, gap = reliability._attempt_diagnostic(case, native, native, True, True, 0, 'saved.json')
                self.assertTrue(gap)
                self.assertEqual(diagnostic['chi2'], 1.)

    def test_nominal_diagnostic_not_misranked_as_common_tight(self):
        case, extra = self.common_diagnostic()
        extra.pop('objective')
        native = dict(fixtures.result(1., True), diagnostic_best=extra)
        diagnostic, gap = reliability._attempt_diagnostic(case, native, native, True, True, 0, 'saved.json')
        self.assertEqual(diagnostic['chi2'], 1.)
        self.assertFalse(gap)

    def test_unexplained_veto_is_not_explained_by_selected_score(self):
        case, extra = self.common_diagnostic()
        for supplied in (None, {'chi2': .25}, dict(extra, residual_accuracy='nominal')):
            native = dict(fixtures.result(1., True), lower_failed_candidate_veto=True,
                          diagnostic_best=supplied)
            diagnostic, gap = reliability._attempt_diagnostic(case, native, native, True, True, 0, 'saved.json')
            self.assertTrue(gap)

    def test_proper_lower_common_veto_remains_rankable(self):
        case, extra = self.common_diagnostic()
        native = dict(fixtures.result(1., True), diagnostic_best=extra, lower_failed_candidate_veto=True)
        diagnostic, gap = reliability._attempt_diagnostic(case, native, native, True, True, 0, 'saved.json')
        self.assertFalse(gap)
        self.assertEqual(diagnostic['chi2'], .25)

    def test_pair_new_higher_attempt_cannot_hide_common_lower(self):
        fixture = fixtures.ReliabilityTests()
        fixture.setUp()
        try:
            case, extra = self.common_diagnostic()
            first = {'ER': dict(fixtures.result(1.), diagnostic_best=deepcopy(extra)),
                     'RN': fixtures.result(2.)}
            second = {'ER': fixtures.result(.5, True), 'RN': fixtures.result(1., True)}
            def validate(case, result, deadline, **kwargs):
                return dict(passed=True, numerical_checks_passed=True,
                    comparison_endpoint=dict(chi2=result['chi2'], residuals=result['residuals'],
                        residual_accuracy='tight', residual_integration=case.get('tight_integration', {})))
            with patch.object(reliability, 'fit_pair', side_effect=fixture.mock_fit([first, second], pair=True)), \
                 patch.object(reliability, 'validate_endpoint', side_effect=validate):
                output = reliability.fit_pair_reliable(case, fixtures.case('RN', True),
                    fixture.output, profile='demo', policy={'max_attempts': 2})
            self.assertEqual(output['ER']['chi2'], .5)
            self.assertEqual(output['ER']['diagnostic_best']['chi2'], .25)
            self.assertFalse(output['ER']['scientific_checks_passed'])
        finally:
            fixture.doCleanups()


if __name__ == '__main__':
    unittest.main()
