"""Failure-boundary regressions for the portable worker startup protocol."""
import multiprocessing as mp
import queue
import time
import unittest
from unittest.mock import Mock, patch

from engine.api import _config, _pool, _worker_init
from hybrid_support import Interrupted
from test_engine import short_case


class WorkerStartupTests(unittest.TestCase):
    def setUp(self):
        self.case = short_case()
        self.config = _config(self.case, 2, 'demo')

    def context(self, replies):
        context = Mock()
        context.Queue.return_value.get.side_effect = replies
        return context

    def assert_cleaned(self, context):
        context.Pool.return_value.terminate.assert_called_once_with()
        context.Pool.return_value.join.assert_called_once_with()
        context.Queue.return_value.close.assert_called_once_with()
        context.Queue.return_value.join_thread.assert_called_once_with()

    def test_initializer_reports_error_without_raising_or_respawning(self):
        ready = Mock()
        with patch('engine.api.worker_init', side_effect=TypeError('bad option')), \
                patch('engine.api.signal.signal'):
            _worker_init('unused', self.case, {}, ready)
        message = ready.put.call_args.args[0]
        self.assertIsInstance(message[0], int)
        self.assertEqual(message[1], 'TypeError: bad option')

    def test_error_from_one_worker_terminates_whole_startup(self):
        context = self.context([(101, None), (102, 'TypeError: bad option')])
        with patch('engine.api.mp.get_context', return_value=context):
            with self.assertRaisesRegex(RuntimeError, 'Worker initialization failed'):
                _pool(self.case, self.config, 2)
        self.assert_cleaned(context)

    def test_partial_ready_timeout_cleans_pool(self):
        context = self.context([(101, None)])
        with patch('engine.api.mp.get_context', return_value=context), \
                patch('engine.api.time.monotonic', side_effect=[0., 0., 61.]):
            with self.assertRaisesRegex(RuntimeError, 'startup timed out'):
                _pool(self.case, self.config, 2)
        self.assert_cleaned(context)

    def test_duplicate_pid_is_not_two_ready_workers(self):
        context = self.context([(101, None), (101, None)])
        with patch('engine.api.mp.get_context', return_value=context), \
                patch('engine.api.time.monotonic', side_effect=[0., 0., 0., 61.]):
            with self.assertRaisesRegex(RuntimeError, 'startup timed out'):
                _pool(self.case, self.config, 2)
        self.assert_cleaned(context)

    def test_cancel_during_wait_cleans_unreturned_pool(self):
        context = self.context([queue.Empty()])
        guard = Mock(side_effect=[None, None, None, KeyboardInterrupt()])
        with patch('engine.api.mp.get_context', return_value=context):
            with self.assertRaises(KeyboardInterrupt):
                _pool(self.case, self.config, 2, guard=guard)
        self.assert_cleaned(context)

    def test_deadline_at_last_ready_never_returns_usable_pool(self):
        context = self.context([(101, None)])
        guard = Mock(side_effect=[None, None, None, Interrupted('shared deadline')])
        with patch('engine.api.mp.get_context', return_value=context):
            with self.assertRaises(Interrupted):
                _pool(self.case, self.config, 1, guard=guard)
        self.assert_cleaned(context)

    def test_success_retains_channel_until_workers_joined(self):
        context = self.context([(101, None), (102, None)])
        with patch('engine.api.mp.get_context', return_value=context):
            pool = _pool(self.case, self.config, 2)
        context.Queue.return_value.close.assert_not_called()
        pool.terminate()
        pool.join()
        self.assert_cleaned(context)

    def test_bad_third_settings_fail_before_process_creation(self):
        self.config['third_integration']['not_a_setting'] = 1
        with patch('engine.api.mp.get_context') as context:
            with self.assertRaises(TypeError):
                _pool(self.case, self.config, 2)
        context.assert_not_called()

    def test_real_child_initializer_error_leaves_no_worker(self):
        # Model construction succeeds, but a child-local required field fails.
        # Invoke only startup, never a fit or an orbit integration.
        self.case.pop('times')
        before = {child.pid for child in mp.active_children()}
        started = time.monotonic()
        with self.assertRaisesRegex(RuntimeError, 'Worker initialization failed: KeyError'):
            unexpected = _pool(self.case, self.config, 2)
            unexpected.terminate()
            unexpected.join()
        self.assertLess(time.monotonic() - started, 20.)
        self.assertEqual({child.pid for child in mp.active_children()} - before, set())


if __name__ == '__main__':
    unittest.main()
