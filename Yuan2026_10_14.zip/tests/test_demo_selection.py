"""Panel coverage uses a small subset of paper inputs, never new fit targets."""
import unittest

from experiments.api import _config, count_cases, describe, iter_cases, list_case_ids


class DemoSelectionTests(unittest.TestCase):
    def test_plan_counts_by_suite(self):
        plan = describe(mode='demo')
        expected = {'baseline': (9, 3, 6, 18), 'extreme': (6, 2, 4, 12),
                    's301': (6, 0, 6, 12)}
        for suite, counts in expected.items():
            record = plan['suites'][suite]
            self.assertEqual(tuple(record[key] for key in
                ('datasets', 'noiseless_datasets', 'noisy_datasets', 'model_fits')), counts)
        self.assertFalse(plan['computations_started'])

    def test_baseline_and_extreme_cover_groups_and_noise_endpoints(self):
        for suite, expected_groups in [('baseline', {0.1, 0.5, 1.0}),
                                       ('extreme', {'eq26', 'eq27'})]:
            config = _config(suite)
            group_key = 'q' if suite == 'baseline' else 'charge_tag'
            cases = list(iter_cases(suite, 'demo', models='ER'))
            self.assertEqual({c['metadata'][group_key] for c in cases}, expected_groups)
            for group in expected_groups:
                selected = [c['metadata'] for c in cases if c['metadata'][group_key] == group]
                minimum_peri = min(t['rho_peri'] for t in config['truths']
                                   if t[group_key] == group)
                self.assertEqual({m['rho_peri'] for m in selected}, {minimum_peri})
                self.assertEqual(len({m['truth_index'] for m in selected}), 1)
                self.assertEqual({m['noise_index'] for m in selected}, {None, 0, 9})
                self.assertTrue(all(m['realization'] == 0 for m in selected if m['add_noise']))

    def test_s301_covers_every_orbit_and_charge_with_one_thirty_uas_draw(self):
        cases = list(iter_cases('s301', 'demo', models='ER'))
        self.assertEqual({c['metadata']['truth_index'] for c in cases}, set(range(6)))
        self.assertEqual({c['metadata']['orbit'] for c in cases}, {'A', 'B'})
        for case in cases:
            metadata = case['metadata']
            self.assertTrue(metadata['add_noise'])
            self.assertEqual(metadata['noise_uas'], 30)
            self.assertEqual(metadata['realization'], 0)

    def test_every_selected_input_matches_its_full_catalogue_counterpart(self):
        for pipeline in ('paper', 'legacy', 's301'):
            for suite in ('baseline', 'extreme', 's301'):
                demo = list(iter_cases(suite, 'demo', fit_pipeline=pipeline))
                dataset_ids = {c['metadata']['dataset_id'] for c in demo}
                paper = {c['case_id']: c for c in iter_cases(suite, 'paper',
                         indices=dataset_ids, fit_pipeline=pipeline)}
                for case in demo:
                    full = paper[case['case_id']]
                    # Execution labels are the only differences before the
                    # engine applies its existing, unchanged demo budget.
                    self.assertEqual(case.pop('execution_mode'), 'demo')
                    self.assertEqual(full.pop('execution_mode'), 'paper')
                    self.assertEqual(case['metadata'].pop('mode'), 'demo')
                    self.assertEqual(full['metadata'].pop('mode'), 'paper')
                    self.assertEqual(case, full)

    def test_filters_only_restrict_the_coverage_selection(self):
        self.assertEqual(count_cases(mode='demo', include_noisy=False), 10)
        self.assertEqual(count_cases(mode='demo', include_noiseless=False), 32)
        self.assertEqual(count_cases(mode='demo', models='ER'), 21)
        self.assertEqual(count_cases('s301', 'demo', indices=['T000']), 0)
        self.assertEqual(count_cases('s301', 'demo', indices=['T001']), 2)
        for suite in ('baseline', 'extreme', 's301'):
            self.assertLessEqual(set(list_case_ids(suite, 'demo')),
                                 set(list_case_ids(suite, 'paper')))


if __name__ == '__main__':
    unittest.main()
