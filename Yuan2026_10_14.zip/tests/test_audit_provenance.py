"""Independent audit checks using fixed, synthetic evidence; no fitting."""
from copy import deepcopy
import json
import math
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from engine.fit_validation import _fixed_point_check
from engine.reliability import _comparison_result
from engine import reliability
import postprocess


def point(score):
    return dict(chi2=score, residuals=[math.sqrt(score), 0.],
                settings=dict(relative_tolerance=1e-12, absolute_tolerance=1e-14, max_step=5000.))


def evidence(score, comparison=None):
    return dict(theta=[1., .3, 30., 0., .2, .004],
                levels={key:point(score if key != 'comparison' or comparison is None else comparison)
                        for key in ('nominal', 'tight', 'selected', 'comparison')})


class AuditProvenanceTests(unittest.TestCase):
    def check(self, data, *, historical=True, pipeline='legacy', ceiling=.01):
        case = (dict(precision_criterion=dict(kind='absolute_delta_chi2', tolerance=ceiling))
                if historical else dict(precision_vector_ceiling=ceiling))
        selected = data['fitted']['levels']['selected']
        saved = dict(chi2=selected['chi2'], residuals=selected['residuals'],
                     theta=data['fitted']['theta'], best_candidate_checks_passed=True)
        checked = _fixed_point_check(case, saved,
            dict(sigma=1., pipeline=pipeline, truth_skip_reason='Different theory'), data)
        return saved, checked

    def test_common_legacy_score_cannot_inherit_native_precision_pass(self):
        native, checked = self.check(dict(fitted=evidence(10., comparison=1.)))
        self.assertTrue(checked['checks']['endpoint_precision']['passed'])
        self.assertTrue(checked['checks']['saved_endpoint_reproduced']['passed'])
        self.assertFalse(checked['checks']['comparison_endpoint_precision']['passed'])
        self.assertEqual(checked['checks']['comparison_endpoint_precision']['tolerance'], .01)
        self.assertFalse(checked['numerical_checks_passed'])
        self.assertFalse(checked['passed'])
        _, comparable = _comparison_result(native, checked, pair=True)
        self.assertFalse(comparable)

    def test_common_legacy_score_within_original_threshold_is_accepted(self):
        _, checked = self.check(dict(fitted=evidence(10., comparison=9.995)))
        self.assertTrue(checked['numerical_checks_passed'])
        self.assertTrue(checked['passed'])
        self.assertEqual(checked['comparison_endpoint']['chi2'], 9.995)
        self.assertEqual(checked['checks']['comparison_endpoint_precision']['kind'], 'absolute_delta_chi2')

    def test_unchecked_comparison_truth_cannot_make_baseline_pass_scientific(self):
        _, checked = self.check(dict(fitted=evidence(1.), injected=evidence(2., comparison=100.)))
        self.assertTrue(checked['truth_baseline']['passed'])
        self.assertTrue(checked['numerical_checks_passed'])
        self.assertTrue(checked['checks']['injected_precision']['passed'])
        self.assertFalse(checked['checks']['injected_comparison_precision']['passed'])
        self.assertFalse(checked['passed'])

    def test_nonhistorical_comparison_uses_vector_not_equal_scalar_scores(self):
        data = dict(fitted=evidence(1.))
        data['fitted']['levels']['comparison']['residuals'] = [0., 1.]
        _, checked = self.check(data, historical=False)
        self.assertFalse(checked['numerical_checks_passed'])
        check = checked['checks']['comparison_endpoint_precision']
        self.assertEqual(check['kind'], 'comparison_selected_residual_vector')
        self.assertAlmostEqual(check['measured'], math.sqrt(2.))
        self.assertEqual(check['tolerance'], .01)

    def test_s301_selected_precision_preserves_original_vector_semantics(self):
        data = dict(fitted=evidence(1.))
        data['fitted']['levels']['tight']['residuals'] = [0., 1.]
        _, checked = self.check(data, historical=False, pipeline='s301')
        self.assertFalse(checked['checks']['endpoint_precision']['passed'])
        self.assertTrue(checked['checks']['comparison_endpoint_precision']['passed'])
        self.assertFalse(checked['numerical_checks_passed'])

    def test_historical_selected_precision_remains_scalar_criterion(self):
        data = dict(fitted=evidence(1.))
        data['fitted']['levels']['tight']['residuals'] = [0., 1.]
        _, checked = self.check(data, historical=True, pipeline='s301')
        self.assertTrue(checked['passed'])
        self.assertEqual(checked['checks']['endpoint_precision']['kind'], 'absolute_delta_chi2')

    def test_lower_failed_s301_validation_remains_diagnostic_and_unpassed(self):
        case = dict(case_id='audit_s301_ER', fit_theory='ER', fit_pipeline='s301',
                    residual_sigma=1., run_seeds=[101, 103])
        validations = iter([
            dict(passed=False, numerical_checks_passed=False,
                 comparison_endpoint=dict(chi2=.5, residuals=[math.sqrt(.5), 0.],
                    residual_accuracy='third', residual_integration={})),
            dict(passed=True, numerical_checks_passed=True,
                 comparison_endpoint=dict(chi2=1., residuals=[1., 0.],
                    residual_accuracy='third', residual_integration={}))])
        scores = iter([.5, 1.])
        def fit(case, output, **kwargs):
            score = next(scores)
            result = dict(case_id=case['case_id'], fit_theory='ER', fit_pipeline='s301',
                status='COMPLETED', run_complete=True, scientific_checks_passed=True,
                best_candidate_checks_passed=True, theta=evidence(score)['theta'],
                chi2=score, residuals=point(score)['residuals'], residual_accuracy='third')
            directory = Path(output)
            directory.mkdir(parents=True)
            (directory/'result.json').write_text(json.dumps(result), encoding='utf-8')
            return result
        with tempfile.TemporaryDirectory() as folder, \
                patch.object(reliability, 'fit_case', side_effect=fit), \
                patch.object(reliability, 'validate_endpoint', side_effect=lambda *args, **kwargs:next(validations)):
            result = reliability.fit_case_reliable(case, Path(folder)/'fit', profile='demo',
                policy=dict(max_attempts=2, budget_multiplier=2.))
        self.assertEqual(result['chi2'], 1.)
        self.assertEqual(result['diagnostic_best']['chi2'], .5)
        self.assertFalse(result['scientific_checks_passed'])
        self.assertEqual(result['status'], 'NEEDS_REVIEW_BEST_FOUND')

    def test_mixed_legacy_retained_minima_report_both_original_sources(self):
        cases = {name:dict(case_id='audit_'+name, dataset_id='audit', fit_theory=name,
            fit_pipeline='legacy', residual_sigma=1., legacy_optimizer_seed=104729,
            metadata=dict(suite='baseline', dataset_id='audit', add_noise=True)) for name in ('ER', 'RN')}
        rounds = iter([{'ER':(1., False), 'RN':(4., False)},
                       {'ER':(2., True), 'RN':(3., True)},
                       {'ER':(3., True), 'RN':(2., True)}])
        def fit(er, rn, output, **kwargs):
            values = next(rounds)
            outputs = {}
            for case in (er, rn):
                name = case['fit_theory']
                score, passed = values[name]
                result = dict(case_id=case['case_id'], fit_theory=name, fit_pipeline='legacy',
                    status='COMPLETED', run_complete=True, scientific_checks_passed=passed,
                    best_candidate_checks_passed=True, theta=evidence(score)['theta'], chi2=score,
                    residuals=point(score)['residuals'], residual_accuracy='tight', residual_integration={},
                    comparison={'ER_chi2':values['ER'][0], 'RN_chi2':values['RN'][0]},
                    run_seeds=case['run_seeds'], legacy_record=dict(local_candidates=[dict(
                        theta=evidence(score)['theta'], chi2=score, success=passed,
                        message='Synthetic termination', nfev=1, njev=1)]))
                directory = Path(output)/name
                directory.mkdir(parents=True)
                (directory/'result.json').write_text(json.dumps(result), encoding='utf-8')
                outputs[name] = result
            return outputs
        def validate(case, result, *args, **kwargs):
            return dict(passed=True, numerical_checks_passed=True,
                effective_bounds=dict(lower=[0.]*6, upper=[100.]*6),
                comparison_endpoint={key:result[key] for key in ('chi2', 'residuals', 'residual_accuracy', 'residual_integration')})
        with tempfile.TemporaryDirectory() as folder, \
                patch.object(reliability, 'fit_pair', side_effect=fit), \
                patch.object(reliability, 'validate_endpoint', side_effect=validate):
            results = reliability.fit_pair_reliable(cases['ER'], cases['RN'], Path(folder)/'fit', profile='demo')
            pair = json.loads((Path(folder)/'fit/pair_result.json').read_text(encoding='utf-8'))
        self.assertEqual([results[name]['chi2'] for name in ('ER', 'RN')], [1., 2.])
        self.assertEqual([results[name]['selected_attempt_index'] for name in ('ER', 'RN')], [0, 2])
        self.assertFalse(pair['scientific_checks_passed'])
        rows = []
        for name, result in results.items():
            self.assertFalse(result['scientific_checks_passed'])
            self.assertTrue(result['run_complete'])
            self.assertNotIn('comparison', result)
            self.assertIn('native_pair_comparison', result)
            self.assertIn('effective_bounds', result['selected_endpoint_validation'])
            self.assertEqual(result['legacy_record']['local_candidates'][0]['message'], 'Synthetic termination')
            rows.append(dict(case=cases[name], result=result, metadata=cases[name]['metadata'],
                             available=True, eligible=True))
        report = postprocess._reliability_report(rows, 'recompute')
        self.assertEqual([row['best_attempt'] for row in report['cases']], [1, 3])
        self.assertTrue(all(row['interpretation'] == 'BEST_FOUND_NEEDS_REVIEW' for row in report['cases']))


if __name__ == '__main__':
    unittest.main()
