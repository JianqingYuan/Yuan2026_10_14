"""Stage failures must never masquerade as ordinary demo iteration limits.

No optimizer, forward integration, or child process is started: the sealed
vendor run/pool/DE boundaries are mocked, while the real adapter and launcher
record their results in isolated temporary directories.
"""
from contextlib import ExitStack, redirect_stdout
from copy import deepcopy
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import main
from engine import api
from experiments.api import PIPELINE_VERSIONS
from test_engine_inputs import static_case


HARD_FAILURES = (
    'FAILED',
    'CLOSURE_FAILED_REQUIRES_REVIEW',
    'CLOSURE_MANIFEST_FAILURE_REQUIRES_REVIEW',
)
ITERATION_LIMITS = (
    'LOCAL_NFEV_BUDGET_EXHAUSTED',
    'CROSS_FIT_LOCAL_BUDGET_EXHAUSTED_DIAGNOSTICS_RETAINED',
    'CLOSURE_NFEV_BUDGET_EXHAUSTED_REQUIRES_REVIEW',
)


class NoWorkPool:
    def terminate(self):
        pass

    def join(self):
        pass


class StageStatusTests(unittest.TestCase):
    def case(self, self_recovery=False):
        case = static_case()
        case.update(fit_pipeline='s301', fit_pipeline_requested='s301',
                    fit_pipeline_version=PIPELINE_VERSIONS['s301'], execution_mode='demo',
                    metadata=dict(suite='baseline', dataset_id='stage_status_fixture', add_noise=False))
        if self_recovery:
            case.pop('fit_mode')
            case['reference_theta'] = [1., .3, 30., 0., .2, .004]
        return case

    def fit_status(self, statuses, self_recovery=False, de_failure_after_first=None):
        if isinstance(statuses, str):
            statuses = [statuses]
        statuses = list(statuses)
        created = []

        def stage(*arguments, **kwargs):
            status = statuses[min(len(created), len(statuses) - 1)]
            out = Path(kwargs['output_override'])
            out.mkdir(parents=True)
            state = dict(status=status, solver_accepted=dict(status=0 if status in ITERATION_LIMITS else 1))
            if status in HARD_FAILURES:
                state.update(error='Frozen numerical reference not reproduced: nominal',
                             traceback='RuntimeError: Frozen numerical reference not reproduced: nominal')
            if status in ('WALL_BUDGET_EXHAUSTED', 'FORWARD_BUDGET_EXHAUSTED'):
                state['reason'] = 'shared_case_wall_budget_exhausted' if status.startswith('WALL') else 'forward_guard'
            run = SimpleNamespace(out=out, state=state, run=lambda: None)
            created.append(run)
            return run

        de = SimpleNamespace(population=np.zeros((1, 6)), population_energies=np.array([1.]),
                             nit=2, success=False, message='Controlled DE maxiter endpoint')
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            stack.enter_context(patch('engine.api._pool', side_effect=lambda *a, **k: NoWorkPool()))
            if de_failure_after_first is None:
                stack.enter_context(patch('engine.api.run_de_search', return_value=de))
            else:
                stack.enter_context(patch('engine.api.run_de_search', side_effect=[de, de_failure_after_first]))
            stack.enter_context(patch('engine.api.select_candidates', return_value=[{'theta': [1., .3, 30., 0., .2, .004]}]))
            stack.enter_context(patch('engine.api._NonzeroRun', side_effect=stage))
            stack.enter_context(patch('engine.api._SelfRun', side_effect=stage))
            stack.enter_context(patch('engine.api._collect', return_value=None))
            result = api.fit_case(self.case(self_recovery), Path(temporary) / 'fit', profile='demo')
            persisted = json.loads((Path(temporary) / 'fit/result.json').read_text(encoding='utf-8'))
            self.assertEqual(persisted, result)
        self.assertTrue(created, 'Regression must reach the mocked vendor stage')
        return result

    def launch_result(self, result, self_recovery=False):
        case = self.case(self_recovery)
        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / 'run'
            with patch('main._select_cases', side_effect=lambda options: iter([deepcopy(case)])), \
                 patch('main._scientific_source_hash', return_value='a' * 64), \
                 patch('engine.reliability.fit_case_reliable', return_value=deepcopy(result)), \
                 patch('postprocess.render_run', return_value=[]) as render, redirect_stdout(io.StringIO()):
                code = main.run(['--mode', 'demo', '--suite', 'baseline', '--fit-pipeline', 's301',
                                 '--max-tasks', '1', '--workers', '1', '--cores-per-fit', '1',
                                 '--output', str(destination)])
            plan = json.loads((destination / 'run.json').read_text(encoding='utf-8'))
            receipt = json.loads((destination / 'tasks' / case['case_id'] / 'task_receipt.json').read_text(encoding='utf-8'))
            render.assert_called_once()
            return code, plan, receipt

    def test_vendor_failures_are_failed_and_demo_exits_nonzero(self):
        for status in HARD_FAILURES:
            with self.subTest(stage=status):
                result = self.fit_status(status)
                self.assertEqual(result['status'], 'FAILED')
                self.assertFalse(result['run_complete'])
                self.assertFalse(result['scientific_checks_passed'])
                self.assertTrue(any(item['status'] == status for item in result['stages']))
                code, plan, receipt = self.launch_result(result)
                self.assertNotEqual(code, 0)
                self.assertNotEqual(plan['state'], 'DEMO_FINISHED_WITH_ITERATION_LIMITS')
                self.assertEqual(receipt['engine_status'], 'FAILED')

    def test_frozen_reference_failure_in_self_recovery_is_not_a_limit(self):
        result = self.fit_status('FAILED', self_recovery=True)
        self.assertEqual(result['status'], 'FAILED')
        self.assertFalse(result['run_complete'])
        code, plan, receipt = self.launch_result(result, self_recovery=True)
        self.assertNotEqual(code, 0)
        self.assertNotEqual(plan['state'], 'DEMO_FINISHED_WITH_ITERATION_LIMITS')

    def test_real_failure_dominates_success_or_budget_from_other_source(self):
        for first in ('CROSS_FIT_DIAGNOSTIC_COMPLETE_REQUIRES_REVIEW', ITERATION_LIMITS[1]):
            with self.subTest(first=first):
                result = self.fit_status([first, 'FAILED'])
                self.assertEqual(result['status'], 'FAILED')
                self.assertFalse(result['run_complete'])
                self.assertNotEqual(self.launch_result(result)[0], 0)

    def test_later_de_budget_exception_does_not_hide_previous_failure(self):
        result = self.fit_status('FAILED',
            de_failure_after_first=api.Interrupted('shared_case_wall_budget_exhausted'))
        self.assertEqual(result['status'], 'FAILED')
        self.assertFalse(result['run_complete'])
        self.assertIn('Frozen numerical reference', result['stop_reason'])
        self.assertNotEqual(self.launch_result(result)[0], 0)

    def test_pure_local_iteration_limits_remain_normal_demo_endpoints(self):
        for status in ITERATION_LIMITS:
            with self.subTest(stage=status):
                result = self.fit_status(status)
                self.assertFalse(result['run_complete'])
                self.assertFalse(result['scientific_checks_passed'])
                self.assertNotEqual(result['status'], 'FAILED')
                code, plan, receipt = self.launch_result(result)
                self.assertEqual(code, 0)
                self.assertEqual(plan['state'], 'DEMO_FINISHED_WITH_ITERATION_LIMITS')
                self.assertEqual(receipt['state'], 'INCOMPLETE')

    def test_wall_and_forward_guards_are_not_successful_iteration_demos(self):
        for status in ('WALL_BUDGET_EXHAUSTED', 'FORWARD_BUDGET_EXHAUSTED'):
            with self.subTest(stage=status):
                result = self.fit_status(status)
                self.assertFalse(result['run_complete'])
                self.assertNotEqual(self.launch_result(result)[0], 0)

    def test_review_and_short_preflight_states_are_not_iteration_limits(self):
        for status in ('NOT_VALIDATED', 'DUAL_GATE_PASSED_THIRD_INCOMPLETE', 'SHORT_PREFLIGHT_COMPLETE',
                       'INTERRUPTED_CHECKPOINT_RETAINED', 'CLOSURE_INTERRUPTED_CHECKPOINT_RETAINED_REQUIRES_REVIEW'):
            with self.subTest(stage=status):
                result = self.fit_status(status)
                self.assertFalse(result['run_complete'])
                code, plan, receipt = self.launch_result(result)
                self.assertNotEqual(code, 0)
                self.assertNotEqual(plan['state'], 'DEMO_FINISHED_WITH_ITERATION_LIMITS')

    def test_completed_stage_is_complete_without_faking_scientific_acceptance(self):
        result = self.fit_status('CROSS_FIT_DIAGNOSTIC_COMPLETE_REQUIRES_REVIEW')
        self.assertEqual(result['status'], 'COMPLETED')
        self.assertTrue(result['run_complete'])
        self.assertFalse(result['scientific_checks_passed'])  # Mock has no independently checked endpoints.
        code, plan, receipt = self.launch_result(result)
        self.assertEqual(code, 0)
        self.assertEqual(plan['state'], 'FINISHED_WITH_UNRESOLVED_RESULTS')
        self.assertEqual(receipt['state'], 'FINISHED')


if __name__ == '__main__':
    unittest.main()
