"""Reject inconsistent S301 plotting inputs before writing any figure output."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from plotting.paper import DEFAULT_DATA, _validate_s301, render_all


class S301CacheValidationTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads((DEFAULT_DATA / 's301.json').read_text(encoding='utf-8'))

    def test_original_snapshot_is_valid_and_unchanged(self):
        before = copy.deepcopy(self.data)
        _validate_s301(self.data)
        self.assertEqual(self.data, before)
        self.assertTrue(any(row['delta_chi2'] < 0 for row in self.data['rows']))

    def test_float_roundoff_is_allowed_but_not_rewritten(self):
        self.data['rows'][0]['delta_chi2'] += 5e-11
        before = copy.deepcopy(self.data)
        _validate_s301(self.data)
        self.assertEqual(self.data, before)

    def test_zero_and_signed_differences_are_valid(self):
        for row, er, rn in zip(self.data['rows'], (0., 0., 2.), (0., 2., 0.)):
            row.update(chi2_ER=er, chi2_RN=rn, delta_chi2=rn-er)
        _validate_s301(self.data)

    def test_stale_difference_rejected(self):
        self.data['rows'][0]['chi2_RN'] += 1000.
        with self.assertRaisesRegex(ValueError, 'delta_chi2 disagrees'):
            _validate_s301(self.data)

    def test_difference_beyond_roundoff_rejected(self):
        self.data['rows'][0]['delta_chi2'] += 1e-8
        with self.assertRaisesRegex(ValueError, 'delta_chi2 disagrees'):
            _validate_s301(self.data)

    def test_invalid_noise_levels_rejected(self):
        for value in (207, 30.0001, None, '30', True, float('nan'), float('inf')):
            with self.subTest(value=value):
                data = copy.deepcopy(self.data)
                data['noise_uas'] = value
                with self.assertRaisesRegex(ValueError, 'noise_uas=30'):
                    _validate_s301(data)

    def test_missing_or_extra_rows_rejected(self):
        for count in (47, 49):
            with self.subTest(count=count):
                data = copy.deepcopy(self.data)
                data['rows'] = (data['rows'] + [copy.deepcopy(data['rows'][0])])[:count]
                with self.assertRaisesRegex(ValueError, 'exactly 48'):
                    _validate_s301(data)

    def test_duplicate_replacing_missing_key_rejected(self):
        self.data['rows'][-1] = copy.deepcopy(self.data['rows'][0])
        with self.assertRaisesRegex(ValueError, 'duplicate pairing key'):
            _validate_s301(self.data)

    def test_invalid_pairing_keys_rejected(self):
        for field, value in (('orbit', 'C'), ('orbit', ['A']),
                             ('charge_index', 3), ('charge_index', 0.),
                             ('charge_index', False), ('realization', -1),
                             ('realization', 8), ('realization', '0')):
            with self.subTest(field=field, value=value):
                data = copy.deepcopy(self.data)
                data['rows'][0][field] = value
                with self.assertRaisesRegex(ValueError, 'pairing key'):
                    _validate_s301(data)

    def test_bad_numeric_values_rejected(self):
        for field in ('chi2_ER', 'chi2_RN', 'delta_chi2'):
            for value in (float('nan'), float('inf'), -float('inf'), None, '1', True, 10**1000):
                with self.subTest(field=field, value_type=type(value).__name__):
                    data = copy.deepcopy(self.data)
                    data['rows'][0][field] = value
                    with self.assertRaisesRegex(ValueError, 'finite'):
                        _validate_s301(data)
        for field in ('chi2_ER', 'chi2_RN'):
            with self.subTest(field=field):
                data = copy.deepcopy(self.data)
                data['rows'][0][field] = -1.
                with self.assertRaisesRegex(ValueError, 'nonnegative'):
                    _validate_s301(data)

    def test_malformed_document_shapes_rejected(self):
        variants = [None, [], {}, dict(noise_uas=30, rows=None),
                    dict(noise_uas=30, rows=[None] * 48)]
        for data in variants:
            with self.subTest(data_type=type(data).__name__):
                with self.assertRaises(ValueError):
                    _validate_s301(data)

    def test_reordered_complete_grid_is_valid(self):
        self.data['rows'].reverse()
        _validate_s301(self.data)

    def test_rejected_cache_creates_no_output_and_starts_no_plot(self):
        self.data['rows'][0]['chi2_RN'] += 1000.
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            cache = root / 's301.json'
            cache.write_text(json.dumps(self.data), encoding='utf-8')
            # Even if Figure 1 was requested first, all Figure 13 validation
            # precedes plotting or creation of the output directory.
            (root / 'geometry.npz').write_bytes(b'not opened before validation')
            before = cache.read_bytes()
            with patch('plotting._plots.s301') as s301, patch('plotting._plots.geometry') as geometry:
                with self.assertRaisesRegex(ValueError, 'delta_chi2 disagrees'):
                    render_all(root / 'out', [1, 13], data_dir=root)
                s301.assert_not_called()
                geometry.assert_not_called()
            self.assertFalse((root / 'out').exists())
            self.assertEqual(cache.read_bytes(), before)

    def test_rejected_cache_preserves_existing_output(self):
        self.data['noise_uas'] = 207
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 's301.json').write_text(json.dumps(self.data), encoding='utf-8')
            output = root / 'out'
            output.mkdir()
            keep = output / 'existing.txt'
            keep.write_bytes(b'untouched')
            with self.assertRaisesRegex(ValueError, 'noise_uas=30'):
                render_all(output, [13], data_dir=root)
            self.assertEqual(list(output.iterdir()), [keep])
            self.assertEqual(keep.read_bytes(), b'untouched')


if __name__ == '__main__':
    unittest.main()
