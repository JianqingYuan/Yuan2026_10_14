"""Source-floor policy and mocked public routing, with zero physical forwards."""
from copy import deepcopy
from pathlib import Path
import tempfile
from types import SimpleNamespace
import threading
import time
import unittest
from unittest.mock import patch

import numpy as np

from engine import api, s301_targeted as target
from test_engine_inputs import static_case


def point(name='a', score=10., lineage='11', scale=1e-7):
    theta = [1., .3, 30., 0., .2, .004]
    raw = [np.sqrt(score)*.01, 0., 0., 0.]
    return dict(id=name, theta=theta,
        chi2={level: score for level in target.LEVELS},
        D={level:float(np.linalg.norm(raw)) for level in target.LEVELS},
        raw_residuals=dict(theta=theta, **{level:list(raw) for level in target.LEVELS}),
        numerical_evidence_valid=True, discrepancy_scale=scale,
        lineage_id=lineage, comparison_key='same-observation-model-weight-bounds',
        counts_as_independent_source=True, truth_seed_used=False)


def pair(gap=8e-5, base=10., scale=1e-7):
    return [point(score=base, scale=scale),
        point('b', base+gap, '22', scale)]


class SourceFloorTests(unittest.TestCase):
    def test_marginal_agreement_preserves_original_fields_and_inputs(self):
        points = pair()
        before = deepcopy(points)
        original = api.rank_candidates(points)
        result = target.rank_source_candidates(points)
        self.assertFalse(original['passed'])
        self.assertTrue(result['passed'])
        self.assertFalse(result['original_passed'])
        self.assertEqual(result['original_status'], original['status'])
        for key, value in original.items():
            if key not in ('passed', 'status'):
                self.assertEqual(result[key], value, key)
        self.assertEqual(points, before)
        policy = result['source_agreement_policy']
        self.assertEqual(policy['absolute_chi2_floor'], 1e-4)
        self.assertEqual(policy['scope'], 'source_agreement_only')
        self.assertFalse(policy['is_optimizer_error_bound'])
        self.assertFalse(policy['is_global_optimum_certificate'])
        self.assertFalse(result['final_production_acceptance'])

    def test_floor_is_inclusive_and_not_added_to_original_scale(self):
        self.assertTrue(target.rank_source_candidates(pair(1e-4, base=0.))['passed'])
        self.assertFalse(target.rank_source_candidates(pair(1.5e-4, base=0., scale=4e-5))['passed'])
        self.assertFalse(target.rank_source_candidates(pair(np.nextafter(1e-4, np.inf), base=0.))['passed'])

    def test_larger_original_scale_is_retained(self):
        result = target.rank_source_candidates(pair(1.5e-4, base=0., scale=1e-4))
        row = result['source_agreement_comparisons']['22']
        self.assertTrue(result['original_passed'])
        self.assertTrue(result['passed'])
        self.assertEqual(row['effective_source_agreement_allowance'], 2e-4+1e-8)

    def test_no_candidates_or_insufficient_independent_sources(self):
        empty = target.rank_source_candidates([])
        self.assertFalse(empty['passed'])
        self.assertEqual(empty['status'], 'NO_VALIDATED_CANDIDATES')
        self.assertEqual(empty['source_agreement_comparisons'], {})
        for points in ([point()], [point(), point('b', lineage='11')]):
            self.assertFalse(target.rank_source_candidates(points)['passed'])

    def test_all_registered_source_bests_must_agree(self):
        result = target.rank_source_candidates(pair()+[point('c', 10.001, '33')])
        self.assertEqual(result['independent_sources'], 3)
        self.assertFalse(result['passed'])
        self.assertTrue(result['source_agreement_comparisons']['22']['source_agreement_passed'])
        self.assertFalse(result['source_agreement_comparisons']['33']['source_agreement_passed'])

    def test_auxiliary_lower_point_is_comparator_not_independent_vote(self):
        extra = point('auxiliary', 9., 'aux')
        extra['counts_as_independent_source'] = False
        result = target.rank_source_candidates(pair()+[extra])
        self.assertEqual(result['best_id'], 'auxiliary')
        self.assertEqual(result['independent_sources'], 2)
        self.assertFalse(result['passed'])
        self.assertFalse(target.rank_source_candidates([point(), extra])['passed'])

    def test_original_identity_and_classification_fail_closed(self):
        for change in ({'comparison_key': 'other'}, {'comparison_key': ''},
                {'id': 'a'}, {'lineage_id': None}, {'truth_seed_used': True},
                {'counts_as_independent_source': 1}, {'numerical_evidence_valid': False}):
            with self.subTest(change=change):
                points = pair(); points[1].update(change)
                with self.assertRaises(ValueError):
                    target.rank_source_candidates(points)

    def test_nonfinite_or_negative_scores_and_scales_fail_closed(self):
        for field in ('chi2', 'discrepancy_scale'):
            for value in (float('nan'), float('inf'), -1.):
                with self.subTest(field=field, value=value):
                    points = pair()
                    if field == 'chi2': points[1][field]['third'] = value
                    else: points[1][field] = value
                    with self.assertRaises(ValueError):
                        target.rank_source_candidates(points)

    def test_invalid_minimum_and_explicit_three_source_requirement(self):
        for minimum in (1, True, 2., 0):
            with self.assertRaises(ValueError):
                target.rank_source_candidates(pair(), minimum_independent_sources=minimum)
        self.assertFalse(target.rank_source_candidates(pair(), minimum_independent_sources=3)['passed'])

    def test_known_lower_actual_is_not_forgiven_by_source_floor(self):
        points = pair()
        self.assertTrue(target.rank_source_candidates(points)['passed'])
        lower = dict(theta=[1., .31, 30., 0., .2, .004], accuracy='third', chi2=10.-1e-8)
        self.assertFalse(target.lower_guard(points, [lower])['passed'])

    def test_lower_failed_point_is_not_forgiven_by_source_floor(self):
        points = pair()
        rejected = point('rejected', 10.-1e-8)
        rejected['numerical_evidence_valid'] = False
        self.assertTrue(target.rank_source_candidates(points)['passed'])
        self.assertTrue(target.lower_guard(points+[rejected], [])['lower_failed_candidate_veto'])

    def test_material_known_counterexample_still_vetoes(self):
        points = pair(gap=0., base=188.565113)
        lower = dict(theta=[1., .31, 30., 0., .2, .004], accuracy='third', chi2=182.683014)
        self.assertFalse(target.lower_guard(points, [lower])['passed'])
        self.assertFalse(target.rank_source_candidates(pair(49.098650353))['passed'])


class RoutingAndPrecisionTests(unittest.TestCase):
    def test_default_and_explicit_s301_nonzero_routing_match(self):
        default = static_case()
        explicit = dict(default, fit_pipeline='s301')
        self.assertEqual(api._rank_candidates_for_case(default, pair()),
                         api._rank_candidates_for_case(explicit, pair()))
        self.assertTrue(api._rank_candidates_for_case(default, pair())['passed'])

    def test_legacy_and_historical_and_self_routes_remain_original(self):
        original = api.rank_candidates(pair())
        cases = [dict(static_case(), fit_pipeline='legacy'),
            dict(static_case(), precision_criterion=dict(kind='absolute_delta_chi2', tolerance=.01)),
            {key:value for key,value in static_case().items() if key != 'fit_mode'}]
        for case in cases:
            with self.subTest(case=case):
                self.assertEqual(api._rank_candidates_for_case(case, pair()), original)

    def test_raw_precision_and_missing_vector_validation_stay_original(self):
        case, bounds = api._validate_case(static_case())
        raw = dict(theta=point()['theta'], nominal=[.01, 0., 0., 0.],
            tight=[.01, 0., 0., 0.], third=[.01, 2e-7, 0., 0.])
        recorded = dict(theta=raw['theta'],
            D={level:float(np.linalg.norm(raw[level])) for level in target.LEVELS})
        kwargs = dict(sigma=.01, bounds=dict(lower=bounds.lower, upper=bounds.upper),
            expected_size=4, ceiling=case['threshold_D'])
        with self.assertRaisesRegex(ValueError, 'original ceiling'):
            api.verify_vectors(raw, recorded, **kwargs)
        raw.pop('nominal')
        with self.assertRaises(KeyError):
            api.verify_vectors(raw, recorded, **kwargs)

    def test_targeted_reranking_uses_same_floor_and_keeps_lineages(self):
        case, bounds = api._validate_case(static_case())
        points = pair(.01)
        stages, actual, rejected, invalid, calls = [], [], [], [], []
        def stage(*args, **kwargs):
            out = kwargs['output_override']; out.mkdir()
            if '_targeted_' in out.name: calls.append(out.name)
            return SimpleNamespace(out=out, state=dict(status=target.COMPLETE), run=lambda: None)
        def collect(run, source, bounds, case, points, rejected):
            points.append(point(run.out.name, 9.+(8e-5 if source == 22 else 0.), str(source)))
        with tempfile.TemporaryDirectory() as tmp, \
                patch('engine.api._TargetedRun', side_effect=stage), \
                patch('engine.api._NonzeroRun', side_effect=stage), \
                patch('engine.api._collect', side_effect=collect), \
                patch('engine.api._boundary_check', return_value=dict(issues=[], significant_fixed_nuisance_descent=False)):
            ranking, _ = api._targeted_completion(None, api._config(case, 1, 'demo'), case,
                bounds, Path(tmp), time.time()+30, threading.Event(), [False], points,
                rejected, stages, actual, invalid, dict(passed=False), {}, [11, 22])
        self.assertTrue(ranking['passed'])
        self.assertFalse(ranking['original_passed'])
        self.assertEqual(ranking['independent_sources'], 2)
        self.assertEqual(len(calls), 2)
        self.assertTrue(all(name.endswith('full6d') for name in calls))


class FakePool:
    def terminate(self): pass
    def join(self): pass


class PublicAdapterTests(unittest.TestCase):
    def run_mock_fit(self, *, state='CROSS_FIT_DIAGNOSTIC_COMPLETE_REQUIRES_REVIEW',
                     lower=False, invalid=False, historical=False, self_mode=False,
                     explicit_pipeline=False, closure=False):
        case = static_case(); case['run_seeds'] = [11, 22]
        if explicit_pipeline: case['fit_pipeline'] = 's301'
        if historical:
            case['precision_criterion'] = dict(kind='absolute_delta_chi2', tolerance=.01)
        if self_mode:
            case.pop('fit_mode'); case['reference_theta'] = point()['theta']
            state = 'RECOVERY_VALIDATED'
        if closure: case['bounds']['q'][0] = 0.
        de = SimpleNamespace(population=np.zeros((1, 6)), population_energies=np.array([100.]),
            nit=2, success=False, message='Mock finite DE; no forward calls')
        def stage(*args, **kwargs):
            out = kwargs['output_override']; out.mkdir()
            record = dict(status=state, solver_accepted=dict(status=1))
            if lower:
                record['actual_minima'] = dict(third=dict(theta=[1., .31, 30., 0., .2, .004],
                    accuracy='third', chi2=10.-1e-8, raw_residuals=[np.sqrt(10.-1e-8)*.01, 0., 0., 0.]))
            return SimpleNamespace(out=out, state=record, run=lambda: None)
        def collect(run, source, bounds, case, points, rejected):
            gap = 8e-5
            if closure and '_q0' not in run.out.name: gap = .01
            p = point(run.out.name, 10.+(gap if source == 22 else 0.), str(source))
            if invalid and source == 22: p['numerical_evidence_valid'] = False
            # Face stages are lower than each original candidate, same lineage.
            if closure and '_q0' in run.out.name:
                p = point(run.out.name, 9.+(gap if source == 22 else 0.), str(source))
            points.append(p)
        def no_completion(*args): return args[-3], args[-2]
        with tempfile.TemporaryDirectory() as tmp, \
                patch('engine.api._pool', return_value=FakePool()), \
                patch('engine.api.run_de_search', return_value=de), \
                patch('engine.api.select_candidates', return_value=[dict(theta=point()['theta'])]), \
                patch('engine.api._NonzeroRun', side_effect=stage), \
                patch('engine.api._SelfRun', side_effect=stage), \
                patch('engine.api._FaceRun', side_effect=stage), \
                patch('engine.api._collect', side_effect=collect), \
                patch('engine.api._targeted_completion', side_effect=no_completion), \
                patch('engine.s301_fixed_evidence.complete', side_effect=lambda *args:(args[12],args[13])), \
                patch('engine.api._boundary_check', return_value=dict(issues=[], significant_fixed_nuisance_descent=False)):
            # Isolate the source-floor gate, not missing-evidence repair. The
            # actual new repair route has separate real-entry mocked contracts.
            return api.fit_case(case, Path(tmp)/'fit', profile='demo')

    def test_mock_public_fit_uses_floor_and_exports_policy(self):
        for explicit in (False, True):
            result = self.run_mock_fit(explicit_pipeline=explicit)
            self.assertTrue(result['ranking']['passed'])
            self.assertFalse(result['ranking']['original_passed'])
            self.assertTrue(result['scientific_checks_passed'])
            self.assertTrue(result['result_is_demo'])
            self.assertTrue(result['no_global_optimum_certificate'])
            self.assertEqual(result['ranking']['source_agreement_policy']['absolute_chi2_floor'], 1e-4)

    def test_public_post_qzero_ranking_uses_same_policy(self):
        result = self.run_mock_fit(closure=True)
        self.assertTrue(result['ranking']['passed'])
        self.assertFalse(result['ranking']['original_passed'])
        self.assertEqual(len(result['stages']), 4)
        self.assertTrue(result['ranking']['best_id'].endswith('_q0'))

    def test_public_historical_route_not_relaxed(self):
        result = self.run_mock_fit(historical=True)
        self.assertFalse(result['ranking']['passed'])
        self.assertNotIn('source_agreement_policy', result['ranking'])
        self.assertFalse(result['scientific_checks_passed'])

    def test_public_self_route_not_relaxed(self):
        result = self.run_mock_fit(self_mode=True)
        self.assertEqual(result['ranking'], dict(passed=True, status='TWO_SOURCE_SELF_GATE_CHECK'))
        self.assertNotIn('source_agreement_policy', result['ranking'])

    def test_public_budget_and_hard_failure_not_forgiven(self):
        for status in ('FORWARD_BUDGET_EXHAUSTED', 'WALL_BUDGET_EXHAUSTED', 'FAILED',
                'CROSS_FIT_LOCAL_BUDGET_EXHAUSTED_DIAGNOSTICS_RETAINED'):
            with self.subTest(status=status):
                result = self.run_mock_fit(state=status)
                self.assertTrue(result['ranking']['passed'])
                self.assertFalse(result['run_complete'])
                self.assertFalse(result['scientific_checks_passed'])

    def test_public_lower_actual_not_forgiven(self):
        result = self.run_mock_fit(lower=True)
        self.assertTrue(result['ranking']['passed'])
        self.assertFalse(result['scientific_checks_passed'])
        self.assertTrue(result['unresolved_lower_actual_candidates'])

    def test_public_bad_precision_leaves_only_one_source(self):
        result = self.run_mock_fit(invalid=True)
        self.assertEqual(result['ranking']['independent_sources'], 1)
        self.assertFalse(result['ranking']['passed'])
        self.assertFalse(result['scientific_checks_passed'])


if __name__ == '__main__':
    unittest.main()
