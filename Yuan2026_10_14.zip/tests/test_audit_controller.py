"""Independent audit regressions for cross-attempt scientific acceptance."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from engine import reliability


class AuditControllerTests(unittest.TestCase):
    def test_rejected_lower_s301_score_remains_a_comparable_diagnostic(self):
        case = dict(case_id='audit_counterexample_ER', dataset_id='audit_counterexample',
            fit_theory='ER', fit_pipeline='s301', residual_sigma=1., run_seeds=[123, 456])
        scores = iter((.5, 1.))
        def fit(case, output_dir, **kwargs):
            score = next(scores)
            result = dict(case_id=case['case_id'], fit_theory='ER', fit_pipeline='s301',
                status='COMPLETED', run_complete=True, scientific_checks_passed=True,
                best_candidate_checks_passed=True, chi2=score,
                theta=[1., .3, 30., 0., .2, .004], residuals=[score**.5, 0.],
                residual_accuracy='third')
            directory = Path(output_dir)
            directory.mkdir()
            (directory/'result.json').write_text(json.dumps(result), encoding='utf-8')
            return result
        reports = [dict(passed=passed, numerical_checks_passed=passed,
            status='PASSED' if passed else 'NEEDS_REVIEW',
            comparison_endpoint=dict(chi2=score, residuals=[score**.5, 0.], residual_accuracy='third'))
            for score, passed in ((.5, False), (1., True))]
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(reliability, 'fit_case', side_effect=fit) as fitted:
                with patch.object(reliability, 'validate_endpoint', side_effect=deepcopy(reports)):
                    result = reliability.fit_case_reliable(case, Path(directory)/'fit',
                        profile='demo', policy=dict(max_attempts=2, budget_multiplier=2.))
        self.assertEqual(fitted.call_count, 2)
        self.assertEqual(result['chi2'], 1., 'Numerically rejected lower point must not become usable')
        self.assertEqual(result['selected_attempt_index'], 1)
        self.assertTrue(result['best_candidate_checks_passed'])
        self.assertFalse(result['scientific_checks_passed'],
            'A lower unresolved same-objective score must prevent acceptance of the higher result')
        self.assertEqual(result['status'], 'NEEDS_REVIEW_BEST_FOUND')
        self.assertEqual(result['diagnostic_best']['chi2'], .5)
        self.assertEqual(result['diagnostic_best']['attempt_index'], 0)
        self.assertTrue(result['diagnostic_best']['comparable_across_attempts'])
        first = result['reliability_attempts'][0]['models']['ER']
        self.assertFalse(first['usable_endpoint'])
        self.assertFalse(first['validation']['numerical_checks_passed'])

    def test_legacy_invalid_common_score_still_does_not_define_a_shared_objective(self):
        native = dict(chi2=.5, residuals=[.5**.5, 0.], residual_accuracy='nominal')
        validation = dict(passed=False, numerical_checks_passed=False,
            comparison_endpoint=dict(chi2=.5, residuals=[.5**.5, 0.], residual_accuracy='tight'))
        _, comparable = reliability._comparison_result(native, validation, pair=True)
        self.assertFalse(comparable)


if __name__ == '__main__':
    unittest.main()
