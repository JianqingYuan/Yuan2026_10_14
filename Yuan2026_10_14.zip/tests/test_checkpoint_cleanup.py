"""Exceptional stage cleanup; no optimizer or orbit integration is run."""
import multiprocessing as mp
import threading
import time
import unittest
from unittest.mock import Mock

from engine.api import _NonzeroRun, _PortableIO, _SelfRun, _WorkerPool
from hybrid_support import Interrupted


class _Stage:
    def run(self):
        self.action(self)


class _Probe(_PortableIO, _Stage):
    def __init__(self, action):
        self.action = action
        self.state = {}


def _signal_ready(ready):
    """Only signal child startup; never construct a numerical model."""
    ready.set()


class CheckpointCleanupTests(unittest.TestCase):
    def owned_pool(self):
        native, ready = Mock(), Mock()
        return _WorkerPool(native, ready), native, ready

    def assert_closed_once(self, native, ready):
        native.terminate.assert_called_once_with()
        native.join.assert_called_once_with()
        ready.close.assert_called_once_with()
        ready.join_thread.assert_called_once_with()

    def test_original_exception_propagates_after_pool_and_queue_cleanup(self):
        for exception in (OSError('checkpoint write failed'), Interrupted('shared deadline'),
                          KeyboardInterrupt('user cancellation')):
            with self.subTest(exception=type(exception).__name__):
                pool, native, ready = self.owned_pool()
                def fail(run):
                    run.pool = pool
                    raise exception
                run = _Probe(fail)
                with self.assertRaises(type(exception)) as raised:
                    run.run()
                self.assertIs(raised.exception, exception)
                self.assertIsNone(run.pool)
                self.assert_closed_once(native, ready)

    def test_normal_vendor_cleanup_is_not_repeated(self):
        pool, native, ready = self.owned_pool()
        def complete(run):
            run.pool = pool
            run.pool.terminate()
            run.pool.join()
            run.pool = None
        run = _Probe(complete)
        run.run()
        self.assertIsNone(run.pool)
        self.assert_closed_once(native, ready)

    def test_actual_vendor_final_save_error_reclaims_both_local_runner_pools(self):
        for runner in (_SelfRun, _NonzeroRun):
            with self.subTest(runner=runner.__name__):
                pool, native, ready = self.owned_pool()
                run = object.__new__(runner)
                run.state = {}
                run.crossfit, run.fit_theory = True, 'RN'
                run.pool = None
                exception = OSError('terminal checkpoint write failed')
                run.save = Mock(side_effect=[None, exception])
                run.start_pool = Mock(side_effect=lambda: setattr(run, 'pool', pool))
                run.preflight = Mock(side_effect=Interrupted('shared_case_wall_budget_exhausted'))
                with self.assertRaises(OSError) as raised:
                    run.run()
                self.assertIs(raised.exception, exception)
                self.assertEqual(run.state['status'], 'WALL_BUDGET_EXHAUSTED')
                self.assertIsNone(run.pool)
                self.assert_closed_once(native, ready)

    def test_exception_after_vendor_cleanup_does_not_repeat_cleanup(self):
        pool, native, ready = self.owned_pool()
        exception = OSError('later terminal report failed')
        def complete_then_fail(run):
            run.pool = pool
            run.pool.terminate()
            run.pool.join()
            run.pool = None
            raise exception
        run = _Probe(complete_then_fail)
        with self.assertRaises(OSError) as raised:
            run.run()
        self.assertIs(raised.exception, exception)
        self.assertIsNone(run.pool)
        self.assert_closed_once(native, ready)

    def test_no_pool_is_safe_on_success_or_exception(self):
        for present in (False, True):
            with self.subTest(pool_attribute_present=present):
                run = _Probe(lambda run: None)
                if present:
                    run.pool = None
                run.run()
                exception = OSError('failed before pool creation')
                def fail(run):
                    raise exception
                run.action = fail
                with self.assertRaises(OSError) as raised:
                    run.run()
                self.assertIs(raised.exception, exception)

    def test_caught_cancellation_is_checked_after_cleanup(self):
        for cancellation in ('flag', 'event', 'traceback'):
            with self.subTest(cancellation=cancellation):
                pool, native, ready = self.owned_pool()
                def caught(run):
                    run.pool = pool
                    if cancellation == 'flag':
                        run.interrupt_requested = [True]
                    elif cancellation == 'event':
                        run.cancel_event = threading.Event()
                        run.cancel_event.set()
                    else:
                        run.state['traceback'] = 'Traceback:\nKeyboardInterrupt: controlled'
                run = _Probe(caught)
                with self.assertRaises(KeyboardInterrupt):
                    run.run()
                self.assertIsNone(run.pool)
                self.assert_closed_once(native, ready)

    def test_real_pending_child_is_joined_before_checkpoint_error_returns(self):
        context = mp.get_context('spawn')
        started = context.Event()
        ready = context.Queue()
        # The only submitted task sleeps. No user data, numerical model,
        # optimizers, or external jobs are involved.
        native = context.Pool(1, initializer=_signal_ready, initargs=(started,))
        children = list(native._pool)
        owned = _WorkerPool(native, ready)
        exception = OSError('controlled final checkpoint failure')
        def fail(run):
            run.pool = owned
            native.imap(time.sleep, [30])
            raise exception
        run = _Probe(fail)
        try:
            self.assertTrue(started.wait(15), 'Controlled child did not start')
            before = time.monotonic()
            with self.assertRaises(OSError) as raised:
                run.run()
            self.assertIs(raised.exception, exception)
            self.assertLess(time.monotonic() - before, 5.)
            self.assertIsNone(run.pool)
            self.assertTrue(all(not child.is_alive() for child in children))
            self.assertTrue(ready._closed)
        finally:
            # Keep the regression bounded even if the implementation regresses.
            native.terminate()
            native.join()
            ready.close()
            ready.join_thread()
            for child in children:
                if child.is_alive():
                    child.terminate()
                child.join(timeout=5)


if __name__ == '__main__':
    unittest.main()
