"""Short real-process checks of cancellation and the shared wall budget."""
import json
import multiprocessing as mp
from pathlib import Path
import signal
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

from engine.api import (_DEMap, _FaceRun, _NonzeroRun, _config, _pool, _prepare,
                        _validate_case, fit_case)
from closure_runner import ClosureRun
from hybrid_support import Interrupted, write
from runner import run_de_search
from test_engine import short_case


def _ready_worker(ready):
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    ready.set()


def _slow_forward(task):
    time.sleep(30)
    return dict(id=task['id'], status='COMPLETE', residual=[0., 0.])


class _Bounds:
    def denormalize(self, point):
        return np.asarray(point)


class _NoWorkPool:
    def terminate(self):
        pass

    def join(self):
        pass


def _locked_sigint_probe(target):
    """Isolated process: a regression must time out, not hang the test suite."""
    event = mp.get_context('spawn').Event()
    original_handler = signal.getsignal(signal.SIGINT)
    def interrupt_with_lock_held(*args, **kwargs):
        with event._cond:
            signal.raise_signal(signal.SIGINT)
    try:
        with patch('engine.api._pool', return_value=_NoWorkPool()):
            with patch('engine.api.run_de_search', side_effect=interrupt_with_lock_held):
                fit_case(short_case(), Path(target), profile='demo', cancel_event=event)
    except KeyboardInterrupt:
        result = json.loads((Path(target)/'result.json').read_text(encoding='utf-8'))
        assert result['status'] == 'INTERRUPTED'
        assert event.is_set()
        assert signal.getsignal(signal.SIGINT) is original_handler
    else:
        raise AssertionError('Expected SIGINT to stop the case')


class EngineControlTests(unittest.TestCase):
    def _de_with_slow_worker(self, cancel):
        context = mp.get_context('spawn')
        ready = context.Event()
        pool = context.Pool(1, initializer=_ready_worker, initargs=(ready,))
        timer = None
        event = threading.Event()
        try:
            self.assertTrue(ready.wait(15), 'Test worker did not initialize')
            started = time.monotonic()
            deadline = time.time() + (10 if cancel else .15)
            mapper = _DEMap({'residual_sigma':1.},
                {'de':{'max_forward_calls':100, 'invalid_chi2':1e100}},
                _Bounds(), pool, deadline, Path('.'), event)
            if cancel:
                timer = threading.Timer(.15, event.set)
                timer.start()
            with patch('engine.api.worker_predict', _slow_forward):
                with self.assertRaises(KeyboardInterrupt if cancel else Interrupted):
                    mapper(None, [[0.], [1.]])
            self.assertLess(time.monotonic()-started, 3.)
        finally:
            if timer is not None:
                timer.cancel()
            children = list(pool._pool)
            pool.terminate(); pool.join()
            self.assertTrue(all(not child.is_alive() for child in children))

    def test_shared_deadline_interrupts_a_slow_de_forward(self):
        self._de_with_slow_worker(cancel=False)

    def test_shared_cancel_interrupts_a_slow_de_forward(self):
        self._de_with_slow_worker(cancel=True)

    def test_de_order_and_values_are_identical_with_one_or_two_workers(self):
        case, bounds = _validate_case(short_case())
        outputs = []
        for workers in (1, 2):
            config = _config(case, workers, 'demo')
            pool = _pool(case, config, workers)
            try:
                mapper = _DEMap(case, config, bounds, pool, time.time()+30, Path('.'))
                result = run_de_search(mapper, bounds.ndim, config['de'], 12345)
                outputs.append((result.population, result.population_energies, mapper.events))
            finally:
                pool.terminate(); pool.join()
        np.testing.assert_array_equal(outputs[0][0], outputs[1][0])
        np.testing.assert_array_equal(outputs[0][1], outputs[1][1])
        self.assertEqual([event['id'] for event in outputs[0][2]],
                         [event['id'] for event in outputs[1][2]])

    def test_already_cancelled_case_does_not_start_or_create_output(self):
        event = threading.Event(); event.set()
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp)/'case'
            with self.assertRaises(KeyboardInterrupt):
                fit_case(short_case(), target, profile='demo', cancel_event=event)
            self.assertFalse(target.exists())

    def test_caught_vendor_interrupt_is_rethrown_and_saved(self):
        event = threading.Event()
        original_handler = signal.getsignal(signal.SIGINT)
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp)/'case'
            with patch('hybrid_support.least_squares', side_effect=KeyboardInterrupt):
                with self.assertRaises(KeyboardInterrupt):
                    fit_case(short_case(), target, profile='demo', cancel_event=event)
            result = json.loads((target/'result.json').read_text(encoding='utf-8'))
            self.assertEqual(result['status'], 'INTERRUPTED')
            self.assertFalse(result['run_complete'])
            self.assertEqual(len(result['sources']), 1)
            self.assertTrue(event.is_set())
            self.assertIs(signal.getsignal(signal.SIGINT), original_handler)

    def test_sigint_sets_the_shared_event_and_restores_the_handler(self):
        event = threading.Event()
        original_handler = signal.getsignal(signal.SIGINT)
        def interrupt_here(*args, **kwargs):
            signal.raise_signal(signal.SIGINT)
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp)/'case'
            with patch('engine.api.run_de_search', side_effect=interrupt_here):
                with self.assertRaises(KeyboardInterrupt):
                    fit_case(short_case(), target, profile='demo', cancel_event=event)
            result = json.loads((target/'result.json').read_text(encoding='utf-8'))
            self.assertEqual(result['status'], 'INTERRUPTED')
            self.assertFalse(result['run_complete'])
            self.assertEqual(result['sources'], [])
            self.assertTrue(event.is_set())
            self.assertIs(signal.getsignal(signal.SIGINT), original_handler)

    def test_sigint_while_event_lock_is_held_does_not_deadlock(self):
        with tempfile.TemporaryDirectory() as tmp:
            child = mp.get_context('spawn').Process(target=_locked_sigint_probe,
                args=(str(Path(tmp)/'case'),))
            child.start()
            child.join(timeout=15)
            if child.is_alive():
                child.terminate(); child.join(timeout=5)
                self.fail('SIGINT deadlocked on the shared Event lock')
            self.assertEqual(child.exitcode, 0)

    def test_closure_cannot_swallow_sigint_without_a_traceback(self):
        event = threading.Event()
        created = []
        def face_without_work(*args, **kwargs):
            face = _FaceRun.__new__(_FaceRun)
            face.state = {}
            created.append(face)
            return face
        def swallow_without_traceback(self):
            try:
                signal.raise_signal(signal.SIGINT)
            except KeyboardInterrupt:
                self.state.update(status='CLOSURE_INTERRUPTED_CHECKPOINT_RETAINED_REQUIRES_REVIEW')
        de = SimpleNamespace(population=np.zeros((1,6)), population_energies=np.array([1.]),
                             nit=0, success=True, message='Controlled no-work interruption test')
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp)/'case'
            with patch('engine.api._pool', return_value=_NoWorkPool()), \
                 patch('engine.api.run_de_search', return_value=de), \
                 patch('engine.api.select_candidates', return_value=[{'theta':[1.,.3,30.,0.,.2,.004]}]), \
                 patch('engine.api._NonzeroRun', side_effect=face_without_work), \
                 patch.object(ClosureRun, 'run', swallow_without_traceback):
                with self.assertRaises(KeyboardInterrupt):
                    fit_case(short_case(), target, profile='demo', cancel_event=event)
            result = json.loads((target/'result.json').read_text(encoding='utf-8'))
            self.assertEqual(result['status'], 'INTERRUPTED')
            self.assertEqual(len(result['sources']), 1)
            self.assertEqual(len(created), 1)
            self.assertNotIn('traceback', created[0].state)
            self.assertTrue(event.is_set())

    def test_local_refinement_guard_observes_shared_cancel(self):
        case, _ = _validate_case(short_case())
        config = _config(case, 1, 'demo')
        seed = dict(theta=[1., .3, 30., 0., .2, .004])
        event = threading.Event()
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp)/'case'
            root = _prepare(target, case, config)
            write(target/'seed.json', seed)
            run = _NonzeroRun(root, config, {'id':'local', 'hybrid_phi':True, 'x_scale':'jac'},
                seed, case, target/'case.json', 'initial', reference_theta=None,
                seed_source=target/'seed.json', output_override=target/'local',
                shared_deadline=time.time()+30)
            run.cancel_event = event
            run.guard()
            event.set()
            with self.assertRaises(KeyboardInterrupt):
                run.guard()

            # The unchanged evaluation loop also polls cancellation during a
            # blocked forward call; it must not wait for the 30-second worker.
            event.clear()
            context = mp.get_context('spawn')
            ready = context.Event()
            run.pool = context.Pool(1, initializer=_ready_worker, initargs=(ready,))
            timer = threading.Timer(.15, event.set)
            try:
                self.assertTrue(ready.wait(15))
                started = time.monotonic()
                timer.start()
                with patch('hybrid_support.worker_predict', _slow_forward):
                    with self.assertRaises(KeyboardInterrupt):
                        run.evaluate([dict(theta=seed['theta'], accuracy='nominal')], 'validation')
                self.assertLess(time.monotonic()-started, 3.)
            finally:
                timer.cancel()
                children = list(run.pool._pool)
                run.pool.terminate(); run.pool.join(); run.pool = None
                self.assertTrue(all(not child.is_alive() for child in children))


if __name__ == '__main__':
    unittest.main()
