"""Boundary evidence retention only: no physical forwards or optimization."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import numpy as np

from engine import api
from test_engine_inputs import static_case


def fixture(directory):
    case = static_case()
    case.update(times=list(range(101)), xy_true=np.zeros((101, 2)).tolist(), residual_sigma=1.)
    case, bounds = api._validate_case(case)
    config = api._config(case, 1, 'paper')
    theta = (bounds.lower + bounds.upper)/2
    theta[1] = bounds.upper[1]
    point = dict(id='original_source/best', theta=theta.tolist(),
        lineage_id='12345', comparison_key=case['case_id'],
        chi2={'third':202.}, discrepancy_scale=0.)
    policy = config['crossfit_review']
    report = dict(samples=[], normalized_tolerance=policy['boundary_normalized_tolerance'],
        steps=policy['boundary_probe_steps'], no_KKT_certificate=True,
        no_joint_no_descent_certificate=True)
    for index, distance in enumerate([0.]+policy['boundary_probe_steps']):
        probe = theta.copy()
        probe[1] = bounds.lower[1]+(1-distance)*(bounds.upper[1]-bounds.lower[1])
        raw = np.full(202, float(index+1))
        norm = np.linalg.norm(raw)
        report['samples'].append(dict(status='COMPLETE', parameter='q', edge=np.float64(1.),
            inward_distance=np.float64(distance), theta=probe,
            D={level:norm for level in ('tight', 'third')},
            raw_residuals={level:raw.copy() for level in ('tight', 'third')},
            chi2={level:np.float64(raw@raw) for level in ('tight', 'third')},
            tight_third_vector_difference=np.float64(0.)))
    pool = Mock()
    state = dict(case_sha256='a'*64, config_sha256='b'*64, manifest_sha256='c'*64,
        integration=dict(nominal=case['nominal_integration'], tight=case['tight_integration'],
            third=api.third_settings(case, config['third_integration'])))
    run = SimpleNamespace(out=Path(directory), state=state, config=config,
        pool=pool, start_pool=Mock(), save=Mock())
    return case, bounds, point, report, run, pool


class BoundaryProvenanceTests(unittest.TestCase):
    def test_all_probes_arrays_scalars_and_exact_identity_are_saved(self):
        with tempfile.TemporaryDirectory() as temp:
            case, bounds, point, report, run, pool = fixture(temp)
            with patch.object(api.ClosureRun, 'all_boundary_diagnostics', return_value=report):
                checked = api._boundary_check(run, point, case, bounds)
            path = Path(temp)/'boundary_raw.json'
            saved = json.loads(path.read_text(encoding='utf-8'))
            self.assertIs(saved['report_generation_completed'], True)
            self.assertIs(saved['scientific_acceptance'], False)
            self.assertEqual(saved['point_theta'], point['theta'])
            self.assertEqual(saved['point_id'], point['id'])
            self.assertEqual(saved['case_sha256'], run.state['case_sha256'])
            self.assertEqual(saved['config_sha256'], run.state['config_sha256'])
            self.assertEqual(saved['manifest_sha256'], run.state['manifest_sha256'])
            self.assertEqual(saved['integration'], run.state['integration'])
            self.assertEqual(saved['residual_sigma'], case['residual_sigma'])
            self.assertEqual(saved['effective_bounds']['upper'], bounds.upper.tolist())
            self.assertEqual(saved['expected_residual_size'], 202)
            self.assertEqual(len(saved['report']['samples']), 3)
            # The two strictly worse, non-minimum probes must not disappear.
            for index, sample in enumerate(saved['report']['samples']):
                self.assertEqual(sample['theta'], report['samples'][index]['theta'].tolist())
                self.assertEqual(sample['raw_residuals']['tight'], [float(index+1)]*202)
                self.assertEqual(sample['raw_residuals']['third'], [float(index+1)]*202)
                self.assertEqual(sample['chi2']['third'], 202*(index+1)**2)
            self.assertFalse(checked['issues'])
            self.assertFalse(checked['significant_fixed_nuisance_descent'])
            self.assertEqual(checked['raw_report_file'], path.name)
            self.assertEqual(checked['raw_report_sha256'], hashlib.sha256(path.read_bytes()).hexdigest())
            pool.terminate.assert_called_once_with()
            pool.join.assert_called_once_with()
            run.save.assert_called_once_with()
            self.assertIsNone(run.pool)

    def test_original_numerical_review_unchanged(self):
        with tempfile.TemporaryDirectory() as temp:
            case, bounds, point, report, run, _ = fixture(temp)
            context = dict(bounds=dict(lower=bounds.lower, upper=bounds.upper), expected_size=202,
                sigma=case['residual_sigma'], ceiling=case['threshold_D'])
            expected = api.boundary_review(report, point, context, run.config['crossfit_review'])
            with patch.object(api.ClosureRun, 'all_boundary_diagnostics', return_value=report):
                actual = api._boundary_check(run, point, case, bounds)
            for key, value in expected.items():
                self.assertEqual(actual[key], value)

    def test_invalid_forward_probe_is_not_filtered(self):
        with tempfile.TemporaryDirectory() as temp:
            case, bounds, point, report, run, _ = fixture(temp)
            sample = report['samples'][1]
            report['samples'][1] = {key:sample[key] for key in
                ('parameter', 'edge', 'inward_distance', 'theta')}
            report['samples'][1].update(status='INVALID_FORWARD', error='fixture failure')
            with patch.object(api.ClosureRun, 'all_boundary_diagnostics', return_value=report):
                checked = api._boundary_check(run, point, case, bounds)
            saved = json.loads((Path(temp)/'boundary_raw.json').read_text())
            self.assertEqual(saved['report']['samples'][1]['status'], 'INVALID_FORWARD')
            self.assertEqual(saved['report']['samples'][1]['error'], 'fixture failure')
            self.assertEqual(checked['issues'][0]['status'], 'INVALID_FORWARD')

    def test_review_error_does_not_erase_raw_report(self):
        with tempfile.TemporaryDirectory() as temp:
            case, bounds, point, report, run, pool = fixture(temp)
            with patch.object(api.ClosureRun, 'all_boundary_diagnostics', return_value=report), \
                    patch.object(api, 'boundary_review', side_effect=ValueError('fixture review failure')):
                with self.assertRaisesRegex(ValueError, 'review failure'):
                    api._boundary_check(run, point, case, bounds)
            saved = json.loads((Path(temp)/'boundary_raw.json').read_text())
            self.assertEqual(len(saved['report']['samples']), 3)
            self.assertIs(saved['scientific_acceptance'], False)
            pool.terminate.assert_called_once_with()
            pool.join.assert_called_once_with()

    def test_interruption_does_not_create_complete_report(self):
        with tempfile.TemporaryDirectory() as temp:
            case, bounds, point, _, run, pool = fixture(temp)
            with patch.object(api.ClosureRun, 'all_boundary_diagnostics', side_effect=api.Interrupted('finite budget')), \
                    patch.object(api, 'boundary_review') as review:
                with self.assertRaises(api.Interrupted):
                    api._boundary_check(run, point, case, bounds)
            self.assertFalse((Path(temp)/'boundary_raw.json').exists())
            review.assert_not_called()
            pool.terminate.assert_called_once_with()
            pool.join.assert_called_once_with()
            run.save.assert_called_once_with()

    def test_pool_termination_error_still_joins_saves_and_never_returns_pass(self):
        with tempfile.TemporaryDirectory() as temp:
            case, bounds, point, report, run, pool = fixture(temp)
            pool.terminate.side_effect = RuntimeError('fixture pool error')
            with patch.object(api.ClosureRun, 'all_boundary_diagnostics', return_value=report), \
                    patch.object(api, 'boundary_review') as review:
                with self.assertRaisesRegex(RuntimeError, 'pool error'):
                    api._boundary_check(run, point, case, bounds)
            saved = json.loads((Path(temp)/'boundary_raw.json').read_text())
            self.assertIs(saved['scientific_acceptance'], False)
            pool.join.assert_called_once_with()
            run.save.assert_called_once_with()
            self.assertIsNone(run.pool)
            review.assert_not_called()

    def test_empty_boundary_set_is_saved_without_inventing_probes(self):
        with tempfile.TemporaryDirectory() as temp:
            case, bounds, point, report, run, _ = fixture(temp)
            point['theta'][1] = (bounds.lower[1]+bounds.upper[1])/2
            report['samples'] = []
            with patch.object(api.ClosureRun, 'all_boundary_diagnostics', return_value=report):
                checked = api._boundary_check(run, point, case, bounds)
            saved = json.loads((Path(temp)/'boundary_raw.json').read_text())
            self.assertEqual(saved['report']['samples'], [])
            self.assertEqual(checked['samples'], [])


if __name__ == '__main__':
    unittest.main()
