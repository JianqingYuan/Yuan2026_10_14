"""Necessary scientific checks; no DE/TRF search is run by these tests."""
from copy import deepcopy
import math
import threading
import time
import unittest
from unittest.mock import patch

import numpy as np
from engine.fit_validation import _fixed_point_check, _payload, validate_endpoint
from experiments.api import smoke_case


def evidence_at(score):
    point = dict(chi2=score, residuals=[math.sqrt(score), 0., 0., 0.], settings={})
    return dict(theta=[1., 0., 10., 0., 0., .01],
                levels={key:deepcopy(point) for key in ('nominal', 'tight', 'selected')})


class FixedPointChecks(unittest.TestCase):
    def check(self, fitted, injected):
        case = dict(precision_criterion=dict(kind='absolute_delta_chi2', tolerance=.01))
        data = {'fitted':evidence_at(fitted)}
        payload = dict(sigma=1., truth_skip_reason='Different theory')
        result = dict(chi2=fitted, residuals=data['fitted']['levels']['selected']['residuals'])
        if injected is not None:
            data['injected'] = evidence_at(injected)
        return _fixed_point_check(case, result, payload, data)

    def test_audit_extreme_counterexample_is_rejected(self):
        result = self.check(300.5097064102233, 200.55422430892628)
        self.assertFalse(result['passed'])
        self.assertTrue(result['numerical_checks_passed'])
        self.assertFalse(result['truth_baseline']['passed'])
        self.assertAlmostEqual(result['truth_baseline']['excess'], 99.95548210129704)

    def test_fit_below_injected_is_allowed_without_truth_seeding(self):
        result = self.check(180., 200.)
        self.assertTrue(result['passed'])
        self.assertFalse(result['truth_baseline']['reference_used_as_optimizer_seed'])
        self.assertTrue(result['no_global_optimum_certificate'])

    def test_original_precision_ceiling_is_not_known_lower_allowance(self):
        result = self.check(200.005, 200.)
        self.assertTrue(result['numerical_checks_passed'])
        self.assertFalse(result['truth_baseline']['passed'])
        self.assertFalse(result['passed'])
        self.assertEqual(result['checks']['endpoint_precision']['tolerance'], .01)
        self.assertEqual(result['truth_baseline']['numerical_allowance'], 1e-8)

    def test_check_not_applicable_is_not_reported_as_truth_pass(self):
        result = self.check(182.683013686247, None)
        self.assertTrue(result['passed'])
        self.assertFalse(result['truth_baseline']['applicable'])
        self.assertIsNone(result['truth_baseline']['passed'])

    def test_precision_problem_cannot_be_hidden_by_good_truth_score(self):
        case = dict(precision_criterion=dict(kind='absolute_delta_chi2', tolerance=.01))
        data = {'fitted':evidence_at(180.), 'injected':evidence_at(200.)}
        data['injected']['levels']['nominal']['chi2'] = 201.
        result = _fixed_point_check(case, dict(chi2=180., residuals=[math.sqrt(180.),0,0,0]),
                                    dict(sigma=1.), data)
        self.assertFalse(result['passed'])
        self.assertFalse(result['checks']['injected_precision']['passed'])

    def test_saved_score_or_residual_mismatch_is_rejected(self):
        case = dict(precision_criterion=dict(kind='absolute_delta_chi2', tolerance=.01))
        data = {'fitted':evidence_at(182.)}
        result = _fixed_point_check(case, dict(chi2=188., residuals=[math.sqrt(188.),0,0,0]),
                                    dict(sigma=1., truth_skip_reason='Different theory'), data)
        self.assertFalse(result['passed'])
        self.assertFalse(result['numerical_checks_passed'])

    def test_cancellation_precedes_any_work(self):
        event = threading.Event()
        event.set()
        with self.assertRaises(KeyboardInterrupt):
            validate_endpoint({}, {}, time.time()+60, event)

    def test_expired_budget_never_starts_subprocess(self):
        with patch('engine.fit_validation._payload', return_value={}), \
             patch('engine.fit_validation.subprocess.Popen') as launch:
            result = validate_endpoint({}, {}, time.time()-1)
        launch.assert_not_called()
        self.assertEqual(result['status'], 'VALIDATION_BUDGET_EXHAUSTED')

    def test_real_two_epoch_point_can_be_recomputed_in_clean_runtime(self):
        from engine.api import predict
        from hybrid_support import third_settings
        case = smoke_case()
        case.update(fit_pipeline='s301', fit_pipeline_version='s301-portable-v1')
        theta = case['metadata']['theta_true']
        settings = third_settings(case, dict(relative_tolerance=1e-13,
                        absolute_tolerance=1e-15, max_step=1250.))
        raw = (predict(theta, case['times'], integration=settings,
                       theory_options=case['fit_theory_options']) - np.asarray(case['xy_true'])).ravel()
        weighted = raw / case['residual_sigma']
        result = dict(theta=theta, residuals=raw.tolist(), chi2=float(weighted @ weighted),
                      best_candidate_checks_passed=True)
        checked = validate_endpoint(case, result, time.time()+30)
        self.assertTrue(checked['passed'], checked)
        self.assertTrue(checked['truth_baseline']['applicable'])

    def test_bounds_and_residual_consistency_checked_before_integration(self):
        case = smoke_case()
        result = dict(theta=case['metadata']['theta_true'], residuals=[0.]*4, chi2=3.,
                      best_candidate_checks_passed=True)
        with self.assertRaisesRegex(ValueError, 'disagrees'):
            _payload(case, result)

    def test_recovered_legacy_precision_pair_and_common_comparison_are_distinct(self):
        case = smoke_case()
        actual = deepcopy(case['tight_integration'])
        stricter = dict(actual, relative_tolerance=actual['relative_tolerance']*.1)
        result = dict(theta=case['metadata']['theta_true'], residuals=[0.]*4, chi2=0.,
            best_candidate_checks_passed=True, residual_integration=actual,
            legacy_record=dict(integration_check=dict(nominal_settings=actual, tight_settings=stricter)))
        payload = _payload(case, result)
        self.assertEqual(payload['integrations']['nominal'], actual)
        self.assertEqual(payload['integrations']['tight'], stricter)
        self.assertEqual(payload['integrations']['comparison'], case['tight_integration'])

    def test_observed_only_alias_is_supported(self):
        case = smoke_case()
        del case['xy_true']
        result = dict(theta=case['metadata']['theta_true'], residuals=[0.]*4, chi2=0.,
                      best_candidate_checks_passed=True, residual_integration=case['nominal_integration'])
        payload = _payload(case, result)
        self.assertEqual(payload['observed'], case['xy_observed'])

    def test_legacy_minima_use_common_tight_score_not_native_score(self):
        case = dict(precision_criterion=dict(kind='absolute_delta_chi2', tolerance=.01))
        data = {'fitted':evidence_at(180.), 'injected':evidence_at(200.)}
        data['fitted']['levels']['comparison'] = deepcopy(data['fitted']['levels']['selected'])
        data['fitted']['levels']['comparison']['chi2'] = 179.999
        data['injected']['levels']['comparison'] = deepcopy(data['injected']['levels']['selected'])
        result = _fixed_point_check(case, dict(chi2=180., residuals=[math.sqrt(180.),0,0,0]),
                                    dict(sigma=1., pipeline='legacy'), data)
        self.assertTrue(result['passed'])
        self.assertEqual(result['comparison_endpoint']['chi2'], 179.999)
        self.assertEqual(result['comparison_endpoint']['residual_accuracy'], 'tight')

    def test_effective_legacy_defaults_and_theory_option_alias(self):
        case = smoke_case()
        result = dict(theta=case['metadata']['theta_true'], residuals=[0.]*4, chi2=0.,
            best_candidate_checks_passed=True, residual_integration=case['nominal_integration'],
            nominal_integration=case.pop('nominal_integration'),
            tight_integration=case.pop('tight_integration'),
            precision_criterion=dict(kind='absolute_delta_chi2', tolerance=.01))
        case.pop('precision_criterion', None)
        case['theory_options'] = case.pop('fit_theory_options')
        payload = _payload(case, result)
        self.assertEqual(payload['theory_options'], case['theory_options'])
        self.assertEqual(payload['integrations']['comparison'], result['tight_integration'])
        self.assertEqual(payload['precision_criterion'], result['precision_criterion'])


if __name__ == '__main__':
    unittest.main()
