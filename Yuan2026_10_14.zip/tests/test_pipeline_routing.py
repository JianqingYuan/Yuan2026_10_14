"""Pipeline identity, atomic legacy pairs, and no-fit redraw regressions."""
from contextlib import redirect_stdout
import copy
import io
import json
from pathlib import Path
import sys
import tempfile
from types import ModuleType
import unittest
from unittest.mock import Mock, patch

import main
import postprocess
from experiments.api import iter_cases
from run_state import digest, load_task, pipeline_provenance, write_json, pair_input_fingerprint
from test_collection import fixture_run, load, save


def result_for(case, *, complete=True, profile='paper'):
    return dict(case_id=case['case_id'], fit_theory=case['fit_theory'], profile=profile,
        result_is_demo=profile == 'demo', run_complete=complete,
        status='COMPLETED' if complete else 'INCOMPLETE_OR_BUDGET_LIMIT',
        scientific_checks_passed=False, **pipeline_provenance(case))


class PipelineRoutingTests(unittest.TestCase):
    def test_all_pipeline_plans_are_cheap_and_preserve_model_counts(self):
        for selector in ('paper', 'legacy', 's301'):
            for mode in ('demo', 'recompute'):
                with self.subTest(selector=selector, mode=mode), tempfile.TemporaryDirectory() as name:
                    target = Path(name) / 'no_write'
                    with patch('experiments.api._observations', side_effect=AssertionError('Observation I/O')), \
                         redirect_stdout(io.StringIO()) as output:
                        self.assertEqual(main.run(['--mode', mode, '--suite', 'all', '--fit-pipeline', selector,
                            '--dry-run', '--output', str(target)]), 0)
                    self.assertIn('12 model fits' if mode == 'demo' else '15660 model fits', output.getvalue())
                    self.assertFalse(target.exists())

    def test_default_routes_suite_flows_and_cli_overrides_setting(self):
        options = main._parser().parse_args(['--mode', 'recompute', '--suite', 'all'])
        plan = main._pipeline_plan(options)
        self.assertEqual({suite: item['fit_pipeline'] for suite,item in plan.items()},
                         {'baseline':'legacy', 'extreme':'legacy', 's301':'s301'})
        with patch('settings.FIT_PIPELINE', 'legacy'):
            options = main._parser().parse_args(['--fit-pipeline', 's301'])
        self.assertEqual(options.fit_pipeline, 's301')

    def test_partial_legacy_selection_is_rejected_before_output_or_observations(self):
        for arguments in (['--max-tasks','1'], ['--models','RN'], ['--task-index','0']):
            with self.subTest(arguments=arguments), tempfile.TemporaryDirectory() as name:
                target = Path(name) / 'no_write'
                with patch('experiments.api._observations', side_effect=AssertionError('Observation I/O')):
                    with self.assertRaisesRegex(ValueError, 'coupled ER/RN'):
                        main.run(['--mode','demo','--suite','baseline','--output',str(target), *arguments])
                self.assertFalse(target.exists())

    def test_legacy_internal_workers_rejected_but_parallel_pairs_allowed(self):
        with patch('main._resource_layout', return_value=2):
            with self.assertRaisesRegex(ValueError, 'single-core'):
                main.run(['--mode','demo','--suite','baseline','--workers','4',
                          '--cores-per-fit','2','--dry-run'])
            with redirect_stdout(io.StringIO()):
                self.assertEqual(main.run(['--mode','demo','--suite','baseline',
                    '--workers','4','--cores-per-fit','1','--dry-run']), 0)

    def test_paper_mode_never_calls_fitter_for_any_pipeline(self):
        for selector in ('paper', 'legacy', 's301'):
            with self.subTest(selector=selector), tempfile.TemporaryDirectory() as name:
                target = Path(name)/'redraw'
                with patch('plotting.paper.render_all', return_value=[]), \
                     patch('main._select_cases', side_effect=AssertionError('Fitting catalogue')), \
                     patch('main._run_pair', side_effect=AssertionError('Fitting')), \
                     patch('main._run_task', side_effect=AssertionError('Fitting')), \
                     redirect_stdout(io.StringIO()):
                    self.assertEqual(main.run(['--mode','paper','--fit-pipeline',selector,
                                               '--output',str(target)]), 0)
                plan = load(target/'run.json')
                self.assertEqual(plan['fit_calls'], 0)
                self.assertIs(plan['fit_pipeline_applied'], False)

    def test_invalid_setting_never_starts_a_fit(self):
        with patch('settings.FIT_PIPELINE','typo'), self.assertRaisesRegex(ValueError, 'FIT_PIPELINE'):
            main.run(['--mode','demo','--dry-run'])

    def test_legacy_pair_runs_once_and_writes_two_consistent_records(self):
        cases = list(iter_cases('baseline', indices=[0]))
        module = ModuleType('engine.legacy')
        module.fit_pair = Mock(return_value={case['fit_theory']:result_for(case) for case in cases})
        with tempfile.TemporaryDirectory() as name, patch.dict(sys.modules, {'engine.legacy':module}):
            root = Path(name)
            targets = [root/'tasks'/case['case_id'] for case in cases]
            outcomes = main._run_pair(cases, targets, 1, 'paper')
            self.assertEqual(len(outcomes), 2)
            module.fit_pair.assert_called_once()
            self.assertEqual(module.fit_pair.call_args.args[:2], tuple(cases))
            for case,target in zip(cases,targets):
                saved, result, receipt = load_task(target, expected_case=case, require_complete=True)
                self.assertEqual(pipeline_provenance(saved), pipeline_provenance(result))
                self.assertEqual(result['pair_input_sha256'], pair_input_fingerprint(*cases))
                self.assertEqual(receipt['pair_input_sha256'], result['pair_input_sha256'])
            with self.assertRaises(FileExistsError):
                main._run_pair(cases, targets, 1, 'paper')
            self.assertEqual(module.fit_pair.call_count, 1)

    def test_legacy_exception_records_both_members_and_interrupt_is_reraised(self):
        cases = list(iter_cases('baseline', indices=[0]))
        module = ModuleType('engine.legacy')
        module.fit_pair = Mock(side_effect=KeyboardInterrupt)
        with tempfile.TemporaryDirectory() as name, patch.dict(sys.modules, {'engine.legacy':module}):
            targets = [Path(name)/'tasks'/case['case_id'] for case in cases]
            with self.assertRaises(KeyboardInterrupt):
                main._run_pair(cases,targets,1,'paper')
            for target in targets:
                self.assertEqual(load(target/'task_receipt.json')['state'], 'FAILED_OR_INTERRUPTED')

    def test_resume_refuses_partial_legacy_pair_without_rewriting_plan(self):
        cases = list(iter_cases('baseline', indices=[0]))
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            options = main._parser().parse_args(['--mode','recompute','--suite','baseline','--max-tasks','2'])
            signature = dict(mode='recompute', suite='baseline', models=['ER','RN'], max_tasks=2,
                task_index=None, science_sha256='a'*64, fit_pipeline_requested='paper',
                fit_pipelines=main._pipeline_plan(options))
            write_json(root/'run.json',dict(signature=signature,state='FINISHED'))
            task = root/'tasks'/cases[0]['case_id']
            task.mkdir(parents=True)
            before = (root/'run.json').read_bytes()
            with patch('main._scientific_source_hash',return_value='a'*64), \
                 patch('main._run_pair') as fitting, redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(ValueError, 'partially saved legacy pair'):
                    main.run(['--mode','recompute','--suite','baseline','--max-tasks','2','--resume',str(root)])
            fitting.assert_not_called()
            self.assertEqual((root/'run.json').read_bytes(),before)

    def test_completed_legacy_pair_is_reused_together(self):
        cases = list(iter_cases('baseline', indices=[0]))
        module = ModuleType('engine.legacy')
        module.fit_pair = Mock(return_value={case['fit_theory']:result_for(case) for case in cases})
        with tempfile.TemporaryDirectory() as name, patch.dict(sys.modules, {'engine.legacy':module}):
            root=Path(name)/'run'
            with patch('main._scientific_source_hash',return_value='a'*64), \
                 patch('postprocess.render_run',return_value=[]), redirect_stdout(io.StringIO()):
                # This is a serial mock test. Never inherit the reader's CPU
                # setting and launch an unmocked full fit in a fresh process.
                argv=['--mode','recompute','--suite','baseline','--workers','1',
                      '--cores-per-fit','1','--max-tasks','2']
                self.assertEqual(main.run([*argv,'--output',str(root)]),0)
                self.assertEqual(main.run([*argv,'--resume',str(root)]),0)
                with self.assertRaisesRegex(ValueError, 'identical science'):
                    main.run([*argv,'--fit-pipeline','s301','--resume',str(root)])
            module.fit_pair.assert_called_once()

    def test_legacy_pair_fingerprint_is_checked_against_both_inputs_before_plotting(self):
        cases=list(iter_cases('baseline',indices=[0]))
        fingerprint=pair_input_fingerprint(*cases)
        rows=[dict(case=case,metadata=case['metadata'],eligible=True,
                   result=dict(result_for(case), pair_input_sha256=fingerprint)) for case in cases]
        self.assertEqual(len(postprocess._paired(rows,'baseline')),1)
        rows[1]['result']['pair_input_sha256']='a'*64
        with self.assertRaisesRegex(ValueError,'fingerprints disagree'):
            postprocess._paired(rows,'baseline')

    def test_legacy_pair_receipt_fingerprint_is_required_and_consistent(self):
        cases=list(iter_cases('baseline',indices=[0]))
        module=ModuleType('engine.legacy')
        module.fit_pair=Mock(return_value={case['fit_theory']:result_for(case) for case in cases})
        with tempfile.TemporaryDirectory() as name, patch.dict(sys.modules,{'engine.legacy':module}):
            targets=[Path(name)/'tasks'/case['case_id'] for case in cases]
            main._run_pair(cases,targets,1,'paper')
            receipt=load(targets[0]/'task_receipt.json')
            receipt['pair_input_sha256']='a'*64
            save(targets[0]/'task_receipt.json',receipt)
            with self.assertRaisesRegex(ValueError,'input fingerprints'):
                load_task(targets[0])

    def test_result_receipt_pipeline_and_version_corruption_is_rejected(self):
        for filename in ('case.json','result.json','task_receipt.json'):
            for field in ('fit_pipeline','fit_pipeline_requested','fit_pipeline_version'):
                with self.subTest(filename=filename,field=field), tempfile.TemporaryDirectory() as name:
                    _,task=fixture_run(Path(name))
                    record=load(task/filename)
                    record[field]='wrong'
                    save(task/filename,record)
                    with self.assertRaises(ValueError):
                        load_task(task)

    def test_collection_rejects_different_requested_pipeline_before_copying(self):
        with tempfile.TemporaryDirectory() as name:
            root=Path(name)
            first,_=fixture_run(root)
            second,_=fixture_run(root,'run_b','case_b_ER')
            plan=load(second/'run.json')
            plan['signature']['fit_pipeline_requested']='paper'
            save(second/'run.json',plan)
            destination=root/'collected'; destination.mkdir()
            with patch('main._scientific_source_hash',return_value='a'*64):
                with self.assertRaisesRegex(ValueError, 'Requested fitting pipelines differ'):
                    postprocess.collect_runs([first,second],destination)
            self.assertEqual(list(destination.iterdir()),[])

    def test_pairing_rejects_different_flows_for_the_same_observations(self):
        cases=list(iter_cases('baseline',indices=[0]))
        rows=[dict(case=case,metadata=case['metadata'],eligible=True) for case in cases]
        rows[1]['case']['fit_pipeline']='s301'
        with self.assertRaisesRegex(ValueError,'Mixed fitting pipelines'):
            postprocess._paired(rows,'baseline')

    def test_legacy_demo_uses_declared_tight_residual(self):
        row=dict(case=dict(xy_true=[[1.,2.],[3.,4.]]), available=False,
                 result=dict(residual_accuracy='tight', residuals=[.1,.2,.3,.4], chi2=2.))
        endpoint=postprocess._demo_endpoint(row)
        self.assertEqual(endpoint['chi2'],2.)
        self.assertEqual(endpoint['prediction'].tolist(),[[1.1,2.2],[3.3,4.4]])


if __name__ == '__main__':
    unittest.main()
