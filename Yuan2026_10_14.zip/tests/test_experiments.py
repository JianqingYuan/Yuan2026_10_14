"""Cheap catalogue checks: no forward model and no optimizer calls."""
import unittest
import json
from pathlib import Path
from experiments.api import (count_cases, describe, iter_cases, list_case_ids, smoke_case,
                             resolve_fit_pipeline, PIPELINE_VERSIONS)


class ExperimentTests(unittest.TestCase):
    def test_paper_counts(self):
        self.assertEqual(count_cases('baseline'),12960)
        self.assertEqual(count_cases('extreme'),2592)
        self.assertEqual(count_cases('s301'),108)
        self.assertEqual(count_cases(),15660)
        self.assertEqual(describe()['datasets'],7830)

    def test_demo_counts_and_label(self):
        self.assertEqual(count_cases(mode='demo'),42)
        self.assertEqual(describe(mode='demo')['datasets'],21)
        for c in iter_cases(mode='demo'):
            self.assertEqual(c['execution_mode'],'demo')
            self.assertEqual(len(c['times']),101)

    def test_identifiers_unique(self):
        ids=list_case_ids()
        self.assertEqual(len(ids),len(set(ids)))
        self.assertTrue(all('/' not in i and '\\' not in i for i in ids))

    def test_models_share_observed_data(self):
        for suite in ('baseline','extreme','s301'):
            cases=list(iter_cases(suite,'demo'))
            for er,rn in zip(cases[::2],cases[1::2]):
                self.assertEqual(er['xy_true'],rn['xy_true'])
                self.assertEqual(er['times'],rn['times'])
                self.assertEqual(er['residual_sigma'],rn['residual_sigma'])
                self.assertEqual(er['dataset_id'],rn['dataset_id'])
                self.assertNotIn('initial_theta',er)
                self.assertNotIn('theta_true',er)

    def test_selection(self):
        self.assertEqual(count_cases('baseline',models='RN',include_noisy=False),80)
        self.assertEqual(count_cases('s301',include_noiseless=False),96)
        self.assertEqual(count_cases('s301',indices=['T000']),2)

    def test_precision_semantics_not_silently_converted(self):
        a=next(iter_cases('baseline',indices=[0]))
        self.assertEqual(a['precision_criterion']['kind'],'absolute_delta_chi2')
        self.assertEqual(a['precision_criterion']['tolerance'],.01)
        self.assertNotIn('threshold_D',a)
        b=next(iter_cases('s301',indices=['T000']))
        self.assertGreater(b['threshold_D'],0)
        self.assertIn('reference_theta',b)

    def test_s301_only_thirty_microarcseconds(self):
        for c in iter_cases('s301',include_noiseless=False):
            self.assertEqual(c['metadata']['noise_uas'],30)

    def test_short_smoke(self):
        self.assertEqual(len(smoke_case()['times']),2)

    def test_invalid_selection(self):
        for kwargs in ({'suite':'other'},{'mode':'other'},{'models':('ER','ER')},{'models':('BAD',)}):
            with self.assertRaises(ValueError):
                count_cases(**kwargs)

    def test_frozen_input_schema_and_no_private_paths(self):
        root=Path(__file__).resolve().parents[1]
        for suite in ('baseline','extreme','s301'):
            raw=(root/'configs'/f'{suite}.json').read_text(encoding='utf-8')
            self.assertNotIn('/thfs',raw)
            self.assertNotIn('C:\\',raw)
            config=json.loads(raw)
            self.assertTrue(config['full_unified_refit_has_not_been_run'])
            for truth in config['truths']:
                self.assertEqual(len(truth['theta_true']),6)
                for model in ('ER','RN'):
                    self.assertEqual(len(truth['bounds_by_theory'][model]),6)

    def test_seeds_are_fixed_distinct_and_no_warm_start(self):
        for c in iter_cases(mode='demo'):
            expected=5 if c['fit_pipeline']=='legacy' else 2
            self.assertEqual(len(c['run_seeds']),expected)
            self.assertEqual(len(set(c['run_seeds'])),expected)
            self.assertNotIn('best_theta',c)
            self.assertNotIn('initial_population',c)
            self.assertNotIn('x0',c)

    def test_paper_workflow_mapping_and_force_switches(self):
        for suite, expected in [('baseline','legacy'),('extreme','legacy'),('s301','s301')]:
            self.assertEqual(resolve_fit_pipeline(suite),expected)
            case=next(iter_cases(suite,'demo'))
            self.assertEqual(case['fit_pipeline'],expected)
            self.assertEqual(case['fit_pipeline_version'],PIPELINE_VERSIONS[expected])
            for forced in ('legacy','s301'):
                chosen=next(iter_cases(suite,'demo',fit_pipeline=forced))
                self.assertEqual(chosen['fit_pipeline'],forced)
                self.assertEqual(chosen['xy_true'],case['xy_true'])
                self.assertEqual(chosen['bounds'],case['bounds'])
        with self.assertRaises(ValueError):
            resolve_fit_pipeline('baseline','unknown')

    def test_forced_legacy_s301_root_is_explicit_not_historical(self):
        er,rn=list(iter_cases('s301','paper',indices=['T000'],fit_pipeline='legacy'))
        self.assertEqual(er['legacy_optimizer_seed'],rn['legacy_optimizer_seed'])
        self.assertEqual(er['legacy_optimizer_seed'],2026103001)
        self.assertEqual(er['legacy_variant'],'extreme')
        self.assertIn('not historical',er['metadata']['legacy_seed_policy'])
        self.assertEqual(er['precision_criterion']['kind'],'absolute_delta_chi2')

    def test_all_s301_input_arrays_present(self):
        all_cases=list(iter_cases('s301'))
        self.assertEqual(len(all_cases),108)
        self.assertEqual(len({c['dataset_id'] for c in all_cases}),54)
        self.assertEqual(sum(not c['metadata']['add_noise'] for c in all_cases),12)

    def test_explicit_data_generator(self):
        from experiments.generate import generate_observations
        d=generate_observations('baseline','q01_p00_s00_r00')
        self.assertEqual(d['xy_observed'].shape,(101,2))
        with self.assertRaises(ValueError):
            generate_observations('baseline','missing')


if __name__=='__main__':
    unittest.main()
