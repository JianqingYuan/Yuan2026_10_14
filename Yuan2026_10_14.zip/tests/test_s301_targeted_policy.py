"""Finite targeted policy and lower-point negatives, with no physical forwards."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import time
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
from engine import api, s301_targeted as target
from hybrid_support import Interrupted
from test_engine_inputs import static_case


def point(name='p', score=10., lineage='11', valid=True, q=.3):
    return dict(id=name, theta=[1., q, 30., 0., .2, .004],
        chi2={level: score for level in target.LEVELS}, lineage_id=lineage,
        numerical_evidence_valid=valid, discrepancy_scale=1e-7,
        comparison_key='same-problem', counts_as_independent_source=True,
        truth_seed_used=False)


class PolicyTests(unittest.TestCase):
    def test_caps_are_finite_without_resetting_original_budget(self):
        config = api._config(static_case(), 1, 'paper')
        policy = config['targeted_completion']
        self.assertEqual(policy['max_nfev'], 1000)
        self.assertEqual(policy['max_stages_per_lineage'], 2)
        self.assertEqual(policy['max_stage_seconds'], 1800)
        self.assertEqual(config['ftol'], 1e-8)
        self.assertEqual(config['xtol'], 1e-12)
        self.assertEqual(policy['automatic_retries'], 0)
        demo = api._config(static_case(), 1, 'demo')['targeted_completion']
        self.assertEqual(demo['max_nfev'], 8)
        self.assertEqual(demo['max_stage_seconds'], 15)

    def test_clean_consensus_does_not_trigger_work(self):
        self.assertFalse(target.needs_completion(dict(passed=True), {}, dict(passed=True)))
        for ranking, boundary, guard in ((False, {}, True), (True, {}, False),
                (True, {'a': dict(issues=[], significant_fixed_nuisance_descent=True)}, True)):
            self.assertTrue(target.needs_completion(dict(passed=ranking), boundary, dict(passed=guard)))

    def test_lower_failed_point_vetoes_two_source_consensus(self):
        points = [point(), point('second', lineage='22'), point('failed', 9., valid=False)]
        self.assertTrue(api.rank_candidates(points[:2])['passed'])
        review = target.lower_guard(points, [])
        self.assertFalse(review['passed'])
        self.assertIs(review['lower_failed_candidate_veto'], True)

    def test_tiny_lower_actual_without_raw_disposition_vetoes(self):
        raw = dict(theta=point(q=.31)['theta'], accuracy='tight', chi2=10.-1e-12)
        review = target.lower_guard([point()], [raw])
        self.assertFalse(review['passed'])
        self.assertEqual(len(review['unresolved_lower_actual_candidates']), 1)

    def test_do_not_mix_scores_at_different_precisions(self):
        p = point(); p['chi2']['nominal'] = 2.
        raw = dict(theta=point(q=.31)['theta'], accuracy='nominal', chi2=3.)
        self.assertTrue(target.lower_guard([p], [raw])['passed'])

    def test_complete_same_point_disposition_can_change_precision_order(self):
        p, other = point(), point('other', score=11., q=.31)
        other['chi2']['tight'] = 9.
        raw = dict(theta=other['theta'], accuracy='tight', chi2=9.)
        self.assertTrue(target.lower_guard([p, other], [raw])['passed'])

    def test_same_point_score_tamper_blocks(self):
        raw = dict(theta=point()['theta'], accuracy='tight', chi2=1.)
        self.assertFalse(target.lower_guard([point()], [raw])['passed'])

    def test_no_valid_endpoint_never_passes(self):
        self.assertFalse(target.lower_guard([point(valid=False)], [])['passed'])

    def test_source_selection_never_transfers_other_lineage(self):
        chosen = target.source_start('11', [point(score=12.), point('other', 1., '22')], [])
        self.assertEqual(chosen['chi2']['third'], 12.)
        self.assertIsNone(target.source_start('33', [point()], []))

    def test_upper_conditioning_uses_actual_declared_bound(self):
        _, bounds = api._validate_case(static_case())
        self.assertTrue(target.upper_face_eligible(point(q=.5)['theta'], bounds, .001))
        self.assertFalse(target.upper_face_eligible(point(q=.3)['theta'], bounds, .001))
        with self.assertRaises(ValueError):
            target.upper_face_eligible(point(q=.51)['theta'], bounds, .001)

    def test_actual_minima_are_separate_by_precision_and_include_FD(self):
        state = {}
        for i, (level, residual) in enumerate((('tight', [3., 0.]), ('nominal', [4., 0.]), ('tight', [2., 0.]))):
            target.retain_actual(state, dict(id=i, status='COMPLETE', theta=point()['theta'],
                residual=residual, accuracy=level, category='fit', role='finite_difference_probe'), 1., 2)
        self.assertEqual(state['actual_minima']['tight']['chi2'], 4.)
        self.assertEqual(state['actual_minima']['nominal']['chi2'], 16.)
        self.assertEqual(state['actual_minima']['tight']['raw_residuals'], [2., 0.])

    def test_short_preflight_cannot_replace_real_minimum(self):
        state = {}
        target.retain_actual(state, dict(status='COMPLETE', theta=point()['theta'],
            residual=[0., 0.], accuracy='tight', category='preflight'), 1., 2)
        self.assertNotIn('actual_minima', state)

    def test_malformed_actual_raw_is_not_silently_ignored(self):
        state = {}
        target.retain_actual(state, dict(status='COMPLETE', theta=point()['theta'],
            residual=[0.], accuracy='tight', category='fit'), 1., 2)
        self.assertTrue(state['invalid_actual_evidence'])

    def test_budget_and_previous_failure_never_become_pass(self):
        self.assertFalse(api._stage_outcome([dict(id='new', status=target.BUDGET)])[0])
        result = api._stage_outcome([dict(id='old', status='FAILED'), dict(id='new', status=target.COMPLETE)])
        self.assertFalse(result[0]); self.assertEqual(result[1], 'FAILED')

    def test_iteration_limit_can_be_closed_without_rewriting_old_failure(self):
        stages = [dict(id='old', status='CROSS_FIT_LOCAL_BUDGET_EXHAUSTED_DIAGNOSTICS_RETAINED', lineage_id='11'),
            dict(id='continued', status=target.COMPLETE, lineage_id='11')]
        before = deepcopy(stages)
        result = target.completion_disposition(stages, True)
        self.assertTrue(result['targeted_completion_closed'])
        self.assertEqual(result['superseded_iteration_stages'][0]['replacement_id'], 'continued')
        self.assertEqual(stages, before)

    def test_continuation_cannot_close_other_lineage_or_later_budget(self):
        limited = dict(id='old', status='CROSS_FIT_LOCAL_BUDGET_EXHAUSTED_DIAGNOSTICS_RETAINED', lineage_id='11')
        complete = dict(id='continued', status=target.COMPLETE, lineage_id='22')
        self.assertFalse(target.completion_disposition([limited, complete], True)['targeted_completion_closed'])
        complete['lineage_id'] = '11'
        self.assertFalse(target.completion_disposition([complete, limited], True)['targeted_completion_closed'])

    def test_failed_final_checks_and_hard_errors_cannot_be_closed(self):
        stages = [dict(id='old', status='CROSS_FIT_LOCAL_BUDGET_EXHAUSTED_DIAGNOSTICS_RETAINED', lineage_id='11'),
            dict(id='continued', status=target.COMPLETE, lineage_id='11')]
        self.assertFalse(target.completion_disposition(stages, False)['targeted_completion_closed'])
        for status in ('FAILED', 'WALL_BUDGET_EXHAUSTED', 'FORWARD_BUDGET_EXHAUSTED', target.BUDGET):
            stages[0]['status'] = status
            self.assertFalse(target.completion_disposition(stages, True)['targeted_completion_closed'])

    def test_no_case_ids_or_known_answers_in_policy(self):
        text = Path(target.__file__).read_text(encoding='utf-8')
        for marker in ('T054', 'T071', 'T088', 'T091', '2026142005', '227.071827'):
            self.assertNotIn(marker, text)


class FakePool:
    def terminate(self): pass
    def join(self): pass


class AnalyticBase:
    """A tiny finite quadratic, no physical forward or multiprocessing."""
    def guard(self):
        if time.time() >= self.shared_deadline:
            raise Interrupted('shared_case_wall_budget_exhausted')
    def start_pool(self): self.guard(); self.pool = FakePool()
    def preflight(self): self.guard()
    def save(self): pass
    def residual(self, z):
        self.guard()
        theta = self.bounds.denormalize(z)
        weighted = np.asarray(z)-self.goal
        raw = weighted*self.sigma
        target.retain_actual(self.state, dict(status='COMPLETE', theta=theta.tolist(),
            residual=raw.tolist(), category='fit', accuracy='tight', role='solver_function'), self.sigma, 6)
        self.base_cache = (None, weighted, np.zeros((3, 2)))
        return weighted
    def jacobian(self, z): return np.eye(6)
    def audit_crossfit_point(self, theta, label):
        self.guard()
        vector = (self.bounds.normalize(theta)-self.goal)*self.sigma
        raw = dict(theta=list(theta), **{level: vector.tolist() for level in target.LEVELS})
        return raw, dict(theta=list(theta), D={level:float(np.linalg.norm(vector)) for level in target.LEVELS})


class AnalyticRun(target.TargetedRunMixin, AnalyticBase):
    # The reduced numerical dispatch is checked with an analytic Jacobian; the
    # real finite-difference/phase stencil receives a separate direct test.
    def _face_jacobian(self, reduced, full, active): return np.eye(6)[:, active]


class RunnerTests(unittest.TestCase):
    def make_run(self, folder, mode='full6d'):
        case, bounds = api._validate_case(static_case())
        run = AnalyticRun()
        run.case, run.bounds, run.config = case, bounds, api._config(case, 1, 'demo')
        run.config['targeted_completion']['max_nfev'] = 100
        run.arm = dict(id='analytic', mode=mode, hybrid_phi=True, x_scale='jac')
        run.shared_deadline, run.out, run.pool = time.time()+30, Path(folder), None
        run.seed_spec = dict(source_theta=bounds.denormalize(np.full(6, .4)).tolist())
        run.state = dict(actual_jacobian_batches=0, solver_accepted=None)
        run.sigma, run.goal, run.phi_index = .01, np.full(6, .6), 4
        return run

    def test_actual_full_scipy_solve_preserves_minimum_and_original_stops(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = self.make_run(tmp); run.run()
            self.assertEqual(run.state['status'], target.COMPLETE)
            self.assertEqual(run.state['targeted_optimizer']['ftol'], 1e-8)
            self.assertEqual(run.state['targeted_optimizer']['xtol'], 1e-12)
            self.assertEqual(run.state['new_independent_DE_sources'], 0)
            saved = json.loads((Path(tmp)/'diagnostic_residuals.json').read_text())
            self.assertGreaterEqual(len(saved['candidates']), 2)
            self.assertLess(run.state['actual_minima']['tight']['chi2'], 1e-12)

    def test_exact_upper_face_keeps_original_other_coordinates_free(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = self.make_run(tmp, 'qmax5d'); run.run()
            self.assertEqual(run.state['status'], target.COMPLETE)
            theta = run.state['solver_accepted']['theta']
            self.assertEqual(theta[1], run.bounds.upper[1])
            np.testing.assert_allclose(run.bounds.normalize(theta)[[0, 2, 3, 4, 5]], .6, atol=1e-6)

    def test_exhausted_shared_budget_never_resets(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = self.make_run(tmp); run.shared_deadline = time.time()-1
            run.run()
            self.assertEqual(run.state['status'], target.BUDGET)
            self.assertFalse(run.state['optimizer_invoked'])
            self.assertLessEqual(run.targeted_deadline, run.shared_deadline)

    def test_original_source_mismatch_prevents_solver(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = self.make_run(tmp)
            run.seed_spec['source_raw_residuals'] = dict(tight=[100.]*6)
            run.run()
            self.assertEqual(run.state['status'], 'FAILED')
            self.assertFalse(run.state['optimizer_invoked'])

    def test_keyboard_interrupt_is_not_swallowed_as_scientific_success(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = self.make_run(tmp)
            with patch('engine.s301_targeted.least_squares', side_effect=KeyboardInterrupt):
                with self.assertRaises(KeyboardInterrupt): run.run()
            self.assertEqual(run.state['status'], 'INTERRUPTED_CHECKPOINT_RETAINED')
            self.assertIsNone(run.pool)

    def test_real_conditional_stencil_never_varies_charge(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = self.make_run(tmp, 'qmax5d')
            run.targeted_deadline = run.optimization_deadline = run.shared_deadline
            run.state['phase'] = 'targeted_optimization'
            visited = []
            original = run.residual
            def residual(z):
                visited.append(np.asarray(z).copy())
                return original(z)
            run.residual = residual
            active = [0, 2, 3, 4, 5]
            def full(x):
                z = np.ones(6); z[active] = x
                return z
            matrix = target.TargetedRunMixin._face_jacobian(run, np.full(5, .4), full, active)
            self.assertEqual(matrix.shape, (6, 5))
            self.assertTrue(all(z[1] == 1. for z in visited))
            np.testing.assert_allclose(matrix[:, [0, 1, 2, 4]], np.eye(6)[:, [0, 2, 3, 5]], atol=1e-8)


class ControllerTests(unittest.TestCase):
    def test_clean_case_creates_no_targeted_stage(self):
        case, bounds = api._validate_case(static_case())
        config = api._config(case, 1, 'demo')
        with tempfile.TemporaryDirectory() as tmp, patch('engine.api._TargetedRun') as runner:
            result = api._targeted_completion(None, config, case, bounds, Path(tmp), time.time()+20,
                threading.Event(), [False], [point()], [], [], [], [], dict(passed=True), {}, [11, 22])
            self.assertTrue(result[0]['passed'])
            runner.assert_not_called()

    def test_one_full_continuation_per_source_stops_when_original_checks_agree(self):
        case, bounds = api._validate_case(static_case())
        config = api._config(case, 1, 'demo')
        points = [point('a', 10., '11'), point('b', 12., '22')]
        stages, actual, rejected, invalid, calls = [], [], [], [], []
        deadline = time.time()+20
        def construct(root, config, arm, seed, case, case_path, attempt, **kwargs):
            calls.append(dict(arm=deepcopy(arm), seed=deepcopy(seed), deadline=kwargs['shared_deadline']))
            out = kwargs['output_override']; out.mkdir()
            return SimpleNamespace(state=dict(status=target.COMPLETE), out=out, run=lambda: None)
        def collect(run, source, bounds, case, points, rejected):
            points.append(point(run.out.name, 5., str(source), q=.31))
        def boundary(*args, **kwargs):
            out = kwargs['output_override']; out.mkdir()
            return SimpleNamespace(state={}, out=out)
        with tempfile.TemporaryDirectory() as tmp, patch('engine.api._TargetedRun', side_effect=construct), \
                patch('engine.api._collect', side_effect=collect), patch('engine.api._NonzeroRun', side_effect=boundary), \
                patch('engine.api._boundary_check', return_value=dict(issues=[], significant_fixed_nuisance_descent=False)):
            ranking, boundaries = api._targeted_completion(None, config, case, bounds, Path(tmp), deadline,
                threading.Event(), [False], points, rejected, stages, actual, invalid,
                dict(passed=False), {}, [11, 22])
        self.assertTrue(ranking['passed'])
        self.assertEqual(len(calls), 2)
        self.assertEqual({row['arm']['mode'] for row in calls}, {'full6d'})
        self.assertTrue(all(row['deadline'] == deadline for row in calls))
        self.assertEqual({row['seed']['lineage_id'] for row in calls}, {'11', '22'})
        self.assertTrue(all(row['seed']['new_independent_DE_sources'] == 0 for row in calls))
        self.assertEqual(len(points), 4)  # Both original candidates remain.

    def test_historical_absolute_gate_route_is_not_migrated(self):
        case = static_case(); case['precision_criterion'] = dict(kind='absolute_delta_chi2', tolerance=.01)
        case, bounds = api._validate_case(case)
        with tempfile.TemporaryDirectory() as tmp, patch('engine.api._TargetedRun') as runner:
            api._targeted_completion(None, api._config(case, 1, 'demo'), case, bounds,
                Path(tmp), time.time()+20, threading.Event(), [False], [point()], [], [], [], [],
                dict(passed=False), {}, [11, 22])
            runner.assert_not_called()

    def fit_closed_case(self, lower_unverified=False):
        case = static_case()
        case['run_seeds'] = [11, 22]
        de = SimpleNamespace(population=np.zeros((1, 6)), population_energies=np.array([100.]),
            nit=2, success=False, message='Test finite DE stage')
        def stage(*args, **kwargs):
            out = kwargs['output_override']; out.mkdir()
            return SimpleNamespace(out=out, state=dict(status='CROSS_FIT_LOCAL_BUDGET_EXHAUSTED_DIAGNOSTICS_RETAINED',
                solver_accepted=dict(status=0)), run=lambda: None)
        def continued(*args, **kwargs):
            out = kwargs['output_override']; out.mkdir()
            state = dict(status=target.COMPLETE, solver_accepted=dict(status=1))
            if lower_unverified:
                state['actual_minima'] = dict(tight=dict(theta=point(q=.33)['theta'],
                    accuracy='tight', chi2=4.9, raw_residuals=[np.sqrt(4.9)*.01, 0., 0., 0.]))
            return SimpleNamespace(out=out, state=state, run=lambda: None)
        def collect(run, source, bounds, case, points, rejected):
            score = 5. if '_targeted_' in run.out.name else (10. if source == 11 else 12.)
            p = point(run.out.name, score, str(source), q=.31 if source == 11 else .32)
            p['raw_residuals'] = dict(theta=p['theta'], **{level:[np.sqrt(score)*.01, 0., 0., 0.] for level in target.LEVELS})
            points.append(p)
        with tempfile.TemporaryDirectory() as tmp, patch('engine.api._pool', return_value=FakePool()), \
                patch('engine.api.run_de_search', return_value=de), \
                patch('engine.api.select_candidates', return_value=[dict(theta=point()['theta'])]), \
                patch('engine.api._NonzeroRun', side_effect=stage), \
                patch('engine.api._TargetedRun', side_effect=continued), \
                patch('engine.api._collect', side_effect=collect), \
                patch('engine.api._boundary_check', return_value=dict(issues=[], significant_fixed_nuisance_descent=False)):
            return api.fit_case(case, Path(tmp)/'fit', profile='demo')

    def test_public_adapter_can_close_old_iteration_limits_without_relabelling(self):
        result = self.fit_closed_case()
        self.assertEqual(result['status'], 'COMPLETED')
        self.assertTrue(result['run_complete'])
        self.assertTrue(result['scientific_checks_passed'])
        self.assertFalse(result['initial_stages_complete'])
        self.assertTrue(result['targeted_completion_closed'])
        self.assertEqual(len(result['superseded_iteration_stages']), 2)
        self.assertEqual(result['stages'][0]['status'], 'CROSS_FIT_LOCAL_BUDGET_EXHAUSTED_DIAGNOSTICS_RETAINED')

    def test_public_adapter_cannot_close_with_lower_unverified_actual(self):
        result = self.fit_closed_case(lower_unverified=True)
        self.assertFalse(result['scientific_checks_passed'])
        self.assertFalse(result['targeted_completion_closed'])
        self.assertTrue(result['unresolved_lower_actual_candidates'])


if __name__ == '__main__': unittest.main()
