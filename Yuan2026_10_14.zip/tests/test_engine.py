"""Short physical/numerical checks; no historical long experiment is launched."""
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest

import numpy as np
from engine.api import (_config, _validate_case, fit_case, predict, verify_vendor, _pool,
                        _collect, _prepare, _FaceRun)
from jacobian import difference_jacobian, phase_column, write
from spherical_geodesics.astrometry.parameters import resolve_theory_bounds


def short_case():
    theta = [1., .3, 30., 0., .2, .003989951603342995]
    times = [0., 1., 2., 3., 4., 5.]
    nominal = dict(relative_tolerance=1e-10, absolute_tolerance=1e-12, max_step=.5)
    tight = dict(relative_tolerance=1e-12, absolute_tolerance=1e-14, max_step=.25)
    observed = predict(theta, times, integration=tight)
    observed[2,0] += 1e-3
    return dict(case_id='tiny_numerical_smoke_ER', fit_theory='ER',
        fit_mode='nonzero_residual_diagnostic', times=times, xy_true=observed.tolist(),
        residual_sigma=.01, threshold_D=1e-7,
        nominal_integration=nominal, tight_integration=tight,
        bounds=dict(M=[.95,1.05], q=[.1,.5], rho0=[29.9,30.1],
            drho_dt0=[-.001,.001], phi0=[.19,.21], dphi_dt0=[.0038,.0042]),
        run_seeds=[12345,67890])


class EngineTests(unittest.TestCase):
    def test_vendor_hashes(self):
        self.assertEqual(verify_vendor()['included_core_file_count'], 25)

    def test_forward_and_exact_phase_derivative(self):
        case = short_case()
        bounds = resolve_theory_bounds('ER', case['bounds'])
        theta = np.array([1., .3, 30., 0., .2, .004])
        z = bounds.normalize(theta)
        def forward(value):
            return predict(bounds.denormalize(value), case['times'],
                integration=case['tight_integration']).reshape(-1)
        jac = difference_jacobian(forward, z, 1e-5)
        phase = phase_column(forward(z).reshape(-1,2), bounds.scale[4])
        np.testing.assert_allclose(jac[:,4], phase, rtol=2e-7, atol=2e-9)

    def test_historical_precision_semantics(self):
        case = short_case()
        del case['threshold_D']
        case['precision_criterion'] = dict(kind='absolute_delta_chi2', tolerance=.01)
        clean, _ = _validate_case(case)
        self.assertTrue(clean['internal_threshold_is_schema_placeholder'])
        self.assertEqual(clean['precision_criterion']['tolerance'], .01)
        self.assertEqual(clean['fit_mode'], 'nonzero_residual_diagnostic')

    def test_historical_precision_decision_ignores_vector_placeholder(self):
        case = short_case()
        case['precision_criterion'] = dict(kind='absolute_delta_chi2', tolerance=.01)
        case, bounds = _validate_case(case)
        theta = [1., .3, 30., 0., .2, .004]
        with tempfile.TemporaryDirectory() as tmp:
            run = SimpleNamespace(out=Path(tmp), state=dict(status='FINISHED'))
            def collect_difference(delta_chi2):
                # Deliberately enormous tight/third vector difference: it must
                # remain a diagnostic rather than become an invented old gate.
                raw = dict(theta=theta, nominal=[10.]+[0.]*11,
                    tight=[np.sqrt(1e6 + delta_chi2)*.01]+[0.]*11,
                    third=[100.]+[0.]*11)
                audit = dict(theta=theta, D={k:float(np.linalg.norm(raw[k])) for k in ('nominal','tight','third')})
                run.state['crossfit_audits'] = {'solver_returned':audit}
                write(run.out / 'diagnostic_residuals.json', dict(candidates={'solver_returned':raw}))
                points, rejected = [], []
                _collect(run, 12345, bounds, case, points, rejected)
                return points[0]
            self.assertTrue(collect_difference(.005)['numerical_evidence_valid'])
            self.assertFalse(collect_difference(.02)['numerical_evidence_valid'])

    def test_q0_closure_preserves_exact_face_and_source(self):
        case = short_case()
        case['bounds']['q'] = [0., .5]
        case, bounds = _validate_case(case)
        config = _config(case, 1, 'demo')
        theta = [1., .3, 30., 0., .2, .004]
        source_audit = {}
        from hybrid_support import third_settings
        levels = dict(nominal=case['nominal_integration'], tight=case['tight_integration'],
            third=third_settings(case, config['third_integration']))
        for level, integration in levels.items():
            residual = (predict(theta, case['times'], integration=integration) - np.asarray(case['xy_true'])).reshape(-1)
            source_audit[level] = dict(D=float(np.linalg.norm(residual)))
        changed = list(theta); changed[1] = 0.
        seed = dict(theta=changed, source_theta=theta, expected_baseline=source_audit,
            source_id='12345', lineage_id='12345', random_seed=12345)
        import time
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp) / 'case'
            root = _prepare(directory, case, config)
            write(directory / 'seed.json', seed)
            arm = dict(id='q0', mode='face_q0', hybrid_phi=True, x_scale='jac')
            run = _FaceRun(root, config, arm, seed, case, directory / 'case.json', 'test',
                seed_source=directory / 'seed.json', output_override=directory / 'q0',
                shared_deadline=time.time()+120)
            run.run()
            self.assertIn('DIAGNOSTIC', run.state['status'], run.state.get('error'))
            self.assertEqual(run.state['solver_accepted']['theta'][1], 0.)
            self.assertEqual(run.state['seed_provenance']['source_theta'], theta)
            self.assertEqual(run.state['independent_stochastic_source_count'], 0)

    def test_demo_is_actual_fit_and_keeps_incomplete_status(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp) / 'case'
            result = fit_case(short_case(), directory, workers=1, profile='demo')
            self.assertTrue(result['result_is_demo'])
            self.assertEqual(len(result['sources']), 2, result.get('stop_reason'))
            self.assertTrue(result['candidates'], result.get('stop_reason'))
            self.assertTrue(np.isfinite(result['chi2']))
            self.assertEqual(len(result['residuals']), 12)
            self.assertEqual(result['run_seeds'], [12345,67890])
            self.assertFalse(result['optimizer_truth_seed_used'])
            if any('BUDGET' in item['status'] for item in result['stages']):
                self.assertFalse(result['run_complete'])
                self.assertFalse(result['scientific_checks_passed'])
            with self.assertRaises(FileExistsError):
                fit_case(short_case(), directory, profile='demo')

    def test_multiprocess_forward_matches_serial(self):
        case = short_case()
        config = _config(case, 2, 'demo')
        from hybrid_support import worker_predict
        task = dict(id=1, theta=[1.,.3,30.,0.,.2,.004], accuracy='tight')
        serial = _pool(case, config, 1)
        try:
            one = serial.map(worker_predict,[task])[0]
        finally:
            serial.terminate(); serial.join()
        parallel = _pool(case, config, 2)
        try:
            two = parallel.map(worker_predict,[task])[0]
        finally:
            parallel.terminate();parallel.join()
        np.testing.assert_array_equal(one['xy'], two['xy'])


if __name__ == '__main__':
    unittest.main()
