"""Pure/mock native deadline regressions; no physical orbit calls."""
from pathlib import Path
import json
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from engine import api
from hybrid_support import Interrupted
from test_demo_evidence import case


class NativeDeadlineTests(unittest.TestCase):
    def test_invalid_absolute_deadline_rejected_before_preparation(self):
        for value in (True, '123', float('nan'), float('inf')):
            with self.subTest(value=value), patch.object(api, '_prepare') as prepare:
                with self.assertRaises(ValueError):
                    api.fit_case(case(), 'unused', absolute_deadline=value)
                prepare.assert_not_called()

    def test_expired_share_does_not_create_a_worker_or_accept_an_endpoint(self):
        with tempfile.TemporaryDirectory() as folder, patch.object(api.mp, 'get_context') as spawn:
            result = api.fit_case(case(), Path(folder)/'result', profile='demo',
                                  absolute_deadline=time.monotonic()-1.)
            spawn.assert_not_called()
            self.assertFalse(result['scientific_checks_passed'])
            self.assertFalse(result['run_complete'])
            self.assertEqual(result['status'], 'BUDGET_OR_INTERRUPTION')
            self.assertTrue(result['preparation_included_in_budget'])

    def test_preparation_cannot_restart_the_native_clock(self):
        clock = [100.]
        original = api._prepare
        def prepare(*args):
            root = original(*args)
            clock[0] = 150.
            return root
        with tempfile.TemporaryDirectory() as folder, \
             patch.object(api.time, 'monotonic', side_effect=lambda: clock[0]), \
             patch.object(api, '_prepare', side_effect=prepare), \
             patch.object(api.mp, 'get_context') as spawn:
            result = api.fit_case(case(), Path(folder)/'result', profile='demo', absolute_deadline=140.)
            spawn.assert_not_called()
            self.assertEqual(result['elapsed_seconds'], 50.)
            self.assertFalse(result['scientific_checks_passed'])

    def test_monotonic_guards_do_not_depend_on_epoch_clock(self):
        run = SimpleNamespace(config={'portable_monotonic_deadline': 5.}, cancel_event=None)
        with patch.object(api.time, 'monotonic', return_value=6.), \
             patch.object(api.time, 'time', return_value=-1e20):
            with self.assertRaisesRegex(Interrupted, 'shared_case_wall_budget'):
                api._PortableIO.guard(run)
            mapper = api._DEMap({}, run.config, None, None, 1e20, None)
            with self.assertRaisesRegex(Interrupted, 'shared_case_wall_budget'):
                mapper.guard()

    def test_cancel_precedes_expired_native_share(self):
        cancelled = SimpleNamespace(is_set=lambda: True)
        run = SimpleNamespace(config={'portable_monotonic_deadline': -1.}, cancel_event=cancelled)
        with self.assertRaises(KeyboardInterrupt):
            api._PortableIO.guard(run)

    def test_late_decode_cannot_return_or_leave_an_accepted_result(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'result.json'
            api.write(path, dict(status='COMPLETED', run_complete=True, scientific_checks_passed=True))
            real_loads = json.loads
            clock = [1.]
            def late_loads(raw):
                result = real_loads(raw)
                clock[0] = 11.
                return result
            with patch.object(api.json, 'loads', side_effect=late_loads), \
                 patch.object(api.time, 'monotonic', side_effect=lambda: clock[0]):
                result = api._read_final_result(path, 10., SimpleNamespace(is_set=lambda: False))
            self.assertFalse(result['scientific_checks_passed'])
            self.assertFalse(json.loads(path.read_text())['run_complete'])
            self.assertEqual(result['status'], 'BUDGET_OR_INTERRUPTION')

    def test_late_cancel_preserves_false_flags_and_raises(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'result.json'
            api.write(path, dict(status='COMPLETED', run_complete=True, scientific_checks_passed=True))
            with self.assertRaises(KeyboardInterrupt):
                api._read_final_result(path, 1e30, SimpleNamespace(is_set=lambda: True))
            self.assertEqual(json.loads(path.read_text())['status'], 'INTERRUPTED')


if __name__ == '__main__':
    unittest.main()
