"""Reporting regressions with synthetic endpoints; no orbit or optimizer calls."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from experiments.api import iter_cases
from plotting.paper import DEFAULT_DATA, render_all
import postprocess
from run_state import digest, write_json


def synthetic_rows():
    rows = []
    for index, case in enumerate(iter_cases('s301', include_noiseless=False)):
        result = dict(case_id=case['case_id'], fit_theory=case['fit_theory'],
            profile='paper', result_is_demo=False, run_complete=True,
            scientific_checks_passed=True, best_candidate_checks_passed=True,
            status='COMPLETED', theta=list(case['metadata']['theta_true']),
            chi2=float(index + 100), best_attempt=1,
            reliability_attempts=[dict(attempt=1, status='COMPLETED')],
            synthetic_test_fixture=True,
            **{key: case[key] for key in ('fit_pipeline', 'fit_pipeline_requested', 'fit_pipeline_version')})
        rows.append(dict(case=case, metadata=case['metadata'], result=result,
                         available=True, eligible=True))
    return rows


class ReliabilityReportingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = synthetic_rows()

    def tearDown(self):
        plt.close('all')

    def unaccepted_rows(self):
        rows = copy.deepcopy(self.rows)
        result = rows[0]['result']
        result.update(scientific_checks_passed=False, status='NEEDS_REVIEW_BEST_FOUND',
                      best_attempt=2, chi2=25., diagnostic_best=dict(chi2=1., checks_passed=False),
                      reliability_attempts=[dict(attempt=i, status='NEEDS_REVIEW') for i in (1, 2, 3)])
        return rows

    def test_completed_unaccepted_endpoint_remains_eligible(self):
        row = self.unaccepted_rows()[0]
        case, result = row['case'], row['result']
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            task = root/'tasks'/case['case_id']
            receipt = dict(case_id=case['case_id'], case_sha256=digest(case),
                           profile='paper', state='FINISHED', engine_status=result['status'],
                           **{key: case[key] for key in ('fit_pipeline', 'fit_pipeline_requested', 'fit_pipeline_version')})
            for name, document in [('case.json', case), ('result.json', result), ('task_receipt.json', receipt)]:
                write_json(task/name, document)
            loaded = postprocess._load(root)
            self.assertEqual(len(loaded), 1)
            self.assertTrue(loaded[0]['available'])
            self.assertTrue(loaded[0]['eligible'])
            self.assertFalse(loaded[0]['result']['scientific_checks_passed'])

    def test_every_case_reported_and_unchecked_lower_value_stays_diagnostic(self):
        rows = self.unaccepted_rows()
        rows[1]['available'] = rows[1]['eligible'] = False
        rows[1]['result'].update(best_candidate_checks_passed=False, scientific_checks_passed=False)
        report = postprocess._reliability_report(rows, 'recompute')
        self.assertEqual(len(report['cases']), 96)
        first, second = report['cases'][:2]
        self.assertEqual(first['best_chi2'], 25.)
        self.assertEqual(first['diagnostic_best']['chi2'], 1.)
        self.assertEqual(first['best_attempt'], 2)
        self.assertEqual(len(first['attempts']), 3)
        self.assertEqual(first['interpretation'], 'BEST_FOUND_NEEDS_REVIEW')
        self.assertEqual(second['interpretation'], 'NO_VALIDATED_ENDPOINT')
        self.assertIsNone(second['best_chi2'])

    def test_controller_attempt_fields_have_explicit_index_and_human_round(self):
        rows = self.unaccepted_rows()[:1]
        result = rows[0]['result']
        result.pop('reliability_attempts')
        result.pop('best_attempt')
        result.update(selected_attempt_index=0, selected_result_path='attempt_01/result.json',
                      reliability=dict(attempts=[dict(attempt_index=0, budget_factor=1.)]))
        report = postprocess._reliability_report(rows, 'recompute')['cases'][0]
        self.assertEqual(report['best_attempt'], 1)
        self.assertEqual(report['selected_attempt_index'], 0)
        self.assertEqual(report['selected_result_path'], 'attempt_01/result.json')
        self.assertEqual(report['attempts'][0]['budget_factor'], 1.)

    def test_complete_grid_keeps_unaccepted_point_and_emits_notice(self):
        rows = self.unaccepted_rows()
        with tempfile.TemporaryDirectory() as directory, \
                patch('postprocess._load', return_value=rows), \
                patch('postprocess._summary', return_value=Path(directory)/'summary.pdf'), \
                patch('postprocess._collection_geometry', return_value=[]), \
                patch('plotting.paper.render_all', return_value=[]) as render:
            postprocess.render_run(directory)
            root = Path(directory)
            cache = json.loads((root/'plot_data/s301.json').read_text())
            self.assertEqual(len(cache['rows']), 48)
            self.assertEqual(cache['rows'][0]['chi2_ER'], 25.)
            self.assertEqual(cache['rows'][0]['delta_chi2'], 101. - 25.)
            self.assertIn('NEEDS REVIEW: 1/96', render.call_args.kwargs['figure_notes'][13])
            status = json.loads((root/'plot_status.json').read_text())
            self.assertEqual(status['needs_review_endpoints'], 1)
            self.assertEqual(status['paper_layout_figures_generated'], [13])
            report = json.loads((root/'reliability_report.json').read_text())
            self.assertEqual(report['cases'][0]['best_chi2'], 25.)
            self.assertFalse(report['cases'][0]['scientific_checks_passed'])
            sidecar = json.loads((root/'plot_data/reliability.json').read_text())
            self.assertIn('NEEDS REVIEW', sidecar['figure_notes']['13'])

    def test_missing_numerical_endpoint_does_not_become_paper_data(self):
        rows = self.unaccepted_rows()
        rows[0]['available'] = rows[0]['eligible'] = False
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'s301.json'
            self.assertEqual(postprocess._s301_cache(postprocess._paired(rows, 's301'), path), [])
            self.assertFalse(path.exists())
        report = postprocess._reliability_report(rows, 'recompute')
        self.assertEqual(len(report['cases']), 96)

    def test_new_cache_redraw_keeps_notice_and_historical_replay_is_unchanged(self):
        original = (DEFAULT_DATA/'s301.json').read_bytes()
        snapshots = []

        def save_figure(figure, *args, **kwargs):
            snapshots.append([text.get_text() for text in figure.texts])

        with tempfile.TemporaryDirectory() as directory, \
                patch('matplotlib.figure.Figure.savefig', autospec=True, side_effect=save_figure):
            root = Path(directory)
            render_all(root/'historical', [13])
            self.assertFalse(any('NEW FITS' in text for texts in snapshots for text in texts))
            snapshots.clear()
            rows = self.unaccepted_rows()
            postprocess._s301_cache(postprocess._paired(rows, 's301'), root/'s301.json')
            write_json(root/'reliability.json', dict(figure_notes=postprocess._figure_reliability_notes(rows, [13])))
            render_all(root/'new', [13], data_dir=root)
            self.assertTrue(any('NEEDS REVIEW: 1/96' in text for texts in snapshots for text in texts))
        self.assertEqual((DEFAULT_DATA/'s301.json').read_bytes(), original)

    def test_demo_is_always_labelled_and_summary_keeps_review_points(self):
        rows = self.unaccepted_rows()[:2]
        report = postprocess._reliability_report(rows, 'demo')
        self.assertTrue(all(case['interpretation'] == 'DEMO_ONLY' for case in report['cases']))
        snapshots = []

        def save_figure(figure, *args, **kwargs):
            snapshots.append((figure.axes[0].get_title(), len(figure.axes[0].collections),
                              [text.get_text() for text in figure.texts]))

        with tempfile.TemporaryDirectory() as directory, \
                patch('matplotlib.figure.Figure.savefig', autospec=True, side_effect=save_figure):
            postprocess._summary(rows, directory, 'demo')
        self.assertIn('not paper statistics', snapshots[0][0])
        self.assertEqual(snapshots[0][1], 2)
        self.assertTrue(any('1 displayed endpoint(s) need review' in text for text in snapshots[0][2]))


if __name__ == '__main__':
    unittest.main()
