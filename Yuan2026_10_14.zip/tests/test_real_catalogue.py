"""Real catalogue initialization plus bounded physical smoke regressions.

No complete catalogue orbit is fitted. Prediction checks use only the first
two archived epochs; the sole optimizer check uses six short RN-generated
epochs and the explicitly reduced demo budget.
"""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from engine.api import CORE, VENDOR, _config, _pool, _validate_case, fit_case, predict
from experiments.api import PIPELINE_VERSIONS, iter_cases
import hybrid_support
from hybrid_support import third_settings, worker_init, worker_predict
from metric_library import build_theory
from spherical_geodesics import CoordinateTimeSettings
from spherical_geodesics.astrometry import TheoryForwardModel
from spherical_geodesics.astrometry.parameters import resolve_theory_bounds


ROOT = Path(__file__).resolve().parents[1]
SUITES = ('baseline', 'extreme', 's301')
SELECTORS = ('paper', 'legacy', 's301')


def catalogue_case(suite, model, noisy, selector='paper'):
    """Read one actual saved dataset, including its original noise recipe."""
    return next(iter_cases(suite, models=(model,), fit_pipeline=selector,
        include_noiseless=not noisy, include_noisy=noisy))


def rn_smoke_case():
    """A physical RN test target, never a saved paper result or fit seed."""
    theta = [1., .3, 30., 0., .2, .003989951603342995]
    times = [0., 1., 2., 3., 4., 5.]
    nominal = dict(relative_tolerance=1e-10, absolute_tolerance=1e-12, max_step=.5)
    tight = dict(relative_tolerance=1e-12, absolute_tolerance=1e-14, max_step=.25)
    observed = predict(theta, times, theory='RN', integration=tight)
    observed[2, 0] += 1e-3
    return dict(case_id='tiny_physical_RN_regression', fit_theory='RN',
        fit_pipeline='s301', fit_pipeline_requested='s301',
        fit_pipeline_version=PIPELINE_VERSIONS['s301'],
        fit_mode='nonzero_residual_diagnostic', times=times,
        xy_true=observed.tolist(), xy_observed=observed.tolist(),
        fit_theory_options={}, theory_options={}, residual_sigma=.01,
        threshold_D=1e-7, nominal_integration=nominal, tight_integration=tight,
        bounds=dict(M=[.95, 1.05], q=[.1, .5], rho0=[29.9, 30.1],
            drho_dt0=[-.001, .001], phi0=[.19, .21], dphi_dt0=[.0038, .0042]),
        run_seeds=[12345, 67890], wall_seconds=120.)


class RealCatalogueTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original_options = {
            suite: json.loads((ROOT/'configs'/f'{suite}.json').read_text(encoding='utf-8'))['theory_options']
            for suite in SUITES
        }
        cls.third = json.loads((VENDOR/'numerical_template.json').read_text(encoding='utf-8'))['third_integration']

    def test_real_catalogue_pipeline_and_model_specific_options(self):
        # The old failure was hidden by artificial fixtures with empty options.
        # S301's actual catalogue explicitly supplies ER's base_frame.
        self.assertIn('base_frame', self.original_options['s301'])
        for suite in SUITES:
            for selector in SELECTORS:
                expected = ('s301' if suite == 's301' else 'legacy') if selector == 'paper' else selector
                for noisy in (False, True):
                    er, rn = [catalogue_case(suite, model, noisy, selector) for model in ('ER', 'RN')]
                    with self.subTest(suite=suite, selector=selector, noisy=noisy):
                        self.assertEqual(er['xy_observed'], rn['xy_observed'])
                        self.assertEqual(er['times'], rn['times'])
                        for case in (er, rn):
                            self.assertEqual(case['metadata']['add_noise'], noisy)
                            self.assertEqual(case['fit_pipeline'], expected)
                            self.assertEqual(case['fit_pipeline_requested'], selector)
                            self.assertEqual(case['fit_pipeline_version'], PIPELINE_VERSIONS[expected])
                            self.assertEqual(len(case['run_seeds']), 5 if expected == 'legacy' else 2)
                            self.assertEqual(case['fit_theory_options'], case['theory_options'])
                        self.assertEqual(er['fit_theory_options'], self.original_options[suite])
                        expected_rn = {key: value for key, value in self.original_options[suite].items()
                                       if key != 'base_frame'}
                        self.assertEqual(rn['fit_theory_options'], expected_rn)
                        self.assertNotIn('base_frame', rn['theory_options'])

    def test_all_real_case_models_and_worker_initializers_construct(self):
        for suite in SUITES:
            for selector in SELECTORS:
                for noisy in (False, True):
                    for theory in ('ER', 'RN'):
                        with self.subTest(suite=suite, selector=selector, noisy=noisy, theory=theory):
                            case = catalogue_case(suite, theory, noisy, selector)
                            saved = deepcopy(case)
                            # Construction and worker initialization must be cheap:
                            # failure here must not wait for a scientific deadline.
                            with patch.object(TheoryForwardModel, 'predict', side_effect=AssertionError('Unexpected integration')):
                                model = TheoryForwardModel(theory, build_theory,
                                    settings=CoordinateTimeSettings(**case['nominal_integration']),
                                    theory_options=case['fit_theory_options'])
                                self.assertEqual(model.theory_name, theory)
                                worker_init(str(CORE), case, self.third)
                            self.assertEqual(set(hybrid_support._WORKER['models']), {'nominal', 'tight', 'third'})
                            for worker_model in hybrid_support._WORKER['models'].values():
                                self.assertEqual(worker_model.theory_name, theory)
                            np.testing.assert_array_equal(hybrid_support._WORKER['truth'], case['xy_observed'])
                            np.testing.assert_array_equal(hybrid_support._WORKER['times'], case['times'])
                            self.assertEqual(case, saved)

    def test_portable_validator_accepts_real_s301_workflow_cases(self):
        for suite in SUITES:
            for noisy in (False, True):
                for theory in ('ER', 'RN'):
                    with self.subTest(suite=suite, noisy=noisy, theory=theory):
                        original = catalogue_case(suite, theory, noisy, 's301')
                        case, bounds = _validate_case(original)
                        self.assertEqual(bounds.ndim, 6)
                        self.assertEqual(case['xy_observed'], original['xy_observed'])
                        self.assertEqual(case['fit_theory_options'], original['fit_theory_options'])

    def test_bad_rn_options_fail_before_any_pool_is_created(self):
        for options_key in ('fit_theory_options', 'theory_options'):
            with self.subTest(options_key=options_key):
                case = catalogue_case('s301', 'RN', True, 's301')
                if options_key == 'theory_options':
                    case.pop('fit_theory_options')
                case[options_key] = {'base_frame': 'einstein'}
                with self.assertRaisesRegex((TypeError, ValueError), 'base_frame'):
                    _validate_case(case)
                config = _config(case, 1, 'demo')
                with patch('engine.api.mp.get_context') as context:
                    with self.assertRaisesRegex((TypeError, ValueError), 'base_frame'):
                        _pool(case, config, 1)
                    context.assert_not_called()

    def test_real_two_epoch_spawn_predictions_match_direct_model(self):
        for suite in SUITES:
            for noisy in (False, True):
                for theory in ('ER', 'RN'):
                    with self.subTest(suite=suite, noisy=noisy, theory=theory):
                        case = catalogue_case(suite, theory, noisy, 's301')
                        for key in ('times', 'xy_true', 'xy_observed'):
                            case[key] = case[key][:2]
                        case, bounds = _validate_case(case)
                        theta = bounds.denormalize(np.full(bounds.ndim, .5))
                        config = _config(case, 1, 'demo')
                        settings = dict(nominal=case['nominal_integration'], tight=case['tight_integration'],
                            third=third_settings(case, config['third_integration']))
                        # Evaluate directly first: a malformed constructor must
                        # fail here, never trigger an initializer respawn storm.
                        expected = {level: predict(theta, case['times'], theory=theory,
                            integration=integration, theory_options=case['fit_theory_options'])
                            for level, integration in settings.items()}
                        pool = _pool(case, config, 1)
                        try:
                            for task_id, level in enumerate(settings, start=1):
                                event = pool.apply_async(worker_predict,
                                    (dict(id=task_id, theta=theta.tolist(), accuracy=level),)).get(timeout=30)
                                self.assertEqual(event['status'], 'COMPLETE', event.get('error'))
                                np.testing.assert_array_equal(event['xy'], expected[level])
                                np.testing.assert_array_equal(event['residual'],
                                    (expected[level]-np.asarray(case['xy_observed'])).reshape(-1))
                        finally:
                            pool.terminate()
                            pool.join()

    def test_tiny_rn_actual_demo_fit_retains_two_sources_and_evidence(self):
        with tempfile.TemporaryDirectory() as temporary:
            result = fit_case(rn_smoke_case(), Path(temporary)/'rn_demo', workers=1, profile='demo')
        self.assertTrue(result['result_is_demo'])
        self.assertEqual(result['fit_theory'], 'RN')
        self.assertEqual(len(result['sources']), 2, result.get('stop_reason'))
        self.assertEqual(result['run_seeds'], [12345, 67890])
        self.assertTrue(result['candidates'], result.get('stop_reason'))
        self.assertTrue(np.isfinite(result['chi2']))
        self.assertEqual(len(result['residuals']), 12)
        self.assertFalse(result['optimizer_truth_seed_used'])
        if any('BUDGET' in stage['status'] for stage in result['stages']):
            self.assertFalse(result['run_complete'])
            self.assertFalse(result['scientific_checks_passed'])


if __name__ == '__main__':
    unittest.main()
