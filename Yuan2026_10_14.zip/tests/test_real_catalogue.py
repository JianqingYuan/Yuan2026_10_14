"""Real catalogue initialization plus bounded physical smoke regressions.

No complete catalogue orbit is fitted. Prediction checks use only the first
two archived epochs; the sole optimizer check uses six short RN-generated
epochs and the explicitly reduced demo budget.
"""
from copy import deepcopy
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from engine import api, s301_targeted
from engine.api import CORE, VENDOR, _config, _pool, _validate_case, fit_case, predict
from experiments.api import PIPELINE_VERSIONS, iter_cases
import hybrid_support
from hybrid_support import third_settings, worker_init, worker_predict
from metric_library import build_theory
from spherical_geodesics import CoordinateTimeSettings
from spherical_geodesics.astrometry import TheoryForwardModel
from spherical_geodesics.astrometry.parameters import resolve_theory_bounds


ROOT = Path(__file__).resolve().parents[1]
SUITES = ('baseline', 'extreme', 's301')
SELECTORS = ('paper', 'legacy', 's301')
SMOKE_EVIDENCE_ENV = 'ER_RN_TEST_EVIDENCE_ROOT'
SMOKE_EVIDENCE_NAME = 'tiny_physical_RN_regression'


@contextmanager
def retained_smoke_directory():
    """Opt-in QA capture; reserve a new destination before any physical work.

    Ordinary unit-test runs still use only a TemporaryDirectory. The opt-in
    preserves that entire directory before cleanup, even if fit/assertion raises.
    It does not retry a fit or change its scientific configuration.
    """
    configured = os.environ.get(SMOKE_EVIDENCE_ENV)
    destination = None
    if configured is not None:
        if not configured.strip() or not Path(configured).is_absolute():
            raise ValueError(SMOKE_EVIDENCE_ENV + ' must name an absolute nonempty directory')
        destination = Path(configured).resolve() / SMOKE_EVIDENCE_NAME
        # Refuse reuse before invoking the fit; never overwrite an earlier run.
        destination.mkdir(parents=True, exist_ok=False)
    with tempfile.TemporaryDirectory() as temporary:
        try:
            yield Path(temporary)
        finally:
            if destination is not None:
                error = sys.exc_info()[1]
                copied = destination / 'result_tree'
                shutil.copytree(temporary, copied)
                files = {p.relative_to(copied).as_posix(): dict(bytes=p.stat().st_size,
                    sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                    for p in sorted(copied.rglob('*')) if p.is_file()}
                with (destination / 'CAPTURE.json').open('x', encoding='utf-8') as stream:
                    json.dump(dict(schema='optional-test-evidence-v1',
                        test='test_tiny_rn_actual_demo_fit_retains_two_sources_and_evidence',
                        capture_complete=True, test_body_raised=error is not None,
                        exception_type=type(error).__name__ if error is not None else None,
                        files=files, automatic_retries=0,
                        scientific_acceptance_not_inferred=True), stream, indent=2, allow_nan=False)


def catalogue_case(suite, model, noisy, selector='paper'):
    """Read one actual saved dataset, including its original noise recipe."""
    return next(iter_cases(suite, models=(model,), fit_pipeline=selector,
        include_noiseless=not noisy, include_noisy=noisy))


def rn_smoke_case():
    """A physical RN test target, never a saved paper result or fit seed."""
    theta = [1., .3, 30., 0., .2, .003989951603342995]
    times = [0., 1., 2., 3., 4., 5.]
    nominal = dict(relative_tolerance=1e-10, absolute_tolerance=1e-12, max_step=.5)
    tight = dict(relative_tolerance=1e-12, absolute_tolerance=1e-14, max_step=.25)
    observed = predict(theta, times, theory='RN', integration=tight)
    observed[2, 0] += 1e-3
    return dict(case_id='tiny_physical_RN_regression', fit_theory='RN',
        fit_pipeline='s301', fit_pipeline_requested='s301',
        fit_pipeline_version=PIPELINE_VERSIONS['s301'],
        fit_mode='nonzero_residual_diagnostic', times=times,
        xy_true=observed.tolist(), xy_observed=observed.tolist(),
        fit_theory_options={}, theory_options={}, residual_sigma=.01,
        threshold_D=1e-7, nominal_integration=nominal, tight_integration=tight,
        bounds=dict(M=[.95, 1.05], q=[.1, .5], rho0=[29.9, 30.1],
            drho_dt0=[-.001, .001], phi0=[.19, .21], dphi_dt0=[.0038, .0042]),
        run_seeds=[12345, 67890], wall_seconds=120.)


def assert_native_completion_contract(test, result):
    """Old iteration history is retained; only explicit same-source closure may cure it.

    This checks the native fit_case contract, not the outer retry controller's
    run_complete flag. Two source records alone are never a science certificate.
    """
    test.assertIsInstance(result['run_complete'], bool)
    test.assertIsInstance(result['scientific_checks_passed'], bool)
    if result['scientific_checks_passed']:
        test.assertTrue(result['run_complete'])
    stages = result['stages']
    if result.get('targeted_completion_closed') is not True:
        test.assertFalse(result.get('superseded_iteration_stages', []))
        if any('BUDGET' in s['status'] or 'FAILED' in s['status'] or
               'INTERRUPTED' in s['status'] for s in stages):
            test.assertFalse(result['run_complete'])
            test.assertFalse(result['scientific_checks_passed'])
        return
    test.assertTrue(result['run_complete'])
    test.assertTrue(result['scientific_checks_passed'])
    test.assertEqual(result['status'], 'COMPLETED')
    complete = {'RECOVERY_VALIDATED', 'DUAL_GATE_PASSED_THIRD_REVIEW',
        'CROSS_FIT_DIAGNOSTIC_COMPLETE_REQUIRES_REVIEW',
        'CLOSURE_DIAGNOSTIC_COMPLETE_REQUIRES_REVIEW',
        'S301_TARGETED_COMPLETE_REQUIRES_REVIEW'}
    iteration = {'LOCAL_NFEV_BUDGET_EXHAUSTED',
        'CROSS_FIT_LOCAL_BUDGET_EXHAUSTED_DIAGNOSTICS_RETAINED',
        'CLOSURE_NFEV_BUDGET_EXHAUSTED_REQUIRES_REVIEW'}
    by_id = {s['id']: (i, s) for i, s in enumerate(stages)}
    test.assertEqual(len(by_id), len(stages))
    pending = [s for s in stages if s['status'] not in complete]
    test.assertTrue(pending, 'A closure must identify an actual earlier limit')
    mapping = result['superseded_iteration_stages']
    test.assertEqual(len(mapping), len(pending))
    test.assertEqual({s['id'] for s in mapping}, {s['id'] for s in pending})
    seeds = result['run_seeds']
    test.assertEqual(len(seeds), 2)
    test.assertEqual(len(set(seeds)), 2)
    lineages = {str(s) for s in seeds}
    test.assertEqual([s['seed'] for s in result['sources']], seeds)
    test.assertTrue(all(s['complete_search_stage'] is True for s in result['sources']))
    for item in mapping:
        old_index, old = by_id[item['id']]
        new_index, new = by_id[item['replacement_id']]
        test.assertTrue(old['status'] in iteration or
            (old['status'] == 'S301_TARGETED_BUDGET_REQUIRES_REVIEW'
             and (old.get('solver') or {}).get('status') == 0))
        test.assertGreater(new_index, old_index)
        test.assertEqual(new['status'], 'S301_TARGETED_COMPLETE_REQUIRES_REVIEW')
        test.assertIn(old['lineage_id'], lineages)
        test.assertEqual(new['lineage_id'], old['lineage_id'])
        test.assertEqual(item['lineage_id'], old['lineage_id'])
        test.assertEqual(item['original_status'], old['status'])
        test.assertIs(item['original_stage_relabelled'], False)
    # Recompute source support and the lower-actual veto from the saved union.
    # Neither is inferred from run_complete or from merely having two seeds.
    points = result['candidates']
    test.assertTrue(points)
    test.assertTrue(all(p['lineage_id'] in lineages for p in points))
    ranking = api.rank_candidates([p for p in points if p['numerical_evidence_valid']])
    test.assertTrue(ranking['passed'])
    test.assertEqual(ranking['independent_sources'], 2)
    test.assertTrue(result['ranking']['passed'])
    test.assertEqual(result['ranking']['independent_best'], ranking['independent_best'])
    guard = s301_targeted.lower_guard(points, result['actual_minimum_candidates'])
    test.assertTrue(guard['passed'])
    test.assertIs(result['lower_failed_candidate_veto'], False)
    test.assertFalse(result['unresolved_lower_actual_candidates'])
    test.assertFalse(result['invalid_actual_evidence'])
    test.assertFalse(result['rejected_stages'])
    test.assertEqual(set(result['boundary_checks']), lineages)
    for boundary in result['boundary_checks'].values():
        test.assertFalse(boundary['issues'])
        test.assertIs(boundary['significant_fixed_nuisance_descent'], False)
    test.assertIs(result['optimizer_truth_seed_used'], False)
    test.assertIs(result['no_global_optimum_certificate'], True)


class CompletionContractTests(unittest.TestCase):
    @staticmethod
    def closed_result():
        seeds = [12345, 67890]
        old_status = 'CROSS_FIT_LOCAL_BUDGET_EXHAUSTED_DIAGNOSTICS_RETAINED'
        old = [dict(id='old_'+str(s), status=old_status, lineage_id=str(s)) for s in seeds]
        new = [dict(id='new_'+str(s), status='S301_TARGETED_COMPLETE_REQUIRES_REVIEW',
                    lineage_id=str(s)) for s in seeds]
        points = [dict(id='p_'+str(s), theta=[1., .3, 30., 0., .2, .004],
            chi2={level: 1. for level in ('nominal', 'tight', 'third')},
            lineage_id=str(s), numerical_evidence_valid=True, discrepancy_scale=1e-7,
            comparison_key='same_problem', counts_as_independent_source=True,
            truth_seed_used=False) for s in seeds]
        return dict(run_complete=True, scientific_checks_passed=True, status='COMPLETED',
            stages=old+new, targeted_completion_closed=True,
            superseded_iteration_stages=[dict(id=a['id'], replacement_id=b['id'],
                original_status=old_status, lineage_id=a['lineage_id'],
                original_stage_relabelled=False) for a,b in zip(old,new)],
            run_seeds=seeds, sources=[dict(seed=s, complete_search_stage=True) for s in seeds],
            candidates=points, ranking=api.rank_candidates(points), actual_minimum_candidates=[],
            lower_failed_candidate_veto=False, unresolved_lower_actual_candidates=[],
            invalid_actual_evidence=[], rejected_stages=[],
            boundary_checks={str(s): dict(issues=[], significant_fixed_nuisance_descent=False) for s in seeds},
            optimizer_truth_seed_used=False, no_global_optimum_certificate=True)

    def test_complete_own_lineage_closure_retains_old_budget_history(self):
        result = self.closed_result()
        before = deepcopy(result)
        assert_native_completion_contract(self, result)
        self.assertEqual(result, before)

    def test_unclosed_iteration_limit_stays_incomplete(self):
        result = self.closed_result()
        result.update(targeted_completion_closed=False, superseded_iteration_stages=[],
                      run_complete=False, scientific_checks_passed=False)
        assert_native_completion_contract(self, result)
        result['run_complete'] = True
        with self.assertRaises(AssertionError): assert_native_completion_contract(self, result)

    def test_bad_mapping_hard_limit_or_other_lineage_cannot_close(self):
        for change in ('foreign_lineage', 'preceding_replacement', 'missing_mapping',
                       'wall', 'forward', 'hard_failure', 'unresolved_later_budget'):
            result = self.closed_result()
            if change == 'foreign_lineage': result['stages'][2]['lineage_id'] = '67890'
            elif change == 'preceding_replacement': result['stages'] = result['stages'][2:]+result['stages'][:2]
            elif change == 'missing_mapping': result['superseded_iteration_stages'].pop()
            elif change == 'unresolved_later_budget':
                result['stages'].append(dict(id='later', lineage_id='12345', status='LOCAL_NFEV_BUDGET_EXHAUSTED'))
            else:
                result['stages'][0]['status'] = {'wall':'WALL_BUDGET_EXHAUSTED',
                    'forward':'FORWARD_BUDGET_EXHAUSTED', 'hard_failure':'FAILED'}[change]
                result['superseded_iteration_stages'][0]['original_status'] = result['stages'][0]['status']
            with self.subTest(change=change), self.assertRaises(AssertionError):
                assert_native_completion_contract(self, result)

    def test_closure_never_substitutes_for_final_scientific_checks(self):
        for change in ('science', 'ranking', 'boundary', 'missing_boundary', 'rejected',
                       'invalid', 'known_lower', 'lower_failed', 'disagreeing_sources', 'duplicate_sources'):
            result = self.closed_result()
            if change == 'science': result['scientific_checks_passed'] = False
            elif change == 'ranking': result['ranking']['passed'] = False
            elif change == 'boundary': result['boundary_checks']['12345']['issues'] = ['failed_precision']
            elif change == 'missing_boundary': result['boundary_checks'].pop('12345')
            elif change == 'rejected': result['rejected_stages'] = ['bad_raw']
            elif change == 'invalid': result['invalid_actual_evidence'] = ['bad_forward']
            elif change == 'known_lower':
                result['actual_minimum_candidates'] = [dict(theta=[1.,.31,30.,0.,.2,.004],
                    accuracy='tight', chi2=.5)]
            elif change == 'lower_failed':
                result['candidates'].append(dict(result['candidates'][0], id='failed',
                    numerical_evidence_valid=False, chi2=dict(nominal=.5,tight=.5,third=.5)))
            elif change == 'disagreeing_sources':
                result['candidates'][1]['chi2'] = dict(nominal=2.,tight=2.,third=2.)
            else: result['sources'][1]['seed'] = 12345
            with self.subTest(change=change), self.assertRaises(AssertionError):
                assert_native_completion_contract(self, result)


class EvidenceRetentionTests(unittest.TestCase):
    def test_default_uses_only_temporary_directory(self):
        with patch.dict(os.environ, {}, clear=True):
            with retained_smoke_directory() as temporary:
                self.assertTrue(temporary.is_dir())
            self.assertFalse(temporary.exists())

    def test_opt_in_copies_complete_nested_tree_and_hashes(self):
        with tempfile.TemporaryDirectory() as root:
            with patch.dict(os.environ, {SMOKE_EVIDENCE_ENV: root}):
                with retained_smoke_directory() as temporary:
                    (temporary/'rn_demo/source').mkdir(parents=True)
                    (temporary/'rn_demo/source/raw.bin').write_bytes(b'raw\x00data')
                    (temporary/'rn_demo/result.json').write_text('{}', encoding='utf-8')
            dest=Path(root)/SMOKE_EVIDENCE_NAME
            self.assertFalse(temporary.exists())
            self.assertEqual((dest/'result_tree/rn_demo/source/raw.bin').read_bytes(), b'raw\x00data')
            manifest=json.loads((dest/'CAPTURE.json').read_text())
            self.assertFalse(manifest['test_body_raised'])
            self.assertEqual(set(manifest['files']), {'rn_demo/source/raw.bin','rn_demo/result.json'})
            self.assertEqual(manifest['files']['rn_demo/source/raw.bin']['sha256'],
                             hashlib.sha256(b'raw\x00data').hexdigest())

    def test_fit_exception_keeps_partial_tree_without_retry(self):
        with tempfile.TemporaryDirectory() as root:
            def failed_fit(case, directory, **kwargs):
                self.assertEqual(kwargs, dict(workers=1,profile='demo'))
                directory.mkdir(); (directory/'checkpoint.json').write_text('{"partial":true}')
                raise RuntimeError('mock fit failure')
            with patch.dict(os.environ,{SMOKE_EVIDENCE_ENV:root}), \
                    patch(__name__+'.rn_smoke_case',return_value={'wall_seconds':120.}), \
                    patch(__name__+'.fit_case',side_effect=failed_fit) as fitting:
                with self.assertRaisesRegex(RuntimeError,'mock fit failure'):
                    RealCatalogueTests().test_tiny_rn_actual_demo_fit_retains_two_sources_and_evidence()
                fitting.assert_called_once()
            dest=Path(root)/SMOKE_EVIDENCE_NAME
            self.assertTrue((dest/'result_tree/rn_demo/checkpoint.json').is_file())
            self.assertEqual(json.loads((dest/'CAPTURE.json').read_text())['exception_type'],'RuntimeError')

    def test_assertion_failure_keeps_result_before_temporary_cleanup(self):
        with tempfile.TemporaryDirectory() as root:
            def finished_fit(case, directory, **kwargs):
                directory.mkdir(); (directory/'result.json').write_text('{"result_is_demo":false}')
                return dict(result_is_demo=False)
            with patch.dict(os.environ,{SMOKE_EVIDENCE_ENV:root}), \
                    patch(__name__+'.rn_smoke_case',return_value={'wall_seconds':120.}), \
                    patch(__name__+'.fit_case',side_effect=finished_fit) as fitting:
                with self.assertRaises(AssertionError):
                    RealCatalogueTests().test_tiny_rn_actual_demo_fit_retains_two_sources_and_evidence()
                fitting.assert_called_once()
            dest=Path(root)/SMOKE_EVIDENCE_NAME
            self.assertTrue((dest/'result_tree/rn_demo/result.json').is_file())
            self.assertEqual(json.loads((dest/'CAPTURE.json').read_text())['exception_type'],'AssertionError')

    def test_existing_destination_rejected_before_any_fit(self):
        with tempfile.TemporaryDirectory() as root:
            dest=Path(root)/SMOKE_EVIDENCE_NAME;dest.mkdir()
            marker=dest/'keep.bin';marker.write_bytes(b'original')
            with patch.dict(os.environ,{SMOKE_EVIDENCE_ENV:root}), \
                    patch(__name__+'.fit_case') as fitting, patch(__name__+'.rn_smoke_case') as case:
                with self.assertRaises(FileExistsError):
                    RealCatalogueTests().test_tiny_rn_actual_demo_fit_retains_two_sources_and_evidence()
                fitting.assert_not_called();case.assert_not_called()
            self.assertEqual(marker.read_bytes(),b'original')
            self.assertEqual(list(dest.iterdir()),[marker])

    def test_empty_or_relative_destination_rejected(self):
        for value in ('', ' ', 'relative/path'):
            with self.subTest(value=value), patch.dict(os.environ,{SMOKE_EVIDENCE_ENV:value}):
                with self.assertRaises(ValueError):
                    with retained_smoke_directory(): self.fail('Invalid path was accepted')


class RealCatalogueTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original_options = {
            suite: json.loads((ROOT/'configs'/f'{suite}.json').read_text(encoding='utf-8'))['theory_options']
            for suite in SUITES
        }
        cls.third = json.loads((VENDOR/'numerical_template.json').read_text(encoding='utf-8'))['third_integration']

    def test_real_catalogue_pipeline_and_model_specific_options(self):
        # The old failure was hidden by artificial fixtures with empty options.
        # S301's actual catalogue explicitly supplies ER's base_frame.
        self.assertIn('base_frame', self.original_options['s301'])
        for suite in SUITES:
            for selector in SELECTORS:
                expected = ('s301' if suite == 's301' else 'legacy') if selector == 'paper' else selector
                for noisy in (False, True):
                    er, rn = [catalogue_case(suite, model, noisy, selector) for model in ('ER', 'RN')]
                    with self.subTest(suite=suite, selector=selector, noisy=noisy):
                        self.assertEqual(er['xy_observed'], rn['xy_observed'])
                        self.assertEqual(er['times'], rn['times'])
                        for case in (er, rn):
                            self.assertEqual(case['metadata']['add_noise'], noisy)
                            self.assertEqual(case['fit_pipeline'], expected)
                            self.assertEqual(case['fit_pipeline_requested'], selector)
                            self.assertEqual(case['fit_pipeline_version'], PIPELINE_VERSIONS[expected])
                            self.assertEqual(len(case['run_seeds']), 5 if expected == 'legacy' else 2)
                            self.assertEqual(case['fit_theory_options'], case['theory_options'])
                        self.assertEqual(er['fit_theory_options'], self.original_options[suite])
                        expected_rn = {key: value for key, value in self.original_options[suite].items()
                                       if key != 'base_frame'}
                        self.assertEqual(rn['fit_theory_options'], expected_rn)
                        self.assertNotIn('base_frame', rn['theory_options'])

    def test_all_real_case_models_and_worker_initializers_construct(self):
        for suite in SUITES:
            for selector in SELECTORS:
                for noisy in (False, True):
                    for theory in ('ER', 'RN'):
                        with self.subTest(suite=suite, selector=selector, noisy=noisy, theory=theory):
                            case = catalogue_case(suite, theory, noisy, selector)
                            saved = deepcopy(case)
                            # Construction and worker initialization must be cheap:
                            # failure here must not wait for a scientific deadline.
                            with patch.object(TheoryForwardModel, 'predict', side_effect=AssertionError('Unexpected integration')):
                                model = TheoryForwardModel(theory, build_theory,
                                    settings=CoordinateTimeSettings(**case['nominal_integration']),
                                    theory_options=case['fit_theory_options'])
                                self.assertEqual(model.theory_name, theory)
                                worker_init(str(CORE), case, self.third)
                            self.assertEqual(set(hybrid_support._WORKER['models']), {'nominal', 'tight', 'third'})
                            for worker_model in hybrid_support._WORKER['models'].values():
                                self.assertEqual(worker_model.theory_name, theory)
                            np.testing.assert_array_equal(hybrid_support._WORKER['truth'], case['xy_observed'])
                            np.testing.assert_array_equal(hybrid_support._WORKER['times'], case['times'])
                            self.assertEqual(case, saved)

    def test_portable_validator_accepts_real_s301_workflow_cases(self):
        for suite in SUITES:
            for noisy in (False, True):
                for theory in ('ER', 'RN'):
                    with self.subTest(suite=suite, noisy=noisy, theory=theory):
                        original = catalogue_case(suite, theory, noisy, 's301')
                        case, bounds = _validate_case(original)
                        self.assertEqual(bounds.ndim, 6)
                        self.assertEqual(case['xy_observed'], original['xy_observed'])
                        self.assertEqual(case['fit_theory_options'], original['fit_theory_options'])

    def test_bad_rn_options_fail_before_any_pool_is_created(self):
        for options_key in ('fit_theory_options', 'theory_options'):
            with self.subTest(options_key=options_key):
                case = catalogue_case('s301', 'RN', True, 's301')
                if options_key == 'theory_options':
                    case.pop('fit_theory_options')
                case[options_key] = {'base_frame': 'einstein'}
                with self.assertRaisesRegex((TypeError, ValueError), 'base_frame'):
                    _validate_case(case)
                config = _config(case, 1, 'demo')
                with patch('engine.api.mp.get_context') as context:
                    with self.assertRaisesRegex((TypeError, ValueError), 'base_frame'):
                        _pool(case, config, 1)
                    context.assert_not_called()

    def test_real_two_epoch_spawn_predictions_match_direct_model(self):
        for suite in SUITES:
            for noisy in (False, True):
                for theory in ('ER', 'RN'):
                    with self.subTest(suite=suite, noisy=noisy, theory=theory):
                        case = catalogue_case(suite, theory, noisy, 's301')
                        for key in ('times', 'xy_true', 'xy_observed'):
                            case[key] = case[key][:2]
                        case, bounds = _validate_case(case)
                        theta = bounds.denormalize(np.full(bounds.ndim, .5))
                        config = _config(case, 1, 'demo')
                        settings = dict(nominal=case['nominal_integration'], tight=case['tight_integration'],
                            third=third_settings(case, config['third_integration']))
                        # Evaluate directly first: a malformed constructor must
                        # fail here, never trigger an initializer respawn storm.
                        expected = {level: predict(theta, case['times'], theory=theory,
                            integration=integration, theory_options=case['fit_theory_options'])
                            for level, integration in settings.items()}
                        pool = _pool(case, config, 1)
                        try:
                            for task_id, level in enumerate(settings, start=1):
                                event = pool.apply_async(worker_predict,
                                    (dict(id=task_id, theta=theta.tolist(), accuracy=level),)).get(timeout=30)
                                self.assertEqual(event['status'], 'COMPLETE', event.get('error'))
                                np.testing.assert_array_equal(event['xy'], expected[level])
                                np.testing.assert_array_equal(event['residual'],
                                    (expected[level]-np.asarray(case['xy_observed'])).reshape(-1))
                        finally:
                            pool.terminate()
                            pool.join()

    def test_tiny_rn_actual_demo_fit_retains_two_sources_and_evidence(self):
        with retained_smoke_directory() as temporary:
            result = fit_case(rn_smoke_case(), temporary/'rn_demo', workers=1, profile='demo')
            self.assertTrue(result['result_is_demo'])
            self.assertEqual(result['fit_theory'], 'RN')
            self.assertEqual(len(result['sources']), 2, result.get('stop_reason'))
            self.assertEqual(result['run_seeds'], [12345, 67890])
            self.assertTrue(result['candidates'], result.get('stop_reason'))
            self.assertTrue(np.isfinite(result['chi2']))
            self.assertEqual(len(result['residuals']), 12)
            self.assertFalse(result['optimizer_truth_seed_used'])
            assert_native_completion_contract(self, result)


if __name__ == '__main__':
    unittest.main()
