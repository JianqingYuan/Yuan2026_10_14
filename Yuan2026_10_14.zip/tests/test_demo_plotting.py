"""Demo plotting tests use synthetic endpoints, never real optimization results.

Only catalogue observations and reference geometry are read. Synthetic figures
are created exclusively in temporary directories, never in the user's output.
"""
import copy
from contextlib import ExitStack
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from experiments.api import iter_cases
from plotting import demo
import postprocess
from postprocess import _demo_endpoint
from run_state import pair_input_fingerprint


def synthetic_rows():
    """Real selected inputs, deliberately artificial finite-budget endpoints."""
    rows = []
    for index, case in enumerate(iter_cases('all', 'demo')):
        chi2 = float(index + 1)
        residual = np.zeros(np.asarray(case['xy_true']).size)
        residual[0] = np.sqrt(chi2) * case['residual_sigma']
        theta = np.asarray(case['metadata']['theta_true'], dtype=float).copy()
        theta[0] += .001 if case['fit_theory'] == 'ER' else .002
        result = dict(chi2=chi2, theta=theta.tolist(), residuals=residual.tolist(),
                      residual_accuracy='nominal', profile='demo', result_is_demo=True,
                      run_complete=False, best_candidate_checks_passed=False,
                      synthetic_test_fixture=True)
        rows.append(dict(case=case, metadata=case['metadata'], result=result,
                         available=False, eligible=False))
    groups = {}
    for row in rows:
        groups.setdefault(row['case']['dataset_id'], {})[row['case']['fit_theory']] = row
    for group in groups.values():
        if group['ER']['case']['fit_pipeline'] == 'legacy':
            fingerprint = pair_input_fingerprint(group['ER']['case'], group['RN']['case'])
            for row in group.values():
                row['result']['pair_input_sha256'] = fingerprint
    return rows


class DemoPlottingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = synthetic_rows()

    def tearDown(self):
        plt.close('all')

    def pair(self, suite='s301'):
        first = next(r for r in self.rows if r['metadata']['suite'] == suite)
        return copy.deepcopy([r for r in self.rows
            if r['case']['dataset_id'] == first['case']['dataset_id']])

    def test_declared_endpoint_preserves_its_parameters_and_observations(self):
        row = copy.deepcopy(self.rows[0])
        before = copy.deepcopy(row)
        point = _demo_endpoint(row)
        self.assertEqual(point['theta'], row['result']['theta'])
        self.assertEqual(point['chi2'], row['result']['chi2'])
        expected = np.asarray(row['case']['xy_true']) + np.asarray(
            row['result']['residuals']).reshape(-1, 2)
        np.testing.assert_array_equal(point['prediction'], expected)
        self.assertEqual(row, before)

    def test_candidate_fallback_never_mixes_theta_and_chi2(self):
        row = self.pair()[0]
        count = np.asarray(row['case']['xy_true']).size
        row['result'] = dict(theta=[99.] * 6, chi2=99.,
            best_candidate_id='accepted', diagnostic_best={'id': 'diagnostic'},
            candidates=[dict(id=name, theta=[value] * 6,
                chi2={'third': value}, raw_residuals={'third': [0.] * count})
                for name, value in [('accepted', 7.), ('diagnostic', 11.)]])
        for available, expected in [(True, 7.), (False, 11.)]:
            with self.subTest(available=available):
                row['available'] = available
                point = _demo_endpoint(row)
                self.assertEqual(point['chi2'], expected)
                self.assertEqual(point['theta'], [expected] * 6)

    def test_invalid_or_missing_endpoints_remain_missing(self):
        original = self.pair()[0]
        for change in ({'residuals': []}, {'residuals': [float('nan')] * 202},
                       {'chi2': -1.}, {'chi2': float('inf')}, {'chi2': None}):
            with self.subTest(change=list(change)):
                row = copy.deepcopy(original)
                row['result'].update(change)
                self.assertIsNone(_demo_endpoint(row))
        original['result'] = {}
        self.assertIsNone(_demo_endpoint(original))

    def test_invalid_theta_does_not_become_a_parameter_measurement(self):
        pair = self.pair()
        pair[0]['result']['theta'] = [float('nan')] * 6
        prepared, paired = demo._prepare(pair)
        self.assertIsNone(prepared[0]['endpoint']['theta'])
        self.assertEqual(len(paired), 1)
        self.assertTrue(np.isfinite(prepared[0]['endpoint']['chi2']))

    def test_pairing_rejects_observation_weight_and_metadata_mismatches(self):
        mutations = [
            lambda r: r['case']['times'].__setitem__(0, -999.),
            lambda r: r['case']['xy_true'][0].__setitem__(0, -999.),
            lambda r: r['case'].__setitem__('residual_sigma', 987.),
            lambda r: r['case'].__setitem__('dataset_id', 'different_dataset'),
            lambda r: r['case'].__setitem__('fit_pipeline', 'legacy'),
            lambda r: r['case'].__setitem__('fit_pipeline_requested', 'legacy'),
            lambda r: r['case'].__setitem__('fit_pipeline_version', 'different_version'),
        ]
        for name, value in [('q', -1.), ('peri', -1.), ('theta_true', [0.] * 6),
                            ('noise_index', 987), ('noise_seed', 987),
                            ('charge_tag', 'different'), ('noise_uas', 207),
                            ('truth_index', 987)]:
            mutations.append(lambda r, name=name, value=value: r['metadata'].__setitem__(name, value))
        for index, mutate in enumerate(mutations):
            with self.subTest(mutation=index):
                pair = self.pair()
                mutate(pair[1])
                with self.assertRaises(ValueError):
                    demo._prepare(pair)

    def test_duplicate_and_broken_legacy_fingerprints_are_rejected(self):
        pair = self.pair('baseline')
        with self.assertRaisesRegex(ValueError, 'Duplicate'):
            demo._prepare(pair + [copy.deepcopy(pair[0])])
        pair[1]['result']['pair_input_sha256'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'fingerprint'):
            demo._prepare(pair)

    def test_missing_pair_member_is_not_filled(self):
        pair = self.pair()
        prepared, paired = demo._prepare(pair[:1])
        self.assertEqual(len(prepared), 1)
        self.assertEqual(paired, [])
        fig = demo._s301(paired)
        self.assertEqual(sum(len(ax.collections) for ax in fig.axes), 0)
        self.assertTrue(all(any('No paired' in text.get_text() for text in ax.texts)
                            for ax in fig.axes))

    def test_zero_negative_and_large_differences_are_retained(self):
        rows = copy.deepcopy([r for r in self.rows if r['metadata']['suite'] == 's301'])
        desired = [-1e12, 0., 1e12, -2., 0., 3.]
        for index, offset in enumerate(range(0, len(rows), 2)):
            # S301 input pairs are adjacent ER/RN entries in the catalogue.
            rows[offset]['result']['chi2'] = max(-desired[index], 0.)
            rows[offset+1]['result']['chi2'] = max(desired[index], 0.)
        _, paired = demo._prepare(rows)
        fig = demo._s301(paired)
        plotted = np.concatenate([np.asarray(c.get_offsets())[:, 1]
            for ax in fig.axes for c in ax.collections])
        np.testing.assert_array_equal(np.sort(plotted), np.sort(desired))
        self.assertEqual(fig.axes[0].get_ylim(), fig.axes[1].get_ylim())
        lower, upper = fig.axes[0].get_ylim()
        self.assertLess(lower, min(desired))
        self.assertGreater(upper, max(desired))
        self.assertTrue(all(ax.get_yscale() == 'symlog' for ax in fig.axes))

    def test_empty_statistical_inputs_and_zero_heatmaps_are_supported(self):
        for number in (6, 7, 8, 9):
            with self.subTest(number=number):
                fig = demo._baseline_figure(number, [], [])
                self.assertTrue(any('No paired' in t.get_text()
                    for ax in fig.axes for t in ax.texts))
                plt.close(fig)
        fig, ax = plt.subplots()
        image = demo._heatmap(ax, [(0.1, 4.5, 0.)], [.1, .5], [4.5])
        array = image.get_array()
        self.assertEqual(float(array[0, 0]), 0.)
        self.assertTrue(np.ma.getmaskarray(array)[0, 1])
        self.assertEqual(np.count_nonzero(~np.ma.getmaskarray(array)), 1)

    def test_s301_rejects_wrong_noise_level(self):
        pair = self.pair()
        for row in pair:
            row['metadata']['noise_uas'] = 207
        _, paired = demo._prepare(pair)
        with self.assertRaisesRegex(ValueError, '30-microarcsecond'):
            demo._s301(paired)

    def test_missing_geometry_cache_is_not_silently_replaced(self):
        with tempfile.TemporaryDirectory(prefix='synthetic_demo_missing_cache_') as folder:
            root = Path(folder)
            with patch.object(demo, 'DEFAULT_DATA', root/'missing_geometry'):
                with self.assertRaises(FileNotFoundError):
                    demo.render_demo([], root/'figures', dpi=45)
            self.assertFalse((root/'demo_plot_data.json').exists())
            self.assertEqual(list((root/'figures').glob('*.pdf')), [])

    def test_postprocess_wiring_keeps_demo_separate_from_formal_statistics(self):
        with tempfile.TemporaryDirectory(prefix='synthetic_demo_wiring_') as folder, ExitStack() as stack:
            root = Path(folder)
            stack.enter_context(patch('postprocess._load', return_value=self.rows))
            stack.enter_context(patch('postprocess._summary', return_value=root/'summary.pdf'))
            stack.enter_context(patch('postprocess._demo_trajectories', return_value=[]))
            paths = [root/'figures'/f'demo_{i}.pdf' for i in range(1, 14)]
            plotter = stack.enter_context(patch('plotting.demo.render_demo', return_value=(paths, {
                'historical_fit_results_used': False, 'reference_geometry_figures': list(range(1, 6))})))
            formal = [stack.enter_context(patch('postprocess.'+name,
                side_effect=AssertionError('Demo must not enter formal statistics')))
                for name in ('_baseline_cache', '_extreme_cache', '_s301_cache', '_collection_geometry')]
            files = postprocess.render_run(root, mode='demo')
            self.assertEqual(len(files), 14)
            plotter.assert_called_once_with(self.rows, root/'figures')
            report = json.loads((root/'plot_status.json').read_text(encoding='utf-8'))
            self.assertEqual(report['demo_layout_figures_generated'], list(range(1, 14)))
            self.assertEqual(report['paper_layout_figures_generated'], [])
            self.assertTrue(report['original_paper_snapshot_used'])
            self.assertFalse(report['original_paper_fit_snapshot_used'])
            self.assertEqual(report['eligible_endpoints'], 0)
            for probe in formal:
                probe.assert_not_called()

    def test_42_synthetic_endpoints_render_13_layouts_without_fitting(self):
        self.assertEqual(len(self.rows), 42)
        before = copy.deepcopy(self.rows)
        geometry_names = {demo.FIGURES[i][1] for i in range(1, 6)}
        original_load = np.load
        original_open = Path.open
        reads = []

        def guard_path(path):
            if isinstance(path, (str, Path)):
                path = Path(path)
                if path.parent.resolve() == demo.DEFAULT_DATA.resolve():
                    self.assertIn(path.name, geometry_names,
                                  'Demo must not read historical fitted values')
                    reads.append(path.name)

        def guarded_load(path, *args, **kwargs):
            guard_path(path)
            return original_load(path, *args, **kwargs)

        def guarded_open(path, *args, **kwargs):
            guard_path(path)
            return original_open(path, *args, **kwargs)

        forbidden = ['engine.api.fit_case', 'engine.api.predict', 'engine.legacy.fit_pair',
                     'scipy.optimize.differential_evolution', 'scipy.optimize.least_squares',
                     'scipy.integrate.solve_ivp', 'scipy.integrate.quad',
                     'plotting.geometry_data.recompute_geometry', 'plotting.paper.render_all']
        with tempfile.TemporaryDirectory(prefix='synthetic_demo_plot_test_') as folder, ExitStack() as stack:
            stack.enter_context(patch('numpy.load', side_effect=guarded_load))
            stack.enter_context(patch.object(Path, 'open', new=guarded_open))
            blocked = [stack.enter_context(patch(name, side_effect=AssertionError(
                'Plotting must not run fitting, integration, or full paper replay'))) for name in forbidden]
            files, report = demo.render_demo(self.rows, Path(folder)/'figures', dpi=45)
            self.assertEqual(len(files), 13)
            self.assertTrue(all(p.is_file() and p.stat().st_size > 500 for p in files))
            self.assertTrue(all(p.with_suffix('.png').is_file() for p in files))
            self.assertEqual(set(reads), geometry_names)
            self.assertEqual(report['optimizer_calls'], 0)
            self.assertEqual(report['integration_calls'], 0)
            self.assertFalse(report['historical_fit_results_used'])
            self.assertEqual(report['reference_geometry_figures'], list(range(1, 6)))
            self.assertEqual(report['demo_fit_figures'], list(range(6, 14)))
            self.assertEqual(len(report['endpoints']), 42)
            self.assertEqual(len(report['paired_differences']), 21)
            self.assertTrue(all(row['delta_chi2'] == 1. for row in report['paired_differences']))
            saved = json.loads((Path(folder)/'demo_plot_data.json').read_text(encoding='utf-8'))
            self.assertEqual(saved, report)
            for probe in blocked:
                probe.assert_not_called()
        self.assertEqual(self.rows, before, 'Drawing must not mutate saved endpoints')


if __name__ == '__main__':
    unittest.main()
