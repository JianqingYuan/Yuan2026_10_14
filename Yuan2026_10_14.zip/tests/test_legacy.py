"""Small isolated checks of the archived paired workflow; no paper jobs."""
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest import mock

import numpy as np
from engine.api import predict
from engine.legacy import ROOT, _payload, fit_pair, verify_legacy_vendor


def pair():
    theta = [1., .3, 30., 0., .2, .004]
    times = np.arange(8., dtype=float)
    observed = predict(theta, times, integration=dict(max_step=1., relative_tolerance=1e-11, absolute_tolerance=1e-13))
    common = dict(dataset_id='legacy_test_pair', times=times.tolist(), xy_observed=observed.tolist(),
        xy_true=observed.tolist(), residual_sigma=.01, legacy_optimizer_seed=104729,
        fit_pipeline='legacy', fit_pipeline_requested='paper', fit_pipeline_version='legacy-paired-v1',
        legacy_variant='baseline', metadata=dict(suite='baseline', add_noise=False),
        bounds=dict(M=[.95, 1.05], q=[.1, .5], rho0=[29.9, 30.1],
            drho_dt0=[-.001, .001], phi0=[.19, .21], dphi_dt0=[.0038, .0042]))
    return tuple(dict(deepcopy(common), case_id='legacy_test_' + name, fit_theory=name) for name in ('ER', 'RN'))


class LegacyTests(unittest.TestCase):
    def test_endpoint_precision_is_separate_from_route_certification(self):
        from engine._legacy_worker import endpoint_precision_check
        record = dict(best_theta=[1., .3, 30., 0., .2, .004], chi2_min=1.,
            diagnostics=dict(certification_status='COMPUTATIONALLY_UNRESOLVED'),
            integration_check=dict(within_tolerance=True, nominal_chi2=1., tight_chi2=1.001))
        self.assertTrue(endpoint_precision_check(record, [1., 0.], [.01, 0.], .01)['passed'])
        record['chi2_min'] = 1.02
        self.assertFalse(endpoint_precision_check(record, [1., 0.], [.01, 0.], .01)['passed'])
        record['chi2_min'] = 1.
        record['integration_check'].update(within_tolerance=False, tight_chi2=None)
        self.assertFalse(endpoint_precision_check(record, [1., 0.], [.01, 0.], .01)['passed'])

    def test_authentic_source_manifest_and_paired_inputs(self):
        manifest = verify_legacy_vendor()
        self.assertFalse(manifest['numerical_sources_modified'])
        er, rn = pair()
        self.assertEqual(_payload(er, rn, 'paper')['optimizer_seed'], 104729)
        changed = deepcopy(rn)
        changed['xy_observed'][0][0] += 1.
        with self.assertRaisesRegex(ValueError, 'same observations'):
            _payload(er, changed, 'paper')
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, 'workers=1'):
                fit_pair(er, rn, Path(directory) / 'pair', workers=2)

    def test_real_demo_calls_original_paired_workflow(self):
        er, rn = pair()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / 'pair'
            results = fit_pair(er, rn, root, profile='demo')
            self.assertTrue((root / 'checkpoint.json').exists(), (root / 'worker.log').read_text())
            checkpoint = json.loads((root / 'checkpoint.json').read_text(encoding='utf-8'))
            self.assertEqual(set(checkpoint['models']), {'ER', 'RN'})
            self.assertTrue(checkpoint['workflow_state']['complete'])
            for name, result in results.items():
                self.assertEqual(result['fit_pipeline'], 'legacy')
                self.assertEqual(result['fit_pipeline_requested'], 'paper')
                self.assertEqual(result['fit_pipeline_version'], 'legacy-paired-v1')
                self.assertTrue(result['result_is_demo'])
                self.assertTrue(result['run_complete'], (root / 'worker.log').read_text())
                self.assertTrue(result['best_candidate_checks_passed'], result['endpoint_precision_check'])
                expected_scientific = result['legacy_record']['diagnostics']['certification_status'] in (
                    'REPEATABLE_SOLUTION', 'MULTIPLE_NEAR_EQUAL_SOLUTIONS')
                self.assertEqual(result['scientific_checks_passed'], expected_scientific)
                self.assertIn(result['residual_accuracy'], ('nominal', 'tight'))
                self.assertNotIn('third', result['legacy_record']['integration_check'])
                self.assertEqual(len(result['residuals']), 16)
                self.assertAlmostEqual(result['residual_check_chi2'], result['chi2'], delta=.01)
                self.assertEqual(result['optimizer_seed'], 104729 + (1000 if name == 'RN' else 0))
                self.assertEqual(len(result['run_seeds']), 2)
                self.assertTrue((root / name / 'result.json').exists())

    def test_original_paper_budget_deserialization_isolated(self):
        er, rn = pair()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.json'
            path.write_text(json.dumps(_payload(er, rn, 'paper')), encoding='utf-8')
            worker = ROOT / 'engine' / '_legacy_worker.py'
            code = "import importlib.util,json,sys; s=importlib.util.spec_from_file_location('legacy_worker',sys.argv[1]); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); p=json.load(open(sys.argv[2])); m.bootstrap(p['variant']); profile,_=m.build_profile(p); print(json.dumps({'runs':profile.global_config.runs,'maxiter':profile.global_config.maxiter,'local':profile.local_config.max_nfev,'jac':profile.local_config.jacobian,'cross':profile.cross_theory_rescue_passes,'recovery':profile.integration_recovery_config.max_levels,'names':profile.theory_names}))"
            completed = subprocess.run([sys.executable, '-E', '-B', '-c', code, str(worker), str(path)],
                capture_output=True, text=True, check=False, timeout=20)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertEqual(json.loads(completed.stdout), dict(runs=5, maxiter=50, local=250,
                jac='3-point', cross=2, recovery=1, names=['ER', 'RN']))

    def test_forced_s301_legacy_retains_dataset_integration(self):
        from experiments.api import iter_cases
        cases = list(iter_cases('s301', 'paper', indices=['T000'], include_noisy=False, fit_pipeline='legacy'))
        payload = _payload(*cases, 'paper')
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.json'
            path.write_text(json.dumps(payload), encoding='utf-8')
            code = "import importlib.util,json,sys; s=importlib.util.spec_from_file_location('legacy_worker',sys.argv[1]); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); p=json.load(open(sys.argv[2])); m.bootstrap(p['variant']); profile,_=m.build_profile(p); print(json.dumps({'nominal':profile.nominal_settings.max_step,'tight':profile.tight_settings.max_step,'runs':profile.global_config.runs,'criterion':profile.integration_check_tolerance}))"
            completed = subprocess.run([sys.executable, '-E', '-B', '-c', code,
                str(ROOT / 'engine' / '_legacy_worker.py'), str(path)], capture_output=True, text=True, timeout=20)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertEqual(json.loads(completed.stdout), dict(nominal=20000., tight=5000., runs=5, criterion=.01))
        cases[1]['nominal_integration']['max_step'] = 4.
        with self.assertRaisesRegex(ValueError, 'nominal_integration'):
            _payload(*cases, 'paper')

    def test_failed_worker_exits_and_retains_false_endpoint_flag(self):
        from engine import legacy
        er, rn = pair()
        for case in (er, rn):
            case['xy_observed'] = [[1.] for _ in case['times']]
            case['xy_true'] = deepcopy(case['xy_observed'])
        children = []
        actual_popen = subprocess.Popen
        def launch(*args, **kwargs):
            child = actual_popen(*args, **kwargs)
            children.append(child)
            return child
        with tempfile.TemporaryDirectory() as directory, mock.patch.object(legacy.subprocess, 'Popen', side_effect=launch):
            result = fit_pair(er, rn, Path(directory) / 'failure', profile='demo')
            self.assertEqual(len(children), 1)
            self.assertIsNotNone(children[0].poll())
            for row in result.values():
                self.assertEqual(row['status'], 'FAILED')
                self.assertFalse(row['run_complete'])
                self.assertFalse(row['best_candidate_checks_passed'])

    def test_main_real_pair_dispatch_and_receipts(self):
        import main
        from postprocess import _load
        cases = pair()
        with tempfile.TemporaryDirectory() as directory:
            destinations = [str(Path(directory) / 'tasks' / case['case_id']) for case in cases]
            rows = main._run_pair(cases, destinations, 1, 'demo')
            self.assertEqual([row['state'] for row in rows], ['FINISHED', 'FINISHED'], rows)
            for destination in destinations:
                result = json.loads((Path(destination) / 'result.json').read_text(encoding='utf-8'))
                receipt = json.loads((Path(destination) / 'task_receipt.json').read_text(encoding='utf-8'))
                for key in ('fit_pipeline', 'fit_pipeline_requested', 'fit_pipeline_version', 'pair_input_sha256'):
                    self.assertEqual(result[key], receipt[key])
            loaded = _load(directory)
            self.assertEqual(len(loaded), 2)
            self.assertTrue(all(row['available'] for row in loaded))
            self.assertTrue(all(not row['eligible'] for row in loaded))  # Demo stays ineligible for paper figures.

    def test_cancellation_preserves_partial_artifacts(self):
        er, rn = pair()
        event = threading.Event()
        timer = threading.Timer(.15, event.set)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / 'cancelled'
            timer.start()
            try:
                with self.assertRaises(KeyboardInterrupt):
                    fit_pair(er, rn, root, profile='demo', cancel_event=event)
            finally:
                timer.cancel()
                timer.join()
            for name in ('ER', 'RN'):
                result = json.loads((root / name / 'result.json').read_text(encoding='utf-8'))
                self.assertEqual(result['status'], 'INTERRUPTED')
                self.assertFalse(result['run_complete'])
                self.assertFalse(result['scientific_checks_passed'])
                self.assertFalse(result['best_candidate_checks_passed'])


if __name__ == '__main__':
    unittest.main()
