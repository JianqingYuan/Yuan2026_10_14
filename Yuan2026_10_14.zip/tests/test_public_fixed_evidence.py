"""Pure/mock public integration contracts; no orbit/DE/TRF forward is executed."""
from contextlib import ExitStack
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import main
from engine import api, reliability
from engine import s301_fixed_evidence as fixed
from hybrid_support import ArmRun, CrossFitArmRun, Interrupted
from test_demo_evidence import case as base_case


THETA = [1., .3, 30., 0., .2, .004]
LOWER = [1.001, .3, 30., 0., .2, .004]
COMPLETE = 'CROSS_FIT_DIAGNOSTIC_COMPLETE_REQUIRES_REVIEW'
CLEAN = dict(issues=[], significant_fixed_nuisance_descent=False)


class Pool:
    def terminate(self):
        pass
    def join(self):
        pass


def point(case, bounds, source, theta, value=1.00005):
    holder = SimpleNamespace(bounds=bounds, sigma=case['residual_sigma'], case=case,
        physical=lambda *a, **kw: np.array([value**.5, 0., 0., 0.]))
    raw, audit = CrossFitArmRun.audit_crossfit_point(holder, theta, 'fixture')
    result = dict(id='source_'+str(source), lineage_id=str(source), source=source,
        theta=list(theta), raw_residuals=raw, truth_seed_used=False,
        counts_as_independent_source=True, new_independent_DE_source=False,
        comparison_key=case['case_id'])
    result.update(api.verify_vectors(raw, audit, sigma=case['residual_sigma'],
        bounds=dict(lower=bounds.lower, upper=bounds.upper), expected_size=4, ceiling=.01))
    return result


class FixedEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)/'case'
        self.case, self.bounds = api._validate_case(base_case())
        self.config = api._config(self.case, 1, 'demo')
        self.config['portable_monotonic_deadline'] = time.monotonic()+60.
        self.root = api._prepare(self.directory, self.case, self.config)
        self.points = [point(self.case, self.bounds, source, THETA) for source in self.case['run_seeds']]
        self.actual = [dict(theta=LOWER, lineage_id='12345', accuracy='tight', chi2=1.,
            raw_residuals=[1.,0.,0.,0.], stage_id='original_boundary')]
        self.invalid, self.report, self.calls = [], {}, []
        self.cancel = threading.Event()
        self.boundaries = {str(s):deepcopy(CLEAN) for s in self.case['run_seeds']}

    def physical(self, run, theta, accuracy, category='validation', role='fixed_theta'):
        self.calls.append((list(theta), accuracy, category, role))
        run.state['submitted_forward_calls'] += 1
        run.state['completed_forward_calls'] += 1
        return np.array([1.,0.,0.,0.])

    def execute(self, physical=None, extra=None):
        with ExitStack() as stack:
            callback=physical or self.physical
            stack.enter_context(patch.object(ArmRun, 'physical', new=lambda run,*a,**kw:callback(run,*a,**kw)))
            stack.enter_context(patch.object(api._NonzeroRun, 'start_pool', new=lambda run:setattr(run,'pool',Pool())))
            stack.enter_context(patch.object(api, 'run_de_search', side_effect=AssertionError('No DE')))
            stack.enter_context(patch('hybrid_support.least_squares', side_effect=AssertionError('No TRF')))
            if extra:
                extra(stack)
            return fixed.complete(api, self.root, self.config, self.case, self.bounds,
                self.directory, time.time()+60., self.cancel, [False], self.points,
                self.actual, self.invalid, api._rank_candidates_for_case(self.case,self.points),
                self.boundaries, self.case['run_seeds'], self.report)

    def test_actual_native_auditor_closes_missing_point_without_optimizer_or_source(self):
        old = deepcopy(self.points)
        ranking, boundaries = self.execute()
        self.assertTrue(ranking['passed'])
        self.assertTrue(api.targeted.lower_guard(self.points,self.actual)['passed'])
        self.assertTrue(self.report['complete'])
        self.assertEqual(len(self.calls),3)
        self.assertEqual(self.report['reserved_forward_calls'],3)
        self.assertEqual(self.report['optimizer_calls'],0)
        self.assertEqual(self.report['new_independent_DE_sources'],0)
        self.assertEqual(self.points[:2],old)
        self.assertEqual(ranking['independent_sources'],2)
        self.assertEqual(set(boundaries),{'12345','67890'})
        self.assertEqual(self.points[-1]['theta'],LOWER)
        self.assertFalse(self.points[-1]['optimizer_invoked'])
        receipts = (self.directory/'fixed_evidence/physical/completed_audits.jsonl').read_text().splitlines()
        self.assertEqual(len(receipts),1)
        self.assertEqual(len(list((self.directory/'fixed_evidence/raw').glob('*.json'))),3)

    def test_original_boundary_ndarray_is_persisted_then_normalized(self):
        self.points = [point(self.case,self.bounds,s,[1.,.5,30.,0.,.2,.004]) for s in self.case['run_seeds']]
        self.actual[0]['theta'] = [1.001,.5,30.,0.,.2,.004]
        self.execute()
        records = self.report['coordinator']['boundary_records']
        self.assertGreater(len(records),0)
        self.assertTrue(any(r['samples'] for r in records))
        for record in records:
            raw=json.loads((self.directory/record['raw_report_file']).read_text())
            self.assertEqual(raw['point_theta'],record['point_theta'])
            self.assertEqual(raw['lineage_id'],record['lineage_id'])
            self.assertEqual(raw['report']['samples'],record['samples'])
        self.assertTrue(self.report['cache_reuse'])
        self.assertLessEqual(len(self.calls),81)

    def test_already_closed_has_zero_new_io_or_physical_calls(self):
        self.actual=[]
        self.execute()
        self.assertEqual(self.report['status'],'SKIPPED')
        self.assertEqual(self.calls,[])
        self.assertFalse((self.directory/'fixed_evidence').exists())

    def test_source_gap_without_missing_evidence_does_not_start_new_work(self):
        self.actual=[]
        self.points[1]=point(self.case,self.bounds,67890,THETA,2.)
        ranking,_=self.execute()
        self.assertFalse(ranking['passed'])
        self.assertEqual(self.calls,[])
        self.assertIn('not an optimizer retry',self.report['reason'])

    def test_missing_lineage_is_not_filled_by_a_fixed_audit(self):
        self.points=self.points[:1]
        self.execute()
        self.assertEqual(self.calls,[])
        self.assertEqual(self.report['status'],'SKIPPED')

    def test_wrong_source_rejected_before_new_io(self):
        self.actual[0]['lineage_id']='999'
        with self.assertRaisesRegex(ValueError,'across sources'):
            self.execute()
        self.assertFalse((self.directory/'fixed_evidence').exists())

    def test_failed_precision_and_its_lower_point_remain_unpassed(self):
        def physical(run,theta,accuracy,**kwargs):
            value=0.1 if accuracy=='third' else 1.
            return np.array([value,0.,0.,0.])
        ranking,_=self.execute(physical)
        self.assertFalse(self.points[-1]['numerical_evidence_valid'])
        self.assertTrue(api.targeted.lower_guard(self.points,self.actual)['lower_failed_candidate_veto'])
        self.assertFalse(self.report['complete'])
        self.assertTrue((self.directory/'fixed_evidence/candidates').is_dir())

    def test_partial_raw_is_saved_before_later_forward_failure(self):
        def physical(run,theta,accuracy,**kwargs):
            if accuracy=='tight':
                raise RuntimeError('controlled physical failure')
            return np.array([1.,0.,0.,0.])
        with self.assertRaisesRegex(RuntimeError,'controlled'):
            self.execute(physical)
        events=self.report['raw_events']
        self.assertEqual([r['status'] for r in events],['COMPLETE','RAISED'])
        self.assertEqual(events[0]['raw_residuals'],[1.,0.,0.,0.])
        self.assertEqual(self.report['status'],'INCOMPLETE')
        self.assertEqual(len(self.points),2)
        self.assertEqual(len(self.actual),2)

    def test_existing_deadline_and_cancel_stop_before_any_forward(self):
        for which in ('deadline','cancel'):
            with self.subTest(which=which):
                if which=='deadline':
                    self.config['portable_monotonic_deadline']=time.monotonic()-1.
                else:
                    self.cancel.set()
                with self.assertRaises((Interrupted,KeyboardInterrupt)):
                    self.execute()
                self.assertEqual(self.calls,[])
                if which=='deadline':
                    # Separate fresh fixture; no reset/overwrite of first output.
                    self.tearDown()
                    self.setUp()

    def test_coordinator_complete_is_not_itself_a_new_public_gate(self):
        original=fixed.s301_finalization.finalize
        def mark_auxiliary_incomplete(*args,**kwargs):
            result=original(*args,**kwargs)
            result['complete']=False
            return result
        ranking,boundaries=self.execute(extra=lambda stack:stack.enter_context(
            patch.object(fixed.s301_finalization,'finalize',side_effect=mark_auxiliary_incomplete)))
        self.assertFalse(self.report['complete'])
        self.assertTrue(ranking['passed'])
        self.assertTrue(all(not b['issues'] for b in boundaries.values()))

    def test_real_boundary_adapter_rejects_string_or_float32_theta(self):
        for theta in ([1.,.3,30.,0.,.2,.004],np.asarray(THETA,dtype=np.float32),
                      np.asarray([str(x) for x in THETA])):
            with self.subTest(theta=type(theta)),self.assertRaises(ValueError):
                fixed._normalize_report(dict(samples=[dict(theta=theta)]))

    def test_legacy_and_noiseless_skip_without_worker_or_new_files(self):
        for mode in ('legacy','noiseless'):
            with self.subTest(mode=mode):
                extra=(lambda stack:stack.enter_context(patch.object(api,'_historical_criterion',return_value={'kind':'original'}))) if mode=='legacy' else (
                    lambda stack:stack.enter_context(patch.object(api,'nonzero_residual_mode',return_value=False)))
                self.execute(extra=extra)
                self.assertEqual(self.report['status'],'SKIPPED')
                self.assertEqual(self.calls,[])
                self.assertFalse((self.directory/'fixed_evidence').exists())

    def test_shared_physical_cap_cannot_be_reset_by_boundary_or_new_source(self):
        def many(*args,**kwargs):
            audit=kwargs['evaluate_point']
            for index in range(28):
                theta=list(LOWER);theta[0]=1.+(index+1)*.00001
                audit('12345' if index%2==0 else '67890',theta,'current_point','cap fixture')
            self.fail('28th physical point should be refused')
        with self.assertRaisesRegex(Interrupted,'cap_exhausted'):
            self.execute(extra=lambda stack:stack.enter_context(
                patch.object(fixed.s301_finalization,'finalize',side_effect=many)))
        self.assertEqual(self.report['observed_point_count'],27)
        self.assertEqual(self.report['reserved_forward_calls'],81)
        self.assertEqual(len(self.calls),81)
        self.assertFalse(self.report['complete'])
        self.assertEqual(self.report['status'],'INCOMPLETE')

    def test_cancellation_after_return_saves_raw_but_stops_audit(self):
        def cancel_after_one(run,theta,accuracy,**kwargs):
            self.cancel.set()
            return np.array([1.,0.,0.,0.])
        with self.assertRaises(KeyboardInterrupt):
            self.execute(cancel_after_one)
        self.assertEqual(self.report['raw_events'][0]['status'],'COMPLETE')
        self.assertEqual(len(self.points),2)
        self.assertEqual(len(self.actual),2)
        self.assertFalse(self.report['complete'])

    def test_raw_report_persisted_before_adapter_failure(self):
        with self.assertRaisesRegex(ValueError,'adapter fixture'):
            self.execute(extra=lambda stack:stack.enter_context(
                patch.object(fixed,'_normalize_report',side_effect=ValueError('adapter fixture'))))
        raw=json.loads((self.directory/'fixed_evidence/boundary_12345_1_raw.json').read_text())
        self.assertTrue(raw['report_generation_completed'])
        self.assertIn('samples',raw['report'])
        self.assertEqual(raw['status'],'RAISED')
        self.assertEqual(self.report['status'],'INCOMPLETE')


class PublicEntryTests(unittest.TestCase):
    """Real main -> reliability -> fit_case scheduling; only numerics are mocked."""
    def exercise(self,status=COMPLETE,auxiliary_complete=True):
        temp=tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        target=Path(temp.name)/'task'
        case=base_case()
        case.update(fit_pipeline='s301',fit_pipeline_requested='s301',
            fit_pipeline_version='s301-portable-v1',reliability_policy=dict(max_attempts=1,budget_multiplier=2.))
        used=[]
        de=SimpleNamespace(population=np.zeros((1,6)),population_energies=np.array([1.]),
            nit=0,success=True,message='mock DE dispatcher only')
        def initial(run):
            run.state.update(status=status,solver_accepted=dict(status=1 if status==COMPLETE else 0))
        def collect(run,source,bounds,clean,points,rejected):
            points.append(point(clean,bounds,source,THETA))
        def targeted(*args):
            actual=args[11]
            actual.append(dict(theta=LOWER,accuracy='tight',chi2=1.,lineage_id='12345',
                raw_residuals=[1.,0.,0.,0.],stage_id='current_native_boundary'))
            return args[13],args[14]
        def physical(run,theta,accuracy,**kwargs):
            used.append(accuracy)
            return np.array([1.,0.,0.,0.])
        original_final=fixed.s301_finalization.finalize
        def final(*args,**kwargs):
            result=original_final(*args,**kwargs)
            result['complete']=auxiliary_complete and result['complete']
            return result
        with patch.object(api,'_pool',return_value=Pool()), \
             patch.object(api,'run_de_search',return_value=de), \
             patch.object(api,'select_candidates',return_value=[dict(theta=THETA)]), \
             patch.object(api._NonzeroRun,'run',new=initial), \
             patch.object(api,'_collect',side_effect=collect), \
             patch.object(api,'_boundary_check',return_value=deepcopy(CLEAN)), \
             patch.object(api,'_targeted_completion',side_effect=targeted), \
             patch.object(api._NonzeroRun,'start_pool',new=lambda run:setattr(run,'pool',Pool())), \
             patch.object(ArmRun,'physical',new=physical), \
             patch.object(fixed.s301_finalization,'finalize',side_effect=final), \
             patch.object(reliability,'validate_endpoint',return_value=dict(passed=True,numerical_checks_passed=True)), \
             patch('hybrid_support.least_squares',side_effect=AssertionError('No TRF in this mocked test')):
            outcome=main._run_task(case,str(target),1,'demo')
        native=json.loads((target/'fit/attempt_01/result.json').read_text())
        aggregate=json.loads((target/'result.json').read_text())
        return outcome,native,aggregate,used

    def test_public_entry_propagates_fixed_completion_and_keeps_reservation(self):
        outcome,native,aggregate,used=self.exercise()
        self.assertTrue(native['fixed_evidence_finalization']['complete'])
        self.assertEqual(used,['nominal','tight','third'])
        self.assertTrue(native['scientific_checks_passed'])
        self.assertTrue(outcome['scientific_checks_passed'])
        self.assertTrue(aggregate['scientific_checks_passed'])
        attempt=aggregate['reliability_attempts'][0]
        self.assertEqual(native['fixed_evidence_finalization']['shared_monotonic_deadline'],
            attempt['native_absolute_deadline_monotonic'])
        self.assertGreater(attempt['reserved_validation_wall_seconds_total'],0)
        self.assertEqual(len(native['stages']),2)
        self.assertEqual(native['ranking']['independent_sources'],2)

    def test_fixed_success_does_not_erase_old_iteration_or_wall_failure(self):
        for status in ('CROSS_FIT_LOCAL_BUDGET_EXHAUSTED_DIAGNOSTICS_RETAINED','WALL_BUDGET_EXHAUSTED','FAILED'):
            with self.subTest(status=status):
                outcome,native,aggregate,_=self.exercise(status)
                self.assertTrue(native['fixed_evidence_finalization']['complete'])
                self.assertFalse(native['scientific_checks_passed'])
                self.assertFalse(outcome['scientific_checks_passed'])
                self.assertFalse(aggregate['scientific_checks_passed'])
                self.assertTrue(all(s['status']==status for s in native['stages']))
                self.assertFalse(native['targeted_completion_closed'])

    def test_auxiliary_flag_false_does_not_create_new_acceptance_rule(self):
        _,native,aggregate,_=self.exercise(auxiliary_complete=False)
        self.assertFalse(native['fixed_evidence_finalization']['complete'])
        self.assertTrue(native['scientific_checks_passed'])
        self.assertTrue(aggregate['scientific_checks_passed'])


if __name__=='__main__':
    unittest.main()
