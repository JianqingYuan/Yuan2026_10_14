"""Pure/mock regressions for retention and budget accounting, no physical calls."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
from engine import api
from engine.demo_evidence import retain_completed_audit, split_attempt_budget
from hybrid_support import Interrupted, write


def case():
    return dict(case_id='pure_retention', fit_theory='ER', fit_mode='nonzero_residual_diagnostic',
        times=[0., 1.], xy_true=[[0., 0.], [0., 0.]], residual_sigma=1., threshold_D=.01,
        nominal_integration=dict(relative_tolerance=1e-10,absolute_tolerance=1e-12,max_step=.5),
        tight_integration=dict(relative_tolerance=1e-12,absolute_tolerance=1e-14,max_step=.25),
        bounds=dict(M=[.95,1.05], q=[.1,.5], rho0=[29.9,30.1], drho_dt0=[-.001,.001],
                    phi0=[.19,.21], dphi_dt0=[.0038,.0042]), run_seeds=[12345,67890])


class CompletedAuditTests(unittest.TestCase):
    def test_original_runner_first_triple_survives_second_audit_wall_stop(self):
        clean, bounds = api._validate_case(case())
        theta = [1., .3, 30., 0., .2, .004]
        lower = [1.001, .3, 30., 0., .2, .004]
        config = api._config(clean, 1, 'demo')
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)/'case'
            root = api._prepare(directory, clean, config)
            seed = dict(theta=theta)
            seed_path = directory/'seed.json'; write(seed_path, seed)
            run = api._NonzeroRun(root, config, dict(id='source_12345_candidate_0'), seed,
                clean, directory/'case.json', 'fixture', seed_source=seed_path,
                output_override=directory/'source_12345_candidate_0', shared_deadline=1e30)
            run.state['best'] = dict(theta=lower, kind='actual_tight_lower')
            run.state['actual_minima'] = dict(tight=dict(theta=lower, accuracy='tight',
                chi2=.25, residuals=[.5,0.,0.,0.], status='COMPLETE'))
            z = bounds.normalize(np.asarray(theta))
            solver = SimpleNamespace(x=z, status=0, success=False, message='finite nfev',
                nfev=8, njev=2, fun=np.array([1.,0.,0.,0.]), jac=np.zeros((4,6)),
                optimality=1., active_mask=np.zeros(6))
            def physical(point, accuracy, *args, **kwargs):
                role = kwargs.get('role', args[1] if len(args)>1 else '')
                if 'best_evaluated' in role:
                    # Exactly the real failure sequence: first triple has fully
                    # returned, second point has not. No synthetic second triple.
                    saved = json.loads((run.out/'diagnostic_residuals.json').read_text())
                    self.assertEqual(set(saved['candidates']), {'solver_returned'})
                    checkpoint = json.loads((run.out/'checkpoint.json').read_text())
                    self.assertIn('solver_returned', checkpoint['crossfit_audits'])
                    raise Interrupted('shared_case_wall_budget_exhausted')
                return np.array([1.,0.,0.,0.])
            with patch.object(run, 'start_pool'), patch.object(run, 'preflight'), \
                 patch.object(run, 'physical', side_effect=physical), \
                 patch.object(run, 'residual', return_value=np.array([1.,0.,0.,0.])), \
                 patch.object(run, 'jacobian', return_value=np.zeros((4,6))), \
                 patch('hybrid_support.least_squares', return_value=solver), \
                 patch('hybrid_support.projected_gradient_diagnostic', return_value={}):
                run.run()  # Real original control flow and three-precision auditor.
            self.assertEqual(run.state['status'], 'WALL_BUDGET_EXHAUSTED')
            self.assertFalse(run.state['solver_accepted']['success'])
            receipts = [json.loads(x) for x in (run.out/'completed_audits.jsonl').read_text().splitlines()]
            self.assertEqual([r['label'] for r in receipts], ['solver_returned'])
            self.assertEqual(receipts[0]['raw_residuals']['theta'], theta)
            points, rejected, actual, invalid = [], [], [], []
            api._collect(run, 12345, bounds, clean, points, rejected)
            api._remember_actual(run.state, 12345, run.out.name, actual, invalid)
            self.assertEqual(len(points), 1)
            self.assertTrue(points[0]['numerical_evidence_valid'])
            self.assertEqual(points[0]['lineage_id'], '12345')
            self.assertFalse(api.targeted.lower_guard(points, actual)['passed'])
            self.assertFalse(api._stage_outcome([api._stage_record(run.out.name,run,12345)])[0])
            self.assertFalse(run.state.get('scientific_checks_passed', False))

    def fixture(self, path):
        theta = [1., .3, 30., 0., .2, .004]
        raw = dict(theta=theta, nominal=[1.,0.], tight=[1.,0.], third=[2.,0.])
        audit = dict(theta=theta, precision_vector_within_ceiling=False)
        run = SimpleNamespace(out=path, truth=np.zeros((1,2)), shared_deadline=123.,
            state=dict(status='RUNNING', phase='audit', scientific_checks_passed=False,
                       lower_failed_candidate_veto=True), fit_theory='ER', sigma=1.,last_save=99.)
        run.save = lambda: write(path/'checkpoint.json',run.state)
        return run, theta, raw, audit

    def test_failed_precision_is_retained_but_never_relabelled_passed(self):
        with tempfile.TemporaryDirectory() as tmp:
            run,theta,raw,audit = self.fixture(Path(tmp))
            original = deepcopy(audit)
            retain_completed_audit(run,theta,'solver_returned',raw,audit,write,endpoint=True)
            self.assertEqual(audit,original)
            self.assertFalse(run.state['crossfit_audits']['solver_returned']['precision_vector_within_ceiling'])
            self.assertFalse(run.state['scientific_checks_passed'])
            self.assertTrue(run.state['lower_failed_candidate_veto'])
            self.assertEqual(run.shared_deadline,123.)

    def test_original_source_check_is_journalled_not_nominated(self):
        with tempfile.TemporaryDirectory() as tmp:
            run,theta,raw,audit = self.fixture(Path(tmp))
            retain_completed_audit(run,theta,'original_unchanged_source',raw,audit,write,endpoint=False)
            self.assertTrue((run.out/'completed_audits.jsonl').exists())
            self.assertFalse((run.out/'diagnostic_residuals.json').exists())
            self.assertNotIn('crossfit_audits',run.state)

    def test_partial_or_wrong_theta_cannot_become_completed_receipt(self):
        for change in ('missing_level','different_theta','nonfinite'):
            with self.subTest(change=change),tempfile.TemporaryDirectory() as tmp:
                run,theta,raw,audit=self.fixture(Path(tmp))
                if change=='missing_level':raw.pop('third')
                if change=='different_theta':audit['theta']=list(theta);audit['theta'][0]+=.1
                if change=='nonfinite':raw['third'][0]=float('nan')
                with self.assertRaises(ValueError):
                    retain_completed_audit(run,theta,'solver_returned',raw,audit,write,endpoint=True)
                self.assertFalse((run.out/'completed_audits.jsonl').exists())

    def test_later_duplicate_label_cannot_erase_previous_raw(self):
        with tempfile.TemporaryDirectory() as tmp:
            run,theta,raw,audit=self.fixture(Path(tmp))
            retain_completed_audit(run,theta,'solver_returned',raw,audit,write,endpoint=True)
            saved=(run.out/'diagnostic_residuals.json').read_bytes()
            altered=deepcopy(raw);altered['third'][0]=1.5
            with self.assertRaises(ValueError):
                retain_completed_audit(run,theta,'solver_returned',altered,audit,write,endpoint=True)
            self.assertEqual(saved,(run.out/'diagnostic_residuals.json').read_bytes())
            self.assertEqual(len((run.out/'completed_audits.jsonl').read_text().splitlines()),2)


class SplitBudgetTests(unittest.TestCase):
    def test_default_single_and_pair_shares_remain_inside_original_total(self):
        for factor in (1,2,4):
            for models,native in ((1,240),(2,180)):
                split=split_attempt_budget(300.*factor,factor,models)
                self.assertEqual(split['native_seconds'],native*factor)
                self.assertEqual(split['validation_seconds_per_model'],60.*factor)
                self.assertEqual(split['native_seconds']+split['reserved_seconds'],300.*factor)

    def test_tiny_budget_reserves_positive_time_without_stealing_other_model(self):
        split=split_attempt_budget(.01,4,2)
        self.assertEqual(split['native_seconds'],.005)
        self.assertEqual(split['validation_seconds_per_model'],.0025)

    def test_bad_budget_rejected(self):
        for value in (0,-1,True,float('nan'),float('inf')):
            with self.assertRaises(ValueError):split_attempt_budget(value,1,2)


if __name__=='__main__':unittest.main()
