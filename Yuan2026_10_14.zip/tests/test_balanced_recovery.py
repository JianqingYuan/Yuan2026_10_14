"""Pure/private schedule and original native recovery with mocked physics."""
from copy import deepcopy
from dataclasses import replace
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('balanced_unit', ROOT/'engine/_legacy_balanced.py')
balanced = importlib.util.module_from_spec(spec)
spec.loader.exec_module(balanced)


class Clock:
    def __init__(self): self.now = 0.
    def __call__(self): return self.now


def schedule_fixture(seeds=None):
    clock, events = Clock(), []
    plan = balanced.BalancedRecoverySchedule(100.,record=events.append,
        verification_reserve=20.,clock=clock)
    seeds = seeds or [dict(source='own',run_index=0),dict(source='own',run_index=1),
                      dict(source='own',run_index=0),dict(source='own',run_index=1)]
    state = {'models':{n:{'seeds':deepcopy(seeds)} for n in ('ER','RN')}}
    plan.bind(state)
    route = lambda row: ('cross-theory:ER' if row.source.startswith('cross')
                          else 'de-run-'+str(row.run_index))
    return plan,state,clock,events,route


class ScheduleTests(unittest.TestCase):
    def test_full_rescores_before_interleaved_original_sources(self):
        plan,state,clock,events,route = schedule_fixture()
        steps = list(plan.steps(('ER','RN'),state,route,lambda d:SimpleNamespace(**d)))
        self.assertEqual(steps[:6],[('ER','rescore',None),('RN','rescore',None),
            ('ER','local',0),('RN','local',0),('ER','local',1),('RN','local',1)])
        self.assertEqual(steps[-2:],[('ER','verify',None),('RN','verify',None)])
        self.assertEqual(state['balanced_schedule']['new_independent_DE_votes'],0)

    def test_extra_basins_do_not_consume_verification_reserve(self):
        plan,state,clock,events,route = schedule_fixture()
        iterator = plan.steps(('ER','RN'),state,route,lambda d:SimpleNamespace(**d))
        for unused in range(6): next(iterator)
        clock.now=80.
        self.assertEqual(list(iterator),[('ER','verify',None),('RN','verify',None)])
        self.assertEqual(len(state['balanced_schedule']['skipped_optional']),4)

    def test_borrowed_or_same_route_not_a_second_own_source(self):
        seeds=[dict(source='cross-theory:ER:x',run_index=None),
               dict(source='own',run_index=0),dict(source='own',run_index=0)]
        plan,state,clock,events,route=schedule_fixture(seeds)
        list(plan.steps(('ER','RN'),state,route,lambda d:SimpleNamespace(**d)))
        self.assertEqual(state['balanced_schedule']['required_seed_indices'],{'ER':[1],'RN':[1]})

    def test_reserve_is_inside_existing_budget_not_a_new_1800_seconds(self):
        clock=Clock()
        schedule=balanced.BalancedRecoverySchedule(60.,record=lambda row:None,clock=clock)
        self.assertEqual((schedule.reserve,schedule.work_deadline,schedule.deadline),(10.,50.,60.))
        with self.assertRaises(ValueError):
            balanced.BalancedRecoverySchedule(60.,record=lambda row:None,clock=clock,verification_reserve=61.)

    def test_resume_cannot_change_deadline(self):
        plan,state,clock,events,route=schedule_fixture()
        other=balanced.BalancedRecoverySchedule(200.,record=events.append,clock=clock)
        with self.assertRaises(ValueError): other.bind(state)

    def test_deadline_is_not_caught_as_an_ordinary_solver_penalty(self):
        self.assertFalse(issubclass(balanced.RecoveryActionDeadline,Exception))
        self.assertFalse(issubclass(balanced.RecoveryDeadline,Exception))

    def test_raw_before_late_action_rejection(self):
        import numpy as np
        from dataclasses import make_dataclass
        plan,state,clock,events,route=schedule_fixture()
        settings=make_dataclass('Settings',[('value',int)])(1)
        plan._stage('ER','local',0,1.)
        def function(theta): clock.now=1.1; return np.array([2.,3.])
        call=plan.wrap(function,'ER',settings,SimpleNamespace(sigma_x=[2.],sigma_y=[4.]))
        with self.assertRaises(balanced.RecoveryActionDeadline): call([1.,.1,30.,0.,0.,.1])
        self.assertEqual(events[-1]['status'],'RETURNED')
        self.assertEqual(events[-1]['raw_residuals'],[4.,12.])
        self.assertEqual(len(state['balanced_schedule']['actual_minima']),1)

    def test_undispatched_and_failed_calls_are_retained(self):
        from dataclasses import make_dataclass
        plan,state,clock,events,route=schedule_fixture()
        settings=make_dataclass('Settings',[('value',int)])(1)
        plan._stage('RN','local',0,1.)
        def recorder(event): events.append(event); clock.now=1.1
        plan.record=recorder
        call=plan.wrap(lambda theta:self.fail('must not dispatch'),'RN',settings,
            SimpleNamespace(sigma_x=[1.],sigma_y=[1.]))
        with self.assertRaises(balanced.RecoveryActionDeadline): call([1.,.1,30.,0.,0.,.1])
        self.assertEqual(events[-1]['status'],'NEVER_DISPATCHED')

    def test_nonfinite_evidence_kept_without_invalid_json(self):
        value=balanced.evidence_wire({'x':[float('nan'),float('inf'),-float('inf')]})
        json.dumps(value,allow_nan=False)
        self.assertEqual(value['x'][0],{'nonfinite':'nan'})

    def test_invalid_lower_point_cannot_hide_legal_actual_minimum(self):
        import numpy as np
        from dataclasses import make_dataclass
        plan,state,clock,events,route=schedule_fixture()
        settings=make_dataclass('Settings',[('value',int)])(1)
        plan._stage('ER','local',0,10.)
        function=plan.wrap(lambda p: np.array([float(p[0]),0.]),'ER',settings,
            SimpleNamespace(sigma_x=[1.],sigma_y=[1.]),
            bounds=SimpleNamespace(normalize=lambda p:p))
        function([.5]*6)
        function([.01,-1.,.5,.5,.5,.5])
        self.assertEqual(next(iter(plan.state['actual_minima'].values()))['chi2'],.25)
        self.assertEqual(next(iter(plan.state['invalid_actual_minima'].values()))['chi2'],.0001)
        self.assertEqual(sum(row['status']=='RETURNED' for row in events),2)


def native_child(action):
    sys.path.insert(0,str(ROOT))
    sys.path.insert(0,str(ROOT/'tests'))
    import numpy as np
    from engine import _legacy_worker as worker
    from test_baseline_demo_recovery import fixture
    worker.bootstrap('baseline')
    from workflow import integration_recovery as recovery, study
    from spherical_geodesics.astrometry.optimization import FitCandidate
    from spherical_geodesics.astrometry.parameters import resolve_theory_bounds
    payload=fixture()
    profile,_=worker.build_profile(payload)
    theta=np.array([1.,.4,30.,0.,.2,.004])
    bounds=resolve_theory_bounds('ER',payload['cases']['ER']['bounds'])
    rows=[study._jsonable(study._candidate_record(FitCandidate(bounds.normalize(theta),theta,4.,
        f'original-de-{i}',run_index=i,success=True,message='old success',nfev=5,njev=4,optimality=0.)))
        for i in range(2)]
    results={n:dict(best_theta=theta.tolist(),best_z=bounds.normalize(theta).tolist(),chi2_min=4.,
        best_source='original-de-0',global_candidates=deepcopy(rows),screening_candidates=[],
        local_candidates=deepcopy(rows),elapsed_seconds=9.,fit_objective=recovery._objective(profile.nominal_settings,0),
        integration_check=dict(within_tolerance=n=='ER',nominal_saved_within_tolerance=True),
        diagnostics=dict(workflow_complete=True,degrees_of_freedom=196,
            certification_status='REPEATABLE_SOLUTION',local_successful_candidates=2)) for n in ('ER','RN')}
    original=deepcopy(results)
    state={}
    clock,events=Clock(),[]
    schedule=balanced.BalancedRecoverySchedule(100.,record=events.append,verification_reserve=20.,clock=clock)
    data=SimpleNamespace(times=np.arange(4.),x_obs=np.zeros(4),y_obs=np.zeros(4),
        sigma_x=np.ones(4),sigma_y=np.ones(4),n_components=8)
    locals_=[]
    def factory(name,record,configured,settings,observed):
        assert configured is profile and observed is data
        def function(point):
            if action=='hard_interrupt' and schedule.context.get('phase')=='local': clock.now=100.
            if action=='soft_interrupt' and schedule.context.get('phase')=='local' and not locals_:
                clock.now=schedule.action_deadline+.001
            if action in ('lower_probe','near_probe') and not np.array_equal(point,theta):
                score=3.8 if action=='lower_probe' else 3.95
                return np.asarray([np.sqrt(score/4.),0.]*4)
            return np.asarray([1.,0.]*4)
        return function
    def local(function,passed_bounds,seeds,components,config,source_prefix):
        assert results==original and seeds[0].success is False
        assert config.max_nfev==3 and config.jacobian=='3-point'
        if action in ('lower_probe','near_probe'):
            function(seeds[0].theta+np.array([.001,0.,0.,0.,0.,0.]))
        function(seeds[0].theta)
        locals_.append((schedule.context['theory'],seeds[0].run_index))
        return SimpleNamespace(candidates=(replace(seeds[0],success=action!='no_success',
            chi2=4.,message='new mock',nfev=1,njev=1,optimality=0.),),total_evaluations=1,invalid_evaluations=0)
    with patch.object(study,'_bounds_from_fit_record',return_value=bounds), \
         patch.object(recovery,'_model_function',side_effect=factory), \
         patch.object(recovery,'run_least_squares',side_effect=local), \
         patch.object(recovery,'TheoryForwardModel',side_effect=AssertionError('No physics')), \
         patch.object(recovery,'residual',side_effect=AssertionError('No physics')):
        if action=='hard_interrupt':
            try: recovery.complete_integration_recovery(data,profile,results,state=state,schedule=schedule)
            except balanced.RecoveryDeadline: pass
            else: raise AssertionError('expected interruption')
            assert results==original and not state['adopted'] and not state['complete']
        else:
            recovery.complete_integration_recovery(data,profile,results,state=state,schedule=schedule)
            assert state['complete'] and state['adopted'] and recovery.shared_objective(results)
            assert state['original_models']==original
            for record in results.values():
                assert record['integration_check']['tolerance']==.01
                assert record['integration_check']['within_tolerance'] is True
                assert all(row['success'] is False for row in record['global_candidates'])
                assert record['fit_objective']['level']==1
            if action=='success':
                assert locals_==[('ER',0),('RN',0),('ER',1),('RN',1)],locals_
                phases=[e['context']['phase'] for e in events if e['status']=='RETURNED']
                assert phases[:8]==['rescore']*8 and phases[-4:]==['verify']*4
            if action=='soft_interrupt':
                assert any(e.get('error','').startswith('RecoveryActionDeadline')
                    for ms in state['models'].values() for e in ms['history'])
                assert all(r['diagnostics']['certification_status']=='COMPUTATIONALLY_UNRESOLVED'
                    for r in results.values())
            if action=='no_success':
                assert all(r['diagnostics']['local_successful_candidates']==0 for r in results.values())
            if action in ('lower_probe','near_probe'):
                for record in results.values():
                    actual=record['diagnostics']['balanced_actual_review']
                    assert actual['original_chi2_agreement']==profile.certification_config.chi2_agreement
                    assert actual['known_lower_unresolved'] is (action=='lower_probe')
                    assert actual['probe_is_optimizer_endpoint'] is False and actual['new_independent_DE_votes']==0
                    assert record['chi2_min']==4., 'An actual probe is not a selected solver endpoint'
                    if action=='lower_probe':
                        assert record['diagnostics']['certification_status']=='COMPUTATIONALLY_UNRESOLVED'
    if action=='hook':
        with tempfile.TemporaryDirectory() as output:
            old=study.complete_integration_recovery
            with worker.balanced_recovery_route(dict(payload,pair_deadline_monotonic=100.),output,study):
                assert study.complete_integration_recovery is not old
            assert study.complete_integration_recovery is old
            assert (Path(output)/'balanced_recovery_raw.jsonl').is_file()
        for variant,mode in (('extreme','demo'),('baseline','paper')):
            with tempfile.TemporaryDirectory() as output:
                with worker.balanced_recovery_route(dict(payload,variant=variant,profile=mode),output,study):
                    assert study.complete_integration_recovery is old
                assert not list(Path(output).iterdir())
    return dict(physical_calls=0, action=action, raw_events=len(events))


class NativeMockTests(unittest.TestCase):
    def child(self,action):
        outcome=subprocess.run([sys.executable,'-B',str(Path(__file__).resolve()),action],
            cwd=ROOT,text=True,capture_output=True,timeout=30)
        self.assertEqual(outcome.returncode,0,outcome.stdout+outcome.stderr)
        self.assertEqual(json.loads(outcome.stdout)['physical_calls'],0)
    def test_balanced_native_adoption(self): self.child('success')
    def test_no_old_success_inheritance(self): self.child('no_success')
    def test_soft_interruption_preserves_original_science_failure(self): self.child('soft_interrupt')
    def test_hard_interruption_no_partial_adoption(self): self.child('hard_interrupt')
    def test_worker_routes_only_baseline_demo(self): self.child('hook')
    def test_actual_lower_probe_veto_uses_original_legacy_scale(self): self.child('lower_probe')
    def test_actual_probe_inside_original_scale_is_retained_not_a_new_stricter_gate(self): self.child('near_probe')


if __name__=='__main__':
    if len(sys.argv)==2 and sys.argv[1] in ('success','no_success','soft_interrupt','hard_interrupt','hook','lower_probe','near_probe'):
        print(json.dumps(native_child(sys.argv[1])))
    else: unittest.main()
