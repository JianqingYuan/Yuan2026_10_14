"""Fixed S301 reference portability checks, never a DE/TRF experiment.

Only the final test integrates: exactly two full T000 truth-reference forwards
(nominal and tight). All other tests exercise policy or saved audit evidence.
"""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from engine.api import (_PortableIO, _SelfRun, _configure_portable_reference,
                        _validate_case, fit_case, predict)
from experiments.api import iter_cases
from hybrid_support import verify_reference_value


def t000():
    return next(iter_cases('s301', models=('ER',), indices=('T000',), fit_pipeline='s301'))


def configured(original):
    case, _ = _validate_case(original)
    _configure_portable_reference(case)
    return case


def recorded_audit(case, measured, directory, status='NOT_VALIDATED'):
    """Exercise the real audit writer after a controlled, non-running arm."""
    run = _SelfRun.__new__(_SelfRun)
    run.case = case
    run.out = Path(directory)
    run.state = dict(status=status, reference_reproduction={'D': measured})
    with patch.object(_PortableIO, 'run'), patch.object(run, 'save'):
        run.run()
    return (json.loads((run.out/'reference_compatibility.json').read_text(encoding='utf-8')),
            json.loads((run.out/'result.json').read_text(encoding='utf-8')))


class ReferencePolicyTests(unittest.TestCase):
    def test_all_six_bundled_self_references_preserve_original_case_and_gates(self):
        cases = list(iter_cases('s301', models=('ER',), include_noisy=False, fit_pipeline='s301'))
        self.assertEqual(len(cases), 6)
        for original in cases:
            with self.subTest(case=original['case_id']):
                before = deepcopy(original)
                # Policy configuration must not query this machine's trajectory.
                with patch('engine.api.predict', side_effect=AssertionError('Adaptive reference calculation')):
                    case = configured(original)
                self.assertEqual(original, before)
                self.assertEqual(case['archived_reference_D'], before['reference_D'])
                self.assertIsNot(case['archived_reference_D'], original['reference_D'])
                self.assertEqual(case['reference_D'], {'nominal': None, 'tight': None})
                self.assertEqual(case['reference_ceiling_D'], before['threshold_D'])
                for name in ('threshold_D', 'precision_vector_ceiling', 'precision_criterion',
                             'reference_theta', 'bounds', 'run_seeds', 'nominal_integration',
                             'tight_integration', 'xy_observed'):
                    self.assertEqual(case[name], before[name], name)

    def test_fit_case_configures_only_its_validated_copy_before_any_computation(self):
        original = t000()
        before = deepcopy(original)
        captured = {}

        class StopBeforeComputation(Exception):
            pass

        def capture(directory, case, config):
            captured.update(case=deepcopy(case), config=deepcopy(config))
            raise StopBeforeComputation()

        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary)/'not_created'
            with patch('engine.api._prepare', side_effect=capture), \
                 patch('engine.api._pool') as pool, patch('engine.api.run_de_search') as de:
                with self.assertRaises(StopBeforeComputation):
                    fit_case(original, destination, workers=1, profile='demo')
                pool.assert_not_called()
                de.assert_not_called()
            self.assertFalse(destination.exists())
        self.assertEqual(original, before)
        self.assertEqual(captured['case']['archived_reference_D'], before['reference_D'])
        self.assertEqual(captured['case']['reference_D'], {'nominal': None, 'tight': None})
        self.assertEqual(captured['case']['reference_ceiling_D'], before['threshold_D'])
        self.assertEqual(captured['case']['threshold_D'], before['threshold_D'])
        self.assertNotIn('reference_theta', captured['case'])

    def test_cases_outside_declared_reference_policy_are_unchanged(self):
        excluded = [
            next(iter_cases('s301', models=('RN',), include_noisy=False, fit_pipeline='s301')),
            next(iter_cases('s301', models=('ER',), include_noiseless=False, fit_pipeline='s301')),
            next(iter_cases('baseline', models=('ER',), include_noisy=False, fit_pipeline='s301')),
            next(iter_cases('extreme', models=('ER',), include_noisy=False, fit_pipeline='s301')),
        ]
        for key, value in (('generating_theory', 'RN'), ('fit_mode', 'nonzero_residual_diagnostic')):
            case = t000()
            case[key] = value
            excluded.append(case)
        for missing in ('reference_theta', 'metadata'):
            case = t000()
            del case[missing]
            excluded.append(case)
        for non_false in (None, 0, 'false'):
            case = t000()
            case['metadata']['add_noise'] = non_false
            excluded.append(case)
        for index, case in enumerate(excluded):
            with self.subTest(index=index, case=case['case_id']):
                before = deepcopy(case)
                _configure_portable_reference(case)
                self.assertEqual(case, before)

    def test_malformed_archived_norms_are_rejected_without_partial_rewrite(self):
        bad = [None, {}, {'nominal': 1e-5}, {'nominal': 1e-5, 'tight': 1e-6, 'third': 1e-7}]
        for value in (None, '0.00001', -1., float('nan'), float('inf'), True, False):
            bad.append({'nominal': value, 'tight': 1e-6})
            bad.append({'nominal': 1e-5, 'tight': value})
        for reference in bad:
            with self.subTest(reference=reference):
                case = t000()
                case['reference_D'] = reference
                with self.assertRaises((ValueError, TypeError)):
                    _configure_portable_reference(case)
                self.assertIs(case['reference_D'], reference)
                self.assertNotIn('archived_reference_D', case)
                self.assertNotIn('reference_ceiling_D', case)

    def test_fixed_original_ceiling_accepts_boundary_and_rejects_any_excess(self):
        case = configured(t000())
        fixed = case['threshold_D']
        for level in ('nominal', 'tight'):
            self.assertTrue(verify_reference_value(0., case['reference_D'][level], case))
            self.assertTrue(verify_reference_value(fixed, case['reference_D'][level], case))
            for measured in (np.nextafter(fixed, np.inf), 10.*fixed, -1., np.inf, np.nan):
                with self.subTest(level=level, measured=measured):
                    self.assertFalse(verify_reference_value(measured, case['reference_D'][level], case))
                    self.assertEqual(case['reference_ceiling_D'], fixed)
                    self.assertEqual(case['threshold_D'], fixed)

    def test_compatibility_audit_does_not_relabel_a_historical_mismatch_or_fit_status(self):
        original = t000()
        case = configured(original)
        measured = {level: .5*case['threshold_D'] for level in ('nominal', 'tight')}
        for level, value in measured.items():
            self.assertFalse(verify_reference_value(value, original['reference_D'][level], original))
            self.assertTrue(verify_reference_value(value, case['reference_D'][level], case))
        for status in ('NOT_VALIDATED', 'FAILED'):
            with self.subTest(status=status), tempfile.TemporaryDirectory() as temporary:
                report, result = recorded_audit(case, measured, temporary, status=status)
            self.assertEqual(report['archived_D'], original['reference_D'])
            self.assertEqual(report['measured_D'], measured)
            self.assertEqual(report['historical_norm_matches'], {'nominal': False, 'tight': False})
            self.assertEqual(report['fixed_ceiling'], original['threshold_D'])
            self.assertFalse(report['historical_norm_match_required'])
            self.assertTrue(report['reference_is_not_optimizer_seed'])
            self.assertTrue(report['fit_acceptance_gate_unchanged'])
            self.assertEqual(result['status'], status)
            self.assertEqual(result['portable_reference_check'], report)
            self.assertNotIn('run_complete', result)


class FullReferencePhysicalTests(unittest.TestCase):
    # Exposed for the independent validation report; no extra prediction needed.
    measured = None
    archived_matches = None

    def test_real_t000_full_times_pass_original_fixed_reference_ceiling(self):
        original = t000()
        before = deepcopy(original)
        case = configured(original)
        self.assertEqual(len(case['times']), 101)
        measured = {}
        for level in ('nominal', 'tight'):
            prediction = predict(case['reference_theta'], case['times'], theory='ER',
                integration=case[level+'_integration'], theory_options=case['fit_theory_options'])
            residual = (prediction-np.asarray(case['xy_observed'])).reshape(-1)
            self.assertEqual(residual.shape, (202,))
            self.assertTrue(np.all(np.isfinite(residual)))
            measured[level] = float(np.linalg.norm(residual))
            self.assertTrue(verify_reference_value(measured[level], case['reference_D'][level], case),
                f'{level} D={measured[level]} exceeds unchanged gate {original["threshold_D"]}')
        expected_matches = {level: verify_reference_value(measured[level], original['reference_D'][level], original)
                            for level in ('nominal', 'tight')}
        with tempfile.TemporaryDirectory() as temporary:
            report, result = recorded_audit(case, measured, temporary)
        self.assertEqual(report['historical_norm_matches'], expected_matches)
        self.assertEqual(report['fixed_ceiling'], original['threshold_D'])
        self.assertEqual(report['archived_D'], original['reference_D'])
        self.assertEqual(result['status'], 'NOT_VALIDATED')
        self.assertEqual(case['threshold_D'], original['threshold_D'])
        self.assertEqual(case['precision_vector_ceiling'], original['precision_vector_ceiling'])
        self.assertEqual(original, before)
        type(self).measured = measured
        type(self).archived_matches = expected_matches


if __name__ == '__main__':
    unittest.main()
