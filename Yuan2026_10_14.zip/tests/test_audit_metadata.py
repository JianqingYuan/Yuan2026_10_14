"""S301 endpoint evidence must survive collection even if revalidation times out."""
import unittest

import test_stage_status as stage_fixtures
from spherical_geodesics.astrometry.parameters import resolve_theory_bounds


class AuditMetadataTests(unittest.TestCase):
    def test_native_result_is_self_describing_before_outer_validation(self):
        fixture = stage_fixtures.StageStatusTests()
        result = fixture.fit_status('LOCAL_NFEV_BUDGET_EXHAUSTED')
        case = fixture.case()
        effective = resolve_theory_bounds(case['fit_theory'], case['bounds'])
        self.assertEqual(result['effective_bounds']['lower'], effective.lower.tolist())
        self.assertEqual(result['effective_bounds']['upper'], effective.upper.tolist())
        self.assertEqual(result['parameter_order'], list(effective.names))
        self.assertEqual(result['effective_bounds']['free_names'], list(effective.free_names))
        self.assertEqual(result['nominal_integration'], case['nominal_integration'])
        self.assertEqual(result['tight_integration'], case['tight_integration'])
        self.assertEqual(result['residual_integration'], result['third_integration'])
        self.assertEqual(result['residual_accuracy'], 'third')
        self.assertIn('fit_theory_options', result)
        self.assertIn('residual/sigma', result['residual_semantics'])
        self.assertFalse(result['scientific_checks_passed'])


if __name__ == '__main__':
    unittest.main()
