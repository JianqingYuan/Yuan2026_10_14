"""Input and checkpoint contracts without forward calls or optimizers."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

from engine.api import (_config, _NonzeroRun, _PortableIO, _prepare,
                        _validate_case, fit_case)
from engine.legacy import _payload, fit_pair
from experiments.api import iter_cases
from hybrid_support import ArmRun, write


def static_case():
    return dict(case_id='static_input_contract', fit_theory='ER',
        fit_mode='nonzero_residual_diagnostic', times=[0., 1.],
        xy_true=[[1., 0.], [1., .1]], residual_sigma=.01, threshold_D=1e-7,
        nominal_integration=dict(relative_tolerance=1e-10,
            absolute_tolerance=1e-12, max_step=.5),
        tight_integration=dict(relative_tolerance=1e-12,
            absolute_tolerance=1e-14, max_step=.25),
        bounds=dict(M=[.95, 1.05], q=[.1, .5], rho0=[29.9, 30.1],
            drho_dt0=[-.001, .001], phi0=[.19, .21], dphi_dt0=[.0038, .0042]),
        run_seeds=[12345, 67890])


class EngineInputTests(unittest.TestCase):
    def test_observation_aliases_must_agree_before_output_is_created(self):
        case = static_case()
        case['xy_observed'] = deepcopy(case['xy_true'])
        case['xy_observed'][0][0] += 1.
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary) / 'conflicting_case'
            with patch('engine.api._pool') as pool:
                with self.assertRaisesRegex(ValueError, 'same observations'):
                    fit_case(case, target, profile='demo')
            self.assertFalse(target.exists())
            pool.assert_not_called()

    def test_either_observation_name_or_equal_aliases_remain_supported(self):
        original = static_case()
        for names in (('xy_true',), ('xy_observed',), ('xy_true', 'xy_observed')):
            with self.subTest(names=names):
                case = deepcopy(original)
                values = case.pop('xy_true')
                case.update({name: deepcopy(values) for name in names})
                before = deepcopy(case)
                clean, _ = _validate_case(case)
                self.assertEqual(clean['xy_true'], original['xy_true'])
                self.assertEqual(case, before)

    def test_legacy_rejects_conflicting_aliases_in_either_model(self):
        pair = list(iter_cases('baseline', 'demo', include_noisy=False))[:2]
        for index in (0, 1):
            with self.subTest(model=pair[index]['fit_theory']):
                changed = deepcopy(pair)
                changed[index]['xy_true'][0][0] += 1.
                with self.assertRaisesRegex(ValueError, 'same observations'):
                    _payload(*changed, 'demo')

    def test_legacy_preserves_single_observation_names_and_equal_aliases(self):
        pair = list(iter_cases('baseline', 'demo', include_noisy=False))[:2]
        expected = pair[0]['xy_observed']
        for names in (('xy_true',), ('xy_observed',), ('xy_true', 'xy_observed')):
            with self.subTest(names=names):
                changed = deepcopy(pair)
                for case in changed:
                    for name in ('xy_true', 'xy_observed'):
                        if name not in names:
                            del case[name]
                self.assertEqual(_payload(*changed, 'demo')['xy_observed'], expected)

    def test_legacy_invalid_wall_budget_creates_no_output(self):
        pair = list(iter_cases('baseline', 'demo', include_noisy=False))[:2]
        for budget in (0, -1, True, float('nan'), float('inf'), -float('inf'), '5', None):
            with self.subTest(budget=budget), tempfile.TemporaryDirectory() as temporary:
                changed = deepcopy(pair)
                changed[0]['wall_seconds_per_pair'] = budget
                target = Path(temporary) / 'invalid_budget'
                with patch('engine.legacy.subprocess.Popen') as launch:
                    with self.assertRaisesRegex(ValueError, 'finite and positive'):
                        fit_pair(*changed, target, profile='demo')
                self.assertFalse(target.exists())
                launch.assert_not_called()


class EngineCheckpointTests(unittest.TestCase):
    def test_rapid_stage_failure_finishes_the_checkpoint(self):
        case, _ = _validate_case(static_case())
        config = _config(case, 1, 'demo')
        seed = dict(theta=[1., .3, 30., 0., .2, .004])
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary) / 'case'
            root = _prepare(directory, case, config)
            write(directory / 'seed.json', seed)
            run = _NonzeroRun(root, config,
                dict(id='stage', hybrid_phi=True, x_scale='jac'), seed, case,
                directory / 'case.json', 'initial', reference_theta=None,
                seed_source=directory / 'seed.json', output_override=directory / 'stage',
                shared_deadline=time.time() + 10)
            with patch.object(run, 'start_pool'), patch.object(run, 'preflight',
                    side_effect=RuntimeError('controlled failure before any forward')):
                run.run()
            checkpoint = json.loads((run.out / 'checkpoint.json').read_text(encoding='utf-8'))
            result = json.loads((run.out / 'result.json').read_text(encoding='utf-8'))
            self.assertEqual(checkpoint, result)
            self.assertEqual(checkpoint['status'], 'FAILED')
            self.assertEqual(checkpoint['phase'], 'finished')
            self.assertIn('finished_utc', checkpoint)

    def test_running_updates_are_throttled_but_explicit_and_terminal_saves_are_not(self):
        run = _NonzeroRun.__new__(_NonzeroRun)
        run.config = dict(checkpoint_seconds=30)
        run.state = dict(status='RUNNING', phase='refinement')
        run.last_save = 99.
        with patch('engine.api.time.monotonic', return_value=100.), \
                patch.object(ArmRun, 'save') as save:
            _PortableIO.save(run)
            save.assert_not_called()
            for status in ('FAILED', 'INTERRUPTED_CHECKPOINT_RETAINED',
                           'CROSS_FIT_DIAGNOSTIC_COMPLETE_REQUIRES_REVIEW'):
                run.state['status'] = status
                _PortableIO.save(run)
            self.assertEqual(save.call_count, 3)
            run.state['status'] = 'RUNNING'
            run.last_save = 0.
            _PortableIO.save(run)
            self.assertEqual(save.call_count, 4)


if __name__ == '__main__':
    unittest.main()
