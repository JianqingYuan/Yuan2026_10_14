"""Launcher regression tests: no full experiments or real paper plotting."""
import _thread
from concurrent.futures import Future
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

import main
from experiments.api import iter_cases, list_case_ids
from run_state import write_json, digest, pipeline_provenance


def controlled_task(case, destination, cores_per_fit, profile):
    """A real spawned worker that stops via the launcher's shared event."""
    path = Path(destination)
    path.mkdir(parents=True)
    (path/'started').touch()
    if not main._STOP_EVENT.wait(20):
        raise RuntimeError('Cancellation was not delivered')
    return dict(case_id=case['case_id'], state='INCOMPLETE', engine_status='INTERRUPTED')


def locked_sigint_probe():
    """Subprocess probe so a future signal-lock regression has a hard timeout."""
    def interrupt_inside_event_lock(*args):
        with main._STOP_EVENT._cond:
            signal.raise_signal(signal.SIGINT)
    with tempfile.TemporaryDirectory() as name:
        output=Path(name)/'interrupted'
        with patch('main._select_cases',side_effect=lambda options: iter([{'case_id':'probe_ER'}])), \
             patch('main._run_task',side_effect=interrupt_inside_event_lock), redirect_stdout(io.StringIO()):
            code=main.run(['--mode','demo','--fit-pipeline','s301','--workers','1',
                          '--cores-per-fit','1','--max-tasks','1','--output',str(output)])
        assert code==130
        assert json.loads((output/'run.json').read_text())['state']=='INTERRUPTED'


class ControlledExecutor:
    """Exercise dispatch failures without starting an optimizer or worker."""
    def __init__(self, fail_submit=None):
        self.fail_submit = fail_submit
        self.futures = []
        self.stopped_on_exit = None

    def __enter__(self):
        return self

    def submit(self, function, *arguments):
        if self.fail_submit == len(self.futures):
            raise RuntimeError('Controlled submit failure')
        future = Future()
        self.futures.append(future)
        return future

    def __exit__(self, *exception):
        self.stopped_on_exit = main._STOP_EVENT.is_set()


class LauncherTests(unittest.TestCase):
    def test_help_groups_keep_all_run_controls(self):
        parser = main._parser()
        groups = {group.title: {option for action in group._group_actions
                               for option in action.option_strings}
                  for group in parser._action_groups}
        self.assertEqual(groups['Common options'],
                         {'--mode', '--suite', '--fit-pipeline', '--workers', '--task-range', '--output', '--dry-run'})
        self.assertEqual(groups['Advanced options'],
                         {'--cores-per-fit', '--resume', '--max-tasks', '--task-index',
                          '--models', '--figures', '--verify', '--collect'})
        self.assertIn('paper: redraw saved figures', parser.format_help())
        with patch('settings.WORKERS', 7):
            self.assertIn('default: 7', main._parser().format_help())

    def test_grouping_preserves_defaults_and_advanced_parsing(self):
        import settings
        parser = main._parser()
        defaults = parser.parse_args([])
        self.assertEqual((defaults.mode, defaults.suite, defaults.workers, defaults.cores_per_fit),
                         (settings.MODE, settings.SUITE, settings.WORKERS, settings.CORES_PER_FIT))
        selected = parser.parse_args(['--mode', 'recompute', '--suite', 's301',
            '--workers', '8', '--cores-per-fit', '2', '--models', 'RN',
            '--task-index', '3', '--resume', 'previous', '--dry-run'])
        self.assertEqual((selected.mode, selected.suite, selected.workers, selected.cores_per_fit,
                          selected.models, selected.task_index, selected.resume, selected.dry_run),
                         ('recompute', 's301', 8, 2, ['RN'], 3, Path('previous'), True))

    def test_sigint_while_event_lock_is_held_does_not_deadlock(self):
        command='import sys; sys.path.insert(0,"tests"); from test_launcher import locked_sigint_probe; locked_sigint_probe()'
        result=subprocess.run([sys.executable,'-B','-c',command],cwd=main.ROOT,
                              capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_invalid_settings_mode_never_falls_through_to_recompute(self):
        with patch('settings.MODE', 'typo'), self.assertRaises(ValueError):
            main.run(['--dry-run'])

    def test_conflicting_task_selectors_are_rejected(self):
        with self.assertRaises(ValueError):
            main.run(['--mode','demo','--task-index','0','--max-tasks','1','--dry-run'])

    def test_task_index_materializes_only_one_requested_input(self):
        import experiments.api as api
        original = api._observations
        options = main._parser().parse_args(['--mode','recompute','--suite','all','--task-index','15659'])
        with patch('experiments.api._observations', wraps=original) as read:
            selected = list(main._select_cases(options))
        self.assertEqual(read.call_count,1)
        self.assertEqual(selected[0]['case_id'],list_case_ids()[-1])

    def test_non_integer_cpu_settings_are_rejected(self):
        for value in (1.5, True, '2'):
            with self.assertRaises(ValueError):
                main._resource_layout(value,1)

    def _resume_fixture(self, folder):
        case = next(iter_cases('baseline', models=('ER',), fit_pipeline='s301'))
        task = folder/'tasks'/case['case_id']
        write_json(task/'case.json',case)
        result=dict(case_id=case['case_id'],fit_theory='ER',profile='paper',result_is_demo=False,
                    run_complete=True,status='COMPLETED',scientific_checks_passed=False, **pipeline_provenance(case))
        write_json(task/'result.json',result)
        write_json(task/'task_receipt.json',dict(case_id=case['case_id'],case_sha256=digest(case),
                    state='FINISHED',profile='paper',engine_status='COMPLETED', **pipeline_provenance(case)))
        plan=dict(signature=dict(mode='recompute',suite='baseline',models=['ER'],max_tasks=1,
                    task_index=None,science_sha256='a'*64,fit_pipeline_requested='s301',
                    fit_pipelines={'baseline':dict(fit_pipeline='s301',fit_pipeline_version='s301-portable-v1')}),
                    state='FINISHED',task_count=1)
        write_json(folder/'run.json',plan)
        return case,task,result

    def test_resume_rejects_false_finished_receipt_without_rewriting_plan(self):
        with tempfile.TemporaryDirectory() as name:
            folder=Path(name)
            case,task,result=self._resume_fixture(folder)
            result['run_complete']=False
            write_json(task/'result.json',result)
            before=(folder/'run.json').read_bytes()
            with patch('main._scientific_source_hash',return_value='a'*64), \
                 patch('main._select_cases',side_effect=lambda options: iter([case])), \
                 patch('main._run_task') as fitting, redirect_stdout(io.StringIO()):
                with self.assertRaises(ValueError):
                    main.run(['--mode','recompute','--suite','baseline','--models','ER','--fit-pipeline','s301',
                              '--max-tasks','1','--resume',str(folder)])
            fitting.assert_not_called()
            self.assertEqual((folder/'run.json').read_bytes(),before)

    def test_verified_resume_does_not_rerun_completed_case(self):
        with tempfile.TemporaryDirectory() as name:
            folder=Path(name)
            case,task,result=self._resume_fixture(folder)
            with patch('main._scientific_source_hash',return_value='a'*64), \
                 patch('main._select_cases',side_effect=lambda options: iter([case])), \
                 patch('main._run_task') as fitting, patch('postprocess.render_run',return_value=[]), \
                 redirect_stdout(io.StringIO()):
                code=main.run(['--mode','recompute','--suite','baseline','--models','ER','--fit-pipeline','s301',
                              '--max-tasks','1','--resume',str(folder)])
            self.assertEqual(code,0)
            fitting.assert_not_called()

    def test_serial_interruption_marks_run_and_does_not_start_next_case(self):
        cases=[{'case_id':'a_ER'},{'case_id':'a_RN'}]
        original_handler=signal.getsignal(signal.SIGINT)
        with tempfile.TemporaryDirectory() as name:
            output=Path(name)/'interrupted'
            with patch('main._select_cases',side_effect=lambda options: iter(cases)), \
                 patch('main._run_task',side_effect=KeyboardInterrupt) as fitting, \
                 patch('postprocess.render_run') as rendering, redirect_stdout(io.StringIO()):
                code=main.run(['--mode','demo','--fit-pipeline','s301','--workers','1',
                              '--cores-per-fit','1','--max-tasks','2','--output',str(output)])
            self.assertEqual(code,130)
            self.assertEqual(fitting.call_count,1)
            rendering.assert_not_called()
            self.assertEqual(json.loads((output/'run.json').read_text())['state'],'INTERRUPTED')
        self.assertIs(signal.getsignal(signal.SIGINT),original_handler)
        self.assertIsNone(main._STOP_EVENT)

    def test_parallel_interruption_broadcasts_stop_and_never_starts_third_task(self):
        cases=[{'case_id':name} for name in ('first_ER','second_ER','third_ER')]
        finished=threading.Event()
        with tempfile.TemporaryDirectory() as name:
            output=Path(name)/'interrupted'
            def trigger():
                deadline=time.monotonic()+15
                while not finished.wait(.05):
                    if len(list((output/'tasks').glob('*/started')))>=2 or time.monotonic()>deadline:
                        _thread.interrupt_main()
                        return
            watcher=threading.Thread(target=trigger,daemon=True)
            started=time.monotonic()
            watcher.start()
            try:
                with patch('main._select_cases',side_effect=lambda options: iter(cases)), \
                     patch('main._run_task',controlled_task), patch('main._resource_layout',return_value=2), \
                     patch('postprocess.render_run') as rendering, redirect_stdout(io.StringIO()):
                    code=main.run(['--mode','demo','--fit-pipeline','s301','--max-tasks','3','--workers','2','--output',str(output)])
            finally:
                finished.set(); watcher.join(2)
            self.assertEqual(code,130)
            self.assertLess(time.monotonic()-started,12)
            self.assertFalse((output/'tasks'/'third_ER').exists())
            self.assertEqual(len(list((output/'tasks').glob('*/started'))),2)
            rendering.assert_not_called()
            self.assertEqual(json.loads((output/'run.json').read_text())['state'],'INTERRUPTED')

    def _check_parallel_failure(self, pool, wait_for_batch):
        cases = [{'case_id':name} for name in ('first_ER','second_ER','third_ER')]
        original_handler = signal.getsignal(signal.SIGINT)
        original_event = main._STOP_EVENT
        with tempfile.TemporaryDirectory() as name:
            output = Path(name)/'failed'
            with patch('main._select_cases', side_effect=lambda options: iter(cases)), \
                 patch('main._resource_layout', return_value=2), \
                 patch('main._scientific_source_hash', return_value='a'*64), \
                 patch('main.ProcessPoolExecutor', return_value=pool), \
                 patch('main.wait', side_effect=wait_for_batch), \
                 patch('postprocess.render_run') as rendering, redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(RuntimeError, 'Controlled'):
                    main.run(['--mode','demo','--fit-pipeline','s301','--workers','2',
                              '--max-tasks','3','--output',str(output)])
            self.assertEqual(json.loads((output/'run.json').read_text())['state'], 'FAILED')
            rendering.assert_not_called()
        self.assertIs(pool.stopped_on_exit, True)
        self.assertIs(signal.getsignal(signal.SIGINT), original_handler)
        self.assertIs(main._STOP_EVENT, original_event)

    def test_completed_batch_failure_prevents_dispatch_after_earlier_success(self):
        pool = ControlledExecutor()
        def finished_batch(active, **kwargs):
            pool.futures[0].set_result(dict(case_id='first_ER', state='FINISHED'))
            pool.futures[1].set_exception(RuntimeError('Controlled failed future'))
            # Inspect the success first to catch dispatch inside the result loop.
            return list(pool.futures), set()
        self._check_parallel_failure(pool, finished_batch)
        self.assertEqual(len(pool.futures), 2)

    def test_submit_failure_cancels_admitted_future_before_pool_exit(self):
        pool = ControlledExecutor(fail_submit=1)
        self._check_parallel_failure(pool, AssertionError('No batch should be awaited'))
        self.assertEqual(len(pool.futures), 1)
        self.assertTrue(pool.futures[0].cancelled())


if __name__=='__main__':
    unittest.main()
