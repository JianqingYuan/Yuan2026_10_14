"""Isolated original-recovery contracts; every physical/optimizer call is mocked."""
from copy import deepcopy
from dataclasses import asdict, replace
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True


def fixture(variant='baseline', noisy=True, profile='demo', factor=1.):
    bounds = dict(M=[.9, 1.1], q=[0., 1.], rho0=[29.8, 30.2],
        drho_dt0=[-.003, .003], phi0=[.19, .21], dphi_dt0=[.003, .005])
    common = dict(times=[0., 1., 2., 3.], residual_sigma=1., bounds=bounds,
        metadata=dict(suite=variant, add_noise=noisy))
    return dict(variant=variant, template=variant+('_noisy' if noisy else '_noiseless'),
        profile=profile, budget_factor=factor,
        cases={name:dict(deepcopy(common), fit_theory=name) for name in ('ER','RN')})


def normalized(value):
    return json.loads(json.dumps(value, default=lambda item:item.tolist(), allow_nan=False))


def child(action):
    sys.path.insert(0, str(ROOT))
    import numpy as np
    from engine import _legacy_worker as worker
    from engine.legacy import verify_legacy_vendor
    variant = 'extreme' if action == 'extreme' else 'baseline'
    worker.bootstrap(variant)
    import workflow.integration_recovery as recovery
    from workflow import study
    from spherical_geodesics.astrometry.optimization import FitCandidate
    from spherical_geodesics.astrometry.parameters import resolve_theory_bounds

    if action == 'manifest':
        manifest = verify_legacy_vendor()
        for name, pin in manifest['files'].items():
            assert hashlib.sha256((ROOT/'vendor/legacy'/name).read_bytes()).hexdigest() == pin
        for variant_name in ('baseline','extreme'):
            for suffix in ('noisy','noiseless'):
                name = f'configs/{variant_name}_{suffix}.json'
                document = json.loads((ROOT/'vendor/legacy'/name).read_text(encoding='utf-8'))
                assert document['profile']['integration_recovery_config']['max_levels'] == 1
        return dict(physical_calls=0, manifest_members=len(manifest['files']))

    if action in ('baseline','extreme','paper','settings','budget'):
        for noisy in (False, True):
            for factor in (1., 2., 4.):
                payload = fixture(variant, noisy, 'paper' if action == 'paper' else 'demo', factor)
                if action == 'settings':
                    for case in payload['cases'].values():
                        case['nominal_integration'] = dict(max_step=8., relative_tolerance=1e-8,
                            absolute_tolerance=1e-10, method='DOP853', inner_stop_radius=None,
                            outer_stop_radius=None)
                        case['tight_integration'] = dict(case['nominal_integration'],
                            max_step=2., relative_tolerance=1e-11, absolute_tolerance=1e-13)
                # Older pure callers omit variant; the frozen template already
                # identifies baseline/extreme and must preserve that contract.
                if factor == 2.:
                    payload.pop('variant')
                before = deepcopy(payload)
                profile, template = worker.build_profile(payload)
                raw = template['profile']
                assert payload == before
                expected_level = 0 if variant == 'extreme' and payload['profile'] == 'demo' else 1
                assert profile.integration_recovery_config.max_levels == expected_level
                expected_local = raw['integration_recovery_config']['local_max_nfev'] if action == 'paper' else 3
                assert profile.integration_recovery_config.local_max_nfev == min(int(expected_local*factor),750)
                assert profile.integration_check_tolerance == raw['integration_check_tolerance'] == .01
                assert normalized(asdict(profile.certification_config)) == raw['certification_config']
                assert profile.theory_parameter_bounds == {n:payload['cases'][n]['bounds'] for n in ('ER','RN')}
                for src,dst in (('nominal_integration','nominal_settings'),('tight_integration','tight_settings')):
                    assert normalized(asdict(getattr(profile,dst))) == payload['cases']['ER'].get(src,raw[dst])
                assert profile.integration_recovery_config.verification_step_factor == .5
                assert profile.integration_recovery_config.verification_tolerance_factor == .1
                if action != 'paper':
                    assert profile.local_config.max_nfev == int(3*factor)
                    assert profile.global_config.runs == 2
                    assert profile.global_config.maxiter == int(factor)-1
        return dict(physical_calls=0, profile_cases=6)

    payload = fixture()
    profile,_ = worker.build_profile(payload)
    theta = np.asarray([1.,.4,30.,0.,.2,.004])
    bounds = resolve_theory_bounds('ER',payload['cases']['ER']['bounds'])
    rows = [study._jsonable(study._candidate_record(FitCandidate(bounds.normalize(theta),theta,4.,
        f'original-de-{index}',run_index=index,success=True,message='old success',nfev=5,njev=4,
        optimality=0.))) for index in range(2)]
    results = {name:dict(best_theta=theta.tolist(),best_z=bounds.normalize(theta).tolist(),
        chi2_min=4.,best_source='original-de-0',global_candidates=deepcopy(rows),
        screening_candidates=[],local_candidates=deepcopy(rows),elapsed_seconds=9.,
        fit_objective=recovery._objective(profile.nominal_settings,0),
        integration_check=dict(within_tolerance=name=='ER',nominal_saved_within_tolerance=True),
        diagnostics=dict(workflow_complete=True,degrees_of_freedom=196,
            certification_status='REPEATABLE_SOLUTION',local_successful_candidates=2))
        for name in ('ER','RN')}
    if action == 'integrity':
        results['RN']['integration_check']['nominal_saved_within_tolerance'] = False
    if action == 'disabled':
        profile = replace(profile,integration_recovery_config=replace(profile.integration_recovery_config,max_levels=0))
    if action == 'not_needed':
        results['RN']['integration_check']['within_tolerance'] = True
    original = deepcopy(results)
    state = {}
    data = SimpleNamespace(times=np.arange(4.),x_obs=np.zeros(4),y_obs=np.zeros(4),
        sigma_x=np.ones(4),sigma_y=np.ones(4),n_components=8)
    local_calls=[]
    def model_function(name,record,configured,settings,observed):
        assert observed is data and configured is profile
        assert settings.max_step <= profile.tight_settings.max_step
        if action == 'interrupted' and name == 'RN':
            raise TimeoutError('mock shared deadline')
        return lambda point:np.asarray([1.,0.]*4)
    def fake_local(function,passed_bounds,seeds,components,config,source_prefix):
        assert passed_bounds is bounds and components == 8
        assert config.max_nfev == 3 and config.jacobian == '3-point'
        assert source_prefix == 'integration-recovery'
        assert seeds[0].success is False and seeds[0].optimality is None
        assert results == original, 'Partial paired adoption is forbidden'
        local_calls.append((seeds[0].source,seeds[0].run_index))
        new = () if action == 'no_success' else (replace(seeds[0],success=True,
            message='new mocked success',nfev=1,njev=1,optimality=0.),)
        return SimpleNamespace(candidates=new,total_evaluations=0,invalid_evaluations=0)
    with patch.object(study,'_bounds_from_fit_record',return_value=bounds), \
         patch.object(recovery,'_model_function',side_effect=model_function), \
         patch.object(recovery,'run_least_squares',side_effect=fake_local), \
         patch.object(recovery,'TheoryForwardModel',side_effect=AssertionError('No physical model')), \
         patch.object(recovery,'residual',side_effect=AssertionError('No physical residual')):
        if action == 'interrupted':
            try:recovery.complete_integration_recovery(data,profile,results,state=state)
            except TimeoutError:pass
            else:raise AssertionError('Expected mock interruption')
            assert results == original and not state['adopted'] and not state['complete']
            return dict(physical_calls=0, partial_pair_adopted=False)
        recovery.complete_integration_recovery(data,profile,results,state=state)
    if action in ('integrity','disabled','not_needed'):
        assert not state['adopted'] and not local_calls
        assert state['outcome'] == ('not_needed' if action == 'not_needed' else 'refused')
    else:
        assert state['adopted'] and state['complete'] and recovery.shared_objective(results)
        assert state['original_models'] == original
        assert {tuple(value) for value in local_calls} == {('original-de-0',0),('original-de-1',1)}
        assert len(local_calls) == 4
        for name,record in results.items():
            assert record['fit_objective']['level'] == 1
            assert record['integration_check']['tolerance'] == .01
            assert record['integration_check']['within_tolerance'] is True
            assert record['integration_check']['nominal_settings'] == asdict(profile.tight_settings)
            assert record['integration_check']['tight_settings']['max_step'] == profile.tight_settings.max_step*.5
            assert record['pre_recovery_integration_check'] == original[name]['integration_check']
            for field in ('global_candidates','local_candidates'):
                old_rows = [r for r in record[field] if r['message'].startswith('Rescored only')]
                assert len(old_rows) == 2 and all(r['success'] is False for r in old_rows)
            if action == 'no_success':
                assert record['diagnostics']['certification_status'] == 'COMPUTATIONALLY_UNRESOLVED'
                assert record['diagnostics']['local_successful_candidates'] == 0
            else:
                assert record['diagnostics']['local_successful_candidates'] == 2
                assert record['diagnostics']['certification_status'] == 'REPEATABLE_SOLUTION'
    return dict(physical_calls=0, real_optimizer_calls=0, local_mock_calls=len(local_calls),
        outcome=state['outcome'])


class BaselineDemoRecoveryTests(unittest.TestCase):
    def check_child(self,action):
        environment = os.environ.copy()
        environment.update(PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
        completed = subprocess.run([sys.executable,'-B',str(Path(__file__).resolve()),'--child',action],
            capture_output=True,text=True,timeout=30,env=environment,cwd=ROOT)
        self.assertEqual(completed.returncode,0,completed.stderr)
        value = json.loads(completed.stdout)
        self.assertEqual(value['physical_calls'],0)
        return value

    def test_baseline_only_uses_original_optional_recovery(self):self.check_child('baseline')
    def test_extreme_demo_still_disables_recovery(self):self.check_child('extreme')
    def test_paper_configuration_unchanged(self):self.check_child('paper')
    def test_effective_explicit_integration_settings_and_domain_unchanged(self):self.check_child('settings')
    def test_budget_factor_never_changes_scientific_gates(self):self.check_child('budget')
    def test_original_vendor_and_all_templates_are_hash_bound(self):self.check_child('manifest')
    def test_original_native_recovery_adopts_two_models_at_one_objective(self):self.check_child('paired')
    def test_rescoring_cannot_inherit_old_optimizer_success(self):self.check_child('no_success')
    def test_interruption_cannot_adopt_only_one_model(self):self.check_child('interrupted')
    def test_inconsistent_old_saved_score_refuses_recovery(self):self.check_child('integrity')
    def test_disabled_recovery_still_refuses(self):self.check_child('disabled')
    def test_passed_original_pair_does_not_start_recovery(self):self.check_child('not_needed')


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--child':
        print(json.dumps(child(sys.argv[2]),allow_nan=False))
    else:
        unittest.main()
