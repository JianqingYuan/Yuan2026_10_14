"""Manual range collection regressions, with no fitting or geometry integration."""
from contextlib import ExitStack
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import postprocess
from run_state import digest, pair_input_fingerprint, write_json


SCIENCE = 'a' * 64


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def fixture_run(root, name, identities, *, pipeline='s301', task_range=(1, 1),
                declare=True, complete=True):
    """Each identity is (case_id, model, dataset_id); records remain genuine."""
    directory = root / name
    directory.mkdir()
    provenance = dict(fit_pipeline=pipeline, fit_pipeline_requested=pipeline,
                      fit_pipeline_version=pipeline + '-test-v1')
    signature = dict(mode='recompute', science_sha256=SCIENCE,
                     fit_pipeline_requested=pipeline,
                     fit_pipelines={'baseline': dict(fit_pipeline=pipeline,
                                      fit_pipeline_version=provenance['fit_pipeline_version'])})
    plan = dict(signature=signature)
    if declare:
        signature['task_range'] = list(task_range) if task_range is not None else None
        plan['work_unit_selection'] = dict(total=10, selected=len(identities),
            first=1, last=len(identities), model_case_ids=[item[0] for item in identities])
    cases = []
    for identity, model, dataset in identities:
        case = dict(case_id=identity, fit_theory=model, dataset_id=dataset,
                    execution_mode='paper', times=[0., 1.], xy_true=[[30., 0.], [30., .1]],
                    residual_sigma=1., metadata=dict(suite='baseline', dataset_id=dataset,
                                                    add_noise=False), **provenance)
        cases.append(case)
    by_dataset = {}
    for case in cases:
        by_dataset.setdefault(case['dataset_id'], {})[case['fit_theory']] = case
    for case in cases:
        identity = case['case_id']
        result = dict(case_id=identity, fit_theory=case['fit_theory'], profile='paper',
            result_is_demo=False, run_complete=complete,
            status='COMPLETED' if complete else 'INCOMPLETE_OR_BUDGET_LIMIT',
            theta=[1., .1, 30., 0., .2, .004], chi2=1.,
            best_candidate_checks_passed=True, scientific_checks_passed=False, **provenance)
        receipt = dict(case_id=identity, case_sha256=digest(case), profile='paper',
            state='FINISHED' if complete else 'INCOMPLETE', engine_status=result['status'],
            scientific_checks_passed=False, **provenance)
        if pipeline == 'legacy':
            models = by_dataset[case['dataset_id']]
            pair_hash = pair_input_fingerprint(models['ER'], models['RN'])
            result['pair_input_sha256'] = receipt['pair_input_sha256'] = pair_hash
        for filename, record in (('case.json', case), ('result.json', result),
                                 ('task_receipt.json', receipt)):
            write_json(directory / 'tasks' / identity / filename, record)
    write_json(directory / 'run.json', plan)
    return directory


class RangeCollectionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.stack = ExitStack()
        self.stack.enter_context(patch('main._scientific_source_hash', return_value=SCIENCE))
        self.render = self.stack.enter_context(patch('postprocess.render_run', return_value=[]))

    def tearDown(self):
        self.stack.close()
        self.temp.cleanup()

    def collect(self, inputs):
        output = self.root / 'collection'
        output.mkdir()
        postprocess.collect_runs(inputs, output)
        return output

    def rejected(self, inputs, message):
        output = self.root / 'rejected'
        output.mkdir()
        with self.assertRaisesRegex(ValueError, message):
            postprocess.collect_runs(inputs, output)
        self.assertEqual(list(output.iterdir()), [])
        self.render.assert_not_called()

    def test_different_ranges_merge_exact_results_without_science_relabelling(self):
        a = fixture_run(self.root, 'a', [('a_ER', 'ER', 'a')], task_range=(1, 1))
        b = fixture_run(self.root, 'b', [('b_RN', 'RN', 'b')], task_range=(2, 2))
        output = self.collect([a, b])
        self.assertEqual(read(output / 'run.json')['model_tasks'], 2)
        self.assertEqual(read(output / 'run.json')['fit_calls'], 0)
        self.assertFalse(read(output / 'tasks/a_ER/result.json')['scientific_checks_passed'])
        self.render.assert_called_once_with(output, mode='recompute')

    def test_missing_declared_result_cannot_be_filled_by_another_run(self):
        a = fixture_run(self.root, 'a', [('a_ER', 'ER', 'a'), ('a_RN', 'RN', 'a')])
        b = fixture_run(self.root, 'b', [('a_RN', 'RN', 'a')])
        shutil.rmtree(a / 'tasks/a_RN')
        self.rejected([a, b], '1 missing, 0 extra')

    def test_extra_result_is_rejected(self):
        a = fixture_run(self.root, 'a', [('a_ER', 'ER', 'a'), ('a_RN', 'RN', 'a')])
        plan = read(a / 'run.json')
        plan['work_unit_selection']['model_case_ids'] = ['a_ER']
        write_json(a / 'run.json', plan)
        self.rejected([a], '0 missing, 1 extra')

    def test_duplicate_declared_identity_is_rejected(self):
        a = fixture_run(self.root, 'a', [('a_ER', 'ER', 'a')])
        plan = read(a / 'run.json')
        plan['work_unit_selection']['model_case_ids'] = ['a_ER', 'a_ER']
        write_json(a / 'run.json', plan)
        self.rejected([a], 'unique model_case_ids')

    def test_range_without_declared_ids_is_rejected(self):
        a = fixture_run(self.root, 'a', [('a_ER', 'ER', 'a')])
        plan = read(a / 'run.json')
        del plan['work_unit_selection']
        write_json(a / 'run.json', plan)
        self.rejected([a], 'lacks its declared')

    def test_old_signature_without_range_metadata_remains_compatible(self):
        a = fixture_run(self.root, 'a', [('a_ER', 'ER', 'a')], declare=False)
        self.assertEqual(read(self.collect([a]) / 'run.json')['model_tasks'], 1)

    def test_full_declared_legacy_pair_is_atomic(self):
        a = fixture_run(self.root, 'a', [('a_ER', 'ER', 'a'), ('a_RN', 'RN', 'a')],
                        pipeline='legacy')
        self.assertEqual(read(self.collect([a]) / 'run.json')['model_tasks'], 2)

    def test_split_legacy_pair_rejected_even_if_union_would_be_complete(self):
        a = fixture_run(self.root, 'a', [('a_ER', 'ER', 'a'), ('a_RN', 'RN', 'a')],
                        pipeline='legacy')
        b = self.root / 'b'
        shutil.copytree(a, b)
        for directory, keep, remove in ((a, 'a_ER', 'a_RN'), (b, 'a_RN', 'a_ER')):
            shutil.rmtree(directory / 'tasks' / remove)
            plan = read(directory / 'run.json')
            plan['work_unit_selection']['model_case_ids'] = [keep]
            write_json(directory / 'run.json', plan)
        self.rejected([a, b], 'cannot split a legacy pair')

    def test_declared_incomplete_result_is_retained_as_incomplete(self):
        a = fixture_run(self.root, 'a', [('a_ER', 'ER', 'a')], complete=False)
        output = self.collect([a])
        self.assertFalse(read(output / 'tasks/a_ER/result.json')['run_complete'])
        self.assertEqual(read(output / 'tasks/a_ER/task_receipt.json')['state'], 'INCOMPLETE')


class CollectionGeometryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.stack = ExitStack()
        self.rows = [dict(case=dict(case_id=identity, fit_theory='ER', fit_pipeline='s301',
                        fit_pipeline_requested='s301', fit_pipeline_version='s301-test-v1'),
                        metadata=dict(suite='baseline'), result=dict(scientific_checks_passed=False),
                        available=True, eligible=True) for identity in ('a', 'b')]
        write_json(self.root / 'run.json', dict(mode='collection', source_science_sha256=SCIENCE))
        self.stack.enter_context(patch('main._scientific_source_hash', return_value=SCIENCE))
        self.stack.enter_context(patch('experiments.api.list_case_ids', return_value=['a', 'b']))
        self.stack.enter_context(patch('postprocess._load', return_value=self.rows))
        self.stack.enter_context(patch('postprocess._summary', return_value=self.root / 'summary.pdf'))
        self.stack.enter_context(patch('postprocess._paired', return_value=[]))
        self.baseline = self.stack.enter_context(patch('postprocess._baseline_cache', return_value=list(range(6, 12))))
        self.stack.enter_context(patch('postprocess._extreme_cache', return_value=[12]))
        self.stack.enter_context(patch('postprocess._s301_cache', return_value=[13]))
        self.render = self.stack.enter_context(patch('plotting.paper.render_all', return_value=[]))
        self.geometry = self.stack.enter_context(patch('plotting.geometry_data.recompute_geometry',
                                                      side_effect=self.fake_geometry))

    @staticmethod
    def fake_geometry(directory, figure_ids):
        from plotting.paper import FIGURES
        for index in figure_ids:
            (directory / FIGURES[index][1]).write_bytes(('new geometry ' + str(index)).encode())

    def tearDown(self):
        self.stack.close()
        self.temp.cleanup()

    def test_complete_collection_computes_geometry_once_and_renders_all_13(self):
        postprocess.render_run(self.root)
        postprocess.render_run(self.root)
        self.geometry.assert_called_once_with(self.root / 'plot_data', figure_ids=list(range(1, 6)))
        self.assertEqual(self.render.call_args.kwargs['figure_ids'], list(range(1, 14)))
        self.assertEqual(self.render.call_args.kwargs['data_dir'], self.root / 'plot_data')
        status = read(self.root / 'plot_status.json')
        self.assertEqual(status['paper_layout_figures_generated'], list(range(1, 14)))
        self.assertFalse(status['original_paper_snapshot_used'])
        self.assertIn('not a claim', status['note'])

    def test_partial_collection_does_not_compute_geometry(self):
        self.rows.pop()
        postprocess.render_run(self.root)
        self.geometry.assert_not_called()
        self.assertEqual(self.render.call_args.kwargs['figure_ids'], list(range(6, 14)))

    def test_noneligible_endpoint_prevents_geometry(self):
        self.rows[0]['eligible'] = False
        postprocess.render_run(self.root)
        self.geometry.assert_not_called()

    def test_incomplete_statistical_grid_prevents_geometry(self):
        self.baseline.return_value = [6, 7, 8, 9]
        postprocess.render_run(self.root)
        self.geometry.assert_not_called()

    def test_regular_recompute_does_not_get_collection_geometry(self):
        write_json(self.root / 'run.json', dict(signature=dict(mode='recompute', task_range=[1, 2])))
        postprocess.render_run(self.root)
        self.geometry.assert_not_called()

    def test_full_collection_with_wrong_code_hash_is_rejected(self):
        write_json(self.root / 'run.json', dict(mode='collection', source_science_sha256='b' * 64))
        with self.assertRaisesRegex(ValueError, 'fingerprint differs'):
            postprocess.render_run(self.root)
        self.geometry.assert_not_called()

    def test_changed_geometry_cache_is_not_silently_reused(self):
        postprocess.render_run(self.root)
        (self.root / 'plot_data/geometry.npz').write_bytes(b'changed cache')
        postprocess.render_run(self.root)
        self.assertEqual(self.geometry.call_count, 2)


if __name__ == '__main__':
    unittest.main()
