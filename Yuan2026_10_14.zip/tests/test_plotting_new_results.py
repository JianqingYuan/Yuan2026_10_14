"""New campaigns must retain signed differences and genuine zero results."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from plotting import _plots
from plotting.paper import DEFAULT_DATA, _read_npz, _extreme, _noiseless, _noisy, render_all


class NewResultPlotTests(unittest.TestCase):
    def tearDown(self):
        plt.close('all')

    def test_original_extreme_panels_keep_log_scale(self):
        core = _extreme(_read_npz(DEFAULT_DATA/'extreme.npz'))
        fig = _plots.extreme(core)
        self.assertEqual([ax.get_yscale() for ax in fig.axes], ['log']*4)

    def test_extreme_signed_and_zero_points_retained(self):
        core = _extreme(_read_npz(DEFAULT_DATA/'extreme.npz'))
        tag = core['pairs'][0]['q_label']
        rows = [r for r in core['pairs'] if r['q_label'] == tag]
        rows[0]['delta_chi2'], rows[1]['delta_chi2'] = -123.5, 0.
        fig = _plots.extreme(core)
        index = 2 if tag == 'eq26' else 3
        ax = fig.axes[index]
        self.assertEqual(ax.get_yscale(), 'symlog')
        plotted = np.concatenate([np.asarray(c.get_offsets())[:, 1] for c in ax.collections])
        self.assertEqual(plotted.size, 640)
        np.testing.assert_array_equal(np.sort(plotted), np.sort([r['delta_chi2'] for r in rows]))
        self.assertTrue(any('nonpositive values retained' in t.get_text() for t in ax.texts))

    def test_s301_expands_both_shared_axes_without_altering_values(self):
        rows = json.loads((DEFAULT_DATA/'s301.json').read_text())['rows']
        rows[0]['delta_chi2'], rows[-1]['delta_chi2'] = -250., 300.
        fig = _plots.s301(rows, adaptive_limits=True)
        limits = [ax.get_ylim() for ax in fig.axes]
        self.assertEqual(limits[0], limits[1])
        self.assertLess(limits[0][0], -250.)
        self.assertGreater(limits[0][1], 300.)
        plotted = np.concatenate([np.asarray(c.get_offsets())[:,1] for ax in fig.axes
                                  for c in ax.collections if c.__class__.__name__ == 'PathCollection'])
        self.assertEqual(plotted.size, 48)
        np.testing.assert_array_equal(np.sort(plotted), np.sort([r['delta_chi2'] for r in rows]))
        self.assertTrue(any('range expanded' in t.get_text() for t in fig.texts))

    def test_original_s301_range_and_footer_unchanged(self):
        rows = json.loads((DEFAULT_DATA/'s301.json').read_text())['rows']
        fig = _plots.s301(rows)
        self.assertEqual(fig.axes[0].get_ylim(), (-1.5, 12.))
        self.assertFalse(any('range expanded' in t.get_text() for t in fig.texts))

    def test_alternate_data_enables_adaptive_limits_automatically(self):
        data = json.loads((DEFAULT_DATA/'s301.json').read_text())
        data['rows'][0]['chi2_RN'] += 1000.
        data['rows'][0]['delta_chi2'] += 1000.
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'s301.json').write_text(json.dumps(data))
            files = render_all(root/'out', [13], data_dir=root, dpi=72)
            self.assertTrue(files[0].is_file())

    def test_true_zeros_in_objective_recovery_and_heatmap(self):
        data = _read_npz(DEFAULT_DATA/'fits.npz')
        data['noiseless_chi2'][0,0] = 0.
        data['noiseless_D'][0,0] = 0.
        rows = _noiseless(data)
        objective = _plots.objective(rows)
        self.assertEqual(objective.axes[0].get_yscale(), 'symlog')
        self.assertEqual(float(objective.axes[0].collections[0].get_offsets()[0,1]), 0.)
        heatmap = _plots.residuals(rows)
        values = heatmap.axes[0].images[0].get_array()
        self.assertFalse(np.ma.getmaskarray(values).any())
        self.assertEqual(float(values[0,0]), 0.)
        data['noisy_error'][:] = 0.
        recovery = _plots.recovery(_noisy(data))
        self.assertTrue(all(ax.get_yscale() == 'linear' for ax in recovery.axes))
        self.assertTrue(all(np.all(line.get_ydata() == 0.) for ax in recovery.axes for line in ax.lines))

    def test_all_zero_charge_differences_do_not_fail(self):
        data = _read_npz(DEFAULT_DATA/'fits.npz')
        data['noisy_chi2'][:,1] = data['noisy_chi2'][:,0]
        fig = _plots.differences(_noisy(data))
        self.assertTrue(all(ax.get_ylim() == (-.001, .001) for ax in fig.axes))


if __name__ == '__main__':
    unittest.main()
