Portable targeted-audit endpoint evidence

Run: python verify_attachment.py
No fitting, dynamics imports or network requests. Standard library only.
Four selected S301 pairs and exactly 77 known extreme ER cases are included.
Raw residual triples, original observations/settings/bounds, original source
lineages, historical scores and exact cache row identities are preserved.
The nonvoting T091 ER warm endpoint is included separately. Conditional
branches do not create independent DE sources. Old extreme fitted vectors
are unavailable, not reconstructed from truth; old RN is not revalidated.
This is a selected endpoint bundle, not every failed/exploratory candidate
or a new test of the integrated release. Full campaign audits are bound by
SHA256 in SUMMARY.json; logical paths are relative to that archived campaign.
No default paper snapshot is changed by extraction. Figures/statistics must
be separately authorized and reviewed before replacing publication values.
Parameter order: M,q,rho0,drho_dt0,phi0,dphi_dt0. Residuals are unweighted;
chi2 is the sum of (residual/residual_sigma)^2 at the stated precision.
Acceptance remains finite evidence, not a proof of global optimality.
