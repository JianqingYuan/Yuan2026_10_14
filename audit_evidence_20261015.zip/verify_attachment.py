"""Verify portable saved evidence without fitting, importing models, or network."""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re

LEVELS=('nominal','tight','third')


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))


def verify(root):
    root=Path(root).resolve();manifest=read(root/'MANIFEST.json')
    expected=set(manifest['files'])|{'MANIFEST.json'}
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    assert actual==expected,'Missing or unexpected files'
    for name,item in manifest['files'].items():
        path=(root/name).resolve()
        assert path.is_relative_to(root) and path.is_file()
        assert path.stat().st_size==item['bytes'] and sha(path)==item['sha256'],name
    summary=read(root/'SUMMARY.json');rows=[read(root/p) for p in sorted(manifest['files']) if p.startswith('cases/')]
    assert len(rows)==81 and len({r['dataset_id'] for r in rows})==81
    assert Counter(r['suite'] for r in rows)=={'s301':4,'extreme':77}
    changes={r['dataset_id']:r for r in summary['changes']}
    triple_count=0;models_count=0;cache_ids=set();routes=Counter()
    for row in rows:
        text=json.dumps(row,sort_keys=True)
        assert not re.search(r'[A-Za-z]:[\\/]|/thfs\d?/|/home/|/Users/|password|private_key|known_hosts',text,re.I)
        observation=row['observation'];sigma=observation['residual_sigma'];n=2*len(observation['times'])
        assert sigma>0 and math.isfinite(sigma)
        identity=(row['mapping']['cache_file'],row['mapping']['zero_based_row'])
        assert identity not in cache_ids;cache_ids.add(identity)
        assert changes[row['dataset_id']]['mapping']==row['mapping']
        assert row['mapping']['cache_sha256'] in summary['upstream_artifact_hashes'].values()
        assert row['acceptance_report_sha256'] in summary['upstream_artifact_hashes'].values()
        for model in row['models'].values():
            models_count+=1;points=model['candidates'];bounds=model['original_effective_bounds'];checked={}
            assert len(points)>=2 and len({p['candidate_id'] for p in points})==len(points)
            supporting=[]
            for p in points:
                assert len(p['theta'])==6
                assert all(math.isfinite(x) and lo<=x<=hi for x,lo,hi in zip(p['theta'],bounds['lower'],bounds['upper']))
                assert p['auxiliary_new_DE_votes']==0
                assert p['upstream_file_sha256'] in summary['upstream_artifact_hashes'].values()
                assert p['original_integration']==model['original_integration']
                for level in LEVELS:
                    raw=p['raw_residuals'][level]
                    assert len(raw)==n and all(math.isfinite(x) for x in raw)
                    value=math.fsum((x/sigma)**2 for x in raw)
                    assert math.isclose(value,p['chi2'][level],rel_tol=1e-12,abs_tol=1e-10)
                d=math.sqrt(math.fsum((a-b)**2 for a,b in zip(p['raw_residuals']['tight'],p['raw_residuals']['third'])))
                norm=math.sqrt(math.fsum(x*x for x in p['raw_residuals']['third']))
                scale=(2*norm*d+d*d)/(sigma*sigma)
                assert math.isclose(scale,p['discrepancy_scale'],rel_tol=1e-12,abs_tol=1e-15)
                gate=model['acceptance_rule']
                if row['suite']=='s301':
                    assert gate['kind']=='s301_original_residual_vector'
                    assert gate['nominal_tight_is_diagnostic_only'] is True
                    assert d<=gate['tight_third_vector_ceiling']==observation['precision_vector_ceiling']
                else:
                    assert gate['nominal_tight_absolute_chi2']==gate['declared_tight_third_absolute_chi2']==.01
                    assert abs(p['chi2']['nominal']-p['chi2']['tight'])<=.01
                    assert abs(p['chi2']['tight']-p['chi2']['third'])<=.01
                checked[p['candidate_id']]=p;triple_count+=1
                if p['independent_source_support']:supporting.append(p)
                else:assert p['kind']=='historical_warm_comparison_only'
            assert len(supporting)==2 and len({p['original_lineage'] for p in supporting})==2
            selected=checked[model['retained_candidate_id']]
            assert model['retained_chi2']==selected['chi2']
            if row['suite']=='s301':
                assert selected['chi2']['third']==min(p['chi2']['third'] for p in points)
                for p in supporting:
                    assert abs(p['chi2']['third']-selected['chi2']['third'])<=p['discrepancy_scale']+selected['discrepancy_scale']+1e-8
            else:
                assert selected['chi2']['tight']<=min(p['chi2']['tight'] for p in points)+1e-10
                a,b=supporting
                assert abs(a['chi2']['tight']-b['chi2']['tight'])<=.1
                assert math.sqrt(math.fsum(((x-y)/(hi-lo))**2 for x,y,lo,hi in zip(a['theta'],b['theta'],bounds['lower'],bounds['upper'])))<=.02
        if row['suite']=='s301':
            delta=row['models']['RN']['retained_chi2']['third']-row['models']['ER']['retained_chi2']['third']
        else:
            assert row['historical']['historical_RN_not_revalidated']
            assert row['historical']['RN']['theta'] is None
            assert row['historical']['ER']['theta'] is None
            delta=row['historical']['RN']['chi2_third']-row['models']['ER']['retained_chi2']['third']
            routes[row['changes']['retained_route']]+=1
        assert math.isclose(delta,row['changes']['new_delta'],rel_tol=1e-12,abs_tol=1e-10)
    assert models_count==85 and triple_count==171
    assert routes=={'u_factor_1.0':37,'original_face':40}
    return dict(verified_files=len(expected),case_files=len(rows),model_records=models_count,
                saved_three_precision_points=triple_count,raw_score_checks=triple_count*3,
                no_physical_forward_calls=True,no_new_fits=True)


if __name__=='__main__':
    print(json.dumps(verify(Path(__file__).resolve().parent),indent=2))
